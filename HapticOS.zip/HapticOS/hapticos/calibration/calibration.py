"""Section 14: DEVICE CALIBRATION.

Routines that probe a device for minimum activation amplitude, maximum
usable amplitude, frequency response, latency, per-actuator variation and
thermal behaviour, producing a `CalibrationProfile` that can be persisted
per device and later used to tighten a `DeviceCapabilities`/`SafetyLimits`
pairing.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pydantic import BaseModel, Field

from hapticos.core.device import HapticDevice


class CalibrationProfile(BaseModel):
    device_id: str
    min_activation_amplitude: float = 0.0
    max_safe_amplitude: float = 1.0
    frequency_response: dict[str, float] = Field(default_factory=dict)  # freq(Hz str) -> measured gain
    measured_latency_s: float = 0.0
    actuator_variation_pct: float = 0.0
    thermal_time_constant_s: float = 30.0

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.model_dump_json(indent=2))

    @classmethod
    def load(cls, path: str | Path) -> "CalibrationProfile":
        return cls.model_validate_json(Path(path).read_text())


class CalibrationEngine:
    """Runs each routine against a `HapticDevice`; all measurements come
    from the device's own driver/state, so a `SimulatedDriver` yields a
    fully deterministic calibration for CI, while a real driver yields a
    genuine (if noisy) measurement."""

    def __init__(self, device: HapticDevice) -> None:
        self.device = device

    def measure_min_activation(self, start: float = 0.01, step: float = 0.01, max_amp: float = 1.0) -> float:
        """Sweep amplitude upward until the device reports itself active."""
        amp = start
        while amp <= max_amp:
            self.device.play(amplitude=amp, duration=0.01, frequency=150.0)
            if self.device.state.is_active:
                return amp
            amp += step
        return max_amp

    def measure_max_amplitude(self) -> float:
        """The device's configured ceiling (post-safety-clamped)."""
        return min(self.device.capabilities.max_amplitude, self.device.safety.limits.max_amplitude)

    def measure_frequency_response(self, frequencies_hz: list[float]) -> dict[str, float]:
        """For each test frequency, drive briefly and record the resulting
        reported amplitude as a proxy "gain" (1.0 == device reproduces the
        drive amplitude faithfully)."""
        response = {}
        for f in frequencies_hz:
            sig = self.device.play(frequency=f, amplitude=0.5, duration=0.01)
            achieved = float(np.max(np.abs(sig))) if sig.size else 0.0
            response[str(f)] = achieved / 0.5 if achieved else 0.0
        return response

    def measure_latency(self, trials: int = 5) -> float:
        from hapticos.latency.engine import LatencyEngine

        engine = LatencyEngine()
        results = [engine.measure_round_trip(self.device) for _ in range(trials)]
        return float(np.mean([r.end_to_end_s for r in results]))

    def measure_actuator_variation(self, siblings: list[HapticDevice]) -> float:
        """Percentage spread in reported amplitude across a set of
        nominally-identical actuators driven the same way — useful for
        multi-actuator arrays (Section 7) where consistency matters."""
        if not siblings:
            return 0.0
        readings = []
        for dev in siblings:
            dev.play(frequency=150.0, amplitude=0.5, duration=0.01)
            readings.append(dev.state.amplitude)
        readings_arr = np.array(readings)
        mean = readings_arr.mean() or 1e-9
        return float((readings_arr.std() / mean) * 100.0)

    def measure_thermal_behavior(self, drive_seconds: float = 0.5, steps: int = 5) -> float:
        """Repeatedly drive the device and fit a simple exponential
        time-constant to the temperature rise (deterministic under
        `SimulatedDriver`)."""
        temps = []
        step_dur = drive_seconds / steps
        for _ in range(steps):
            self.device.play(frequency=150.0, amplitude=1.0, duration=min(step_dur, self.device.capabilities.max_duration_s))
            temps.append(self.device.state.temperature_c)
        temps_arr = np.array(temps)
        if len(temps_arr) < 2 or np.allclose(temps_arr, temps_arr[0]):
            return 30.0
        # crude time-constant estimate: time to reach ~63% of total rise
        rise = temps_arr - temps_arr[0]
        target = 0.63 * rise[-1]
        idx = int(np.argmax(rise >= target)) if target != 0 else len(rise) - 1
        return float((idx + 1) * step_dur)

    def run_full_calibration(self) -> CalibrationProfile:
        return CalibrationProfile(
            device_id=self.device.device_id,
            min_activation_amplitude=self.measure_min_activation(),
            max_safe_amplitude=self.measure_max_amplitude(),
            frequency_response=self.measure_frequency_response([50, 150, 250, 400]),
            measured_latency_s=self.measure_latency(),
            thermal_time_constant_s=self.measure_thermal_behavior(),
        )
