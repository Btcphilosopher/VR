"""Section 10: HAPTIC COMPOSER.

Combines primitive patterns/profiles into richer composites, e.g.::

    IMPACT + ROUGH_TEXTURE + LOW_FREQUENCY_PULSE = MATERIAL_CONTACT

and manages a library of reusable `.haptic` profiles on disk.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from hapticos.composer.profile import HapticProfile


class HapticComposer:
    """Combines rendered signals or `HapticProfile`s and manages a profile
    library directory of `.haptic` files."""

    def __init__(self, library_dir: str | Path | None = None) -> None:
        self.library_dir = Path(library_dir) if library_dir else None
        self._profiles: dict[str, HapticProfile] = {}
        if self.library_dir and self.library_dir.exists():
            for f in self.library_dir.glob("*.haptic"):
                profile = HapticProfile.load(f)
                self._profiles[profile.name] = profile

    # -- library management ------------------------------------------------
    def register(self, profile: HapticProfile) -> None:
        self._profiles[profile.name] = profile

    def get(self, name: str) -> HapticProfile:
        if name not in self._profiles:
            raise KeyError(f"no registered profile named {name!r}")
        return self._profiles[name]

    def save_profile(self, profile: HapticProfile) -> Path:
        if not self.library_dir:
            raise RuntimeError("composer has no library_dir configured")
        self.library_dir.mkdir(parents=True, exist_ok=True)
        path = self.library_dir / f"{profile.name}.haptic"
        profile.save(path)
        self.register(profile)
        return path

    def list_profiles(self) -> list[str]:
        return sorted(self._profiles.keys())

    # -- combining -----------------------------------------------------
    @staticmethod
    def combine(
        *signals_or_profiles: np.ndarray | HapticProfile,
        weights: list[float] | None = None,
        sample_rate: int = 8000,
        normalize: bool = True,
    ) -> np.ndarray:
        """Sum multiple signals (or profiles, which are rendered first)
        into one composite waveform, e.g.
        ``combine(impact_sig, rough_texture_sig, low_freq_pulse_sig)`` for
        the spec's MATERIAL_CONTACT example. Signals of different lengths
        are zero-padded to the longest one."""
        rendered = []
        for item in signals_or_profiles:
            if isinstance(item, HapticProfile):
                rendered.append(item.render(sample_rate=sample_rate))
            else:
                rendered.append(np.asarray(item, dtype=np.float64))
        if not rendered:
            return np.zeros(0)
        weights = weights or [1.0] * len(rendered)
        if len(weights) != len(rendered):
            raise ValueError("weights must match number of signals")
        n = max(len(s) for s in rendered)
        out = np.zeros(n)
        for sig, w in zip(rendered, weights):
            out[: len(sig)] += w * sig
        if normalize:
            peak = np.max(np.abs(out))
            if peak > 1.0:
                out /= peak
        return out

    def compose_named(
        self, name: str, *component_names: str, weights: list[float] | None = None, sample_rate: int = 8000
    ) -> HapticProfile:
        """Combine named library profiles into a new composite profile,
        rendered and stored as raw-signal extra data (waveform=CUSTOM) so
        it can be replayed without re-resolving its components."""
        from hapticos.core.types import WaveformType

        profiles = [self.get(n) for n in component_names]
        combined = self.combine(*profiles, weights=weights, sample_rate=sample_rate)
        new_profile = HapticProfile(
            name=name,
            waveform=WaveformType.CUSTOM,
            amplitude=float(np.max(np.abs(combined)) if combined.size else 0.0),
            duration=len(combined) / sample_rate,
            extra={"raw_samples": combined.tolist(), "sample_rate": sample_rate},
        )
        self.register(new_profile)
        return new_profile
