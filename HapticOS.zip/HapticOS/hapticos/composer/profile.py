"""Reusable `.haptic` profile format (Section 10).

A `.haptic` file is just JSON (via Pydantic) describing one named haptic
pattern: waveform, frequency, amplitude, duration, envelope, target
actuator and a timing offset — enough for the composer/runtime to render
and dispatch it without any other context.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

import numpy as np
from pydantic import BaseModel, Field

from hapticos.core.types import WaveformType


class HapticProfile(BaseModel):
    name: str
    waveform: WaveformType = WaveformType.SINE
    frequency: float = 150.0
    amplitude: float = 0.7
    duration: float = 0.15
    envelope: Optional[str] = None  # "adsr" | "keyframe:..." | None
    actuator: Optional[str] = None  # target actuator label, resolved by runtime
    timing_offset_ms: float = 0.0
    extra: dict = Field(default_factory=dict)

    def render(self, sample_rate: int = 8000) -> np.ndarray:
        from hapticos.signals.envelope import ADSREnvelope
        from hapticos.signals.generator import SignalGenerator

        if self.waveform == WaveformType.CUSTOM and "raw_samples" in self.extra:
            # A pre-rendered composite (see HapticComposer.compose_named).
            return np.asarray(self.extra["raw_samples"], dtype=np.float64)

        sig = SignalGenerator.generate(
            self.waveform,
            frequency=self.frequency,
            amplitude=self.amplitude,
            duration=self.duration,
            sample_rate=sample_rate,
            **self.extra,
        )
        if self.envelope == "adsr":
            env = ADSREnvelope().render(self.duration, sample_rate)
            sig = SignalGenerator.apply_envelope(sig, env)
        return sig

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.model_dump_json(indent=2))

    @classmethod
    def load(cls, path: str | Path) -> "HapticProfile":
        return cls.model_validate_json(Path(path).read_text())
