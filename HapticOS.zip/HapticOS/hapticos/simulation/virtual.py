"""Section 16: SIMULATION MODE.

The entire engine can run without physical hardware: virtual actuators
(`SimulatedDriver`, already used as `HapticDevice`'s default), virtual
sensors, virtual hands, virtual objects/surfaces, and collision detection
between them, wired into the physics engine to produce haptic signals —
exactly the pipeline:

    Virtual Hand -> Virtual Object -> Virtual Contact -> Haptic Signal
                                                        -> Virtual Actuator
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from hapticos.core.device import HapticDevice
from hapticos.core.types import Vector3
from hapticos.materials.material import Material
from hapticos.physics.contact import ContactResult, HapticPhysicsEngine


@dataclass
class VirtualSensor:
    """A minimal virtual position/velocity sensor for a simulated finger
    or probe."""

    position: Vector3 = field(default_factory=Vector3.zero)
    velocity: Vector3 = field(default_factory=Vector3.zero)

    def move_to(self, position: Vector3, dt_s: float) -> None:
        if dt_s > 0:
            self.velocity = (position - self.position) * (1.0 / dt_s)
        self.position = position


@dataclass
class VirtualSurface:
    """An infinite plane at `height` along `axis` ("x"|"y"|"z"), covered in
    `material`."""

    material: Material
    axis: str = "z"
    height: float = 0.0

    def _coord(self, position: Vector3) -> float:
        return getattr(position, self.axis)

    def penetration(self, position: Vector3) -> float:
        return max(0.0, self.height - self._coord(position))

    def is_touching(self, position: Vector3) -> bool:
        return self._coord(position) <= self.height


@dataclass
class VirtualObject:
    """A simple sphere-shaped virtual object with its own material,
    usable as a graspable/collidable target."""

    center: Vector3
    radius: float
    material: Material

    def penetration(self, position: Vector3) -> float:
        dist = (position - self.center).norm()
        return max(0.0, self.radius - dist)

    def is_touching(self, position: Vector3) -> bool:
        return (position - self.center).norm() <= self.radius


@dataclass
class VirtualHand:
    """A minimal multi-finger virtual hand: named `VirtualSensor`s."""

    fingers: dict[str, VirtualSensor] = field(default_factory=dict)

    @classmethod
    def default(cls) -> "VirtualHand":
        return cls(fingers={name: VirtualSensor() for name in ("thumb", "index", "middle", "palm")})

    def move_finger(self, name: str, position: Vector3, dt_s: float = 0.01) -> None:
        self.fingers[name].move_to(position, dt_s)


class VirtualSimulation:
    """Ties virtual hand + object/surface + physics engine + virtual
    actuator together into the full contact pipeline, so a complete haptic
    interaction can be developed and tested with zero real hardware.
    """

    def __init__(self, sample_rate: int = 8000) -> None:
        self.physics = HapticPhysicsEngine(sample_rate=sample_rate)
        self.objects: list[VirtualObject] = []
        self.surfaces: list[VirtualSurface] = []

    def add_object(self, obj: VirtualObject) -> None:
        self.objects.append(obj)

    def add_surface(self, surface: VirtualSurface) -> None:
        self.surfaces.append(surface)

    def step(
        self, sensor: VirtualSensor, actuator: HapticDevice, duration: float = 0.08
    ) -> ContactResult | None:
        """Advance one simulation step: check the sensor against every
        registered object/surface; on the deepest contact, render and play
        the resulting haptic signal on `actuator`. Returns None if nothing
        is touched."""
        best: tuple[float, Material] | None = None

        for obj in self.objects:
            depth = obj.penetration(sensor.position)
            if depth > 0 and (best is None or depth > best[0]):
                best = (depth, obj.material)
        for surf in self.surfaces:
            depth = surf.penetration(sensor.position)
            if depth > 0 and (best is None or depth > best[0]):
                best = (depth, surf.material)

        if best is None:
            return None

        depth, material = best
        force = float(np.clip(depth * 4.0, 0.0, 1.0))  # crude penetration -> force mapping
        velocity = sensor.velocity.norm()
        result = self.physics.contact(material, force=force, velocity=velocity, duration=duration)
        actuator.driver.send_signal(result.signal, result.sample_rate)
        return result
