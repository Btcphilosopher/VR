"""Section 8: TEMPORAL ENGINE.

Precise, millisecond-addressable haptic timelines, e.g.::

    0 ms      CONTACT
    20 ms     IMPACT
    80 ms     VIBRATION
    400 ms    TEXTURE
    1200 ms   RELEASE

Two execution modes are provided:

  * ``run_virtual()`` — a deterministic virtual clock that just replays
    events in time order with no real sleeping. Used for testing and
    simulation mode, where reproducibility matters more than wall-clock
    accuracy.
  * ``run_realtime()`` — actually schedules callbacks against the wall
    clock (via `time.monotonic`), for real playback.

This split is exactly the seam a future Rust/C++ scheduler would replace:
`run_realtime()` is the timing-critical part; `run_virtual()` and the event
list stay in Python either way.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass(order=True)
class TimelineEvent:
    time_ms: float
    label: str = field(compare=False, default="")
    action: Callable[[], Any] = field(compare=False, default=lambda: None)


@dataclass
class ExecutedEvent:
    scheduled_ms: float
    actual_ms: float
    label: str
    result: Any = None
    error: str | None = None


class HapticTimeline:
    """An ordered list of `(time_ms, action)` pairs."""

    def __init__(self) -> None:
        self._events: list[TimelineEvent] = []

    def schedule(self, time_ms: float, action: Callable[[], Any], label: str = "") -> "HapticTimeline":
        self._events.append(TimelineEvent(time_ms=time_ms, label=label or f"event@{time_ms}ms", action=action))
        return self

    @property
    def events(self) -> list[TimelineEvent]:
        return sorted(self._events, key=lambda e: e.time_ms)

    @property
    def duration_ms(self) -> float:
        if not self._events:
            return 0.0
        return max(e.time_ms for e in self._events)

    def run_virtual(self) -> list[ExecutedEvent]:
        """Deterministic execution: run every action in schedule order,
        reporting `actual_ms == scheduled_ms` (no real timing is used).
        Ideal for CI and simulation mode."""
        results: list[ExecutedEvent] = []
        for event in self.events:
            try:
                result = event.action()
                results.append(ExecutedEvent(event.time_ms, event.time_ms, event.label, result=result))
            except Exception as exc:  # noqa: BLE001 - report, don't crash the timeline
                results.append(ExecutedEvent(event.time_ms, event.time_ms, event.label, error=str(exc)))
        return results

    def run_realtime(self, clock: Callable[[], float] = time.monotonic, sleep=time.sleep) -> list[ExecutedEvent]:
        """Real-time execution: sleeps between events so each action fires
        as close as possible to its scheduled offset from the timeline's
        start. Returns actual fire times for jitter analysis (see
        hapticos/latency)."""
        results: list[ExecutedEvent] = []
        start = clock()
        for event in self.events:
            target = start + event.time_ms / 1000.0
            now = clock()
            if target > now:
                sleep(target - now)
            actual_ms = (clock() - start) * 1000.0
            try:
                result = event.action()
                results.append(ExecutedEvent(event.time_ms, actual_ms, event.label, result=result))
            except Exception as exc:  # noqa: BLE001
                results.append(ExecutedEvent(event.time_ms, actual_ms, event.label, error=str(exc)))
        return results

    def clear(self) -> None:
        self._events.clear()
