"""Section 6: HAPTIC TEXTURE ENGINE.

Procedural tactile textures generated from noise, periodic patterns,
arbitrary procedural functions, or wrapping a recorded signal. Textures can
be rendered either as a function of *time* (for a fixed-position vibration)
or as a function of *scan position* (for surfaces explored by a moving
finger/stylus), matching how real texture perception is velocity-dependent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np


class TextureEngine:
    """Stateless generators for the texture primitives in the spec."""

    @staticmethod
    def generate_noise_texture(
        roughness: float, duration: float, sample_rate: int = 8000, seed: int | None = None
    ) -> np.ndarray:
        """Band-limited noise whose spectral content scales with roughness:
        smooth surfaces -> low-pass-heavy, rough surfaces -> broadband/high
        frequency content."""
        n = max(1, int(round(duration * sample_rate)))
        rng = np.random.default_rng(seed)
        white = rng.uniform(-1.0, 1.0, n)
        roughness = float(np.clip(roughness, 0.0, 1.0))
        if n > 3:
            # Simple one-pole low-pass; cutoff rises with roughness.
            alpha = 0.05 + 0.9 * roughness
            filtered = np.empty(n)
            filtered[0] = white[0]
            for i in range(1, n):
                filtered[i] = alpha * white[i] + (1 - alpha) * filtered[i - 1]
            out = filtered
        else:
            out = white
        peak = np.max(np.abs(out)) or 1.0
        return (out / peak) * roughness

    @staticmethod
    def generate_periodic_texture(
        pattern: str, spatial_frequency: float, duration: float, sample_rate: int = 8000
    ) -> np.ndarray:
        """`pattern` in {"ridged", "smooth", "rough"} — periodic, silent, or
        gated square-wave textures respectively, matching the ASCII examples
        in the spec."""
        n = max(1, int(round(duration * sample_rate)))
        t = np.linspace(0.0, duration, n, endpoint=False)
        if pattern == "smooth":
            return np.zeros(n)
        if pattern == "ridged":
            return np.sign(np.sin(2 * np.pi * spatial_frequency * t))
        if pattern == "rough":
            square = (np.sin(2 * np.pi * spatial_frequency * t) > 0).astype(np.float64)
            noise = np.random.default_rng(0).uniform(0.5, 1.0, n)
            return square * noise
        raise ValueError(f"unknown periodic pattern: {pattern}")

    @staticmethod
    def procedural(
        fn: Callable[[np.ndarray], np.ndarray], duration: float, sample_rate: int = 8000
    ) -> np.ndarray:
        """Wrap an arbitrary user function `f(t) -> amplitude`."""
        n = max(1, int(round(duration * sample_rate)))
        t = np.linspace(0.0, duration, n, endpoint=False)
        return np.asarray(fn(t), dtype=np.float64)

    @staticmethod
    def from_recording(sig: np.ndarray) -> np.ndarray:
        """Treat a previously recorded signal as a reusable texture."""
        return np.asarray(sig, dtype=np.float64)

    @staticmethod
    def render_ascii(texture: np.ndarray, width: int = 40, levels: str = " .:-=+*#%@") -> str:
        """Render a texture array as an ASCII strip, for terminal/dashboard
        preview (mirrors the ROUGH/SMOOTH/RIDGED examples in the spec)."""
        if len(texture) == 0:
            return ""
        idx = np.linspace(0, len(texture) - 1, width).astype(int)
        sampled = np.abs(texture[idx])
        peak = sampled.max() or 1.0
        norm = sampled / peak
        chars = [levels[min(len(levels) - 1, int(v * (len(levels) - 1)))] for v in norm]
        return "".join(chars)


@dataclass
class Texture:
    """A named, reusable texture that can be mapped onto a surface and
    re-rendered at any scan velocity."""

    name: str
    base_signal: np.ndarray
    spatial_frequency_hz: float = 40.0

    def render_for_velocity(self, velocity: float, duration: float, sample_rate: int = 8000) -> np.ndarray:
        """Render the texture as felt when scanned at `velocity` (arbitrary
        units/s). Faster scanning -> higher effective vibration frequency,
        matching how texture perception is rate-dependent in reality."""
        n = max(1, int(round(duration * sample_rate)))
        if len(self.base_signal) == 0:
            return np.zeros(n)
        speed_factor = max(0.05, abs(velocity))
        src_len = max(1, int(n * speed_factor))
        idx = (np.linspace(0, len(self.base_signal) - 1, src_len)).astype(int)
        stretched = self.base_signal[idx]
        out_idx = np.linspace(0, len(stretched) - 1, n).astype(int)
        return stretched[out_idx]
