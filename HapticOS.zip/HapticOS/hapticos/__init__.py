"""HapticOS — a general-purpose Python engine for haptic simulation,
modelling, signal generation and optimisation.

    User / Simulation
          |
    Interaction Model
          |
    Haptic Physics
          |
    Signal Generator
          |
    Device Driver
          |
    Haptic Actuator
          |
    Human Touch
          (loop)

The top-level imports below expose the most commonly used objects; deeper
functionality lives in each subpackage (hapticos.signals, hapticos.physics,
hapticos.materials, hapticos.temporal, hapticos.composer, ...).
"""

from hapticos.core.device import HapticDevice
from hapticos.core.events import EventBus, HapticEvent, HapticEventType
from hapticos.core.types import DeviceCapabilities, DeviceState, DeviceType, Vector3, WaveformType
from hapticos.materials.material import Material, get_material
from hapticos.runtime.engine import HapticRuntime

__version__ = "0.1.0"

__all__ = [
    "HapticDevice",
    "HapticRuntime",
    "EventBus",
    "HapticEvent",
    "HapticEventType",
    "DeviceCapabilities",
    "DeviceState",
    "DeviceType",
    "Vector3",
    "WaveformType",
    "Material",
    "get_material",
    "__version__",
]
