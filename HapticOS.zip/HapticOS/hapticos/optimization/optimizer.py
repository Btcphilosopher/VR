"""Section 13: HAPTIC OPTIMISATION.

Optimise a pattern's (frequency, amplitude, duration) triple against a
weighted objective, e.g.::

    OBJECTIVE
    MAXIMISE: perceptual distinction
    MINIMISE: energy, duration, actuator stress

subject to device capability bounds (Section 14 calibration profiles can
tighten these further).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize

from hapticos.core.types import DeviceCapabilities
from hapticos.signals.generator import SignalGenerator
from hapticos.core.types import WaveformType


@dataclass
class OptimizationObjective:
    """Relative weights for each optimisation term. All terms are combined
    into a single scalar cost that `scipy.optimize.minimize` drives down;
    "maximise perceptual distinction" is implemented as minimising its
    negative."""

    maximize_perceptual_distinction: float = 1.0
    minimize_energy: float = 0.3
    minimize_duration: float = 0.2
    minimize_actuator_stress: float = 0.3


@dataclass
class OptimizationResult:
    frequency: float
    amplitude: float
    duration: float
    cost: float
    signal: np.ndarray


class HapticOptimizer:
    def __init__(self, capabilities: DeviceCapabilities, sample_rate: int | None = None) -> None:
        self.capabilities = capabilities
        self.sample_rate = sample_rate or capabilities.sample_rate_hz

    def _perceptual_distinction(self, sig: np.ndarray, baseline: np.ndarray) -> float:
        """Higher = more distinguishable from a neutral/baseline signal.
        Proxied by normalised RMS energy difference + spectral centroid
        separation (cheap perceptual proxies, not a validated psychoacoustic
        model)."""
        from hapticos.signals.analysis import SignalAnalyzer

        rms_delta = abs(SignalAnalyzer.rms(sig) - SignalAnalyzer.rms(baseline))
        spec_a = SignalAnalyzer.fft(sig, self.sample_rate)
        spec_b = SignalAnalyzer.fft(baseline, self.sample_rate)
        centroid_a = self._spectral_centroid(spec_a.frequencies, spec_a.magnitude)
        centroid_b = self._spectral_centroid(spec_b.frequencies, spec_b.magnitude)
        centroid_delta = abs(centroid_a - centroid_b) / max(self.capabilities.max_frequency_hz, 1.0)
        return rms_delta + centroid_delta

    @staticmethod
    def _spectral_centroid(freqs: np.ndarray, mag: np.ndarray) -> float:
        total = np.sum(mag)
        if total < 1e-12:
            return 0.0
        return float(np.sum(freqs * mag) / total)

    @staticmethod
    def _energy(sig: np.ndarray, duration: float) -> float:
        return float(np.sum(sig**2) * duration / max(len(sig), 1))

    def optimize(
        self,
        objective: OptimizationObjective,
        waveform: WaveformType = WaveformType.SINE,
        initial: tuple[float, float, float] | None = None,
    ) -> OptimizationResult:
        cap = self.capabilities
        f0, a0, d0 = initial or (
            (cap.min_frequency_hz + cap.max_frequency_hz) / 2,
            (cap.min_amplitude + cap.max_amplitude) / 2,
            min(0.15, cap.max_duration_s),
        )
        baseline = SignalGenerator.generate(
            waveform, frequency=cap.min_frequency_hz or 1.0, amplitude=cap.min_amplitude or 0.01,
            duration=d0, sample_rate=self.sample_rate,
        )

        bounds = [
            (cap.min_frequency_hz, cap.max_frequency_hz),
            (cap.min_amplitude, cap.max_amplitude),
            (1.0 / self.sample_rate, cap.max_duration_s),
        ]

        def cost_fn(x: np.ndarray) -> float:
            freq, amp, dur = x
            sig = SignalGenerator.generate(
                waveform, frequency=freq, amplitude=amp, duration=dur, sample_rate=self.sample_rate
            )
            distinction = self._perceptual_distinction(sig, baseline)
            energy = self._energy(sig, dur)
            stress = amp * (freq / max(cap.max_frequency_hz, 1.0))  # crude actuator-stress proxy
            cost = (
                -objective.maximize_perceptual_distinction * distinction
                + objective.minimize_energy * energy
                + objective.minimize_duration * dur
                + objective.minimize_actuator_stress * stress
            )
            return float(cost)

        result = minimize(cost_fn, x0=np.array([f0, a0, d0]), bounds=bounds, method="L-BFGS-B")
        freq, amp, dur = result.x
        signal = SignalGenerator.generate(
            waveform, frequency=freq, amplitude=amp, duration=dur, sample_rate=self.sample_rate
        )
        return OptimizationResult(
            frequency=float(freq), amplitude=float(amp), duration=float(dur),
            cost=float(result.fun), signal=signal,
        )
