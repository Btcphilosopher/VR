"""Section 17 (external API) + 18 (dashboard): FastAPI/WebSocket interface.

Exposes the `HapticRuntime` over HTTP + WebSocket so external applications
(a browser dashboard, a game engine, a remote control app) can drive
HapticOS without embedding Python. Runs entirely against simulated devices
by default, so `uvicorn hapticos.api.server:app` works with zero hardware.
"""

from __future__ import annotations

import asyncio
import time
from contextlib import asynccontextmanager
from pathlib import Path

import numpy as np
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

from hapticos.api.schemas import ContactRequest, DeviceStateResponse, DeviceSummary, EventRequest, PlayRequest, PlayResponse
from hapticos.core.device import HapticDevice
from hapticos.core.events import HapticEvent, HapticEventType
from hapticos.materials.material import get_material
from hapticos.runtime.engine import HapticRuntime
from hapticos.safety.limits import SafetyViolation

_PROFILE_LIBRARY_DIR = Path(__file__).resolve().parents[2] / "profiles"
runtime = HapticRuntime(library_dir=str(_PROFILE_LIBRARY_DIR) if _PROFILE_LIBRARY_DIR.exists() else None)

_STATIC_DIR = Path(__file__).parent / "static"


def _ensure_default_device() -> HapticDevice:
    if "controller_01" not in runtime.devices:
        device = HapticDevice("controller_01")
        device.connect()
        runtime.register_device(device)
    return runtime.devices["controller_01"]


@asynccontextmanager
async def _lifespan(_: FastAPI):
    _ensure_default_device()
    yield


app = FastAPI(title="HapticOS", description="Haptic simulation & control engine API", lifespan=_lifespan)


@app.get("/", response_class=HTMLResponse)
async def dashboard() -> str:
    dashboard_path = _STATIC_DIR / "dashboard.html"
    if dashboard_path.exists():
        return dashboard_path.read_text()
    return "<h1>HapticOS</h1><p>Dashboard asset missing.</p>"


@app.get("/api/devices", response_model=list[DeviceSummary])
async def list_devices() -> list[DeviceSummary]:
    return [
        DeviceSummary(
            device_id=d.device_id,
            device_type=d.capabilities.device_type.value,
            connected=d.is_connected,
        )
        for d in runtime.devices.values()
    ]


@app.post("/api/devices/{device_id}/connect")
async def connect_device(device_id: str) -> dict:
    if device_id not in runtime.devices:
        runtime.register_device(HapticDevice(device_id))
    runtime.devices[device_id].connect()
    return {"device_id": device_id, "connected": True}


@app.get("/api/devices/{device_id}/state", response_model=DeviceStateResponse)
async def device_state(device_id: str) -> DeviceStateResponse:
    device = _get_device_or_404(device_id)
    return DeviceStateResponse(**device.state.model_dump())


@app.post("/api/devices/{device_id}/play", response_model=PlayResponse)
async def play(device_id: str, req: PlayRequest) -> PlayResponse:
    device = _get_device_or_404(device_id)
    try:
        signal = device.play(
            frequency=req.frequency, amplitude=req.amplitude, duration=req.duration, waveform=req.waveform
        )
    except SafetyViolation as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return PlayResponse(
        device_id=device_id,
        samples=len(signal),
        sample_rate=device.capabilities.sample_rate_hz,
        peak_amplitude=float(np.max(np.abs(signal))) if signal.size else 0.0,
    )


@app.post("/api/devices/{device_id}/stop")
async def stop(device_id: str) -> dict:
    device = _get_device_or_404(device_id)
    device.stop()
    return {"device_id": device_id, "stopped": True}


@app.post("/api/devices/{device_id}/emergency_stop")
async def emergency_stop(device_id: str) -> dict:
    device = _get_device_or_404(device_id)
    device.emergency_stop()
    return {"device_id": device_id, "emergency_stopped": True}


@app.post("/api/devices/{device_id}/contact", response_model=PlayResponse)
async def contact(device_id: str, req: ContactRequest) -> PlayResponse:
    device = _get_device_or_404(device_id)
    try:
        material = get_material(req.material)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    result = runtime.contact(device_id, material, force=req.force, velocity=req.velocity)
    return PlayResponse(
        device_id=device_id,
        samples=len(result.signal),
        sample_rate=result.sample_rate,
        peak_amplitude=float(np.max(np.abs(result.signal))) if result.signal.size else 0.0,
    )


@app.post("/api/events")
async def send_event(req: EventRequest) -> dict:
    try:
        event_type = HapticEventType(req.type)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"unknown event type: {req.type}") from exc
    _get_device_or_404(req.device_id)
    signal = runtime.dispatch_event(HapticEvent(type=event_type, payload=req.payload), req.device_id)
    return {"dispatched": True, "played": signal is not None}


def _get_device_or_404(device_id: str) -> HapticDevice:
    if device_id not in runtime.devices:
        raise HTTPException(status_code=404, detail=f"unknown device: {device_id}")
    return runtime.devices[device_id]


@app.websocket("/ws/stream")
async def stream(websocket: WebSocket) -> None:
    """Streams live telemetry for every registered device at ~20Hz, for the
    dashboard's waveform/latency/status widgets."""
    await websocket.accept()
    try:
        while True:
            payload = {
                "timestamp": time.time(),
                "devices": {
                    device_id: device.state.model_dump(mode="json")
                    for device_id, device in runtime.devices.items()
                },
            }
            await websocket.send_json(payload)
            await asyncio.sleep(0.05)
    except WebSocketDisconnect:
        return


def run(host: str = "127.0.0.1", port: int = 8000) -> None:
    """Entry point for `hapticos-server` (see pyproject.toml)."""
    import uvicorn

    uvicorn.run("hapticos.api.server:app", host=host, port=port, reload=False)


if __name__ == "__main__":
    run()
