"""Pydantic request/response schemas for the FastAPI layer."""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel

from hapticos.core.types import DeviceState, WaveformType


class PlayRequest(BaseModel):
    frequency: float = 150.0
    amplitude: float = 0.7
    duration: float = 0.2
    waveform: WaveformType = WaveformType.SINE


class PlayResponse(BaseModel):
    device_id: str
    samples: int
    sample_rate: int
    peak_amplitude: float


class ContactRequest(BaseModel):
    material: str
    force: float = 0.7
    velocity: float = 0.0


class DeviceStateResponse(DeviceState):
    pass


class DeviceSummary(BaseModel):
    device_id: str
    device_type: str
    connected: bool


class EventRequest(BaseModel):
    type: str
    payload: dict = {}
    device_id: str
