"""HAPTIC RUNTIME — the top-level orchestrator described in the final
architecture diagram:

                     HAPTICOS
                         |
              +----------+----------+
              v          v          v
           PHYSICS     SIGNALS    EVENTS
              |          |          |
              +----------+----------+
                         v
                  HAPTIC RUNTIME
                         v
              +----------+----------+
              v          v          v
           VIBRATION    FORCE    TEXTURE
              |          |          |
              +----------+----------+
                         v
                     ACTUATORS
                         v
                       HUMAN

`HapticRuntime` wires together the device registry, event bus + mapper,
physics engine, composer/profile library and safety layer, and is the
object the FastAPI layer (hapticos/api) drives.
"""

from __future__ import annotations

import numpy as np

from hapticos.composer.composer import HapticComposer
from hapticos.core.device import HapticDevice
from hapticos.core.events import EventBus, EventMapper, HapticEvent, HapticEventType
from hapticos.materials.material import Material
from hapticos.physics.contact import HapticPhysicsEngine
from hapticos.safety.limits import SafetyViolation


class HapticRuntime:
    def __init__(self, library_dir: str | None = None) -> None:
        self.devices: dict[str, HapticDevice] = {}
        self.events = EventBus()
        self.event_mapper = EventMapper()
        self.composer = HapticComposer(library_dir)
        self.physics = HapticPhysicsEngine()
        self.events.subscribe_all(self._on_event)

    # -- device registry -------------------------------------------------
    def register_device(self, device: HapticDevice) -> None:
        self.devices[device.device_id] = device

    def get_device(self, device_id: str) -> HapticDevice:
        if device_id not in self.devices:
            raise KeyError(f"no device registered with id {device_id!r}")
        return self.devices[device_id]

    # -- event-driven playback -------------------------------------------
    def dispatch_event(self, event: HapticEvent, device_id: str) -> np.ndarray | None:
        """Publish an application event and, if it maps to a known profile,
        immediately render + play it on `device_id`. Returns the rendered
        signal, or None if unmapped/failed safety."""
        self.events.publish(event)
        profile_name = self.event_mapper.resolve(event.type)
        if profile_name is None:
            return None
        try:
            profile = self.composer.get(profile_name)
        except KeyError:
            return None
        return self.play_profile(profile.name, device_id)

    def play_profile(self, profile_name: str, device_id: str):
        profile = self.composer.get(profile_name)
        device = self.get_device(device_id)
        try:
            return device.play(
                frequency=profile.frequency,
                amplitude=profile.amplitude,
                duration=profile.duration,
                waveform=profile.waveform,
                **profile.extra,
            )
        except SafetyViolation:
            device.stop()
            raise

    def _on_event(self, event: HapticEvent) -> None:
        # Hook point for logging/telemetry/dashboard streaming; kept as a
        # no-op default so subclasses/consumers can override cheaply.
        pass

    # -- material contact convenience ------------------------------------
    def contact(self, device_id: str, material: Material, force: float = 0.7, velocity: float = 0.0):
        device = self.get_device(device_id)
        result = self.physics.contact(material, force=force, velocity=velocity)
        device.driver.send_signal(result.signal, result.sample_rate)
        return result

    def emergency_stop_all(self) -> None:
        for device in self.devices.values():
            device.emergency_stop()
