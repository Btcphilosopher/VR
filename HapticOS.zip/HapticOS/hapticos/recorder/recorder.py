"""Section 11: HAPTIC RECORDER.

Records live device telemetry (position, force, amplitude, frequency,
temperature) into a time series that can be replayed, edited, analysed,
compared and optimised.
"""

from __future__ import annotations

import csv
import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np
from pydantic import BaseModel

from hapticos.core.device import HapticDevice
from hapticos.core.types import Vector3
from hapticos.signals.analysis import SignalAnalyzer


class RecordedSample(BaseModel):
    timestamp: float
    actuator: str
    amplitude: float
    frequency: float
    position: Vector3
    force: Vector3
    temperature_c: float


class HapticRecording(BaseModel):
    device_id: str
    samples: list[RecordedSample] = []

    def to_signal(self) -> np.ndarray:
        """Collapse the recording to an amplitude time-series (approximate
        signal reconstruction from sampled telemetry, not a raw waveform
        capture)."""
        return np.array([s.amplitude for s in self.samples], dtype=np.float64)

    def save_json(self, path: str | Path) -> None:
        Path(path).write_text(self.model_dump_json(indent=2))

    @classmethod
    def load_json(cls, path: str | Path) -> "HapticRecording":
        return cls.model_validate_json(Path(path).read_text())

    def save_csv(self, path: str | Path) -> None:
        with open(path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["timestamp", "actuator", "amplitude", "frequency", "px", "py", "pz", "fx", "fy", "fz", "temperature_c"]
            )
            for s in self.samples:
                writer.writerow(
                    [
                        s.timestamp, s.actuator, s.amplitude, s.frequency,
                        s.position.x, s.position.y, s.position.z,
                        s.force.x, s.force.y, s.force.z, s.temperature_c,
                    ]
                )


class HapticRecorder:
    """Polls a device's state at a fixed sample interval and buffers it."""

    def __init__(self, device: HapticDevice, sample_rate_hz: float = 100.0) -> None:
        self.device = device
        self.sample_rate_hz = sample_rate_hz
        self._recording: HapticRecording | None = None
        self._active = False

    @property
    def is_recording(self) -> bool:
        return self._active

    def start(self) -> None:
        self._recording = HapticRecording(device_id=self.device.device_id)
        self._active = True

    def sample_once(self) -> RecordedSample:
        """Take a single sample from the device's current state (call this
        in your own real-time loop, or use `record_virtual` for
        deterministic simulated capture)."""
        if not self._active or self._recording is None:
            raise RuntimeError("recorder is not active; call start() first")
        state = self.device.state
        sample = RecordedSample(
            timestamp=time.time(),
            actuator=self.device.device_id,
            amplitude=state.amplitude,
            frequency=state.frequency,
            position=state.position,
            force=state.force,
            temperature_c=state.temperature_c,
        )
        self._recording.samples.append(sample)
        return sample

    def record_virtual(self, n_samples: int, dt_s: float = 0.01) -> HapticRecording:
        """Deterministic capture loop for simulation/testing: takes
        `n_samples` samples spaced `dt_s` apart *by label only* (no real
        sleeping), reading the device's current state each time."""
        self.start()
        for i in range(n_samples):
            state = self.device.state
            self._recording.samples.append(
                RecordedSample(
                    timestamp=i * dt_s,
                    actuator=self.device.device_id,
                    amplitude=state.amplitude,
                    frequency=state.frequency,
                    position=state.position,
                    force=state.force,
                    temperature_c=state.temperature_c,
                )
            )
        return self.stop()

    def stop(self) -> HapticRecording:
        self._active = False
        if self._recording is None:
            raise RuntimeError("nothing was recorded")
        return self._recording

    # -- replay / analysis --------------------------------------------
    @staticmethod
    def replay(recording: HapticRecording, device: HapticDevice, sample_rate: int = 8000) -> list[np.ndarray]:
        """Replay each sample as a short pulse at the recorded
        amplitude/frequency (approximate, since telemetry sampling loses
        the original waveform shape)."""
        rendered = []
        for s in recording.samples:
            rendered.append(
                device.play(frequency=max(s.frequency, 1.0), amplitude=s.amplitude, duration=0.02)
            )
        return rendered

    @staticmethod
    def compare(a: HapticRecording, b: HapticRecording) -> dict:
        return SignalAnalyzer.compare(a.to_signal(), b.to_signal())
