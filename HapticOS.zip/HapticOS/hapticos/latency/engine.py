"""Section 15: LATENCY ENGINE.

Measures the pipeline EVENT -> SOFTWARE -> SIGNAL -> DEVICE -> ACTUATOR,
computing end-to-end latency, jitter, scheduling delay and device response
time, plus a simple benchmarking helper.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np

from hapticos.core.device import HapticDevice


@dataclass
class LatencyTrace:
    event_s: float
    software_s: float
    signal_s: float
    device_s: float
    actuator_s: float

    @property
    def end_to_end_s(self) -> float:
        return self.actuator_s - self.event_s

    @property
    def scheduling_delay_s(self) -> float:
        return self.software_s - self.event_s

    @property
    def device_response_s(self) -> float:
        return self.actuator_s - self.device_s


@dataclass
class BenchmarkResult:
    mean_latency_s: float
    jitter_s: float  # standard deviation across trials
    min_latency_s: float
    max_latency_s: float
    n_trials: int
    traces: list[LatencyTrace] = field(default_factory=list)


class LatencyEngine:
    """Measures pipeline stage timestamps around a single `device.play()`
    call using `time.perf_counter()` (wall-clock, real execution — not the
    virtual/deterministic clock used by `HapticTimeline.run_virtual`).
    """

    def __init__(self, clock=time.perf_counter) -> None:
        self._clock = clock

    def measure_round_trip(
        self, device: HapticDevice, frequency: float = 150.0, amplitude: float = 0.5, duration: float = 0.01
    ) -> LatencyTrace:
        t_event = self._clock()
        t_software = self._clock()  # dispatch/validation overhead starts here
        signal = device.play(frequency=frequency, amplitude=amplitude, duration=duration)
        t_signal = self._clock()
        t_device = self._clock()
        # "actuator" timestamp: when the device reports the drive as active.
        state = device.state
        t_actuator = self._clock()
        if not state.is_active and signal.size and np.max(np.abs(signal)) > 1e-6:
            # Device didn't confirm activation in time for this sample; still
            # record the timestamp so callers can see the miss rather than
            # silently mask it.
            pass
        return LatencyTrace(t_event, t_software, t_signal, t_device, t_actuator)

    def benchmark(self, device: HapticDevice, n_trials: int = 50, **play_kwargs) -> BenchmarkResult:
        traces = [self.measure_round_trip(device, **play_kwargs) for _ in range(n_trials)]
        latencies = np.array([t.end_to_end_s for t in traces])
        return BenchmarkResult(
            mean_latency_s=float(latencies.mean()),
            jitter_s=float(latencies.std()),
            min_latency_s=float(latencies.min()),
            max_latency_s=float(latencies.max()),
            n_trials=n_trials,
            traces=traces,
        )
