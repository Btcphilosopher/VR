"""Serial (PySerial) driver for hardware talking a simple binary/ASCII
protocol over UART/USB-serial — typical for Arduino/microcontroller-driven
actuator boards.

Wire protocol (deliberately simple, replace with your board's real one):
each command is a newline-terminated ASCII line::

    "P <freq_hz> <amplitude_0_1>\\n"   -- set continuous parameters
    "S <n_samples> <sample_rate>\\n" followed by `n_samples` little-endian
                                        int16 samples -- send a waveform
    "X\\n"                             -- stop

`pyserial` is an optional dependency: importing this module without it
installed raises a clear error only when a `SerialDriver` is actually
instantiated, not at import time, so the rest of HapticOS works fine
without it.
"""

from __future__ import annotations

import struct
import time
from typing import Optional

import numpy as np

from hapticos.core.types import ConnectionState, DeviceCapabilities, DeviceState
from hapticos.drivers.base import DriverError, HapticDriver

try:
    import serial as _pyserial  # type: ignore
except ImportError:  # pragma: no cover - optional dependency
    _pyserial = None


class SerialDriver(HapticDriver):
    def __init__(
        self,
        device_id: str,
        port: str,
        baudrate: int = 115200,
        capabilities: Optional[DeviceCapabilities] = None,
        timeout: float = 0.5,
    ) -> None:
        if _pyserial is None:  # pragma: no cover - exercised only without pyserial
            raise ImportError(
                "pyserial is required for SerialDriver; install with `pip install pyserial`"
            )
        self.device_id = device_id
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.capabilities = capabilities or DeviceCapabilities()
        self._conn = None
        self._state = DeviceState(device_id=device_id, connection=ConnectionState.DISCONNECTED)

    def connect(self) -> None:
        if self._conn is not None and self._conn.is_open:
            return
        try:
            self._conn = _pyserial.Serial(self.port, self.baudrate, timeout=self.timeout)
            self._state.connection = ConnectionState.CONNECTED
        except Exception as exc:  # noqa: BLE001
            self._state.connection = ConnectionState.ERROR
            raise DriverError(f"failed to open serial port {self.port!r}: {exc}") from exc

    def disconnect(self) -> None:
        if self._conn is not None:
            try:
                self._conn.close()
            finally:
                self._conn = None
        self._state.connection = ConnectionState.DISCONNECTED

    @property
    def is_connected(self) -> bool:
        return self._conn is not None and getattr(self._conn, "is_open", False)

    def _require_connected(self) -> None:
        if not self.is_connected:
            raise DriverError(f"serial device '{self.device_id}' is not connected")

    def send_signal(self, signal: np.ndarray, sample_rate: int) -> None:
        self._require_connected()
        samples = np.clip(signal, -1.0, 1.0)
        int_samples = (samples * 32767).astype("<i2")
        header = f"S {len(int_samples)} {sample_rate}\n".encode("ascii")
        try:
            self._conn.write(header)
            self._conn.write(int_samples.tobytes())
            self._conn.flush()
        except Exception as exc:  # noqa: BLE001
            self._state.connection = ConnectionState.ERROR
            raise DriverError(f"serial write failed: {exc}") from exc
        self._state.amplitude = float(np.max(np.abs(samples))) if samples.size else 0.0
        self._state.is_active = self._state.amplitude > 1e-6

    def set_parameters(self, frequency: float, amplitude: float) -> None:
        self._require_connected()
        cmd = f"P {frequency:.3f} {amplitude:.3f}\n".encode("ascii")
        try:
            self._conn.write(cmd)
            self._conn.flush()
        except Exception as exc:  # noqa: BLE001
            self._state.connection = ConnectionState.ERROR
            raise DriverError(f"serial write failed: {exc}") from exc
        self._state.frequency = frequency
        self._state.amplitude = amplitude
        self._state.is_active = amplitude > 1e-6

    def stop(self) -> None:
        if not self.is_connected:
            return
        try:
            self._conn.write(b"X\n")
            self._conn.flush()
        except Exception:  # noqa: BLE001 - stop must never raise
            pass
        self._state.amplitude = 0.0
        self._state.is_active = False

    def read_state(self) -> DeviceState:
        """Best-effort telemetry read: expects the board to echo a line
        like ``"T <temp_c> <battery_pct>"`` when polled; falls back to the
        last-known software state if nothing is available within timeout.
        """
        state = self._state.model_copy(deep=True)
        if self.is_connected and self._conn.in_waiting:
            try:
                line = self._conn.readline().decode("ascii", errors="ignore").strip()
                parts = line.split()
                if len(parts) == 3 and parts[0] == "T":
                    state.temperature_c = float(parts[1])
                    state.battery_pct = float(parts[2])
            except Exception:  # noqa: BLE001 - telemetry parse failure is non-fatal
                pass
        state.timestamp = time.time()
        return state
