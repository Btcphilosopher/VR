"""Deterministic virtual hardware.

This driver never touches real I/O. It is used for:
  * Simulation Mode (Section 16) — developing haptic applications without
    hardware.
  * CI (Section 20) — deterministic, seedable virtual devices so tests never
    depend on real actuators or wall-clock timing quirks.

Determinism is achieved by driving all "physical" drift (temperature,
battery) off an explicit step counter rather than `time.time()` or an
unseeded RNG.
"""

from __future__ import annotations

import numpy as np

from hapticos.core.types import ConnectionState, DeviceCapabilities, DeviceState, Vector3
from hapticos.drivers.base import DriverError, HapticDriver


class SimulatedDriver(HapticDriver):
    """A fully deterministic in-memory stand-in for a real actuator."""

    def __init__(
        self,
        device_id: str,
        capabilities: DeviceCapabilities | None = None,
        seed: int = 0,
    ) -> None:
        self.device_id = device_id
        self.capabilities = capabilities or DeviceCapabilities()
        self._rng = np.random.default_rng(seed)
        self._connected = False
        self._step = 0
        self._state = DeviceState(device_id=device_id, connection=ConnectionState.DISCONNECTED)
        self._last_signal: np.ndarray | None = None
        self._last_sample_rate: int | None = None

    def connect(self) -> None:
        self._connected = True
        self._state.connection = ConnectionState.CONNECTED
        self._state.battery_pct = 100.0

    def disconnect(self) -> None:
        self._connected = False
        self._state.connection = ConnectionState.DISCONNECTED
        self._state.is_active = False
        self._state.amplitude = 0.0
        self._state.frequency = 0.0

    @property
    def is_connected(self) -> bool:
        return self._connected

    def _require_connected(self) -> None:
        if not self._connected:
            raise DriverError(f"device '{self.device_id}' is not connected")

    def send_signal(self, signal: np.ndarray, sample_rate: int) -> None:
        self._require_connected()
        self._last_signal = np.asarray(signal, dtype=np.float64)
        self._last_sample_rate = sample_rate
        self._step += 1
        peak = float(np.max(np.abs(self._last_signal))) if self._last_signal.size else 0.0
        self._state.amplitude = min(peak, 1.0)
        self._state.is_active = peak > 1e-6
        self._advance_physical_model(peak)

    def set_parameters(self, frequency: float, amplitude: float) -> None:
        self._require_connected()
        self._step += 1
        self._state.frequency = float(frequency)
        self._state.amplitude = float(np.clip(amplitude, 0.0, 1.0))
        self._state.is_active = amplitude > 1e-6
        self._advance_physical_model(amplitude)

    def stop(self) -> None:
        self._state.amplitude = 0.0
        self._state.frequency = 0.0
        self._state.is_active = False

    def read_state(self) -> DeviceState:
        state = self._state.model_copy(deep=True)
        state.timestamp = float(self._step)
        return state

    def _advance_physical_model(self, drive_amplitude: float) -> None:
        """Deterministic thermal/battery drift, purely a function of the
        accumulated drive energy (self._step and amplitude), never wall time.
        """
        heating = 0.05 * abs(drive_amplitude) - 0.01
        self._state.temperature_c = float(np.clip(self._state.temperature_c + heating, 20.0, 85.0))
        if self._state.battery_pct is not None:
            drain = 0.001 * abs(drive_amplitude)
            self._state.battery_pct = float(np.clip(self._state.battery_pct - drain, 0.0, 100.0))

    # -- helpers used by tests / recorder -------------------------------
    def last_signal(self) -> np.ndarray | None:
        return self._last_signal
