"""Audio-output driver — many LRA/voice-coil actuators (and cheap ERM
motors via amplifier) can be driven directly from a sound card channel.
This driver streams a rendered haptic waveform out through PyAudio.

`pyaudio` is optional; instantiating `AudioDriver` without it installed
raises a clear `ImportError` rather than breaking the rest of the package.
"""

from __future__ import annotations

import time
from typing import Optional

import numpy as np

from hapticos.core.types import ConnectionState, DeviceCapabilities, DeviceState
from hapticos.drivers.base import DriverError, HapticDriver

try:
    import pyaudio as _pyaudio  # type: ignore
except ImportError:  # pragma: no cover - optional dependency
    _pyaudio = None


class AudioDriver(HapticDriver):
    """Drives an actuator through a system audio output channel."""

    def __init__(
        self,
        device_id: str,
        output_device_index: Optional[int] = None,
        capabilities: Optional[DeviceCapabilities] = None,
    ) -> None:
        if _pyaudio is None:  # pragma: no cover - exercised only without pyaudio
            raise ImportError("pyaudio is required for AudioDriver; install with `pip install pyaudio`")
        self.device_id = device_id
        self.output_device_index = output_device_index
        self.capabilities = capabilities or DeviceCapabilities()
        self._pa = None
        self._stream = None
        self._state = DeviceState(device_id=device_id, connection=ConnectionState.DISCONNECTED)

    def connect(self) -> None:
        if self._pa is not None:
            return
        try:
            self._pa = _pyaudio.PyAudio()
            self._state.connection = ConnectionState.CONNECTED
        except Exception as exc:  # noqa: BLE001
            self._state.connection = ConnectionState.ERROR
            raise DriverError(f"failed to initialise PyAudio: {exc}") from exc

    def disconnect(self) -> None:
        if self._stream is not None:
            try:
                self._stream.close()
            finally:
                self._stream = None
        if self._pa is not None:
            try:
                self._pa.terminate()
            finally:
                self._pa = None
        self._state.connection = ConnectionState.DISCONNECTED

    @property
    def is_connected(self) -> bool:
        return self._pa is not None

    def send_signal(self, signal: np.ndarray, sample_rate: int) -> None:
        if not self.is_connected:
            raise DriverError(f"audio device '{self.device_id}' is not connected")
        samples = np.clip(signal, -1.0, 1.0).astype(np.float32)
        try:
            stream = self._pa.open(
                format=_pyaudio.paFloat32,
                channels=1,
                rate=sample_rate,
                output=True,
                output_device_index=self.output_device_index,
            )
            stream.write(samples.tobytes())
            stream.stop_stream()
            stream.close()
        except Exception as exc:  # noqa: BLE001
            self._state.connection = ConnectionState.ERROR
            raise DriverError(f"audio playback failed: {exc}") from exc
        self._state.amplitude = float(np.max(np.abs(samples))) if samples.size else 0.0
        self._state.is_active = False  # playback already completed (blocking write)

    def set_parameters(self, frequency: float, amplitude: float) -> None:
        """Continuous drive via a short looping tone; real applications
        should stream via a callback for true continuous output."""
        from hapticos.signals.generator import SignalGenerator

        sig = SignalGenerator.sine(frequency, amplitude, duration=0.05, sample_rate=44100)
        self.send_signal(sig, 44100)
        self._state.frequency = frequency
        self._state.amplitude = amplitude
        self._state.is_active = True

    def stop(self) -> None:
        self._state.amplitude = 0.0
        self._state.is_active = False

    def read_state(self) -> DeviceState:
        state = self._state.model_copy(deep=True)
        state.timestamp = time.time()
        return state
