"""Driver interface separating hardware I/O from the simulation/authoring core.

Every concrete driver (simulated, serial, audio, ...) implements
:class:`HapticDriver`. The rest of HapticOS (physics, signal generation,
composer, runtime) only ever talks to this interface, which is exactly
what lets the timing-critical parts migrate to a Rust/C++ runtime later
without touching the Python modelling layer: a Rust driver would only need
to satisfy the same contract over FFI or a local socket.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import numpy as np

from hapticos.core.types import DeviceCapabilities, DeviceState


class DriverError(RuntimeError):
    """Raised when a driver cannot communicate with its device."""


class HapticDriver(ABC):
    """Abstract hardware/software driver for a single haptic device."""

    device_id: str
    capabilities: DeviceCapabilities

    @abstractmethod
    def connect(self) -> None:
        """Establish communication with the device. Must be idempotent."""

    @abstractmethod
    def disconnect(self) -> None:
        """Tear down communication. Must be safe to call repeatedly."""

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        ...

    @abstractmethod
    def send_signal(self, signal: np.ndarray, sample_rate: int) -> None:
        """Send a pre-rendered waveform (in [-1, 1] or [0, 1]) to the device."""

    @abstractmethod
    def set_parameters(self, frequency: float, amplitude: float) -> None:
        """Drive the device continuously at the given frequency/amplitude."""

    @abstractmethod
    def stop(self) -> None:
        """Immediately silence the actuator (used by safety/emergency stop)."""

    @abstractmethod
    def read_state(self) -> DeviceState:
        """Return the current, live device state."""

    def calibration_ping(self, amplitude: float, duration_s: float = 0.02) -> Optional[float]:
        """Optional hook used by the calibration engine to probe minimum
        activation energy. Default implementation is a no-op returning None;
        real drivers may override to report measured response latency.
        """
        return None
