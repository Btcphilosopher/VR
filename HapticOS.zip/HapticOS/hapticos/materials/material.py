"""Section 3: HAPTIC MATERIAL ENGINE.

Simulated tactile materials with physically-motivated (but deliberately
simplified — see hapticos/physics for the disclaimer) parameters: friction,
stiffness, damping, roughness and compliance, plus a characteristic
vibration signature used to render a contact response.
"""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel, Field

from hapticos.textures.texture import TextureEngine


class Material(BaseModel):
    """A tactile material definition.

    All parameters are normalised to [0, 1] unless noted, so materials
    compose predictably with the physics/force-feedback engines regardless
    of device-specific scaling.
    """

    name: str
    friction: float = Field(0.5, ge=0.0, le=1.0)
    stiffness: float = Field(0.5, ge=0.0, le=1.0)
    damping: float = Field(0.3, ge=0.0, le=1.0)
    roughness: float = Field(0.3, ge=0.0, le=1.0)
    compliance: float = Field(0.5, ge=0.0, le=1.0, description="1 - stiffness-like softness")
    vibration_frequency_hz: float = 150.0

    def contact_response(
        self, force: float, velocity: float = 0.0, duration: float = 0.08, sample_rate: int = 8000
    ) -> np.ndarray:
        """Render the haptic waveform felt when this material is touched
        with the given contact force and scan velocity: an initial impact
        transient (scaled by stiffness) blended with a roughness-driven
        texture (scaled by scan speed), matching the flow described in the
        physics engine section (CONTACT -> +FRICTION -> +TEXTURE -> signal).
        """
        from hapticos.signals.generator import SignalGenerator

        force = float(np.clip(force, 0.0, 1.0))
        impact_amp = force * (0.4 + 0.6 * self.stiffness)
        impact = impact_amp * SignalGenerator.impact(
            carrier_frequency=self.vibration_frequency_hz, sample_rate=sample_rate
        )
        texture_amp = force * self.roughness * (0.3 + 0.7 * min(1.0, abs(velocity)))
        texture = texture_amp * TextureEngine.generate_noise_texture(
            roughness=self.roughness, duration=duration, sample_rate=sample_rate
        )
        n = max(len(impact), len(texture), 1)
        out = np.zeros(n)
        out[: len(impact)] += impact
        out[: len(texture)] += texture
        peak = np.max(np.abs(out))
        if peak > 1.0:
            out /= peak
        return out


# -- Presets (Section 3 examples) -----------------------------------------

MATERIAL_PRESETS: dict[str, Material] = {
    "WOOD": Material(
        name="WOOD", friction=0.55, stiffness=0.75, damping=0.4, roughness=0.45,
        compliance=0.25, vibration_frequency_hz=180,
    ),
    "METAL": Material(
        name="METAL", friction=0.25, stiffness=0.95, damping=0.15, roughness=0.15,
        compliance=0.05, vibration_frequency_hz=320,
    ),
    "GLASS": Material(
        name="GLASS", friction=0.15, stiffness=0.98, damping=0.05, roughness=0.05,
        compliance=0.02, vibration_frequency_hz=420,
    ),
    "RUBBER": Material(
        name="RUBBER", friction=0.85, stiffness=0.3, damping=0.7, roughness=0.35,
        compliance=0.75, vibration_frequency_hz=90,
    ),
    "FABRIC": Material(
        name="FABRIC", friction=0.7, stiffness=0.15, damping=0.6, roughness=0.6,
        compliance=0.8, vibration_frequency_hz=60,
    ),
    "STONE": Material(
        name="STONE", friction=0.6, stiffness=0.9, damping=0.2, roughness=0.7,
        compliance=0.1, vibration_frequency_hz=250,
    ),
    "ICE": Material(
        name="ICE", friction=0.05, stiffness=0.9, damping=0.1, roughness=0.05,
        compliance=0.08, vibration_frequency_hz=380,
    ),
    "SAND": Material(
        name="SAND", friction=0.9, stiffness=0.2, damping=0.5, roughness=0.95,
        compliance=0.6, vibration_frequency_hz=45,
    ),
    "LIQUID": Material(
        name="LIQUID", friction=0.1, stiffness=0.05, damping=0.9, roughness=0.1,
        compliance=0.95, vibration_frequency_hz=30,
    ),
}


def get_material(name: str) -> Material:
    key = name.upper()
    if key not in MATERIAL_PRESETS:
        raise KeyError(f"unknown material preset: {name!r}; available: {list(MATERIAL_PRESETS)}")
    return MATERIAL_PRESETS[key].model_copy()
