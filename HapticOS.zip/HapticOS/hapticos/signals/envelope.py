"""Amplitude envelopes: ADSR and arbitrary keyframe envelopes.

An envelope is a function of time in [0, duration] -> amplitude scale in
[0, 1] (usually), sampled onto a signal produced by
:mod:`hapticos.signals.generator`.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class ADSREnvelope:
    """Classic attack/decay/sustain/release envelope, in seconds."""

    attack_s: float = 0.01
    decay_s: float = 0.02
    sustain_level: float = 0.7
    release_s: float = 0.05

    def render(self, duration_s: float, sample_rate: int) -> np.ndarray:
        n = max(1, int(round(duration_s * sample_rate)))
        t = np.linspace(0.0, duration_s, n, endpoint=False)
        env = np.zeros(n)

        a, d, r = self.attack_s, self.decay_s, self.release_s
        sustain_start = a + d
        release_start = max(sustain_start, duration_s - r)

        attack_mask = t < a
        if a > 0:
            env[attack_mask] = t[attack_mask] / a
        else:
            env[attack_mask] = 1.0

        decay_mask = (t >= a) & (t < sustain_start)
        if d > 0:
            env[decay_mask] = 1.0 - (1.0 - self.sustain_level) * (t[decay_mask] - a) / d
        else:
            env[decay_mask] = self.sustain_level

        sustain_mask = (t >= sustain_start) & (t < release_start)
        env[sustain_mask] = self.sustain_level

        release_mask = t >= release_start
        if r > 0:
            env[release_mask] = self.sustain_level * np.clip(
                1.0 - (t[release_mask] - release_start) / r, 0.0, 1.0
            )
        else:
            env[release_mask] = 0.0

        return np.clip(env, 0.0, 1.0)


@dataclass
class KeyframeEnvelope:
    """Piecewise-linear envelope defined by ``(time_ms, value)`` keyframes.

    This is exactly the shape used in the spec's IMPACT example::

        0 ms   0
        10 ms  1.0
        30 ms  0.7
        80 ms  0.0
    """

    keyframes: list[tuple[float, float]] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.keyframes = sorted(self.keyframes, key=lambda kf: kf[0])

    @property
    def duration_s(self) -> float:
        if not self.keyframes:
            return 0.0
        return self.keyframes[-1][0] / 1000.0

    def render(self, duration_s: float | None = None, sample_rate: int = 8000) -> np.ndarray:
        if not self.keyframes:
            return np.zeros(0)
        dur = duration_s if duration_s is not None else self.duration_s
        n = max(1, int(round(dur * sample_rate)))
        t_ms = np.linspace(0.0, dur * 1000.0, n, endpoint=False)
        xp = np.array([kf[0] for kf in self.keyframes], dtype=np.float64)
        fp = np.array([kf[1] for kf in self.keyframes], dtype=np.float64)
        return np.interp(t_ms, xp, fp, left=fp[0], right=fp[-1])
