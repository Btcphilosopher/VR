"""Section 2: HAPTIC SIGNAL ENGINE.

Pure, stateless waveform generators. Every function returns a 1D
``numpy.ndarray`` sampled at ``sample_rate`` Hz, with values nominally in
``[-1, 1]`` (bipolar, e.g. sine/burst) or ``[0, 1]`` (unipolar envelopes,
e.g. pulse/ramp/impact) so that drivers can decide how to map them onto
real actuator drive signals.
"""

from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np
from scipy import signal as sp_signal

from hapticos.core.types import WaveformType
from hapticos.signals.envelope import KeyframeEnvelope


def _n_samples(duration_s: float, sample_rate: int) -> int:
    return max(1, int(round(duration_s * sample_rate)))


def _time_vector(duration_s: float, sample_rate: int) -> np.ndarray:
    n = _n_samples(duration_s, sample_rate)
    return np.linspace(0.0, duration_s, n, endpoint=False)


class SignalGenerator:
    """Factory for the waveform primitives listed in the spec."""

    @staticmethod
    def sine(
        frequency: float,
        amplitude: float,
        duration: float,
        phase: float = 0.0,
        sample_rate: int = 8000,
    ) -> np.ndarray:
        t = _time_vector(duration, sample_rate)
        return amplitude * np.sin(2 * np.pi * frequency * t + phase)

    @staticmethod
    def continuous(
        frequency: float, amplitude: float, duration: float, sample_rate: int = 8000
    ) -> np.ndarray:
        """Steady-state vibration; identical to `sine` but named separately
        to match the spec's "Continuous vibration" primitive."""
        return SignalGenerator.sine(frequency, amplitude, duration, sample_rate=sample_rate)

    @staticmethod
    def pulse(amplitude: float, duration: float, sample_rate: int = 8000) -> np.ndarray:
        n = _n_samples(duration, sample_rate)
        return np.full(n, amplitude, dtype=np.float64)

    @staticmethod
    def ramp(
        start_amplitude: float,
        end_amplitude: float,
        duration: float,
        sample_rate: int = 8000,
    ) -> np.ndarray:
        n = _n_samples(duration, sample_rate)
        return np.linspace(start_amplitude, end_amplitude, n)

    @staticmethod
    def burst(
        frequency: float,
        amplitude: float,
        cycles: int,
        sample_rate: int = 8000,
    ) -> np.ndarray:
        """`cycles` full periods of a sine wave, i.e. a gated tone burst."""
        duration = cycles / max(frequency, 1e-9)
        return SignalGenerator.sine(frequency, amplitude, duration, sample_rate=sample_rate)

    @staticmethod
    def click(amplitude: float = 1.0, duration: float = 0.003, sample_rate: int = 8000) -> np.ndarray:
        """A very short, sharply-decaying transient — a "detent" or button click."""
        t = _time_vector(duration, sample_rate)
        tau = duration / 4.0
        # cos (not sin) so the very first sample starts at full amplitude
        # before decaying, matching a real click/detent transient.
        return amplitude * np.exp(-t / max(tau, 1e-9)) * np.sign(np.cos(2 * np.pi * 250 * t))

    @staticmethod
    def sweep(
        f0: float,
        f1: float,
        amplitude: float,
        duration: float,
        sample_rate: int = 8000,
        method: str = "linear",
    ) -> np.ndarray:
        """A frequency sweep (chirp) from f0 to f1 over `duration` seconds."""
        t = _time_vector(duration, sample_rate)
        return amplitude * sp_signal.chirp(t, f0=f0, f1=f1, t1=max(duration, 1e-9), method=method)

    @staticmethod
    def impact(
        keyframes: Sequence[tuple[float, float]] | None = None,
        sample_rate: int = 8000,
        carrier_frequency: float | None = 250.0,
    ) -> np.ndarray:
        """Render the spec's IMPACT profile: a keyframe envelope, optionally
        modulating a carrier tone (so it can drive an LRA/voice-coil rather
        than only a DC-coupled actuator)::

            IMPACT
             0 ms   0
            10 ms   1.0
            30 ms   0.7
            80 ms   0.0
        """
        kf = keyframes or [(0, 0.0), (10, 1.0), (30, 0.7), (80, 0.0)]
        env = KeyframeEnvelope(list(kf))
        envelope = env.render(sample_rate=sample_rate)
        if carrier_frequency is None:
            return envelope
        t = np.arange(len(envelope)) / sample_rate
        carrier = np.sin(2 * np.pi * carrier_frequency * t)
        return envelope * carrier

    @staticmethod
    def apply_duty_cycle(
        signal_arr: np.ndarray, duty_cycle: float, period_samples: int
    ) -> np.ndarray:
        """Gate a signal on/off with the given duty cycle (0-1) and period."""
        if period_samples <= 0:
            return signal_arr
        idx = np.arange(len(signal_arr)) % period_samples
        on_samples = int(round(period_samples * np.clip(duty_cycle, 0.0, 1.0)))
        gate = (idx < on_samples).astype(np.float64)
        return signal_arr * gate

    @staticmethod
    def apply_envelope(signal_arr: np.ndarray, envelope: np.ndarray) -> np.ndarray:
        """Multiply a raw waveform by a (possibly differently-lengthed)
        envelope, resampling the envelope to match via linear interpolation.
        """
        if len(envelope) == len(signal_arr):
            return signal_arr * envelope
        x_old = np.linspace(0, 1, len(envelope)) if len(envelope) > 1 else np.array([0.0])
        x_new = np.linspace(0, 1, len(signal_arr))
        resampled = np.interp(x_new, x_old, envelope)
        return signal_arr * resampled

    @classmethod
    def generate(
        cls,
        waveform: WaveformType,
        frequency: float = 150.0,
        amplitude: float = 1.0,
        duration: float = 0.1,
        phase: float = 0.0,
        sample_rate: int = 8000,
        **kwargs,
    ) -> np.ndarray:
        """Dispatch by :class:`WaveformType`, used by the composer/API layer
        so callers don't need to know each generator's exact signature."""
        if waveform == WaveformType.SINE:
            return cls.sine(frequency, amplitude, duration, phase, sample_rate)
        if waveform == WaveformType.CONTINUOUS:
            return cls.continuous(frequency, amplitude, duration, sample_rate)
        if waveform == WaveformType.PULSE:
            return cls.pulse(amplitude, duration, sample_rate)
        if waveform == WaveformType.RAMP:
            return cls.ramp(kwargs.get("start_amplitude", 0.0), amplitude, duration, sample_rate)
        if waveform == WaveformType.BURST:
            cycles = kwargs.get("cycles", max(1, int(frequency * duration)))
            return cls.burst(frequency, amplitude, cycles, sample_rate)
        if waveform == WaveformType.CLICK:
            return cls.click(amplitude, duration, sample_rate)
        if waveform == WaveformType.SWEEP:
            return cls.sweep(
                kwargs.get("f0", frequency),
                kwargs.get("f1", frequency * 2),
                amplitude,
                duration,
                sample_rate,
            )
        if waveform == WaveformType.IMPACT:
            return amplitude * cls.impact(
                kwargs.get("keyframes"), sample_rate, kwargs.get("carrier_frequency", frequency)
            )
        if waveform == WaveformType.TEXTURE:
            from hapticos.textures.texture import TextureEngine

            return amplitude * TextureEngine.generate_noise_texture(
                roughness=kwargs.get("roughness", 0.5), duration=duration, sample_rate=sample_rate
            )
        raise ValueError(f"unsupported waveform type: {waveform}")
