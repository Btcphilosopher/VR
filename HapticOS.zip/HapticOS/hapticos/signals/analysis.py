"""Section 12: SIGNAL ANALYSIS.

FFT, spectrograms, RMS, peak detection, envelope analysis and signal
comparison — used by the recorder, optimiser and dashboard.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import signal as sp_signal


@dataclass
class SpectrumResult:
    frequencies: np.ndarray
    magnitude: np.ndarray

    def dominant_frequency(self) -> float:
        if len(self.magnitude) == 0:
            return 0.0
        idx = int(np.argmax(self.magnitude))
        return float(self.frequencies[idx])


@dataclass
class SpectrogramResult:
    frequencies: np.ndarray
    times: np.ndarray
    magnitude: np.ndarray  # shape (len(frequencies), len(times))


class SignalAnalyzer:
    @staticmethod
    def fft(sig: np.ndarray, sample_rate: int) -> SpectrumResult:
        sig = np.asarray(sig, dtype=np.float64)
        n = len(sig)
        if n == 0:
            return SpectrumResult(np.array([]), np.array([]))
        windowed = sig * np.hanning(n) if n > 1 else sig
        spectrum = np.fft.rfft(windowed)
        freqs = np.fft.rfftfreq(n, d=1.0 / sample_rate)
        magnitude = np.abs(spectrum) / n
        return SpectrumResult(freqs, magnitude)

    @staticmethod
    def spectrogram(
        sig: np.ndarray, sample_rate: int, nperseg: int = 256
    ) -> SpectrogramResult:
        sig = np.asarray(sig, dtype=np.float64)
        nperseg = min(nperseg, max(8, len(sig)))
        f, t, Sxx = sp_signal.spectrogram(sig, fs=sample_rate, nperseg=nperseg)
        return SpectrogramResult(f, t, Sxx)

    @staticmethod
    def rms(sig: np.ndarray) -> float:
        sig = np.asarray(sig, dtype=np.float64)
        if len(sig) == 0:
            return 0.0
        return float(np.sqrt(np.mean(np.square(sig))))

    @staticmethod
    def peak_detection(
        sig: np.ndarray, sample_rate: int, height: float | None = None, distance: int | None = None
    ) -> np.ndarray:
        """Return peak timestamps (seconds)."""
        sig = np.asarray(sig, dtype=np.float64)
        if len(sig) == 0:
            return np.array([])
        peaks, _ = sp_signal.find_peaks(sig, height=height, distance=distance)
        return peaks / sample_rate

    @staticmethod
    def envelope_analysis(sig: np.ndarray) -> np.ndarray:
        """Amplitude envelope via the analytic signal (Hilbert transform)."""
        sig = np.asarray(sig, dtype=np.float64)
        if len(sig) == 0:
            return np.array([])
        analytic = sp_signal.hilbert(sig)
        return np.abs(analytic)

    @staticmethod
    def compare(sig_a: np.ndarray, sig_b: np.ndarray) -> dict:
        """Compare two (possibly different-length) signals: correlation,
        mean-squared error (after length alignment via resampling) and RMS
        energy difference."""
        a = np.asarray(sig_a, dtype=np.float64)
        b = np.asarray(sig_b, dtype=np.float64)
        if len(a) == 0 or len(b) == 0:
            return {"correlation": 0.0, "mse": float("inf"), "rms_delta": float("inf")}
        n = max(len(a), len(b))
        a_r = np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(a)), a)
        b_r = np.interp(np.linspace(0, 1, n), np.linspace(0, 1, len(b)), b)
        if np.std(a_r) < 1e-12 or np.std(b_r) < 1e-12:
            correlation = 1.0 if np.allclose(a_r, b_r) else 0.0
        else:
            correlation = float(np.corrcoef(a_r, b_r)[0, 1])
        mse = float(np.mean((a_r - b_r) ** 2))
        rms_delta = float(abs(SignalAnalyzer.rms(a_r) - SignalAnalyzer.rms(b_r)))
        return {"correlation": correlation, "mse": mse, "rms_delta": rms_delta}
