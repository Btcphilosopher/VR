"""Section 7: MULTI-ACTUATOR ENGINE.

Groups multiple `HapticDevice` actuators into a spatial hierarchy (e.g. a
hand with a thumb/index/middle/palm) and synchronises signals across them,
including spatial patterns like sweeps/waves across actuators.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from hapticos.core.device import HapticDevice
from hapticos.core.types import WaveformType


@dataclass
class ActuatorGroup:
    """A named collection of actuators, which may themselves be nested
    groups (e.g. `RIGHT_HAND` containing `THUMB`, `INDEX`, ...)."""

    name: str
    devices: dict[str, HapticDevice] = field(default_factory=dict)
    subgroups: dict[str, "ActuatorGroup"] = field(default_factory=dict)

    def add_device(self, label: str, device: HapticDevice) -> None:
        self.devices[label] = device

    def add_subgroup(self, group: "ActuatorGroup") -> None:
        self.subgroups[group.name] = group

    def flatten(self, prefix: str = "") -> dict[str, HapticDevice]:
        """Return {"LEFT_HAND/Thumb": device, ...} for every leaf device."""
        out: dict[str, HapticDevice] = {}
        full_prefix = f"{prefix}{self.name}/" if prefix or self.name else ""
        for label, dev in self.devices.items():
            out[f"{full_prefix}{label}"] = dev
        for sub in self.subgroups.values():
            out.update(sub.flatten(full_prefix))
        return out

    def play_all(
        self,
        frequency: float = 150.0,
        amplitude: float = 0.7,
        duration: float = 0.2,
        waveform: WaveformType | str = WaveformType.SINE,
        **kwargs,
    ) -> dict[str, np.ndarray]:
        """Play the same pattern, synchronised, on every actuator in the
        group (and subgroups)."""
        results = {}
        for label, dev in self.flatten().items():
            results[label] = dev.play(
                frequency=frequency, amplitude=amplitude, duration=duration, waveform=waveform, **kwargs
            )
        return results

    def play_spatial_pattern(
        self,
        order: list[str],
        frequency: float = 150.0,
        amplitude: float = 0.7,
        duration: float = 0.08,
        delay_s: float = 0.03,
        waveform: WaveformType | str = WaveformType.PULSE,
    ) -> dict[str, tuple[float, np.ndarray]]:
        """Render a spatial "wave" pattern: `order` names actuators (by
        flattened label) in the sequence they should fire, each offset by
        `delay_s`. Returns {label: (fire_time_s, signal)} — actual
        scheduling/playback is left to a `HapticTimeline` (Section 8), this
        method only computes signals + offsets so it stays deterministic
        and testable without real-time execution.
        """
        flat = self.flatten()
        out: dict[str, tuple[float, np.ndarray]] = {}
        for i, label in enumerate(order):
            if label not in flat:
                raise KeyError(f"unknown actuator label: {label!r}")
            dev = flat[label]
            sig = dev.play(frequency=frequency, amplitude=amplitude, duration=duration, waveform=waveform)
            out[label] = (i * delay_s, sig)
        return out

    def stop_all(self) -> None:
        for dev in self.flatten().values():
            dev.stop()


def build_hand(hand_name: str, driver_factory=None) -> ActuatorGroup:
    """Convenience constructor matching the spec's example hierarchy::

        LEFT HAND
        ├── Thumb
        ├── Index
        ├── Middle
        └── Palm
    """
    group = ActuatorGroup(name=hand_name)
    for finger in ("Thumb", "Index", "Middle", "Palm"):
        device_id = f"{hand_name}_{finger}"
        driver = driver_factory(device_id) if driver_factory else None
        group.add_device(finger, HapticDevice(device_id, driver=driver))
    return group
