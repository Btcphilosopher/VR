"""Section 5: FORCE-FEEDBACK ENGINE.

Position/velocity-based force models: springs, dampers, virtual walls,
virtual objects, constraints and collision forces, all following

    F = -Kx - Cv

with K = stiffness, x = displacement, C = damping, v = velocity.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Spring:
    stiffness: float  # K
    rest_position: float = 0.0

    def force(self, position: float) -> float:
        return -self.stiffness * (position - self.rest_position)


@dataclass
class Damper:
    damping: float  # C

    def force(self, velocity: float) -> float:
        return -self.damping * velocity


@dataclass
class SpringDamper:
    """Combined spring-damper: F = -Kx - Cv."""

    stiffness: float
    damping: float
    rest_position: float = 0.0

    def force(self, position: float, velocity: float) -> float:
        x = position - self.rest_position
        return -self.stiffness * x - self.damping * velocity


@dataclass
class VirtualWall:
    """A one-sided spring: solid on one side of `surface_position`, free
    space on the other, chosen by `normal`:

      * ``normal=+1`` — free space is ``position <= surface_position``;
        penetrating from below pushes the probe back down (force < 0).
      * ``normal=-1`` — free space is ``position >= surface_position``;
        penetrating from above pushes the probe back up (force > 0).
    """

    surface_position: float
    stiffness: float
    damping: float = 0.0
    normal: int = 1

    def penetration(self, position: float) -> float:
        if self.normal == 1:
            return max(0.0, position - self.surface_position)
        return max(0.0, self.surface_position - position)

    def force(self, position: float, velocity: float) -> float:
        depth = self.penetration(position)
        if depth <= 0:
            return 0.0
        spring_force = self.stiffness * depth
        damp_force = self.damping * velocity
        return -self.normal * spring_force - damp_force


@dataclass
class Constraint:
    """Clamp position to [min_position, max_position], returning a
    restoring force when out of bounds (a simple constraint/limit stop)."""

    min_position: float
    max_position: float
    stiffness: float = 100.0

    def force(self, position: float) -> float:
        if position < self.min_position:
            return self.stiffness * (self.min_position - position)
        if position > self.max_position:
            return self.stiffness * (self.max_position - position)
        return 0.0


@dataclass
class VirtualObject:
    """A simple bounding-sphere virtual object rendering a spring-damper
    restoring force whenever a probe penetrates it."""

    center: float
    radius: float
    stiffness: float = 200.0
    damping: float = 5.0

    def contains(self, position: float) -> bool:
        return abs(position - self.center) < self.radius

    def force(self, position: float, velocity: float) -> float:
        depth = self.radius - abs(position - self.center)
        if depth <= 0:
            return 0.0
        direction = 1.0 if position >= self.center else -1.0
        return direction * (self.stiffness * depth) - self.damping * velocity


class ForceFeedbackEngine:
    """Aggregates multiple force elements (springs, dampers, walls,
    objects, constraints) acting on a single degree of freedom and returns
    the net force, matching the spec's F = -Kx - Cv baseline plus
    collision/constraint terms."""

    def __init__(self) -> None:
        self.springs: list[Spring] = []
        self.dampers: list[Damper] = []
        self.walls: list[VirtualWall] = []
        self.objects: list[VirtualObject] = []
        self.constraints: list[Constraint] = []

    def net_force(self, position: float, velocity: float) -> float:
        total = 0.0
        for s in self.springs:
            total += s.force(position)
        for d in self.dampers:
            total += d.force(velocity)
        for w in self.walls:
            total += w.force(position, velocity)
        for o in self.objects:
            total += o.force(position, velocity)
        for c in self.constraints:
            total += c.force(position)
        return total
