"""Section 4: HAPTIC PHYSICS ENGINE.

Simplified, real-time-friendly models of contact, friction, collision,
pressure, elasticity, vibration and texture:

    Virtual Surface -> Contact Force + Friction + Surface Texture
                     -> Haptic Signal

IMPORTANT: these are simplified simulation models tuned for perceptual
plausibility and real-time performance, not experimentally validated
physical models. Do not use them as a stand-in for measured material
science data in safety-critical or scientific applications — see each
docstring for what is and isn't modelled.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from hapticos.materials.material import Material


@dataclass
class ContactResult:
    normal_force: float
    friction_force: float
    signal: np.ndarray
    sample_rate: int


class HapticPhysicsEngine:
    """Simplified (non-experimentally-validated) contact physics."""

    def __init__(self, sample_rate: int = 8000) -> None:
        self.sample_rate = sample_rate

    def contact(
        self, material: Material, force: float, velocity: float = 0.0, duration: float = 0.08
    ) -> ContactResult:
        """Compute the haptic response of touching `material` with a given
        normal `force` (0-1) and tangential scan `velocity`."""
        friction_force = self.friction(material, force, velocity)
        signal = material.contact_response(force, velocity, duration, self.sample_rate)
        return ContactResult(
            normal_force=force, friction_force=friction_force, signal=signal, sample_rate=self.sample_rate
        )

    @staticmethod
    def friction(material: Material, normal_force: float, velocity: float) -> float:
        """Coulomb friction model: F_friction = mu * F_normal, with a small
        static/kinetic distinction (static friction is ~20% higher, applied
        when velocity is near zero)."""
        mu = material.friction
        if abs(velocity) < 1e-6:
            mu *= 1.2  # static friction bump
        return float(mu * max(0.0, normal_force))

    @staticmethod
    def collision(mass: float, velocity: float, restitution: float = 0.5) -> tuple[float, np.ndarray]:
        """Impulse-based collision: returns (impulse magnitude, impact
        waveform). `restitution` in [0, 1] (0 = inelastic, 1 = perfectly
        elastic) shapes how "sharp" the rendered impact feels."""
        from hapticos.signals.generator import SignalGenerator

        impulse = abs(mass * velocity) * (1.0 + restitution)
        amplitude = float(np.clip(impulse / (impulse + 1.0), 0.0, 1.0))
        carrier = 200.0 + 400.0 * restitution
        waveform = amplitude * SignalGenerator.impact(carrier_frequency=carrier)
        return impulse, waveform

    @staticmethod
    def pressure(force_n: float, area_m2: float) -> float:
        """Simple pressure = force / area (Pa). Guards against div-by-zero."""
        return float(force_n / max(area_m2, 1e-9))

    @staticmethod
    def elasticity(stiffness: float, displacement: float) -> float:
        """Linear (Hookean) restoring force F = -k * x."""
        return float(-stiffness * displacement)

    def vibration_signature(self, material: Material, intensity: float, duration: float) -> np.ndarray:
        """Steady-state vibration a material "hums" at under continuous
        contact (e.g. dragging a finger across it)."""
        from hapticos.signals.generator import SignalGenerator

        return SignalGenerator.sine(
            material.vibration_frequency_hz,
            float(np.clip(intensity, 0.0, 1.0)),
            duration,
            sample_rate=self.sample_rate,
        )
