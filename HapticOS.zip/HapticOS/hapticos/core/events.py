"""Section 9: HAPTIC EVENT SYSTEM.

Application/digital events (a button press, a collision, a UI notification)
are decoupled from *how* they feel. An `EventBus` lets producers publish
`HapticEvent`s and an `EventMapper` routes each event type to a named
`.haptic` profile (see hapticos/composer), which the runtime then plays on
one or more devices.
"""

from __future__ import annotations

import time
from collections import defaultdict
from enum import Enum
from typing import Callable, DefaultDict

from pydantic import BaseModel, Field


class HapticEventType(str, Enum):
    TOUCH = "touch"
    PRESS = "press"
    RELEASE = "release"
    COLLISION = "collision"
    IMPACT = "impact"
    DRAG = "drag"
    SLIDE = "slide"
    GRAB = "grab"
    ROTATE = "rotate"
    ERROR = "error"
    SUCCESS = "success"
    WARNING = "warning"
    NOTIFICATION = "notification"


class HapticEvent(BaseModel):
    type: HapticEventType
    payload: dict = Field(default_factory=dict)
    timestamp: float = Field(default_factory=time.time)
    source: str = "application"


EventHandler = Callable[[HapticEvent], None]


class EventBus:
    """Minimal synchronous publish/subscribe hub for haptic events."""

    def __init__(self) -> None:
        self._subscribers: DefaultDict[HapticEventType, list[EventHandler]] = defaultdict(list)
        self._wildcard_subscribers: list[EventHandler] = []
        self.history: list[HapticEvent] = []

    def subscribe(self, event_type: HapticEventType, handler: EventHandler) -> None:
        self._subscribers[event_type].append(handler)

    def subscribe_all(self, handler: EventHandler) -> None:
        self._wildcard_subscribers.append(handler)

    def publish(self, event: HapticEvent) -> None:
        self.history.append(event)
        for handler in self._subscribers.get(event.type, []):
            handler(event)
        for handler in self._wildcard_subscribers:
            handler(event)


class EventMapper:
    """Maps `HapticEventType` -> profile name(s), so application events can
    be authored once and re-skinned per device/product without touching
    application code.
    """

    def __init__(self) -> None:
        self._map: dict[HapticEventType, str] = {
            HapticEventType.TOUCH: "soft_touch",
            HapticEventType.PRESS: "click",
            HapticEventType.RELEASE: "release_tick",
            HapticEventType.COLLISION: "impact_hard",
            HapticEventType.IMPACT: "impact_hard",
            HapticEventType.DRAG: "texture_drag",
            HapticEventType.SLIDE: "texture_drag",
            HapticEventType.GRAB: "grab_pulse",
            HapticEventType.ROTATE: "detent_ramp",
            HapticEventType.ERROR: "error_buzz",
            HapticEventType.SUCCESS: "success_chime",
            HapticEventType.WARNING: "warning_pulse",
            HapticEventType.NOTIFICATION: "notify_tap",
        }

    def map(self, event_type: HapticEventType, profile_name: str) -> None:
        self._map[event_type] = profile_name

    def resolve(self, event_type: HapticEventType) -> str | None:
        return self._map.get(event_type)
