"""Core data types shared across the HapticOS engine.

These are the vocabulary of the system: vectors, device/actuator state,
capability descriptors and enums. Everything else (physics, signals,
drivers, API) is built on top of these Pydantic models so that state can be
validated, serialised (JSON) and passed across process/network boundaries
(e.g. the FastAPI/WebSocket layer) without extra glue code.
"""

from __future__ import annotations

import math
import time
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class Vector3(BaseModel):
    """A simple 3D vector used for position, velocity and force."""

    model_config = ConfigDict(frozen=False)

    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def __add__(self, other: "Vector3") -> "Vector3":
        return Vector3(x=self.x + other.x, y=self.y + other.y, z=self.z + other.z)

    def __sub__(self, other: "Vector3") -> "Vector3":
        return Vector3(x=self.x - other.x, y=self.y - other.y, z=self.z - other.z)

    def __mul__(self, scalar: float) -> "Vector3":
        return Vector3(x=self.x * scalar, y=self.y * scalar, z=self.z * scalar)

    __rmul__ = __mul__

    def dot(self, other: "Vector3") -> float:
        return self.x * other.x + self.y * other.y + self.z * other.z

    def norm(self) -> float:
        return math.sqrt(self.dot(self))

    def normalized(self) -> "Vector3":
        n = self.norm()
        if n < 1e-12:
            return Vector3()
        return Vector3(x=self.x / n, y=self.y / n, z=self.z / n)

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)

    @classmethod
    def zero(cls) -> "Vector3":
        return cls(x=0.0, y=0.0, z=0.0)


class DeviceType(str, Enum):
    """Supported haptic device categories (Section 1: HAPTIC DEVICE MODEL)."""

    VIBRATION_MOTOR = "vibration_motor"
    LINEAR_RESONANT_ACTUATOR = "linear_resonant_actuator"
    VOICE_COIL_ACTUATOR = "voice_coil_actuator"
    FORCE_FEEDBACK_MOTOR = "force_feedback_motor"
    HAPTIC_GLOVE = "haptic_glove"
    CONTROLLER = "controller"
    STEERING_WHEEL = "steering_wheel"
    JOYSTICK = "joystick"
    WEARABLE = "wearable"
    ROBOTIC_INTERFACE = "robotic_interface"
    CUSTOM_ACTUATOR = "custom_actuator"


class ConnectionState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


class WaveformType(str, Enum):
    SINE = "sine"
    PULSE = "pulse"
    RAMP = "ramp"
    BURST = "burst"
    CLICK = "click"
    TEXTURE = "texture"
    IMPACT = "impact"
    CONTINUOUS = "continuous"
    SWEEP = "sweep"
    CUSTOM = "custom"


class DeviceCapabilities(BaseModel):
    """Static description of what a device can physically do.

    Used by the safety layer, calibration routines and the optimiser to
    bound generated signals to values the hardware can actually reproduce.
    """

    device_type: DeviceType = DeviceType.CUSTOM_ACTUATOR
    min_frequency_hz: float = 0.0
    max_frequency_hz: float = 1000.0
    min_amplitude: float = 0.0
    max_amplitude: float = 1.0
    max_force_n: float = 10.0
    max_duration_s: float = 5.0
    supports_position_sensing: bool = False
    supports_force_feedback: bool = False
    actuator_count: int = 1
    channel_names: list[str] = Field(default_factory=lambda: ["default"])
    sample_rate_hz: int = 8000


class DeviceState(BaseModel):
    """Live, mutable state of a haptic device, as required by the spec:
    position, velocity, force, frequency, amplitude, temperature, battery,
    connection.
    """

    device_id: str
    position: Vector3 = Field(default_factory=Vector3.zero)
    velocity: Vector3 = Field(default_factory=Vector3.zero)
    force: Vector3 = Field(default_factory=Vector3.zero)
    frequency: float = 0.0
    amplitude: float = 0.0
    temperature_c: float = 25.0
    battery_pct: Optional[float] = None
    connection: ConnectionState = ConnectionState.DISCONNECTED
    timestamp: float = Field(default_factory=time.time)
    is_active: bool = False
