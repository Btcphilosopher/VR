"""Section 1 + 17: the generic device abstraction and public play() API.

`HapticDevice` is the main object application code touches:

    device = HapticDevice("controller_01")
    device.play(frequency=150, amplitude=0.7, duration=0.2)

It owns a driver (hardware-specific I/O, see hapticos/drivers) and a
SafetyMonitor (hapticos/safety), and is deliberately hardware-agnostic:
swap the driver and the same `.play()` call drives real hardware, a serial
device, or a fully virtual/simulated actuator.
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from hapticos.core.types import DeviceCapabilities, DeviceState, WaveformType
from hapticos.drivers.base import HapticDriver
from hapticos.drivers.simulated import SimulatedDriver
from hapticos.safety.limits import SafetyLimits, SafetyMonitor
from hapticos.signals.generator import SignalGenerator


class HapticDevice:
    """A generic haptic device: motors, LRAs, voice-coils, gloves,
    controllers, wheels, joysticks, wearables, robotic interfaces or
    fully custom actuators — anything speaking the `HapticDriver`
    interface.
    """

    def __init__(
        self,
        device_id: str,
        driver: Optional[HapticDriver] = None,
        capabilities: Optional[DeviceCapabilities] = None,
        safety_limits: Optional[SafetyLimits] = None,
    ) -> None:
        self.device_id = device_id
        self.capabilities = capabilities or DeviceCapabilities()
        self.driver: HapticDriver = driver or SimulatedDriver(device_id, self.capabilities)
        self.safety = SafetyMonitor(limits=safety_limits or SafetyLimits())

    # -- lifecycle --------------------------------------------------
    def connect(self) -> None:
        self.driver.connect()

    def disconnect(self) -> None:
        self.driver.disconnect()

    @property
    def is_connected(self) -> bool:
        return self.driver.is_connected

    # -- primary API --------------------------------------------------
    def play(
        self,
        frequency: float = 150.0,
        amplitude: float = 0.7,
        duration: float = 0.2,
        waveform: WaveformType | str = WaveformType.SINE,
        phase: float = 0.0,
        force_n: float = 0.0,
        **kwargs,
    ) -> np.ndarray:
        """Render a waveform and send it to the device, after clamping to
        device capabilities and passing safety validation.

        Returns the rendered signal (useful for visualisation/testing).
        """
        if isinstance(waveform, str):
            waveform = WaveformType(waveform)

        amplitude = float(np.clip(amplitude, self.capabilities.min_amplitude, self.capabilities.max_amplitude))
        frequency = float(
            np.clip(frequency, self.capabilities.min_frequency_hz, self.capabilities.max_frequency_hz)
        )
        duration = float(min(duration, self.capabilities.max_duration_s))

        # Safety gate: never send an unvalidated signal to the driver.
        self.safety.validate(amplitude=amplitude, duration_s=duration, force_n=force_n)

        signal_arr = SignalGenerator.generate(
            waveform,
            frequency=frequency,
            amplitude=amplitude,
            duration=duration,
            phase=phase,
            sample_rate=self.capabilities.sample_rate_hz,
            **kwargs,
        )
        self.driver.send_signal(signal_arr, self.capabilities.sample_rate_hz)
        self._check_thermal()
        return signal_arr

    def drive_continuous(self, frequency: float, amplitude: float) -> None:
        """Open-ended continuous drive (e.g. a held trigger rumble). Caller
        is responsible for calling `.stop()`."""
        amplitude = float(np.clip(amplitude, 0.0, self.capabilities.max_amplitude))
        self.safety.validate(amplitude=amplitude, duration_s=0.0)
        self.driver.set_parameters(frequency, amplitude)
        self._check_thermal()

    def stop(self) -> None:
        self.driver.stop()

    def emergency_stop(self) -> None:
        self.safety.emergency_stop()
        self.driver.stop()

    @property
    def state(self) -> DeviceState:
        return self.driver.read_state()

    def _check_thermal(self) -> None:
        try:
            self.safety.report_temperature(self.state.temperature_c)
        except Exception:
            self.driver.stop()
            raise

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"HapticDevice(id={self.device_id!r}, type={self.capabilities.device_type})"
