"""Section 19: SAFETY.

Configurable hard limits enforced *before* any signal reaches a driver, plus
an emergency-stop mechanism and duty-cycle tracking. This module must never
be bypassed by `HapticDevice.play()` — see hapticos/core/device.py.

Important: simulation passing these checks is NOT proof that real hardware
is safe. `SimulatedDriver` never validates thermal/mechanical reality; a
physical actuator can still overheat or exceed force limits in ways this
software model does not capture. Treat `SafetyMonitor` as a necessary floor,
not a substitute for hardware-level protection (fuses, thermal cutoffs,
mechanical stops) on real devices.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass, field

from pydantic import BaseModel, Field


class SafetyLimits(BaseModel):
    """Per-device configurable ceilings."""

    max_amplitude: float = 1.0
    max_duration_s: float = 5.0
    max_temperature_c: float = 60.0
    max_force_n: float = 20.0
    max_duty_cycle: float = 0.8  # fraction of a rolling window allowed "on"
    duty_cycle_window_s: float = 1.0


class SafetyViolation(RuntimeError):
    """Raised when a requested action would exceed a configured limit."""


@dataclass
class _ActivationRecord:
    start: float
    end: float


@dataclass
class SafetyMonitor:
    """Stateful safety gate for one device.

    Call :meth:`validate` before every play/drive command and
    :meth:`report_temperature` whenever fresh telemetry arrives. Any
    violation raises :class:`SafetyViolation`; callers must treat that as
    "do not send this to the driver", not a warning to ignore.
    """

    limits: SafetyLimits = field(default_factory=SafetyLimits)
    _emergency_stopped: bool = field(default=False, init=False)
    _activations: deque[_ActivationRecord] = field(default_factory=deque, init=False)
    _clock: callable = field(default=time.monotonic, init=False, repr=False)

    def emergency_stop(self) -> None:
        self._emergency_stopped = True

    def reset_emergency_stop(self) -> None:
        self._emergency_stopped = False

    @property
    def is_emergency_stopped(self) -> bool:
        return self._emergency_stopped

    def validate(self, amplitude: float, duration_s: float, force_n: float = 0.0) -> None:
        """Raise SafetyViolation if the requested drive is out of bounds."""
        if self._emergency_stopped:
            raise SafetyViolation("emergency stop is engaged")
        if amplitude < 0.0 or amplitude > self.limits.max_amplitude:
            raise SafetyViolation(
                f"amplitude {amplitude} exceeds max_amplitude={self.limits.max_amplitude}"
            )
        if duration_s < 0.0 or duration_s > self.limits.max_duration_s:
            raise SafetyViolation(
                f"duration {duration_s}s exceeds max_duration_s={self.limits.max_duration_s}"
            )
        if abs(force_n) > self.limits.max_force_n:
            raise SafetyViolation(
                f"force {force_n}N exceeds max_force_n={self.limits.max_force_n}"
            )
        self._check_duty_cycle(duration_s)

    def report_temperature(self, temperature_c: float) -> None:
        if temperature_c > self.limits.max_temperature_c:
            self.emergency_stop()
            raise SafetyViolation(
                f"temperature {temperature_c}C exceeds max_temperature_c="
                f"{self.limits.max_temperature_c}; emergency stop engaged"
            )

    def report_invalid_state(self, reason: str) -> None:
        """Called by drivers/runtime when device or sensor state becomes
        invalid (e.g. malformed telemetry, lost connection mid-drive). Fails
        safe by engaging the emergency stop rather than guessing.
        """
        self.emergency_stop()
        raise SafetyViolation(f"invalid device state, failing safe: {reason}")

    def _check_duty_cycle(self, incoming_duration_s: float) -> None:
        now = self._clock()
        window_start = now - self.limits.duty_cycle_window_s
        while self._activations and self._activations[0].end < window_start:
            self._activations.popleft()
        active_time = sum(
            max(0.0, rec.end - max(rec.start, window_start)) for rec in self._activations
        )
        projected = active_time + incoming_duration_s
        if projected > self.limits.duty_cycle_window_s * self.limits.max_duty_cycle:
            raise SafetyViolation(
                f"duty cycle would reach {projected / self.limits.duty_cycle_window_s:.2f}, "
                f"exceeding max_duty_cycle={self.limits.max_duty_cycle}"
            )
        self._activations.append(_ActivationRecord(start=now, end=now + incoming_duration_s))
