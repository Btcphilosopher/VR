"""Section 15 example: EVENT -> SOFTWARE -> SIGNAL -> DEVICE -> ACTUATOR latency."""

from hapticos import HapticDevice
from hapticos.latency.engine import LatencyEngine

device = HapticDevice("controller_01")
device.connect()

engine = LatencyEngine()
result = engine.benchmark(device, n_trials=100, frequency=150, amplitude=0.5, duration=0.005)

print(f"Trials:        {result.n_trials}")
print(f"Mean latency:  {result.mean_latency_s * 1000:.3f} ms")
print(f"Jitter (std):  {result.jitter_s * 1000:.3f} ms")
print(f"Min / Max:     {result.min_latency_s*1000:.3f} / {result.max_latency_s*1000:.3f} ms")

device.disconnect()
