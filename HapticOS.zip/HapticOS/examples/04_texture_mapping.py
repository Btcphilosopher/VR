"""Section 6 example: procedural textures + ASCII preview, as in the spec:

    ROUGH   ████ ░███ ███░ ░███
    SMOOTH  ────────────────────
    RIDGED  /\\/\\/\\/\\/\\/\\/\\/\\/\\/\\
"""

from hapticos.textures.texture import TextureEngine

for label, sig in [
    ("ROUGH", TextureEngine.generate_noise_texture(roughness=0.9, duration=0.2, sample_rate=2000, seed=1)),
    ("SMOOTH", TextureEngine.generate_periodic_texture("smooth", spatial_frequency=1, duration=0.2)),
    ("RIDGED", TextureEngine.generate_periodic_texture("ridged", spatial_frequency=15, duration=0.2, sample_rate=2000)),
]:
    print(f"{label:<8} {TextureEngine.render_ascii(sig, width=40)}")
