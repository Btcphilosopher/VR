"""Section 11 example: record, replay, compare."""

import tempfile
from pathlib import Path

from hapticos import HapticDevice
from hapticos.recorder.recorder import HapticRecorder

device = HapticDevice("controller_01")
device.connect()
device.play(frequency=150, amplitude=0.6, duration=0.05)

recorder = HapticRecorder(device, sample_rate_hz=100)
recording = recorder.record_virtual(n_samples=20, dt_s=0.01)
print(f"Recorded {len(recording.samples)} samples for device {recording.device_id}")

with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "session.json"
    recording.save_json(path)
    reloaded = recording.load_json(path)
    print(f"Round-tripped through {path.name}: {len(reloaded.samples)} samples")

rendered = HapticRecorder.replay(recording, device)
print(f"Replayed {len(rendered)} short pulses onto the device")

# Compare two recordings (e.g. before/after an optimisation pass).
device.play(frequency=150, amplitude=0.6, duration=0.05)
recorder2 = HapticRecorder(device, sample_rate_hz=100)
recording2 = recorder2.record_virtual(n_samples=20, dt_s=0.01)
diff = HapticRecorder.compare(recording, recording2)
print(f"Comparison: correlation={diff['correlation']:.3f}, mse={diff['mse']:.5f}")

device.disconnect()
