"""Section 7 example:

    LEFT HAND
    ├── Thumb
    ├── Index
    ├── Middle
    └── Palm
"""

from hapticos.actuators.array import build_hand
from hapticos.core.types import WaveformType

left_hand = build_hand("LEFT_HAND")
for dev in left_hand.flatten().values():
    dev.connect()

print("Flattened actuators:", list(left_hand.flatten().keys()))

# Fire the same pulse on every actuator simultaneously.
results = left_hand.play_all(frequency=200, amplitude=0.6, duration=0.05, waveform=WaveformType.PULSE)
print(f"Played on {len(results)} actuators")

# A spatial "wave" across the fingers.
pattern = left_hand.play_spatial_pattern(
    order=["LEFT_HAND/Thumb", "LEFT_HAND/Index", "LEFT_HAND/Middle", "LEFT_HAND/Palm"],
    delay_s=0.03,
)
for label, (offset, sig) in pattern.items():
    print(f"{label:<20} fires at +{offset*1000:.0f}ms ({len(sig)} samples)")

left_hand.stop_all()
