"""Section 9 example: application events -> haptic patterns."""

from hapticos import HapticDevice, HapticEvent, HapticEventType
from hapticos.composer.composer import HapticComposer
from hapticos.composer.profile import HapticProfile
from hapticos.core.types import WaveformType
from hapticos.runtime.engine import HapticRuntime

runtime = HapticRuntime()
device = HapticDevice("controller_01")
device.connect()
runtime.register_device(device)

# Register the profiles the default EventMapper expects.
for name, waveform, amp, dur in [
    ("success_chime", WaveformType.BURST, 0.5, 0.08),
    ("error_buzz", WaveformType.SWEEP, 0.9, 0.15),
    ("impact_hard", WaveformType.IMPACT, 1.0, 0.08),
]:
    runtime.composer.register(HapticProfile(name=name, waveform=waveform, amplitude=amp, duration=dur))

for event_type in (HapticEventType.SUCCESS, HapticEventType.ERROR, HapticEventType.COLLISION):
    signal = runtime.dispatch_event(HapticEvent(type=event_type), device_id="controller_01")
    played = "played" if signal is not None else "no profile mapped"
    print(f"{event_type.value:<12} -> {played}")

device.disconnect()
