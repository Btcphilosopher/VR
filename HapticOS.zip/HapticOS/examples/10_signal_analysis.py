"""Section 12 example: FFT, RMS, peak detection, envelope."""

from hapticos.signals.analysis import SignalAnalyzer
from hapticos.signals.generator import SignalGenerator

sr = 8000
sig = SignalGenerator.sine(frequency=220, amplitude=0.8, duration=0.3, sample_rate=sr)

spectrum = SignalAnalyzer.fft(sig, sr)
print(f"Dominant frequency: {spectrum.dominant_frequency():.1f} Hz")
print(f"RMS: {SignalAnalyzer.rms(sig):.4f}")

envelope = SignalAnalyzer.envelope_analysis(sig)
print(f"Envelope mean: {envelope.mean():.4f}")

impact = SignalGenerator.impact(carrier_frequency=250, sample_rate=sr)
peaks = SignalAnalyzer.peak_detection(impact, sr, height=0.3)
print(f"Impact signal peaks at: {[f'{p*1000:.1f}ms' for p in peaks]}")

comparison = SignalAnalyzer.compare(sig, impact)
print(f"sine vs impact -> correlation={comparison['correlation']:.3f}, rms_delta={comparison['rms_delta']:.3f}")
