"""Section 3/4 example: touching a virtual material.

    surface = Material(stiffness=0.8, friction=0.4, roughness=0.7)
    engine.contact(surface)
"""

from hapticos import HapticDevice
from hapticos.materials.material import Material, get_material
from hapticos.physics.contact import HapticPhysicsEngine

device = HapticDevice("controller_01")
device.connect()

engine = HapticPhysicsEngine(sample_rate=device.capabilities.sample_rate_hz)

# Using a preset...
wood = get_material("WOOD")
result = engine.contact(wood, force=0.8, velocity=0.3)
device.driver.send_signal(result.signal, result.sample_rate)
print(f"WOOD contact: friction={result.friction_force:.3f}, peak={abs(result.signal).max():.2f}")

# ...or a fully custom material.
custom_surface = Material(name="CUSTOM_GEL", stiffness=0.2, friction=0.6, roughness=0.5, damping=0.8)
result = engine.contact(custom_surface, force=0.5)
device.driver.send_signal(result.signal, result.sample_rate)
print(f"CUSTOM_GEL contact: friction={result.friction_force:.3f}, peak={abs(result.signal).max():.2f}")

device.disconnect()
