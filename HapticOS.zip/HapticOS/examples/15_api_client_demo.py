"""Section 17/18 example: driving HapticOS over its FastAPI/WebSocket API.

Run the server first:

    uvicorn hapticos.api.server:app --reload

...then run this script (requires `requests`; falls back to printing curl
commands if it isn't installed).
"""

BASE_URL = "http://127.0.0.1:8000"

try:
    import requests
except ImportError:
    requests = None

if requests is None:
    print("`requests` not installed — equivalent curl commands:")
    print(f'  curl -X POST {BASE_URL}/api/devices/controller_01/connect')
    print(f'  curl -X POST {BASE_URL}/api/devices/controller_01/play '
          '-H "Content-Type: application/json" '
          '-d \'{"frequency": 150, "amplitude": 0.7, "duration": 0.2, "waveform": "sine"}\'')
    print(f'  curl {BASE_URL}/api/devices/controller_01/state')
    raise SystemExit(0)

requests.post(f"{BASE_URL}/api/devices/controller_01/connect")

resp = requests.post(
    f"{BASE_URL}/api/devices/controller_01/play",
    json={"frequency": 150, "amplitude": 0.7, "duration": 0.2, "waveform": "sine"},
)
print("play ->", resp.json())

resp = requests.get(f"{BASE_URL}/api/devices/controller_01/state")
print("state ->", resp.json())

resp = requests.post(
    f"{BASE_URL}/api/devices/controller_01/contact", json={"material": "RUBBER", "force": 0.6}
)
print("contact ->", resp.json())

print(f"Open {BASE_URL}/ in a browser for the live dashboard.")
