"""Section 5 example: F = -Kx - Cv, plus a one-sided virtual wall."""

from hapticos.physics.force_feedback import ForceFeedbackEngine, Spring, Damper, VirtualWall

engine = ForceFeedbackEngine()
engine.springs.append(Spring(stiffness=50.0, rest_position=0.0))
engine.dampers.append(Damper(damping=5.0))
engine.walls.append(VirtualWall(surface_position=1.0, stiffness=300.0, damping=2.0, normal=1))

for position in [0.0, 0.5, 1.0, 1.2, 1.5]:
    velocity = 0.1
    force = engine.net_force(position, velocity)
    print(f"position={position:>4.1f}  net_force={force:8.2f} N")
