"""Section 10 example:

    IMPACT + ROUGH_TEXTURE + LOW_FREQUENCY_PULSE = MATERIAL_CONTACT
"""

import tempfile
from pathlib import Path

from hapticos.composer.composer import HapticComposer
from hapticos.composer.profile import HapticProfile
from hapticos.core.types import WaveformType

with tempfile.TemporaryDirectory() as tmp:
    library = Path(tmp)
    composer = HapticComposer(library_dir=library)

    composer.save_profile(HapticProfile(name="IMPACT", waveform=WaveformType.IMPACT, amplitude=0.9, duration=0.08))
    composer.save_profile(
        HapticProfile(name="ROUGH_TEXTURE", waveform=WaveformType.TEXTURE, amplitude=0.4, duration=0.08, extra={"roughness": 0.9})
    )
    composer.save_profile(
        HapticProfile(name="LOW_FREQUENCY_PULSE", waveform=WaveformType.PULSE, frequency=30, amplitude=0.3, duration=0.08)
    )

    material_contact = composer.compose_named(
        "MATERIAL_CONTACT", "IMPACT", "ROUGH_TEXTURE", "LOW_FREQUENCY_PULSE", weights=[1.0, 0.6, 0.4]
    )
    composer.save_profile(material_contact)

    print(f"Saved profiles: {composer.list_profiles()}")
    rendered = material_contact.render()
    print(f"MATERIAL_CONTACT: {len(rendered)} samples, peak={abs(rendered).max():.2f}")
    print(f".haptic files on disk: {[p.name for p in library.glob('*.haptic')]}")
