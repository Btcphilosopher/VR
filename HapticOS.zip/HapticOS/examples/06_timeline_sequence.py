"""Section 8 example:

    0 ms      CONTACT
    20 ms     IMPACT
    80 ms     VIBRATION
    400 ms    TEXTURE
    1200 ms   RELEASE
"""

from hapticos import HapticDevice, WaveformType
from hapticos.temporal.timeline import HapticTimeline

device = HapticDevice("controller_01")
device.connect()

timeline = HapticTimeline()
timeline.schedule(0, lambda: device.play(amplitude=0.3, duration=0.01, waveform=WaveformType.PULSE), "CONTACT")
timeline.schedule(20, lambda: device.play(amplitude=1.0, duration=0.05, waveform=WaveformType.IMPACT), "IMPACT")
timeline.schedule(80, lambda: device.play(frequency=150, amplitude=0.6, duration=0.2, waveform=WaveformType.CONTINUOUS), "VIBRATION")
timeline.schedule(400, lambda: device.play(amplitude=0.4, duration=0.3, waveform=WaveformType.TEXTURE), "TEXTURE")
timeline.schedule(1200, lambda: device.stop(), "RELEASE")

# Deterministic (CI-safe) execution:
for event in timeline.run_virtual():
    status = "OK" if event.error is None else f"ERROR: {event.error}"
    print(f"{event.scheduled_ms:>6.0f} ms   {event.label:<12} {status}")

device.disconnect()
