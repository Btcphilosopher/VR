"""Section 16 example: the full pipeline with zero physical hardware.

    Virtual Hand -> Virtual Object -> Virtual Contact -> Haptic Signal
                                                        -> Virtual Actuator
"""

from hapticos import HapticDevice
from hapticos.core.types import Vector3
from hapticos.materials.material import get_material
from hapticos.simulation.virtual import VirtualHand, VirtualObject, VirtualSimulation, VirtualSurface

device = HapticDevice("virtual_index_finger")
device.connect()

simulation = VirtualSimulation(sample_rate=device.capabilities.sample_rate_hz)
simulation.add_surface(VirtualSurface(material=get_material("WOOD"), axis="z", height=0.0))
simulation.add_object(VirtualObject(center=Vector3(x=0.3, z=-0.1), radius=0.15, material=get_material("GLASS")))

hand = VirtualHand.default()

# Sweep the index finger downward through the table surface.
for step, z in enumerate([0.1, 0.05, 0.0, -0.05, -0.1]):
    hand.move_finger("index", Vector3(x=0.0, y=0.0, z=z), dt_s=0.02)
    result = simulation.step(hand.fingers["index"], device, duration=0.03)
    if result is None:
        print(f"step {step}: no contact (z={z:.2f})")
    else:
        print(f"step {step}: contact! friction={result.friction_force:.3f} peak={abs(result.signal).max():.2f}")

device.disconnect()
