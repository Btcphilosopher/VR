"""Section 17 example: the minimal HapticOS API.

    device = HapticDevice("controller_01")
    device.play(frequency=150, amplitude=0.7, duration=0.2)
"""

from hapticos import HapticDevice, WaveformType

device = HapticDevice("controller_01")
device.connect()

signal = device.play(frequency=150, amplitude=0.7, duration=0.2, waveform=WaveformType.SINE)
print(f"Rendered {len(signal)} samples, peak amplitude {abs(signal).max():.2f}")
print(f"Device state: {device.state}")

device.stop()
device.disconnect()
