"""Section 13 example:

    OBJECTIVE
    MAXIMISE: perceptual distinction
    MINIMISE: energy, duration, actuator stress
"""

from hapticos.core.types import DeviceCapabilities, WaveformType
from hapticos.optimization.optimizer import HapticOptimizer, OptimizationObjective

capabilities = DeviceCapabilities(min_frequency_hz=20, max_frequency_hz=400, max_duration_s=0.3)
optimizer = HapticOptimizer(capabilities)

objective = OptimizationObjective(
    maximize_perceptual_distinction=1.0,
    minimize_energy=0.4,
    minimize_duration=0.2,
    minimize_actuator_stress=0.3,
)

result = optimizer.optimize(objective, waveform=WaveformType.SINE)
print(f"Optimised pattern: frequency={result.frequency:.1f}Hz amplitude={result.amplitude:.2f} "
      f"duration={result.duration*1000:.1f}ms cost={result.cost:.4f}")
