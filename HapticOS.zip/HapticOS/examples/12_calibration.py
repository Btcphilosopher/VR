"""Section 14 example: run a full device calibration and persist the profile."""

import tempfile
from pathlib import Path

from hapticos import HapticDevice
from hapticos.calibration.calibration import CalibrationEngine

device = HapticDevice("controller_01")
device.connect()

calibration_engine = CalibrationEngine(device)
profile = calibration_engine.run_full_calibration()

print(f"Device: {profile.device_id}")
print(f"Min activation amplitude: {profile.min_activation_amplitude:.3f}")
print(f"Max safe amplitude: {profile.max_safe_amplitude:.2f}")
print(f"Frequency response: {profile.frequency_response}")
print(f"Measured latency: {profile.measured_latency_s*1000:.3f} ms")
print(f"Thermal time constant: {profile.thermal_time_constant_s:.3f} s")

with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / f"{device.device_id}.calibration.json"
    profile.save(path)
    print(f"Saved calibration profile to {path}")

device.disconnect()
