from hapticos.latency.engine import LatencyEngine


def test_measure_round_trip_returns_ordered_timestamps(device):
    engine = LatencyEngine()
    trace = engine.measure_round_trip(device, frequency=100, amplitude=0.5, duration=0.01)
    assert trace.event_s <= trace.software_s <= trace.signal_s <= trace.device_s <= trace.actuator_s
    assert trace.end_to_end_s >= 0
    assert trace.scheduling_delay_s >= 0
    assert trace.device_response_s >= 0


def test_benchmark_runs_n_trials(device):
    engine = LatencyEngine()
    result = engine.benchmark(device, n_trials=10, frequency=150, amplitude=0.3, duration=0.005)
    assert result.n_trials == 10
    assert len(result.traces) == 10
    assert result.mean_latency_s >= 0
    assert result.jitter_s >= 0
    assert result.min_latency_s <= result.mean_latency_s <= result.max_latency_s


def test_benchmark_with_fake_clock_is_deterministic(device):
    fake_time = [0.0]

    def clock():
        fake_time[0] += 0.001
        return fake_time[0]

    engine = LatencyEngine(clock=clock)
    result = engine.benchmark(device, n_trials=5, duration=0.001)
    assert result.mean_latency_s > 0
    assert result.jitter_s == 0 or result.jitter_s >= 0
