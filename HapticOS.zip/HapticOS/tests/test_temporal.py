from hapticos.temporal.timeline import HapticTimeline


def test_virtual_timeline_executes_in_order():
    order = []
    timeline = HapticTimeline()
    timeline.schedule(80, lambda: order.append("release"), label="release")
    timeline.schedule(0, lambda: order.append("contact"), label="contact")
    timeline.schedule(20, lambda: order.append("impact"), label="impact")

    results = timeline.run_virtual()

    assert order == ["contact", "impact", "release"]
    assert [r.scheduled_ms for r in results] == [0, 20, 80]
    assert all(r.error is None for r in results)


def test_virtual_timeline_matches_scheduled_time():
    timeline = HapticTimeline()
    timeline.schedule(100, lambda: 42, label="x")
    [result] = timeline.run_virtual()
    assert result.actual_ms == 100
    assert result.result == 42


def test_timeline_duration_ms():
    timeline = HapticTimeline()
    timeline.schedule(0, lambda: None)
    timeline.schedule(1200, lambda: None)
    assert timeline.duration_ms == 1200


def test_timeline_captures_action_errors_without_raising():
    timeline = HapticTimeline()

    def boom():
        raise ValueError("actuator fault")

    timeline.schedule(0, boom, label="boom")
    [result] = timeline.run_virtual()
    assert result.error == "actuator fault"


def test_realtime_execution_respects_ordering():
    order = []
    timeline = HapticTimeline()
    timeline.schedule(2, lambda: order.append("b"))
    timeline.schedule(0, lambda: order.append("a"))
    # Use a fake fast clock so the test doesn't actually sleep for ms deltas
    fake_time = [0.0]

    def clock():
        return fake_time[0]

    def sleep(seconds):
        fake_time[0] += seconds

    results = timeline.run_realtime(clock=clock, sleep=sleep)
    assert order == ["a", "b"]
    assert results[0].actual_ms <= results[1].actual_ms
