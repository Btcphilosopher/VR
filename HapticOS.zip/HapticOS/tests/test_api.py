import pytest
from fastapi.testclient import TestClient

from hapticos.api.server import app, runtime


@pytest.fixture(autouse=True)
def _reset_runtime():
    runtime.devices.clear()
    yield
    runtime.devices.clear()


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def test_dashboard_serves_html(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert "HapticOS" in resp.text or "HAPTICOS" in resp.text


def test_list_devices_includes_default(client):
    resp = client.get("/api/devices")
    assert resp.status_code == 200
    ids = [d["device_id"] for d in resp.json()]
    assert "controller_01" in ids


def test_connect_new_device(client):
    resp = client.post("/api/devices/glove_01/connect")
    assert resp.status_code == 200
    assert resp.json()["connected"] is True


def test_device_state_returns_fields(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.get("/api/devices/controller_01/state")
    assert resp.status_code == 200
    body = resp.json()
    assert "amplitude" in body and "frequency" in body and "temperature_c" in body


def test_device_state_404_for_unknown(client):
    resp = client.get("/api/devices/does_not_exist/state")
    assert resp.status_code == 404


def test_play_endpoint(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post(
        "/api/devices/controller_01/play",
        json={"frequency": 150, "amplitude": 0.5, "duration": 0.05, "waveform": "sine"},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["samples"] > 0
    assert body["peak_amplitude"] <= 0.5 + 1e-6


def test_stop_endpoint(client):
    client.post("/api/devices/controller_01/connect")
    client.post("/api/devices/controller_01/play", json={"amplitude": 0.5, "duration": 0.02})
    resp = client.post("/api/devices/controller_01/stop")
    assert resp.status_code == 200
    assert resp.json()["stopped"] is True


def test_emergency_stop_endpoint(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post("/api/devices/controller_01/emergency_stop")
    assert resp.status_code == 200
    assert resp.json()["emergency_stopped"] is True


def test_contact_endpoint(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post("/api/devices/controller_01/contact", json={"material": "WOOD", "force": 0.5})
    assert resp.status_code == 200
    assert resp.json()["samples"] > 0


def test_contact_unknown_material_404(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post("/api/devices/controller_01/contact", json={"material": "UNOBTANIUM"})
    assert resp.status_code == 404


def test_events_endpoint_dispatches(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post(
        "/api/events", json={"type": "impact", "payload": {}, "device_id": "controller_01"}
    )
    assert resp.status_code == 200
    assert resp.json()["dispatched"] is True


def test_events_endpoint_unknown_type(client):
    client.post("/api/devices/controller_01/connect")
    resp = client.post(
        "/api/events", json={"type": "not_a_real_event", "payload": {}, "device_id": "controller_01"}
    )
    assert resp.status_code == 400


def test_websocket_stream_sends_device_payload(client):
    client.post("/api/devices/controller_01/connect")
    with client.websocket_connect("/ws/stream") as ws:
        data = ws.receive_json()
        assert "devices" in data
        assert "controller_01" in data["devices"]
