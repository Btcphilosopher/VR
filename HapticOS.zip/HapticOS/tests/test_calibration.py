from hapticos.calibration.calibration import CalibrationEngine, CalibrationProfile
from hapticos.core.device import HapticDevice
from hapticos.drivers.simulated import SimulatedDriver


def test_measure_min_activation_is_within_bounds(device):
    engine = CalibrationEngine(device)
    min_amp = engine.measure_min_activation(start=0.01, step=0.05, max_amp=1.0)
    assert 0.0 < min_amp <= 1.0


def test_measure_max_amplitude_respects_safety(device):
    engine = CalibrationEngine(device)
    assert engine.measure_max_amplitude() <= device.capabilities.max_amplitude


def test_measure_frequency_response_returns_all_frequencies(device):
    engine = CalibrationEngine(device)
    response = engine.measure_frequency_response([50, 100, 200])
    assert set(response.keys()) == {"50", "100", "200"}
    assert all(v >= 0 for v in response.values())


def test_measure_latency_returns_nonnegative(device):
    engine = CalibrationEngine(device)
    latency = engine.measure_latency(trials=3)
    assert latency >= 0.0


def test_measure_actuator_variation_across_siblings(capabilities):
    devices = []
    for i in range(3):
        driver = SimulatedDriver(f"dev_{i}", capabilities, seed=i)
        d = HapticDevice(f"dev_{i}", driver=driver, capabilities=capabilities)
        d.connect()
        devices.append(d)
    engine = CalibrationEngine(devices[0])
    variation = engine.measure_actuator_variation(devices)
    assert variation >= 0.0


def test_measure_actuator_variation_empty_list_is_zero(device):
    engine = CalibrationEngine(device)
    assert engine.measure_actuator_variation([]) == 0.0


def test_thermal_behavior_returns_positive_time_constant(device):
    engine = CalibrationEngine(device)
    tau = engine.measure_thermal_behavior(drive_seconds=0.5, steps=5)
    assert tau > 0


def test_run_full_calibration_produces_profile(device):
    engine = CalibrationEngine(device)
    profile = engine.run_full_calibration()
    assert isinstance(profile, CalibrationProfile)
    assert profile.device_id == device.device_id


def test_calibration_profile_persistence(tmp_path):
    profile = CalibrationProfile(device_id="d1", min_activation_amplitude=0.05)
    path = tmp_path / "d1.calibration.json"
    profile.save(path)
    loaded = CalibrationProfile.load(path)
    assert loaded == profile
