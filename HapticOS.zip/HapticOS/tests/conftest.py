import pytest

from hapticos.core.device import HapticDevice
from hapticos.core.types import DeviceCapabilities
from hapticos.drivers.simulated import SimulatedDriver


@pytest.fixture
def capabilities() -> DeviceCapabilities:
    return DeviceCapabilities(
        min_frequency_hz=10.0,
        max_frequency_hz=500.0,
        min_amplitude=0.0,
        max_amplitude=1.0,
        max_force_n=10.0,
        max_duration_s=2.0,
        sample_rate_hz=4000,
    )


@pytest.fixture
def device(capabilities) -> HapticDevice:
    driver = SimulatedDriver("test_device", capabilities, seed=42)
    dev = HapticDevice("test_device", driver=driver, capabilities=capabilities)
    dev.connect()
    return dev
