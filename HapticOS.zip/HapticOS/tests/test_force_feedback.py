import pytest

from hapticos.physics.force_feedback import (
    Constraint,
    Damper,
    ForceFeedbackEngine,
    Spring,
    SpringDamper,
    VirtualObject,
    VirtualWall,
)


def test_spring_pulls_toward_rest():
    spring = Spring(stiffness=10.0, rest_position=0.0)
    assert spring.force(position=1.0) == -10.0
    assert spring.force(position=-1.0) == 10.0


def test_damper_opposes_velocity():
    damper = Damper(damping=2.0)
    assert damper.force(velocity=3.0) == -6.0


def test_spring_damper_formula_f_eq_neg_kx_neg_cv():
    sd = SpringDamper(stiffness=5.0, damping=1.0, rest_position=0.0)
    f = sd.force(position=2.0, velocity=1.0)
    assert f == pytest.approx(-5.0 * 2.0 - 1.0 * 1.0)


def test_virtual_wall_no_force_before_penetration():
    wall = VirtualWall(surface_position=1.0, stiffness=100.0, normal=1)
    assert wall.force(position=0.5, velocity=0.0) == 0.0


def test_virtual_wall_pushes_back_when_penetrated():
    wall = VirtualWall(surface_position=1.0, stiffness=100.0, normal=1)
    f = wall.force(position=1.2, velocity=0.0)
    assert f < 0  # pushes back toward decreasing position


def test_constraint_clamps_out_of_range():
    c = Constraint(min_position=0.0, max_position=10.0, stiffness=1.0)
    assert c.force(position=-2.0) == 2.0
    assert c.force(position=12.0) == -2.0
    assert c.force(position=5.0) == 0.0


def test_virtual_object_contains_and_force():
    obj = VirtualObject(center=0.0, radius=1.0, stiffness=50.0, damping=1.0)
    assert obj.contains(0.5)
    assert not obj.contains(2.0)
    f = obj.force(position=0.8, velocity=0.0)
    assert f > 0


def test_force_feedback_engine_aggregates():
    engine = ForceFeedbackEngine()
    engine.springs.append(Spring(stiffness=1.0, rest_position=0.0))
    engine.dampers.append(Damper(damping=1.0))
    total = engine.net_force(position=1.0, velocity=1.0)
    assert total == pytest.approx(-1.0 - 1.0)


def test_force_feedback_engine_with_wall_and_constraint():
    engine = ForceFeedbackEngine()
    engine.walls.append(VirtualWall(surface_position=2.0, stiffness=10.0, normal=1))
    engine.constraints.append(Constraint(min_position=-5.0, max_position=5.0))
    assert engine.net_force(position=1.0, velocity=0.0) == 0.0
    assert engine.net_force(position=2.5, velocity=0.0) < 0
