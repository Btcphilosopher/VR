import numpy as np
import pytest

from hapticos.materials.material import get_material
from hapticos.physics.contact import HapticPhysicsEngine


def test_friction_scales_with_normal_force():
    material = get_material("RUBBER")
    low = HapticPhysicsEngine.friction(material, normal_force=0.2, velocity=1.0)
    high = HapticPhysicsEngine.friction(material, normal_force=0.8, velocity=1.0)
    assert high > low


def test_static_friction_bump_at_zero_velocity():
    material = get_material("METAL")
    static = HapticPhysicsEngine.friction(material, normal_force=1.0, velocity=0.0)
    kinetic = HapticPhysicsEngine.friction(material, normal_force=1.0, velocity=1.0)
    assert static > kinetic


def test_collision_impulse_increases_with_velocity():
    _, low_wave = HapticPhysicsEngine.collision(mass=1.0, velocity=0.5)
    impulse_low, _ = HapticPhysicsEngine.collision(mass=1.0, velocity=0.5)
    impulse_high, high_wave = HapticPhysicsEngine.collision(mass=1.0, velocity=5.0)
    assert impulse_high > impulse_low


def test_pressure_formula():
    assert HapticPhysicsEngine.pressure(force_n=10.0, area_m2=2.0) == 5.0


def test_pressure_guards_zero_area():
    assert HapticPhysicsEngine.pressure(force_n=10.0, area_m2=0.0) > 0


def test_elasticity_hookes_law():
    assert HapticPhysicsEngine.elasticity(stiffness=10.0, displacement=0.5) == -5.0


def test_contact_returns_signal_and_forces():
    engine = HapticPhysicsEngine(sample_rate=2000)
    material = get_material("STONE")
    result = engine.contact(material, force=0.6, velocity=0.3, duration=0.05)
    assert result.normal_force == 0.6
    assert result.friction_force > 0
    assert len(result.signal) > 0
    assert result.sample_rate == 2000


def test_vibration_signature_uses_material_frequency():
    engine = HapticPhysicsEngine(sample_rate=8000)
    material = get_material("ICE")
    sig = engine.vibration_signature(material, intensity=0.5, duration=0.1)
    assert len(sig) == 800
    assert np.max(np.abs(sig)) <= 0.5 + 1e-9
