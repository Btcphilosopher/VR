import pytest

from hapticos.safety.limits import SafetyLimits, SafetyMonitor, SafetyViolation


def test_validate_passes_within_limits():
    monitor = SafetyMonitor(limits=SafetyLimits(max_amplitude=1.0, max_duration_s=1.0, max_force_n=5.0))
    monitor.validate(amplitude=0.5, duration_s=0.1, force_n=1.0)  # should not raise


def test_validate_rejects_excess_amplitude():
    monitor = SafetyMonitor(limits=SafetyLimits(max_amplitude=0.5))
    with pytest.raises(SafetyViolation):
        monitor.validate(amplitude=0.9, duration_s=0.1)


def test_validate_rejects_excess_duration():
    monitor = SafetyMonitor(limits=SafetyLimits(max_duration_s=0.1))
    with pytest.raises(SafetyViolation):
        monitor.validate(amplitude=0.1, duration_s=1.0)


def test_validate_rejects_excess_force():
    monitor = SafetyMonitor(limits=SafetyLimits(max_force_n=1.0))
    with pytest.raises(SafetyViolation):
        monitor.validate(amplitude=0.1, duration_s=0.01, force_n=5.0)


def test_emergency_stop_blocks_all_validation():
    monitor = SafetyMonitor()
    monitor.emergency_stop()
    assert monitor.is_emergency_stopped
    with pytest.raises(SafetyViolation):
        monitor.validate(amplitude=0.01, duration_s=0.001)


def test_reset_emergency_stop_allows_validation_again():
    monitor = SafetyMonitor()
    monitor.emergency_stop()
    monitor.reset_emergency_stop()
    monitor.validate(amplitude=0.1, duration_s=0.01)  # should not raise


def test_report_temperature_triggers_emergency_stop():
    monitor = SafetyMonitor(limits=SafetyLimits(max_temperature_c=50.0))
    with pytest.raises(SafetyViolation):
        monitor.report_temperature(80.0)
    assert monitor.is_emergency_stopped


def test_report_invalid_state_fails_safe():
    monitor = SafetyMonitor()
    with pytest.raises(SafetyViolation):
        monitor.report_invalid_state("lost connection mid-drive")
    assert monitor.is_emergency_stopped


def test_duty_cycle_rejects_excessive_activation():
    limits = SafetyLimits(max_duty_cycle=0.5, duty_cycle_window_s=1.0, max_duration_s=10.0)
    monitor = SafetyMonitor(limits=limits)
    monitor._clock = lambda: 0.0  # freeze the window so activations stack up
    monitor.validate(amplitude=0.1, duration_s=0.4)
    with pytest.raises(SafetyViolation):
        monitor.validate(amplitude=0.1, duration_s=0.4)


def test_device_play_raises_and_stops_on_violation(device):
    device.safety.limits.max_amplitude = 0.2
    with pytest.raises(Exception):
        device.play(amplitude=0.9, duration=0.01)


def test_device_emergency_stop_halts_driver(device):
    device.play(frequency=100, amplitude=0.5, duration=0.02)
    device.emergency_stop()
    assert device.safety.is_emergency_stopped
    assert device.state.amplitude == 0.0
