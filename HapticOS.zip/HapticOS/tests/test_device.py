import numpy as np
import pytest

from hapticos.core.types import ConnectionState, WaveformType
from hapticos.drivers.base import DriverError


def test_connect_sets_connected_state(device):
    assert device.is_connected
    assert device.state.connection == ConnectionState.CONNECTED


def test_play_returns_rendered_signal(device):
    sig = device.play(frequency=150, amplitude=0.5, duration=0.05, waveform=WaveformType.SINE)
    assert isinstance(sig, np.ndarray)
    assert len(sig) > 0


def test_play_clamps_amplitude_to_capabilities(device):
    device.capabilities.max_amplitude = 0.6
    sig = device.play(frequency=100, amplitude=2.0, duration=0.01)
    assert np.max(np.abs(sig)) <= 0.6 + 1e-9


def test_play_clamps_frequency_to_capabilities(device):
    sig_low = device.play(frequency=-100, amplitude=0.5, duration=0.02)
    sig_high = device.play(frequency=100000, amplitude=0.5, duration=0.02)
    assert len(sig_low) > 0 and len(sig_high) > 0


def test_play_updates_device_state(device):
    device.play(frequency=200, amplitude=0.7, duration=0.02)
    assert device.state.is_active
    assert device.state.amplitude == pytest.approx(0.7, abs=0.05)


def test_stop_silences_device(device):
    device.play(frequency=100, amplitude=0.8, duration=0.02)
    device.stop()
    assert device.state.amplitude == 0.0
    assert not device.state.is_active


def test_drive_continuous_sets_parameters(device):
    device.drive_continuous(frequency=180, amplitude=0.4)
    assert device.state.frequency == 180
    assert device.state.amplitude == pytest.approx(0.4, abs=1e-6)
    device.stop()


def test_disconnect_prevents_further_play(device):
    device.disconnect()
    assert not device.is_connected
    with pytest.raises(DriverError):
        device.play(frequency=100, amplitude=0.5, duration=0.01)


def test_repr_contains_device_id(device):
    assert "test_device" in repr(device)
