import numpy as np
import pytest

from hapticos.materials.material import MATERIAL_PRESETS, Material, get_material


def test_all_presets_present():
    expected = {"WOOD", "METAL", "GLASS", "RUBBER", "FABRIC", "STONE", "ICE", "SAND", "LIQUID"}
    assert expected <= set(MATERIAL_PRESETS.keys())


def test_get_material_case_insensitive():
    m1 = get_material("wood")
    m2 = get_material("WOOD")
    assert m1.name == m2.name == "WOOD"


def test_get_material_unknown_raises():
    with pytest.raises(KeyError):
        get_material("unobtanium")


def test_get_material_returns_copy():
    m1 = get_material("METAL")
    m1.friction = 0.99
    m2 = get_material("METAL")
    assert m2.friction != 0.99


def test_metal_stiffer_than_rubber():
    metal = get_material("METAL")
    rubber = get_material("RUBBER")
    assert metal.stiffness > rubber.stiffness


def test_glass_less_rough_than_sand():
    glass = get_material("GLASS")
    sand = get_material("SAND")
    assert glass.roughness < sand.roughness


def test_contact_response_scales_with_force():
    material = get_material("WOOD")
    low = material.contact_response(force=0.1, sample_rate=2000)
    high = material.contact_response(force=1.0, sample_rate=2000)
    assert np.max(np.abs(high)) >= np.max(np.abs(low))


def test_contact_response_bounded():
    material = Material(name="CUSTOM", friction=1.0, stiffness=1.0, roughness=1.0)
    sig = material.contact_response(force=1.0, velocity=1.0, sample_rate=2000)
    assert np.max(np.abs(sig)) <= 1.0 + 1e-9
