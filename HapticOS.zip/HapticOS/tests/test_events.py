from hapticos.core.events import EventBus, EventMapper, HapticEvent, HapticEventType


def test_subscribe_and_publish_calls_handler():
    bus = EventBus()
    received = []
    bus.subscribe(HapticEventType.COLLISION, lambda e: received.append(e))
    event = HapticEvent(type=HapticEventType.COLLISION, payload={"force": 1.0})
    bus.publish(event)
    assert received == [event]


def test_publish_records_history():
    bus = EventBus()
    bus.publish(HapticEvent(type=HapticEventType.TOUCH))
    bus.publish(HapticEvent(type=HapticEventType.RELEASE))
    assert len(bus.history) == 2


def test_wildcard_subscriber_receives_all_types():
    bus = EventBus()
    received = []
    bus.subscribe_all(lambda e: received.append(e.type))
    bus.publish(HapticEvent(type=HapticEventType.GRAB))
    bus.publish(HapticEvent(type=HapticEventType.SUCCESS))
    assert received == [HapticEventType.GRAB, HapticEventType.SUCCESS]


def test_unrelated_subscriber_not_called():
    bus = EventBus()
    calls = []
    bus.subscribe(HapticEventType.ERROR, lambda e: calls.append(e))
    bus.publish(HapticEvent(type=HapticEventType.SUCCESS))
    assert calls == []


def test_event_mapper_default_resolution():
    mapper = EventMapper()
    assert mapper.resolve(HapticEventType.IMPACT) is not None


def test_event_mapper_custom_override():
    mapper = EventMapper()
    mapper.map(HapticEventType.NOTIFICATION, "custom_buzz")
    assert mapper.resolve(HapticEventType.NOTIFICATION) == "custom_buzz"
