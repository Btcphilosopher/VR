from hapticos.actuators.array import ActuatorGroup, build_hand
from hapticos.core.device import HapticDevice
from hapticos.core.types import WaveformType
from hapticos.drivers.simulated import SimulatedDriver


def test_build_hand_creates_four_fingers():
    hand = build_hand("LEFT_HAND")
    flat = hand.flatten()
    assert len(flat) == 4
    assert "LEFT_HAND/Thumb" in flat
    for dev in flat.values():
        dev.connect()


def test_actuator_group_flatten_includes_subgroups():
    root = ActuatorGroup(name="")
    left = build_hand("LEFT_HAND")
    right = build_hand("RIGHT_HAND")
    root.add_subgroup(left)
    root.add_subgroup(right)
    flat = root.flatten()
    assert len(flat) == 8


def test_play_all_drives_every_actuator():
    hand = build_hand("LEFT_HAND")
    for dev in hand.flatten().values():
        dev.connect()
    results = hand.play_all(frequency=150, amplitude=0.5, duration=0.01, waveform=WaveformType.SINE)
    assert len(results) == 4
    for sig in results.values():
        assert len(sig) > 0


def test_play_spatial_pattern_orders_offsets():
    hand = build_hand("RIGHT_HAND")
    for dev in hand.flatten().values():
        dev.connect()
    order = ["RIGHT_HAND/Thumb", "RIGHT_HAND/Index", "RIGHT_HAND/Middle"]
    result = hand.play_spatial_pattern(order, delay_s=0.02)
    offsets = [result[label][0] for label in order]
    assert offsets == [0.0, 0.02, 0.04]


def test_play_spatial_pattern_unknown_label_raises():
    hand = build_hand("LEFT_HAND")
    for dev in hand.flatten().values():
        dev.connect()
    import pytest

    with pytest.raises(KeyError):
        hand.play_spatial_pattern(["not_a_finger"])


def test_stop_all_silences_group():
    hand = build_hand("LEFT_HAND")
    for dev in hand.flatten().values():
        dev.connect()
    hand.play_all(amplitude=0.9, duration=0.02)
    hand.stop_all()
    for dev in hand.flatten().values():
        assert dev.state.amplitude == 0.0
