import numpy as np

from hapticos.signals.analysis import SignalAnalyzer
from hapticos.signals.generator import SignalGenerator


def test_fft_dominant_frequency():
    sr = 8000
    sig = SignalGenerator.sine(frequency=200, amplitude=1.0, duration=0.5, sample_rate=sr)
    spectrum = SignalAnalyzer.fft(sig, sr)
    assert abs(spectrum.dominant_frequency() - 200) < 10


def test_rms_of_constant_signal():
    sig = np.full(100, 0.5)
    assert SignalAnalyzer.rms(sig) == 0.5


def test_rms_empty_signal():
    assert SignalAnalyzer.rms(np.array([])) == 0.0


def test_peak_detection_counts_pulses():
    sr = 1000
    sig = np.zeros(sr)
    # start at 100, not 0: scipy.signal.find_peaks never reports a peak at
    # the very first sample (it has no left neighbour to compare against).
    for i in range(100, sr, 100):
        sig[i] = 1.0
    peaks = SignalAnalyzer.peak_detection(sig, sr, height=0.5, distance=50)
    assert len(peaks) == 9


def test_envelope_analysis_matches_amplitude():
    sr = 8000
    sig = SignalGenerator.sine(150, 0.8, 0.2, sample_rate=sr)
    env = SignalAnalyzer.envelope_analysis(sig)
    assert np.mean(env) == np.mean(env)  # not NaN
    assert np.max(env) <= 0.9


def test_compare_identical_signals():
    sig = SignalGenerator.sine(150, 0.8, 0.1, sample_rate=4000)
    result = SignalAnalyzer.compare(sig, sig)
    assert result["correlation"] > 0.99
    assert result["mse"] < 1e-6


def test_compare_dissimilar_signals():
    sig_a = SignalGenerator.sine(100, 1.0, 0.1, sample_rate=4000)
    sig_b = np.zeros(400)
    result = SignalAnalyzer.compare(sig_a, sig_b)
    assert result["rms_delta"] > 0.1


def test_spectrogram_shape():
    sr = 4000
    sig = SignalGenerator.sweep(50, 400, 1.0, 0.5, sample_rate=sr)
    spec = SignalAnalyzer.spectrogram(sig, sr, nperseg=128)
    assert spec.magnitude.shape[0] == len(spec.frequencies)
    assert spec.magnitude.shape[1] == len(spec.times)
