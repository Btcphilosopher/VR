from hapticos.core.types import Vector3
from hapticos.materials.material import get_material
from hapticos.simulation.virtual import VirtualHand, VirtualObject, VirtualSensor, VirtualSimulation, VirtualSurface


def test_sensor_move_updates_position_and_velocity():
    sensor = VirtualSensor()
    sensor.move_to(Vector3(x=1.0), dt_s=1.0)
    assert sensor.position.x == 1.0
    assert sensor.velocity.x == 1.0


def test_virtual_surface_penetration():
    surface = VirtualSurface(material=get_material("WOOD"), axis="z", height=0.0)
    assert surface.penetration(Vector3(z=0.5)) == 0.0
    assert surface.penetration(Vector3(z=-0.3)) > 0.0
    assert surface.is_touching(Vector3(z=-0.1))


def test_virtual_object_penetration():
    obj = VirtualObject(center=Vector3(), radius=1.0, material=get_material("RUBBER"))
    assert obj.penetration(Vector3(x=2.0)) == 0.0
    assert obj.penetration(Vector3(x=0.5)) > 0.0
    assert obj.is_touching(Vector3(x=0.5))


def test_virtual_hand_default_has_four_fingers():
    hand = VirtualHand.default()
    assert set(hand.fingers.keys()) == {"thumb", "index", "middle", "palm"}


def test_virtual_hand_move_finger():
    hand = VirtualHand.default()
    hand.move_finger("index", Vector3(y=2.0), dt_s=1.0)
    assert hand.fingers["index"].position.y == 2.0


def test_simulation_step_no_contact_returns_none(device):
    sim = VirtualSimulation(sample_rate=2000)
    sensor = VirtualSensor(position=Vector3(z=10.0))
    result = sim.step(sensor, device)
    assert result is None


def test_simulation_step_with_surface_contact_produces_signal(device):
    sim = VirtualSimulation(sample_rate=2000)
    sim.add_surface(VirtualSurface(material=get_material("METAL"), axis="z", height=0.0))
    sensor = VirtualSensor(position=Vector3(z=-0.2))
    result = sim.step(sensor, device, duration=0.02)
    assert result is not None
    assert len(result.signal) > 0
    assert device.state.is_active


def test_simulation_step_prefers_deepest_contact(device):
    sim = VirtualSimulation(sample_rate=2000)
    sim.add_surface(VirtualSurface(material=get_material("SAND"), axis="z", height=0.0))
    sim.add_object(VirtualObject(center=Vector3(z=-1.0), radius=2.0, material=get_material("GLASS")))
    sensor = VirtualSensor(position=Vector3(z=-0.5))
    result = sim.step(sensor, device, duration=0.02)
    assert result is not None
