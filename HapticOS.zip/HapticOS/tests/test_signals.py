import numpy as np
import pytest

from hapticos.core.types import WaveformType
from hapticos.signals.envelope import ADSREnvelope, KeyframeEnvelope
from hapticos.signals.generator import SignalGenerator


def test_sine_length_and_amplitude():
    sig = SignalGenerator.sine(frequency=100, amplitude=0.5, duration=0.1, sample_rate=1000)
    assert len(sig) == 100
    assert np.max(np.abs(sig)) <= 0.5 + 1e-9


def test_sine_frequency_via_zero_crossings():
    sr = 8000
    sig = SignalGenerator.sine(frequency=100, amplitude=1.0, duration=0.5, sample_rate=sr)
    crossings = np.sum(np.diff(np.sign(sig)) != 0)
    approx_freq = crossings / 2 / 0.5
    assert 90 <= approx_freq <= 110


def test_pulse_is_constant():
    sig = SignalGenerator.pulse(amplitude=0.8, duration=0.05, sample_rate=1000)
    assert np.allclose(sig, 0.8)


def test_ramp_monotonic():
    sig = SignalGenerator.ramp(0.0, 1.0, duration=0.1, sample_rate=1000)
    assert np.all(np.diff(sig) >= 0)
    assert sig[0] == pytest.approx(0.0, abs=1e-6)


def test_burst_cycle_count():
    sig = SignalGenerator.burst(frequency=50, amplitude=1.0, cycles=4, sample_rate=8000)
    expected_duration = 4 / 50
    assert len(sig) == pytest.approx(expected_duration * 8000, abs=2)


def test_click_decays():
    sig = SignalGenerator.click(amplitude=1.0, duration=0.01, sample_rate=8000)
    assert sig[0] == pytest.approx(1.0, abs=1e-6)
    envelope = np.abs(sig)
    assert envelope[0] >= envelope[-1]


def test_sweep_changes_frequency():
    sig = SignalGenerator.sweep(f0=50, f1=400, amplitude=1.0, duration=0.2, sample_rate=8000)
    assert len(sig) == 1600
    assert np.max(np.abs(sig)) <= 1.0 + 1e-9


def test_impact_matches_keyframe_shape():
    sig = SignalGenerator.impact(carrier_frequency=None, sample_rate=1000)
    # keyframes: 0->0, 10ms->1.0, 30ms->0.7, 80ms->0.0
    assert sig[0] == pytest.approx(0.0, abs=0.05)
    peak_idx = int(np.argmax(sig))
    assert 5 <= peak_idx <= 15  # near the 10ms peak
    assert sig[-1] == pytest.approx(0.0, abs=0.05)


def test_apply_duty_cycle_gates_signal():
    sig = np.ones(100)
    gated = SignalGenerator.apply_duty_cycle(sig, duty_cycle=0.5, period_samples=10)
    assert np.isclose(gated.mean(), 0.5, atol=0.05)


def test_apply_envelope_scales_signal():
    sig = np.ones(100)
    env = np.linspace(0, 1, 10)
    out = SignalGenerator.apply_envelope(sig, env)
    assert out[0] == pytest.approx(0.0, abs=1e-6)
    assert out[-1] == pytest.approx(1.0, abs=1e-6)


def test_generate_dispatch_matches_direct_call():
    a = SignalGenerator.generate(WaveformType.SINE, frequency=100, amplitude=0.5, duration=0.1, sample_rate=1000)
    b = SignalGenerator.sine(100, 0.5, 0.1, sample_rate=1000)
    assert np.allclose(a, b)


def test_generate_unsupported_raises():
    with pytest.raises(ValueError):
        SignalGenerator.generate(WaveformType.CUSTOM, duration=0.01)


def test_adsr_envelope_shape():
    env = ADSREnvelope(attack_s=0.01, decay_s=0.01, sustain_level=0.5, release_s=0.02)
    rendered = env.render(duration_s=0.1, sample_rate=1000)
    assert rendered[0] == pytest.approx(0.0, abs=0.05)
    assert np.max(rendered) == pytest.approx(1.0, abs=0.05)
    assert rendered[-1] == pytest.approx(0.0, abs=0.05)


def test_keyframe_envelope_render():
    env = KeyframeEnvelope([(0, 0.0), (10, 1.0), (30, 0.7), (80, 0.0)])
    rendered = env.render(sample_rate=1000)
    assert len(rendered) == 80
    # last sample is at t=79ms (endpoint=False), just shy of the 80ms->0.0
    # keyframe, so it should be small but not necessarily exactly zero.
    assert rendered[-1] == pytest.approx(0.0, abs=0.02)
