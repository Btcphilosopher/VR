import numpy as np

from hapticos.recorder.recorder import HapticRecorder, HapticRecording, RecordedSample
from hapticos.core.types import Vector3


def test_record_virtual_produces_deterministic_samples(device):
    device.play(frequency=150, amplitude=0.6, duration=0.05)
    recorder = HapticRecorder(device)
    recording = recorder.record_virtual(n_samples=5, dt_s=0.01)
    assert len(recording.samples) == 5
    assert recording.device_id == "test_device"
    assert all(s.actuator == "test_device" for s in recording.samples)


def test_recorder_start_sample_stop_flow(device):
    recorder = HapticRecorder(device)
    recorder.start()
    assert recorder.is_recording
    device.play(frequency=100, amplitude=0.4, duration=0.02)
    sample = recorder.sample_once()
    assert isinstance(sample, RecordedSample)
    recording = recorder.stop()
    assert not recorder.is_recording
    assert len(recording.samples) == 1


def test_recording_to_signal():
    recording = HapticRecording(
        device_id="d",
        samples=[
            RecordedSample(
                timestamp=0, actuator="d", amplitude=0.1, frequency=100,
                position=Vector3(), force=Vector3(), temperature_c=25,
            ),
            RecordedSample(
                timestamp=1, actuator="d", amplitude=0.5, frequency=100,
                position=Vector3(), force=Vector3(), temperature_c=25,
            ),
        ],
    )
    signal = recording.to_signal()
    assert np.allclose(signal, [0.1, 0.5])


def test_recording_json_roundtrip(tmp_path):
    recording = HapticRecording(
        device_id="d",
        samples=[
            RecordedSample(
                timestamp=0, actuator="d", amplitude=0.3, frequency=120,
                position=Vector3(x=1), force=Vector3(), temperature_c=26,
            )
        ],
    )
    path = tmp_path / "rec.json"
    recording.save_json(path)
    loaded = HapticRecording.load_json(path)
    assert loaded == recording


def test_recording_csv_export(tmp_path):
    recording = HapticRecording(
        device_id="d",
        samples=[
            RecordedSample(
                timestamp=0, actuator="d", amplitude=0.3, frequency=120,
                position=Vector3(), force=Vector3(), temperature_c=26,
            )
        ],
    )
    path = tmp_path / "rec.csv"
    recording.save_csv(path)
    content = path.read_text()
    assert "amplitude" in content.splitlines()[0]
    assert "0.3" in content


def test_compare_recordings():
    a = HapticRecording(device_id="d", samples=[
        RecordedSample(timestamp=0, actuator="d", amplitude=0.5, frequency=100, position=Vector3(), force=Vector3(), temperature_c=25)
    ])
    b = HapticRecording(device_id="d", samples=[
        RecordedSample(timestamp=0, actuator="d", amplitude=0.5, frequency=100, position=Vector3(), force=Vector3(), temperature_c=25)
    ])
    result = HapticRecorder.compare(a, b)
    assert result["correlation"] >= 0.99 or result["mse"] < 1e-6


def test_replay_plays_each_sample(device):
    recording = HapticRecording(device_id=device.device_id, samples=[
        RecordedSample(timestamp=0, actuator=device.device_id, amplitude=0.4, frequency=120, position=Vector3(), force=Vector3(), temperature_c=25),
        RecordedSample(timestamp=1, actuator=device.device_id, amplitude=0.6, frequency=140, position=Vector3(), force=Vector3(), temperature_c=25),
    ])
    rendered = HapticRecorder.replay(recording, device)
    assert len(rendered) == 2
