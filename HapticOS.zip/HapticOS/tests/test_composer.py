import numpy as np
import pytest

from hapticos.composer.composer import HapticComposer
from hapticos.composer.profile import HapticProfile
from hapticos.core.types import WaveformType


def test_combine_sums_signals():
    a = np.array([0.1, 0.2, 0.3])
    b = np.array([0.1, 0.1, 0.1])
    combined = HapticComposer.combine(a, b, normalize=False)
    assert np.allclose(combined, [0.2, 0.3, 0.4])


def test_combine_pads_different_lengths():
    a = np.array([1.0, 1.0, 1.0, 1.0])
    b = np.array([1.0])
    combined = HapticComposer.combine(a, b, normalize=False)
    assert len(combined) == 4
    assert combined[0] == 2.0
    assert combined[-1] == 1.0


def test_combine_normalizes_when_clipping():
    a = np.array([1.0, 1.0])
    b = np.array([1.0, 1.0])
    combined = HapticComposer.combine(a, b, normalize=True)
    assert np.max(np.abs(combined)) <= 1.0 + 1e-9


def test_combine_renders_profiles():
    p1 = HapticProfile(name="a", waveform=WaveformType.PULSE, amplitude=0.5, duration=0.01)
    p2 = HapticProfile(name="b", waveform=WaveformType.PULSE, amplitude=0.3, duration=0.01)
    combined = HapticComposer.combine(p1, p2, sample_rate=1000, normalize=False)
    assert np.allclose(combined, 0.8)


def test_profile_save_and_load_roundtrip(tmp_path):
    profile = HapticProfile(name="click", waveform=WaveformType.CLICK, amplitude=0.9, duration=0.02)
    path = tmp_path / "click.haptic"
    profile.save(path)
    loaded = HapticProfile.load(path)
    assert loaded == profile


def test_composer_registers_and_lists_profiles():
    composer = HapticComposer()
    composer.register(HapticProfile(name="p1"))
    composer.register(HapticProfile(name="p2"))
    assert composer.list_profiles() == ["p1", "p2"]


def test_composer_get_missing_raises():
    composer = HapticComposer()
    with pytest.raises(KeyError):
        composer.get("nonexistent")


def test_composer_save_profile_to_library(tmp_path):
    composer = HapticComposer(library_dir=tmp_path)
    profile = HapticProfile(name="saved_profile", waveform=WaveformType.SINE, amplitude=0.5, duration=0.05)
    path = composer.save_profile(profile)
    assert path.exists()
    reloaded_composer = HapticComposer(library_dir=tmp_path)
    assert "saved_profile" in reloaded_composer.list_profiles()


def test_compose_named_material_contact_example():
    composer = HapticComposer()
    composer.register(HapticProfile(name="IMPACT", waveform=WaveformType.IMPACT, amplitude=0.8, duration=0.08))
    composer.register(HapticProfile(name="ROUGH_TEXTURE", waveform=WaveformType.TEXTURE, amplitude=0.4, duration=0.08))
    composer.register(
        HapticProfile(name="LOW_FREQUENCY_PULSE", waveform=WaveformType.PULSE, frequency=30, amplitude=0.3, duration=0.08)
    )
    composite = composer.compose_named(
        "MATERIAL_CONTACT", "IMPACT", "ROUGH_TEXTURE", "LOW_FREQUENCY_PULSE", sample_rate=2000
    )
    assert composite.name == "MATERIAL_CONTACT"
    assert composite.extra["raw_samples"]
    rendered = composite.render(sample_rate=2000)
    assert len(rendered) > 0
    assert np.max(np.abs(rendered)) <= 1.0 + 1e-9
