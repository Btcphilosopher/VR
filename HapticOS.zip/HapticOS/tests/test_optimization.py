from hapticos.core.types import WaveformType
from hapticos.optimization.optimizer import HapticOptimizer, OptimizationObjective, OptimizationResult


def test_optimize_returns_result_within_bounds(capabilities):
    optimizer = HapticOptimizer(capabilities)
    result = optimizer.optimize(OptimizationObjective(), waveform=WaveformType.SINE)
    assert isinstance(result, OptimizationResult)
    assert capabilities.min_frequency_hz <= result.frequency <= capabilities.max_frequency_hz
    assert capabilities.min_amplitude <= result.amplitude <= capabilities.max_amplitude
    assert 0 < result.duration <= capabilities.max_duration_s
    assert len(result.signal) > 0


def test_optimize_energy_minimizing_prefers_lower_amplitude(capabilities):
    optimizer = HapticOptimizer(capabilities)
    energy_heavy = optimizer.optimize(
        OptimizationObjective(
            maximize_perceptual_distinction=0.0, minimize_energy=5.0, minimize_duration=0.0, minimize_actuator_stress=0.0
        )
    )
    distinction_heavy = optimizer.optimize(
        OptimizationObjective(
            maximize_perceptual_distinction=5.0, minimize_energy=0.0, minimize_duration=0.0, minimize_actuator_stress=0.0
        )
    )
    assert energy_heavy.amplitude <= distinction_heavy.amplitude + 0.2
