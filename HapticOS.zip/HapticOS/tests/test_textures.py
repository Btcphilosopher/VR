import numpy as np

from hapticos.textures.texture import Texture, TextureEngine


def test_noise_texture_roughness_scales_amplitude():
    smooth = TextureEngine.generate_noise_texture(roughness=0.1, duration=0.1, sample_rate=2000, seed=1)
    rough = TextureEngine.generate_noise_texture(roughness=0.9, duration=0.1, sample_rate=2000, seed=1)
    assert np.max(np.abs(rough)) >= np.max(np.abs(smooth))


def test_periodic_texture_smooth_is_silent():
    sig = TextureEngine.generate_periodic_texture("smooth", spatial_frequency=10, duration=0.1)
    assert np.all(sig == 0.0)


def test_periodic_texture_ridged_alternates():
    sig = TextureEngine.generate_periodic_texture("ridged", spatial_frequency=20, duration=0.1, sample_rate=2000)
    assert set(np.unique(sig)).issubset({-1.0, 0.0, 1.0})
    assert np.any(sig > 0) and np.any(sig < 0)


def test_procedural_texture_uses_custom_function():
    sig = TextureEngine.procedural(lambda t: np.sin(t), duration=0.1, sample_rate=1000)
    assert len(sig) == 100


def test_from_recording_passthrough():
    original = np.array([0.1, 0.2, 0.3])
    sig = TextureEngine.from_recording(original)
    assert np.allclose(sig, original)


def test_render_ascii_produces_string_of_expected_width():
    sig = np.linspace(0, 1, 100)
    ascii_str = TextureEngine.render_ascii(sig, width=20)
    assert len(ascii_str) == 20


def test_texture_render_for_velocity_changes_with_speed():
    base = np.sin(np.linspace(0, 20 * np.pi, 1000))
    texture = Texture(name="test", base_signal=base)
    slow = texture.render_for_velocity(velocity=0.2, duration=0.1, sample_rate=1000)
    fast = texture.render_for_velocity(velocity=2.0, duration=0.1, sample_rate=1000)
    assert len(slow) == len(fast) == 100
    assert not np.allclose(slow, fast)
