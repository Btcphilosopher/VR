# HapticOS

**A general-purpose Python engine for haptic simulation, modelling, signal
generation and optimisation.**

HapticOS translates digital events, physical simulations and user
interactions into force, vibration, pressure and tactile feedback. It runs
entirely in software — a full "digital laboratory" for haptics — and is
architected so its timing-critical layers can migrate to a Rust/C++ runtime
later without disturbing the Python modelling/authoring layer above them.

```
User / Simulation
      |
Interaction Model
      |
Haptic Physics
      |
Signal Generator
      |
Device Driver
      |
Haptic Actuator
      |
Human Touch
     (loop)
```

## Why it's architected this way

Every subsystem talks to the next through a small, typed interface
(Pydantic models, an abstract `HapticDriver`), so:

- **Simulation Mode needs zero hardware.** `SimulatedDriver` is the default
  driver for every `HapticDevice`; the same `.play()` / `.contact()` calls
  drive a virtual actuator in CI or a real one on your desk.
- **Physics is explicitly a simplified model.** Contact, friction and
  collision formulas here are tuned for perceptual plausibility and
  real-time performance, not validated against physical measurement — see
  the docstrings in `hapticos/physics/`.
- **Safety is a hard floor, not a suggestion.** `HapticDevice.play()` always
  routes through `SafetyMonitor` before touching a driver; passing
  simulation is *not* proof a real actuator won't overheat.
- **The timing-critical layer is separable.** `HapticTimeline` splits a
  deterministic virtual-clock executor (for tests/simulation) from a
  real-time executor — exactly the seam a future Rust/C++ scheduler would
  replace.

## Install

```bash
pip install -e .                 # core engine
pip install -e ".[hardware]"     # + pyserial / pyaudio for real devices
pip install -e ".[dev]"          # + pytest, httpx for the test suite
```

Requires Python 3.10+ (developed and tested against 3.11; the spec's
target is 3.13+ — the code has no 3.13-only syntax).

## Quick start

```python
from hapticos import HapticDevice, WaveformType

device = HapticDevice("controller_01")
device.connect()
device.play(frequency=150, amplitude=0.7, duration=0.2, waveform=WaveformType.SINE)
```

```python
from hapticos.materials.material import Material
from hapticos.physics.contact import HapticPhysicsEngine

surface = Material(name="varnished_oak", stiffness=0.8, friction=0.4, roughness=0.7)
engine = HapticPhysicsEngine()
result = engine.contact(surface, force=0.6, velocity=0.2)
device.driver.send_signal(result.signal, result.sample_rate)
```

Run the FastAPI/WebSocket server and open the built-in dashboard:

```bash
uvicorn hapticos.api.server:app --reload
# then open http://127.0.0.1:8000/
```

## Package layout

| Package                 | Spec section                     | What it does                                                  |
|--------------------------|-----------------------------------|-----------------------------------------------------------------|
| `hapticos.core`          | 1, 9, 17                          | `HapticDevice`, `DeviceState`/`DeviceCapabilities`, event bus   |
| `hapticos.signals`       | 2, 12                             | Waveform generators, envelopes, FFT/spectrogram/analysis        |
| `hapticos.materials`     | 3                                  | `Material` + WOOD/METAL/GLASS/RUBBER/FABRIC/STONE/ICE/SAND/LIQUID |
| `hapticos.physics`       | 4, 5                               | Contact/friction/collision + spring-damper force feedback       |
| `hapticos.textures`      | 6                                  | Procedural noise/periodic/custom textures, ASCII preview        |
| `hapticos.actuators`     | 7                                  | `ActuatorGroup` — multi-actuator arrays, spatial patterns       |
| `hapticos.temporal`      | 8                                  | `HapticTimeline` — ms-precise virtual & real-time scheduling    |
| `hapticos.composer`      | 10                                 | `.haptic` profile format + combining patterns                   |
| `hapticos.recorder`      | 11                                 | Record/replay/save/compare device telemetry                     |
| `hapticos.optimization`  | 13                                 | Objective-driven pattern optimisation (`scipy.optimize`)         |
| `hapticos.calibration`   | 14                                 | Min-activation/frequency-response/latency/thermal routines      |
| `hapticos.latency`       | 15                                 | End-to-end latency, jitter, benchmarking                        |
| `hapticos.simulation`    | 16                                 | Virtual hand/object/surface — full pipeline, no hardware        |
| `hapticos.drivers`       | 1, 20                              | `SimulatedDriver` (deterministic, CI-safe), `SerialDriver`, `AudioDriver` |
| `hapticos.safety`        | 19                                 | Amplitude/duration/temperature/force/duty-cycle limits, e-stop  |
| `hapticos.runtime`       | final architecture                | `HapticRuntime` — wires physics + signals + events together     |
| `hapticos.api`           | 17, 18                             | FastAPI REST + WebSocket, built-in dashboard                    |

## Examples

`examples/` has one runnable script per major subsystem (`01_basic_playback.py`
through `15_api_client_demo.py`), each with a short docstring pointing back
to the relevant spec section.

## Testing

```bash
pytest
```

142 tests cover signal generation, physics, force-feedback, textures,
temporal scheduling, events, the composer, recorder, calibration, latency
benchmarking, simulation mode, safety limits and the HTTP/WebSocket API —
all against the deterministic `SimulatedDriver`, so the suite needs no
physical hardware and no network access.

## Safety notice

`hapticos.safety` enforces configurable amplitude/duration/temperature/
force/duty-cycle limits and an emergency stop before any signal reaches a
driver. This is necessary but not sufficient for real hardware: simulation
passing these checks does not prove a physical actuator is safe under
sustained real-world drive. Pair it with hardware-level protection (fuses,
thermal cutoffs, mechanical stops) before deploying to real devices.
