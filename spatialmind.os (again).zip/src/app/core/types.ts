// ============================================================================
// SPATIALMIND.OS - CORE SPATIAL TYPES & ENUMS
// Machine Intelligence for Spatial Computing (VR/AR/MR)
// ============================================================================

export type TimestampMicros = number; // Microseconds epoch/monotonic
export type UUID = string;

// 9. Coordinate Frames
export enum CoordinateFrame {
  DEVICE = 'DEVICE',
  HEAD = 'HEAD',
  EYE_LEFT = 'EYE_LEFT',
  EYE_RIGHT = 'EYE_RIGHT',
  HAND_LEFT = 'HAND_LEFT',
  HAND_RIGHT = 'HAND_RIGHT',
  CONTROLLER_LEFT = 'CONTROLLER_LEFT',
  CONTROLLER_RIGHT = 'CONTROLLER_RIGHT',
  CAMERA = 'CAMERA',
  IMU = 'IMU',
  WORLD = 'WORLD',
  LOCAL = 'LOCAL',
  OBJECT = 'OBJECT',
  ANCHOR = 'ANCHOR'
}

// Vector 3D
export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

// Quaternion 4D
export interface Quat {
  x: number;
  y: number;
  z: number;
  w: number;
}

// 79. Strongly typed Spatial Data Types
export interface SpatialPose {
  timestamp: TimestampMicros;
  frame: CoordinateFrame;
  position: Vec3;
  orientation: Quat;
  confidence: number; // 0.0 - 1.0
  covariance: number[][]; // 6x6 pose covariance matrix
}

export interface SpatialVelocity {
  linear: Vec3; // m/s
  angular: Vec3; // rad/s
}

export interface SpatialAcceleration {
  linear: Vec3; // m/s^2
  angular: Vec3; // rad/s^2
}

// 6. Sensor Timeline Sample
export enum SensorType {
  IMU_6DOF = 'sensor_imu_6dof',
  CAMERA_STEREO = 'sensor_rgb_stereo',
  LIDAR_TOF = 'sensor_depth_lidar',
  EYE_TRACKER_IR = 'sensor_eye_ir',
  HAND_CAMERAS = 'sensor_hand_mono'
}

export interface SensorSample {
  sensor_id: string;
  sensor_type: 'IMU' | 'RGB_CAMERA' | 'DEPTH_LIDAR' | 'EYE_TRACKER' | 'HAND_TRACKER' | 'CONTROLLER' | 'AUDIO_ARRAY' | 'SPATIAL_ANCHOR';
  timestamp: TimestampMicros;
  sequence_number: number;
  coordinate_frame: CoordinateFrame;
  payload: any;
  quality: number; // 0.0 - 1.0
  calibration_version: string;
  latency_ms: number;
}

// 50. Sensor Health State
export interface SensorHealth {
  sensor_id: string;
  sensor_type: string;
  availability: boolean;
  noise_level: number; // RMS noise
  drop_rate: number; // 0.0 - 1.0
  latency_ms: number;
  calibration_state: 'CALIBRATED' | 'DEGRADED' | 'UNCALIBRATED';
  temperature_c: number;
  quality: number; // 0.0 - 1.0
  fault_injected?: string | null;
}

// 11. Spatial Object Model
export enum SemanticClass {
  TABLE = 'TABLE',
  CHAIR = 'CHAIR',
  WALL = 'WALL',
  DOOR = 'DOOR',
  WINDOW = 'WINDOW',
  SCREEN = 'SCREEN',
  PERSON = 'PERSON',
  HAND = 'HAND',
  FLOOR = 'FLOOR',
  CEILING = 'CEILING',
  VEHICLE = 'VEHICLE',
  CONTROLLER = 'CONTROLLER',
  OBSTACLE = 'OBSTACLE',
  CUSTOM = 'CUSTOM'
}

export interface BoundingVolume {
  type: 'BOX' | 'SPHERE' | 'CYLINDER' | 'ORIENTED_BOX';
  center: Vec3;
  extents: Vec3; // width, height, depth
  orientation: Quat;
}

export interface SpatialObject {
  id: string;
  class_name: SemanticClass;
  position: Vec3;
  orientation: Quat;
  scale: Vec3;
  velocity: Vec3;
  bounding_volume: BoundingVolume;
  mesh_reference?: string;
  semantic_label: string;
  confidence: number;
  last_seen: TimestampMicros;
  tracking_state: 'TRACKED' | 'OCCLUDED' | 'PREDICTED' | 'LOST';
  anchor_id?: string;
  embedding?: number[];
  color?: string;
}

// 23. Spatial Relationships
export enum SpatialRelationship {
  ABOVE = 'ABOVE',
  BELOW = 'BELOW',
  LEFT_OF = 'LEFT_OF',
  RIGHT_OF = 'RIGHT_OF',
  NEAR = 'NEAR',
  FAR = 'FAR',
  INSIDE = 'INSIDE',
  OUTSIDE = 'OUTSIDE',
  ON = 'ON',
  UNDER = 'UNDER',
  BEHIND = 'BEHIND',
  IN_FRONT_OF = 'IN_FRONT_OF',
  CONNECTED_TO = 'CONNECTED_TO',
  OCCUPIED_BY = 'OCCUPIED_BY'
}

export interface SceneEdge {
  source_id: string;
  target_id: string;
  relationship: SpatialRelationship;
  confidence: number;
  distance_meters: number;
}

export interface SceneGraph {
  world_id: string;
  nodes: SpatialObject[];
  edges: SceneEdge[];
  last_updated: TimestampMicros;
}

// 17. Eye-Gaze State
export interface GazeState {
  timestamp: TimestampMicros;
  origin: Vec3;
  direction: Vec3;
  target_point: Vec3;
  confidence: number;
  vergence_distance: number; // meters
  velocity_deg_per_sec: number;
  duration_ms: number;
  fixation_state: 'FIXATION' | 'SACCADE' | 'SMOOTH_PURSUIT';
  looked_at_object_id?: string | null;
  attention_score: number; // 0.0 - 1.0
}

// 18. Hand Intent & Joint Tracking
export enum GestureType {
  PINCH = 'PINCH',
  GRAB = 'GRAB',
  POINT = 'POINT',
  OPEN_HAND = 'OPEN_HAND',
  FIST = 'FIST',
  SWIPE = 'SWIPE',
  ROTATE = 'ROTATE',
  TAP = 'TAP',
  DRAG = 'DRAG',
  RELEASE = 'RELEASE',
  IDLE = 'IDLE'
}

export interface HandJoint {
  id: number;
  name: string;
  position: Vec3;
  orientation: Quat;
  confidence: number;
}

export interface HandState {
  hand: 'LEFT' | 'RIGHT';
  is_tracked: boolean;
  joints: HandJoint[]; // 21 standard XR joints
  palm_position: Vec3;
  palm_orientation: Quat;
  velocity: Vec3;
  gesture: GestureType;
  pinch_distance: number; // meters (between thumb tip and index tip)
  confidence: number;
}

// 19. User Intent Model
export interface UserIntent {
  timestamp: TimestampMicros;
  primary_intent: string;
  confidence: number;
  target_object_id: string | null;
  candidate_actions: {
    action: string;
    probability: number;
    description: string;
  }[];
  trigger_signals: {
    gaze_signal: string;
    hand_signal: string;
    head_signal: string;
    context_signal: string;
  };
  explanation: string;
}

// 40. Context State
export interface ContextState {
  timestamp: TimestampMicros;
  location_type: 'DESK_WORKSPACE' | 'OPEN_ROOM' | 'MEETING_SPACE' | 'VEHICLE' | 'OUTDOOR';
  user_activity: 'SITTING' | 'STANDING' | 'WALKING' | 'REACHING' | 'CONVERSING';
  lighting_lux: number;
  active_application: string;
  interaction_mode: 'DIRECT_MANIPULATION' | 'RAYCAST_POINT' | 'GAZE_PINCH' | 'VOICE_SPATIAL';
  device_battery_percent: number;
  thermal_state: 'NOMINAL' | 'ELEVATED' | 'THROTTLED';
}

// 28. Spatial Anchor
export interface SpatialAnchor {
  id: string;
  name: string;
  pose: SpatialPose;
  confidence: number;
  persistence_type: 'PERSISTENT' | 'SESSION' | 'SHARED' | 'LOCAL';
  semantic_context: string;
  created_at: TimestampMicros;
  reconfirmed_at: TimestampMicros;
}

// 10. Spatial World Model
export interface SpatialWorld {
  world_id: string;
  origin: Vec3;
  anchors: SpatialAnchor[];
  scene_graph: SceneGraph;
  planes: {
    id: string;
    type: 'HORIZONTAL_UP' | 'HORIZONTAL_DOWN' | 'VERTICAL';
    center: Vec3;
    extents: { width: number; height: number };
    normal: Vec3;
  }[];
  rooms: {
    id: string;
    name: string;
    boundary: Vec3[];
  }[];
  dynamic_entities: SpatialObject[];
  lighting_estimates: {
    intensity_lumens: number;
    color_temp_kelvin: number;
    primary_light_direction: Vec3;
  };
}

// 15 & 16. Motion & Pose Prediction
export interface PredictedPose {
  timestamp: TimestampMicros;
  prediction_horizon_ms: number; // e.g. 20ms, 40ms, 60ms
  frame: CoordinateFrame;
  predicted_position: Vec3;
  predicted_orientation: Quat;
  predicted_velocity: Vec3;
  confidence: number;
  model_used: 'POLYNOMIAL_EXTRAPOLATION' | 'KALMAN_PREDICTOR' | 'TRANSFORMER_TEMPORAL_ML';
}

// 46. Safety Boundary & Collision Engine
export interface SafetyState {
  risk_level: 'SAFE' | 'CAUTION' | 'HIGH_RISK';
  confidence: number;
  closest_obstacle_id: string | null;
  time_to_impact_sec: number;
  distance_to_boundary_m: number;
  recommended_response: string;
  collision_ray: { origin: Vec3; direction: Vec3; length: number };
}

// 30. Latency Engine Metrics
export interface LatencyBreakdown {
  sensor_capture_ms: number;
  sync_and_calibration_ms: number;
  preprocessing_ms: number;
  inference_ms: number;
  sensor_fusion_ms: number;
  temporal_prediction_ms: number;
  scene_update_ms: number;
  render_submission_ms: number;
  total_motion_to_photon_ms: number;
  target_budget_ms: number;
  budget_met: boolean;
}

// 31. Real-Time Scheduler Task Priorities
export enum TaskPriority {
  CRITICAL = 'CRITICAL',     // 500 Hz Head/IMU Pose
  HIGH = 'HIGH',             // 120 Hz Hands & Eye Gaze
  NORMAL = 'NORMAL',         // 30 Hz Object Detection & World Mesh
  BACKGROUND = 'BACKGROUND'  // 5 Hz Long-term Memory & Embeddings
}

export interface ScheduledTask {
  name: string;
  priority: TaskPriority;
  target_frequency_hz: number;
  actual_frequency_hz: number;
  last_execution_micros: TimestampMicros;
  execution_duration_us: number;
  state: 'RUNNING' | 'IDLE' | 'SKIPPED_LOAD_SHED';
}

// 32. Model Quantisation & 52. Model Registry
export enum QuantizationFormat {
  FP32 = 'FP32',
  FP16 = 'FP16',
  BF16 = 'BF16',
  INT8 = 'INT8'
}

export enum PowerMode {
  PERFORMANCE = 'PERFORMANCE',
  BALANCED = 'BALANCED',
  BATTERY = 'BATTERY',
  ULTRA_LOW_POWER = 'ULTRA_LOW_POWER'
}

export interface MLModelProfile {
  id: string;
  name: string;
  task_category: 'OBJECT_DETECTION' | 'POSE_ESTIMATION' | 'HAND_TRACKING' | 'GAZE_ATTENTION' | 'INTENT_PREDICTION' | 'DEPTH_ESTIMATION';
  backend_engine: 'ONNX_RUNTIME' | 'CANDLE' | 'BURN' | 'TFLITE' | 'WEBGPU' | 'CUSTOM_NPU';
  quantization: QuantizationFormat;
  model_size_mb: number;
  typical_latency_ms: number;
  accuracy_map: number; // Mean Average Precision / Accuracy score
  power_draw_watts: number;
  device_target: 'CPU' | 'GPU' | 'NPU' | 'DSP';
  is_active: boolean;
  version: string;
}

// 76. Spatial Device Digital Twin State
export interface DigitalTwinState {
  headset_model: string;
  battery_level: number; // 0-100%
  battery_temp_c: number;
  soc_temperature_c: number;
  thermal_throttling: boolean;
  active_power_mode: PowerMode;
  gpu_utilization_pct: number;
  npu_utilization_pct: number;
  cpu_utilization_pct: number;
  memory_used_mb: number;
  memory_total_mb: number;
  power_consumption_watts: number;
  fps: number;
}

// 82. Replay Session Frame
export interface ReplayFrame {
  frame_index: number;
  timestamp: TimestampMicros;
  head_pose: SpatialPose;
  predicted_head_pose: PredictedPose;
  gaze_state: GazeState;
  left_hand: HandState;
  right_hand: HandState;
  detected_objects: SpatialObject[];
  user_intent: UserIntent;
  safety: SafetyState;
  latency: LatencyBreakdown;
  active_events: string[];
}

export interface SpatialSession {
  session_id: string;
  session_name: string;
  started_at: TimestampMicros;
  duration_seconds: number;
  total_frames: number;
  frames: ReplayFrame[];
}
