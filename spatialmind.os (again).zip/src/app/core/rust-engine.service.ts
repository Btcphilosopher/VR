import { Injectable, signal, computed } from '@angular/core';
import {
  CoordinateFrame,
  GazeState,
  HandState,
  HandJoint,
  GestureType,
  LatencyBreakdown,
  MLModelProfile,
  PowerMode,
  PredictedPose,
  QuantizationFormat,
  ReplayFrame,
  SafetyState,
  ScheduledTask,
  SemanticClass,
  SensorHealth,
  SensorSample,
  SpatialAnchor,
  SpatialObject,
  SpatialPose,
  SpatialRelationship,
  SpatialSession,
  SpatialWorld,
  TaskPriority,
  TimestampMicros,
  UserIntent,
  Vec3,
  Quat,
  DigitalTwinState
} from './types';

@Injectable({
  providedIn: 'root'
})
export class RustEngineService {
  // Engine execution state
  readonly isRunning = signal<boolean>(true);
  readonly isReplaying = signal<boolean>(false);
  readonly replayIndex = signal<number>(0);
  readonly replayPlaybackSpeed = signal<number>(1.0);
  readonly simulationEnvironment = signal<'DESK_WORKSPACE' | 'VR_LAB' | 'FACTORY_FLOOR' | 'STREET_AR'>('DESK_WORKSPACE');

  // Timestamps & Ticks
  readonly currentTimestampMicros = signal<TimestampMicros>(Date.now() * 1000);
  readonly totalTicks = signal<number>(0);

  // 1. Primary Spatial Pose (Fused by EKF)
  readonly headPose = signal<SpatialPose>({
    timestamp: Date.now() * 1000,
    frame: CoordinateFrame.HEAD,
    position: { x: 0.0, y: 1.65, z: 0.4 },
    orientation: { x: 0, y: 0, z: 0, w: 1 },
    confidence: 0.99,
    covariance: [
      [1e-4, 0, 0, 0, 0, 0],
      [0, 1e-4, 0, 0, 0, 0],
      [0, 0, 1e-4, 0, 0, 0],
      [0, 0, 0, 1e-4, 0, 0],
      [0, 0, 0, 0, 1e-4, 0],
      [0, 0, 0, 0, 0, 1e-4]
    ]
  });

  // 2. Predicted Head Pose (Forward extrapolated)
  readonly predictedHeadPose = signal<PredictedPose>({
    timestamp: Date.now() * 1000 + 40000,
    prediction_horizon_ms: 40,
    frame: CoordinateFrame.HEAD,
    predicted_position: { x: 0.02, y: 1.652, z: 0.395 },
    predicted_orientation: { x: 0.005, y: 0.012, z: 0.001, w: 0.999 },
    predicted_velocity: { x: 0.05, y: 0.01, z: -0.08 },
    confidence: 0.96,
    model_used: 'KALMAN_PREDICTOR'
  });

  // 3. Eye Gaze State
  readonly gazeState = signal<GazeState>({
    timestamp: Date.now() * 1000,
    origin: { x: 0.0, y: 1.65, z: 0.4 },
    direction: { x: 0.15, y: -0.22, z: -0.96 },
    target_point: { x: 0.25, y: 1.15, z: -0.95 },
    confidence: 0.97,
    vergence_distance: 1.35,
    velocity_deg_per_sec: 4.2,
    duration_ms: 640,
    fixation_state: 'FIXATION',
    looked_at_object_id: 'obj_screen_primary',
    attention_score: 0.94
  });

  // 4. Hand States (Left & Right with 21 articulated joints)
  readonly rightHand = signal<HandState>(this.generateHandJoints('RIGHT', { x: 0.22, y: 1.25, z: -0.45 }, GestureType.PINCH, 0.018));
  readonly leftHand = signal<HandState>(this.generateHandJoints('LEFT', { x: -0.28, y: 1.18, z: -0.42 }, GestureType.OPEN_HAND, 0.085));

  // 5. Detected 3D Spatial Objects
  readonly spatialObjects = signal<SpatialObject[]>([
    {
      id: 'obj_screen_primary',
      class_name: SemanticClass.SCREEN,
      position: { x: 0.0, y: 1.35, z: -1.2 },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      scale: { x: 1.2, y: 0.75, z: 0.04 },
      velocity: { x: 0, y: 0, z: 0 },
      bounding_volume: {
        type: 'BOX',
        center: { x: 0.0, y: 1.35, z: -1.2 },
        extents: { x: 1.2, y: 0.75, z: 0.04 },
        orientation: { x: 0, y: 0, z: 0, w: 1 }
      },
      semantic_label: 'UltraWide Virtual Workspace Screen',
      confidence: 0.98,
      last_seen: Date.now() * 1000,
      tracking_state: 'TRACKED',
      color: '#06b6d4'
    },
    {
      id: 'obj_desk_main',
      class_name: SemanticClass.TABLE,
      position: { x: 0.0, y: 0.75, z: -1.0 },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      scale: { x: 1.8, y: 0.75, z: 0.9 },
      velocity: { x: 0, y: 0, z: 0 },
      bounding_volume: {
        type: 'BOX',
        center: { x: 0.0, y: 0.75, z: -1.0 },
        extents: { x: 1.8, y: 0.75, z: 0.9 },
        orientation: { x: 0, y: 0, z: 0, w: 1 }
      },
      semantic_label: 'Workstation Desk Surface',
      confidence: 0.99,
      last_seen: Date.now() * 1000,
      tracking_state: 'TRACKED',
      color: '#3b82f6'
    },
    {
      id: 'obj_laptop',
      class_name: SemanticClass.CUSTOM,
      position: { x: -0.35, y: 0.8, z: -0.85 },
      orientation: { x: 0, y: 0.1, z: 0, w: 0.995 },
      scale: { x: 0.32, y: 0.22, z: 0.25 },
      velocity: { x: 0, y: 0, z: 0 },
      bounding_volume: {
        type: 'BOX',
        center: { x: -0.35, y: 0.8, z: -0.85 },
        extents: { x: 0.32, y: 0.22, z: 0.25 },
        orientation: { x: 0, y: 0.1, z: 0, w: 0.995 }
      },
      semantic_label: 'MacBook Pro Host Bridge',
      confidence: 0.95,
      last_seen: Date.now() * 1000,
      tracking_state: 'TRACKED',
      color: '#a855f7'
    },
    {
      id: 'obj_chair_office',
      class_name: SemanticClass.CHAIR,
      position: { x: 0.0, y: 0.5, z: 0.3 },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      scale: { x: 0.65, y: 0.95, z: 0.65 },
      velocity: { x: 0, y: 0, z: 0 },
      bounding_volume: {
        type: 'BOX',
        center: { x: 0.0, y: 0.5, z: 0.3 },
        extents: { x: 0.65, y: 0.95, z: 0.65 },
        orientation: { x: 0, y: 0, z: 0, w: 1 }
      },
      semantic_label: 'Ergonomic Task Chair',
      confidence: 0.94,
      last_seen: Date.now() * 1000,
      tracking_state: 'TRACKED',
      color: '#10b981'
    },
    {
      id: 'obj_spatial_window_notes',
      class_name: SemanticClass.WINDOW,
      position: { x: 0.75, y: 1.45, z: -0.9 },
      orientation: { x: 0, y: -0.35, z: 0, w: 0.936 },
      scale: { x: 0.6, y: 0.55, z: 0.02 },
      velocity: { x: 0, y: 0, z: 0 },
      bounding_volume: {
        type: 'BOX',
        center: { x: 0.75, y: 1.45, z: -0.9 },
        extents: { x: 0.6, y: 0.55, z: 0.02 },
        orientation: { x: 0, y: -0.35, z: 0, w: 0.936 }
      },
      semantic_label: 'Spatial Telemetry HUD',
      confidence: 0.99,
      last_seen: Date.now() * 1000,
      tracking_state: 'TRACKED',
      color: '#f59e0b'
    }
  ]);

  // 6. Spatial Anchors
  readonly spatialAnchors = signal<SpatialAnchor[]>([
    {
      id: 'anchor_origin_world',
      name: 'World Reference Grid 0,0,0',
      pose: {
        timestamp: Date.now() * 1000,
        frame: CoordinateFrame.WORLD,
        position: { x: 0, y: 0, z: 0 },
        orientation: { x: 0, y: 0, z: 0, w: 1 },
        confidence: 1.0,
        covariance: [[0]]
      },
      confidence: 1.0,
      persistence_type: 'PERSISTENT',
      semantic_context: 'Root room coordinate origin on floor center',
      created_at: Date.now() * 1000 - 3600000000,
      reconfirmed_at: Date.now() * 1000
    },
    {
      id: 'anchor_desk_corner',
      name: 'Primary Desk Alignment Pin',
      pose: {
        timestamp: Date.now() * 1000,
        frame: CoordinateFrame.ANCHOR,
        position: { x: 0.9, y: 0.75, z: -0.55 },
        orientation: { x: 0, y: 0, z: 0, w: 1 },
        confidence: 0.99,
        covariance: [[0]]
      },
      confidence: 0.99,
      persistence_type: 'PERSISTENT',
      semantic_context: 'Fixed optical fiducial anchor on physical desk corner',
      created_at: Date.now() * 1000 - 1800000000,
      reconfirmed_at: Date.now() * 1000
    }
  ]);

  // 7. Multimodal User Intent State
  readonly userIntent = signal<UserIntent>({
    timestamp: Date.now() * 1000,
    primary_intent: 'MANIPULATE_OBJECT',
    confidence: 0.94,
    target_object_id: 'obj_screen_primary',
    candidate_actions: [
      {
        action: 'MANIPULATE_OBJECT',
        probability: 0.94,
        description: 'Pinch gesture engaged while fixating on UltraWide Virtual Workspace Screen'
      },
      {
        action: 'QUERY_SPATIAL_METADATA',
        probability: 0.04,
        description: 'Point and dwell for detailed 3D spatial properties'
      },
      {
        action: 'AMBIENT_OBSERVE',
        probability: 0.02,
        description: 'Ambient visual scanning across spatial scene'
      }
    ],
    trigger_signals: {
      gaze_signal: 'FIXATION on obj_screen_primary (dur: 640ms, conf: 0.97)',
      hand_signal: 'PINCH detected on RIGHT hand (gap: 1.8cm, vel: 0.03m/s)',
      head_signal: 'STABLE orientation (angular rate: 0.02 rad/s)',
      context_signal: 'DESK_WORKSPACE / DIRECT_MANIPULATION mode'
    },
    explanation: 'High confidence intentional grab/move initiated via simultaneous Gaze fixation and Index-Thumb pinch.'
  });

  // 8. Predictive Safety & Collision Engine
  readonly safetyState = signal<SafetyState>({
    risk_level: 'SAFE',
    confidence: 0.98,
    closest_obstacle_id: 'obj_desk_main',
    time_to_impact_sec: 14.8,
    distance_to_boundary_m: 1.25,
    recommended_response: 'NOMINAL - Head velocity clear of obstacle envelope',
    collision_ray: {
      origin: { x: 0.0, y: 1.65, z: 0.4 },
      direction: { x: 0.05, y: 0.01, z: -0.08 },
      length: 1.45
    }
  });

  // 9. Sensor Health Monitor (Supports Fault Injection)
  readonly sensorHealthMap = signal<SensorHealth[]>([
    {
      sensor_id: 'sensor_imu_6dof',
      sensor_type: 'IMU (Accel + Gyro)',
      availability: true,
      noise_level: 0.0024,
      drop_rate: 0.0,
      latency_ms: 0.4,
      calibration_state: 'CALIBRATED',
      temperature_c: 36.2,
      quality: 0.99
    },
    {
      sensor_id: 'sensor_rgb_stereo',
      sensor_type: 'Stereo RGB Camera',
      availability: true,
      noise_level: 0.012,
      drop_rate: 0.001,
      latency_ms: 6.2,
      calibration_state: 'CALIBRATED',
      temperature_c: 41.5,
      quality: 0.97
    },
    {
      sensor_id: 'sensor_depth_lidar',
      sensor_type: 'Time-of-Flight Depth LiDAR',
      availability: true,
      noise_level: 0.008,
      drop_rate: 0.0,
      latency_ms: 8.5,
      calibration_state: 'CALIBRATED',
      temperature_c: 38.9,
      quality: 0.98
    },
    {
      sensor_id: 'sensor_eye_ir',
      sensor_type: 'Dual IR Eye Trackers',
      availability: true,
      noise_level: 0.004,
      drop_rate: 0.0,
      latency_ms: 2.1,
      calibration_state: 'CALIBRATED',
      temperature_c: 34.8,
      quality: 0.98
    },
    {
      sensor_id: 'sensor_hand_mono',
      sensor_type: 'Wide-Angle Hand Cameras',
      availability: true,
      noise_level: 0.009,
      drop_rate: 0.002,
      latency_ms: 5.4,
      calibration_state: 'CALIBRATED',
      temperature_c: 39.1,
      quality: 0.96
    }
  ]);

  // 10. Real-Time Scheduler Multi-Rate Priorities
  readonly scheduledTasks = signal<ScheduledTask[]>([
    {
      name: 'HEAD_POSE_IMU_FUSION',
      priority: TaskPriority.CRITICAL,
      target_frequency_hz: 500,
      actual_frequency_hz: 498.4,
      last_execution_micros: Date.now() * 1000,
      execution_duration_us: 340,
      state: 'RUNNING'
    },
    {
      name: 'HAND_JOINT_KINEMATICS',
      priority: TaskPriority.HIGH,
      target_frequency_hz: 120,
      actual_frequency_hz: 119.8,
      last_execution_micros: Date.now() * 1000,
      execution_duration_us: 1820,
      state: 'RUNNING'
    },
    {
      name: 'EYE_GAZE_ATTENTION',
      priority: TaskPriority.HIGH,
      target_frequency_hz: 120,
      actual_frequency_hz: 120.0,
      last_execution_micros: Date.now() * 1000,
      execution_duration_us: 780,
      state: 'RUNNING'
    },
    {
      name: 'SCENE_OBJECT_DETECTOR',
      priority: TaskPriority.NORMAL,
      target_frequency_hz: 30,
      actual_frequency_hz: 29.9,
      last_execution_micros: Date.now() * 1000,
      execution_duration_us: 8450,
      state: 'RUNNING'
    },
    {
      name: 'SPATIAL_MEMORY_EMBEDDINGS',
      priority: TaskPriority.BACKGROUND,
      target_frequency_hz: 5,
      actual_frequency_hz: 5.0,
      last_execution_micros: Date.now() * 1000,
      execution_duration_us: 14200,
      state: 'RUNNING'
    }
  ]);

  // 11. Latency Engine Metrics (Motion-to-Photon)
  readonly latencyBreakdown = signal<LatencyBreakdown>({
    sensor_capture_ms: 1.2,
    sync_and_calibration_ms: 0.4,
    preprocessing_ms: 0.8,
    inference_ms: 3.5,
    sensor_fusion_ms: 0.6,
    temporal_prediction_ms: 0.3,
    scene_update_ms: 0.5,
    render_submission_ms: 1.1,
    total_motion_to_photon_ms: 8.4,
    target_budget_ms: 11.1, // 90 Hz budget is 11.1ms, 120 Hz is 8.3ms
    budget_met: true
  });

  // 12. Model Registry & Adaptive Router
  readonly activePowerMode = signal<PowerMode>(PowerMode.PERFORMANCE);
  readonly modelRegistry = signal<MLModelProfile[]>([
    {
      id: 'model_spatial_det_v4',
      name: 'SpatialNet-3D-YOLOv4',
      task_category: 'OBJECT_DETECTION',
      backend_engine: 'ONNX_RUNTIME',
      quantization: QuantizationFormat.FP16,
      model_size_mb: 24.8,
      typical_latency_ms: 3.4,
      accuracy_map: 0.942,
      power_draw_watts: 2.8,
      device_target: 'NPU',
      is_active: true,
      version: 'v4.2.1'
    },
    {
      id: 'model_pose_ekf_transformer',
      name: 'PoseTransformer-Temporal',
      task_category: 'POSE_ESTIMATION',
      backend_engine: 'CANDLE',
      quantization: QuantizationFormat.FP32,
      model_size_mb: 8.4,
      typical_latency_ms: 0.8,
      accuracy_map: 0.988,
      power_draw_watts: 0.9,
      device_target: 'GPU',
      is_active: true,
      version: 'v2.0.0'
    },
    {
      id: 'model_hand_mesh_21j',
      name: 'ArticulatedHandNet-21',
      task_category: 'HAND_TRACKING',
      backend_engine: 'BURN',
      quantization: QuantizationFormat.FP16,
      model_size_mb: 16.2,
      typical_latency_ms: 1.8,
      accuracy_map: 0.965,
      power_draw_watts: 1.4,
      device_target: 'NPU',
      is_active: true,
      version: 'v3.1.0'
    },
    {
      id: 'model_gaze_vergence_net',
      name: 'GazeVergence-DualIR',
      task_category: 'GAZE_ATTENTION',
      backend_engine: 'TFLITE',
      quantization: QuantizationFormat.INT8,
      model_size_mb: 4.1,
      typical_latency_ms: 0.6,
      accuracy_map: 0.971,
      power_draw_watts: 0.4,
      device_target: 'DSP',
      is_active: true,
      version: 'v1.8.4'
    },
    {
      id: 'model_intent_bayesian_net',
      name: 'MultimodalIntent-Transformer',
      task_category: 'INTENT_PREDICTION',
      backend_engine: 'ONNX_RUNTIME',
      quantization: QuantizationFormat.FP16,
      model_size_mb: 12.0,
      typical_latency_ms: 1.2,
      accuracy_map: 0.938,
      power_draw_watts: 1.1,
      device_target: 'GPU',
      is_active: true,
      version: 'v2.5.0'
    }
  ]);

  // 13. Digital Twin Hardware Telemetry
  readonly digitalTwin = signal<DigitalTwinState>({
    headset_model: 'SPATIALMIND Reference DevKit Pro',
    battery_level: 86,
    battery_temp_c: 32.4,
    soc_temperature_c: 44.8,
    thermal_throttling: false,
    active_power_mode: PowerMode.PERFORMANCE,
    gpu_utilization_pct: 42,
    npu_utilization_pct: 68,
    cpu_utilization_pct: 28,
    memory_used_mb: 1420,
    memory_total_mb: 8192,
    power_consumption_watts: 6.8,
    fps: 119.6
  });

  // 14. Spatial Time Machine & Recorded Session
  readonly recordedSession = signal<SpatialSession>({
    session_id: 'session_demo_rec_01',
    session_name: 'Interactive Gaze & Pinch Spatial Manipulation Test',
    started_at: Date.now() * 1000 - 120000000,
    duration_seconds: 120,
    total_frames: 120,
    frames: []
  });

  // Event stream for terminal / HUD logs
  readonly eventStream = signal<{ timestamp: string; level: 'INFO' | 'WARN' | 'CRIT'; message: string; module: string }[]>([
    { timestamp: '00:00:00.001', level: 'INFO', module: 'spatial-core', message: 'SPATIALMIND.OS Rust Engine Booted. Zero-copy ring buffers initialized.' },
    { timestamp: '00:00:00.004', level: 'INFO', module: 'fusion', message: '6-DoF EKF active on IMU + Stereo Cameras @ 500 Hz.' },
    { timestamp: '00:00:00.008', level: 'INFO', module: 'scheduler', message: 'Real-time scheduler online. Critical tracking budget locked at 1800 us.' },
    { timestamp: '00:00:00.012', level: 'INFO', module: 'model-router', message: 'Model Router active: PERFORMANCE mode selected. NPU + GPU compute devices claimed.' },
    { timestamp: '00:00:00.020', level: 'INFO', module: 'scene', message: 'Spatial World constructed: 5 objects, 2 anchors, 7 topological relationships.' }
  ]);

  private timerInterval: any = null;
  private animationTime = 0;

  constructor() {
    this.generateSampleReplayFrames();
    this.startEngineLoop();
  }

  startEngineLoop() {
    if (this.timerInterval) return;
    this.timerInterval = setInterval(() => {
      if (!this.isRunning()) return;

      if (this.isReplaying()) {
        this.stepReplayFrame();
      } else {
        this.stepLiveSimulation();
      }
    }, 33); // ~30 fps UI update of the 500Hz/120Hz internal pipeline
  }

  stopEngineLoop() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  togglePause() {
    this.isRunning.update(v => !v);
  }

  setPowerMode(mode: PowerMode) {
    this.activePowerMode.set(mode);
    this.digitalTwin.update(dt => ({
      ...dt,
      active_power_mode: mode,
      power_consumption_watts: mode === PowerMode.PERFORMANCE ? 7.2 : mode === PowerMode.BALANCED ? 4.8 : mode === PowerMode.BATTERY ? 3.1 : 1.9,
      soc_temperature_c: mode === PowerMode.PERFORMANCE ? 48.2 : mode === PowerMode.BALANCED ? 41.0 : mode === PowerMode.BATTERY ? 36.5 : 32.1
    }));
    this.logEvent('INFO', 'model-router', `Power mode transitioned to ${mode}. Model frequencies & quantisation updated.`);
  }

  // Sensor Control Helpers
  setSensorStatus(sensorIdOrType: string, faultStatus: 'DEGRADED' | 'OFFLINE' | 'RESTORE') {
    if (faultStatus === 'RESTORE') {
      this.injectSensorFault(sensorIdOrType, 'RESTORE');
    } else if (faultStatus === 'OFFLINE') {
      this.injectSensorFault(sensorIdOrType, 'DISCONNECT');
    } else {
      this.injectSensorFault(sensorIdOrType, 'DRIFT');
    }
  }

  restoreAllSensors() {
    this.sensorHealthMap.update(sensors =>
      sensors.map(s => ({
        ...s,
        availability: true,
        calibration_state: 'CALIBRATED',
        noise_level: 0.002,
        drop_rate: 0.0,
        quality: 0.99,
        fault_injected: null
      }))
    );
    this.logEvent('INFO', 'sensor-core', 'All sensor channels re-calibrated and fully restored.');
  }

  // Spatial Time Machine Helpers
  readonly isRecordingLive = computed(() => !this.isReplaying());
  readonly recordedFrames = computed(() => this.recordedSession().frames);
  readonly playbackSpeed = computed(() => this.replayPlaybackSpeed());

  togglePlayPause() {
    if (this.isReplaying()) {
      this.togglePause();
    } else {
      this.isReplaying.set(true);
      this.replayIndex.set(0);
    }
  }

  resumeLive() {
    this.isReplaying.set(false);
    this.isRunning.set(true);
  }

  setPlaybackSpeed(speed: number) {
    this.replayPlaybackSpeed.set(speed);
  }

  seekToFrame(index: number) {
    this.isReplaying.set(true);
    this.scrubToFrame(index);
  }

  injectSensorFault(sensorId: string, faultType: 'DISCONNECT' | 'DRIFT' | 'NOISE_SPIKE' | 'RESTORE') {
    this.sensorHealthMap.update(sensors => {
      return sensors.map(s => {
        if (s.sensor_id === sensorId) {
          if (faultType === 'RESTORE') {
            return {
              ...s,
              availability: true,
              calibration_state: 'CALIBRATED',
              noise_level: 0.002,
              quality: 0.99,
              fault_injected: null
            };
          } else if (faultType === 'DISCONNECT') {
            return {
              ...s,
              availability: false,
              calibration_state: 'UNCALIBRATED',
              quality: 0.0,
              fault_injected: 'DISCONNECTED'
            };
          } else if (faultType === 'DRIFT') {
            return {
              ...s,
              calibration_state: 'DEGRADED',
              noise_level: 0.085,
              quality: 0.45,
              fault_injected: 'CLOCK_AND_BIAS_DRIFT'
            };
          } else {
            return {
              ...s,
              noise_level: 0.12,
              quality: 0.62,
              fault_injected: 'NOISE_SPIKE'
            };
          }
        }
        return s;
      });
    });

    if (faultType === 'RESTORE') {
      this.logEvent('INFO', 'sensor-core', `Sensor ${sensorId} recovered. Calibrated and restored to primary fusion pipeline.`);
    } else {
      this.logEvent('WARN', 'fusion', `Sensor anomaly on ${sensorId}: ${faultType}. Fusion engine gracefully degraded.`);
    }
  }

  // Live simulation tick
  private stepLiveSimulation() {
    this.animationTime += 0.033;
    const t = this.animationTime;
    const now = Date.now() * 1000;

    this.currentTimestampMicros.set(now);
    this.totalTicks.update(ticks => ticks + 1);

    // 1. Oscillate Head in continuous realistic spatial motion
    const headX = Math.sin(t * 0.8) * 0.08;
    const headY = 1.65 + Math.sin(t * 1.2) * 0.03;
    const headZ = 0.4 + Math.cos(t * 0.8) * 0.05;
    const headRotY = Math.sin(t * 0.6) * 0.06;

    const currentHeadPose: SpatialPose = {
      timestamp: now,
      frame: CoordinateFrame.HEAD,
      position: { x: headX, y: headY, z: headZ },
      orientation: { x: 0, y: Math.sin(headRotY / 2), z: 0, w: Math.cos(headRotY / 2) },
      confidence: 0.99,
      covariance: [
        [1e-4, 0, 0, 0, 0, 0],
        [0, 1e-4, 0, 0, 0, 0],
        [0, 0, 1e-4, 0, 0, 0],
        [0, 0, 0, 1e-4, 0, 0],
        [0, 0, 0, 0, 1e-4, 0],
        [0, 0, 0, 0, 0, 1e-4]
      ]
    };
    this.headPose.set(currentHeadPose);

    // 2. Predict Head 40ms forward
    const predDt = 0.04;
    const velX = Math.cos(t * 0.8) * 0.08 * 0.8;
    const velY = Math.cos(t * 1.2) * 0.03 * 1.2;
    const velZ = -Math.sin(t * 0.8) * 0.05 * 0.8;

    this.predictedHeadPose.set({
      timestamp: now + predDt * 1000000,
      prediction_horizon_ms: 40,
      frame: CoordinateFrame.HEAD,
      predicted_position: {
        x: headX + velX * predDt,
        y: headY + velY * predDt,
        z: headZ + velZ * predDt
      },
      predicted_orientation: currentHeadPose.orientation,
      predicted_velocity: { x: velX, y: velY, z: velZ },
      confidence: 0.96,
      model_used: 'KALMAN_PREDICTOR'
    });

    // 3. Move Hand in interactive reach & pinch
    const pinchPhase = (Math.sin(t * 1.5) + 1) / 2; // 0 to 1
    const handX = 0.18 + Math.sin(t * 1.1) * 0.08;
    const handY = 1.22 + Math.cos(t * 1.3) * 0.05;
    const handZ = -0.45 + Math.sin(t * 0.9) * 0.12;
    const isPinching = pinchPhase > 0.65;
    const pinchGap = isPinching ? 0.015 : 0.065;

    this.rightHand.set(
      this.generateHandJoints(
        'RIGHT',
        { x: handX, y: handY, z: handZ },
        isPinching ? GestureType.PINCH : GestureType.POINT,
        pinchGap
      )
    );

    // 4. Update Gaze target
    const gazeLookScreen = Math.sin(t * 0.5) > -0.2;
    const targetObjId = gazeLookScreen ? 'obj_screen_primary' : 'obj_laptop';
    const targetPos = gazeLookScreen ? { x: 0.0, y: 1.35, z: -1.2 } : { x: -0.35, y: 0.8, z: -0.85 };

    const dir = {
      x: targetPos.x - headX,
      y: targetPos.y - headY,
      z: targetPos.z - headZ
    };
    const len = Math.sqrt(dir.x * dir.x + dir.y * dir.y + dir.z * dir.z);

    this.gazeState.set({
      timestamp: now,
      origin: { x: headX, y: headY, z: headZ },
      direction: { x: dir.x / len, y: dir.y / len, z: dir.z / len },
      target_point: targetPos,
      confidence: 0.97,
      vergence_distance: len,
      velocity_deg_per_sec: Math.abs(Math.cos(t)) * 3.5,
      duration_ms: Math.floor((t % 2.5) * 1000),
      fixation_state: Math.abs(Math.cos(t)) > 0.8 ? 'SACCADE' : 'FIXATION',
      looked_at_object_id: targetObjId,
      attention_score: isPinching && gazeLookScreen ? 0.98 : 0.78
    });

    // 5. Update Intent
    if (isPinching && gazeLookScreen) {
      this.userIntent.set({
        timestamp: now,
        primary_intent: 'MANIPULATE_OBJECT',
        confidence: 0.95,
        target_object_id: 'obj_screen_primary',
        candidate_actions: [
          { action: 'MANIPULATE_OBJECT', probability: 0.95, description: 'Direct pinch-to-move virtual screen window' },
          { action: 'RESIZE_WINDOW', probability: 0.04, description: 'Dual-hand corner grab' },
          { action: 'DISMISS', probability: 0.01, description: 'Quick outward flick' }
        ],
        trigger_signals: {
          gaze_signal: `FIXATION on obj_screen_primary (dist: ${len.toFixed(2)}m)`,
          hand_signal: `PINCH on RIGHT hand (gap: ${(pinchGap * 100).toFixed(1)}cm)`,
          head_signal: 'STABLE frame alignment',
          context_signal: 'DESK_WORKSPACE'
        },
        explanation: 'User is fixating on the primary virtual screen while closing index & thumb in direct manipulation gesture.'
      });
    } else {
      this.userIntent.set({
        timestamp: now,
        primary_intent: 'FOCUS_INSPECT',
        confidence: 0.82,
        target_object_id: targetObjId,
        candidate_actions: [
          { action: 'FOCUS_INSPECT', probability: 0.82, description: `Visual inspection of ${targetObjId}` },
          { action: 'AMBIENT_SCAN', probability: 0.15, description: 'Peripheral workspace scanning' },
          { action: 'PREPARE_GESTURE', probability: 0.03, description: 'Hand approaching interaction zone' }
        ],
        trigger_signals: {
          gaze_signal: `Dwell on ${targetObjId}`,
          hand_signal: 'OPEN / POINT gesture',
          head_signal: 'Oriented towards workstation',
          context_signal: 'DESK_WORKSPACE'
        },
        explanation: 'User eye gaze is dwelling on workspace object with hand in neutral reach posture.'
      });
    }

    // 6. Update Safety
    const distToDesk = Math.max(0.2, 1.25 - (headZ - 0.4) * 2);
    this.safetyState.set({
      risk_level: distToDesk < 0.4 ? 'CAUTION' : 'SAFE',
      confidence: 0.98,
      closest_obstacle_id: 'obj_desk_main',
      time_to_impact_sec: distToDesk / (Math.abs(velZ) + 0.01),
      distance_to_boundary_m: distToDesk,
      recommended_response: distToDesk < 0.4 ? 'CAUTION - Approaching physical desk plane' : 'NOMINAL - Workspace envelope clear',
      collision_ray: {
        origin: { x: headX, y: headY, z: headZ },
        direction: { x: velX, y: velY, z: velZ },
        length: distToDesk
      }
    });

    // 7. Update Latency Timers slightly
    const infLatency = this.activePowerMode() === PowerMode.PERFORMANCE ? 3.2 : this.activePowerMode() === PowerMode.BALANCED ? 5.1 : 8.4;
    this.latencyBreakdown.set({
      sensor_capture_ms: 1.1 + Math.sin(t * 4) * 0.1,
      sync_and_calibration_ms: 0.4,
      preprocessing_ms: 0.8,
      inference_ms: infLatency + Math.cos(t * 3) * 0.2,
      sensor_fusion_ms: 0.6,
      temporal_prediction_ms: 0.3,
      scene_update_ms: 0.5,
      render_submission_ms: 1.0,
      total_motion_to_photon_ms: 4.7 + infLatency,
      target_budget_ms: 11.1,
      budget_met: 4.7 + infLatency < 11.1
    });
  }

  private stepReplayFrame() {
    const session = this.recordedSession();
    if (session.frames.length === 0) return;

    let idx = this.replayIndex() + 1;
    if (idx >= session.frames.length) {
      idx = 0;
    }
    this.replayIndex.set(idx);
    this.applyReplayFrame(session.frames[idx]);
  }

  scrubToFrame(frameIndex: number) {
    const session = this.recordedSession();
    if (frameIndex >= 0 && frameIndex < session.frames.length) {
      this.replayIndex.set(frameIndex);
      this.applyReplayFrame(session.frames[frameIndex]);
    }
  }

  private applyReplayFrame(frame: ReplayFrame) {
    this.currentTimestampMicros.set(frame.timestamp);
    this.headPose.set(frame.head_pose);
    this.predictedHeadPose.set(frame.predicted_head_pose);
    this.gazeState.set(frame.gaze_state);
    this.leftHand.set(frame.left_hand);
    this.rightHand.set(frame.right_hand);
    this.userIntent.set(frame.user_intent);
    this.safetyState.set(frame.safety);
    this.latencyBreakdown.set(frame.latency);
  }

  logEvent(level: 'INFO' | 'WARN' | 'CRIT', module: string, message: string) {
    const d = new Date();
    const timeStr = `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}:${d.getSeconds().toString().padStart(2, '0')}.${d.getMilliseconds().toString().padStart(3, '0')}`;
    this.eventStream.update(logs => [{ timestamp: timeStr, level, module, message }, ...logs.slice(0, 49)]);
  }

  private generateHandJoints(hand: 'LEFT' | 'RIGHT', palm: Vec3, gesture: GestureType, pinchGap: number): HandState {
    const isRight = hand === 'RIGHT';
    const sign = isRight ? 1 : -1;
    const joints: HandJoint[] = [];

    // 21 standard XR joints
    const jointNames = [
      'WRIST',
      'THUMB_METACARPAL', 'THUMB_PROXIMAL', 'THUMB_DISTAL', 'THUMB_TIP',
      'INDEX_METACARPAL', 'INDEX_PROXIMAL', 'INDEX_INTERMEDIATE', 'INDEX_DISTAL', 'INDEX_TIP',
      'MIDDLE_METACARPAL', 'MIDDLE_PROXIMAL', 'MIDDLE_INTERMEDIATE', 'MIDDLE_DISTAL', 'MIDDLE_TIP',
      'RING_METACARPAL', 'RING_PROXIMAL', 'RING_INTERMEDIATE', 'RING_DISTAL', 'RING_TIP',
      'LITTLE_METACARPAL', 'LITTLE_PROXIMAL', 'LITTLE_INTERMEDIATE', 'LITTLE_DISTAL', 'LITTLE_TIP'
    ];

    joints.push({
      id: 0,
      name: 'WRIST',
      position: { x: palm.x, y: palm.y - 0.05, z: palm.z + 0.03 },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      confidence: 0.98
    });

    // Thumb tip
    joints.push({
      id: 4,
      name: 'THUMB_TIP',
      position: { x: palm.x + sign * 0.03, y: palm.y + 0.04, z: palm.z - 0.05 },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      confidence: 0.96
    });

    // Index tip
    const indexTipZ = gesture === GestureType.PINCH ? palm.z - 0.05 + pinchGap : palm.z - 0.09;
    const indexTipX = gesture === GestureType.PINCH ? palm.x + sign * 0.03 : palm.x + sign * 0.01;
    joints.push({
      id: 9,
      name: 'INDEX_TIP',
      position: { x: indexTipX, y: palm.y + 0.05, z: indexTipZ },
      orientation: { x: 0, y: 0, z: 0, w: 1 },
      confidence: 0.97
    });

    return {
      hand,
      is_tracked: true,
      joints,
      palm_position: palm,
      palm_orientation: { x: 0, y: 0, z: 0, w: 1 },
      velocity: { x: 0.02 * sign, y: 0.01, z: -0.04 },
      gesture,
      pinch_distance: pinchGap,
      confidence: 0.97
    };
  }

  private generateSampleReplayFrames() {
    const frames: ReplayFrame[] = [];
    const baseTime = Date.now() * 1000 - 120000000;

    for (let i = 0; i < 120; i++) {
      const t = i * 0.1;
      const headX = Math.sin(t * 0.8) * 0.08;
      const headY = 1.65 + Math.sin(t * 1.2) * 0.03;
      const headZ = 0.4 + Math.cos(t * 0.8) * 0.05;

      const pinchPhase = (Math.sin(t * 1.5) + 1) / 2;
      const isPinching = pinchPhase > 0.65;
      const pinchGap = isPinching ? 0.015 : 0.065;

      const hp: SpatialPose = {
        timestamp: baseTime + i * 1000000,
        frame: CoordinateFrame.HEAD,
        position: { x: headX, y: headY, z: headZ },
        orientation: { x: 0, y: 0, z: 0, w: 1 },
        confidence: 0.99,
        covariance: [[1e-4]]
      };

      frames.push({
        frame_index: i,
        timestamp: baseTime + i * 1000000,
        head_pose: hp,
        predicted_head_pose: {
          timestamp: baseTime + i * 1000000 + 40000,
          prediction_horizon_ms: 40,
          frame: CoordinateFrame.HEAD,
          predicted_position: { x: headX + 0.01, y: headY, z: headZ - 0.01 },
          predicted_orientation: { x: 0, y: 0, z: 0, w: 1 },
          predicted_velocity: { x: 0.04, y: 0, z: -0.05 },
          confidence: 0.96,
          model_used: 'KALMAN_PREDICTOR'
        },
        gaze_state: {
          timestamp: baseTime + i * 1000000,
          origin: { x: headX, y: headY, z: headZ },
          direction: { x: 0.1, y: -0.2, z: -0.9 },
          target_point: { x: 0, y: 1.35, z: -1.2 },
          confidence: 0.97,
          vergence_distance: 1.4,
          velocity_deg_per_sec: 3.2,
          duration_ms: 500 + i * 10,
          fixation_state: 'FIXATION',
          looked_at_object_id: 'obj_screen_primary',
          attention_score: isPinching ? 0.98 : 0.75
        },
        left_hand: this.generateHandJoints('LEFT', { x: -0.25, y: 1.15, z: -0.4 }, GestureType.OPEN_HAND, 0.08),
        right_hand: this.generateHandJoints('RIGHT', { x: 0.2, y: 1.25, z: -0.45 }, isPinching ? GestureType.PINCH : GestureType.POINT, pinchGap),
        detected_objects: this.spatialObjects(),
        user_intent: {
          timestamp: baseTime + i * 1000000,
          primary_intent: isPinching ? 'MANIPULATE_OBJECT' : 'FOCUS_INSPECT',
          confidence: isPinching ? 0.95 : 0.84,
          target_object_id: 'obj_screen_primary',
          candidate_actions: [
            { action: isPinching ? 'MANIPULATE_OBJECT' : 'FOCUS_INSPECT', probability: 0.92, description: 'Target interaction' }
          ],
          trigger_signals: {
            gaze_signal: 'FIXATION on obj_screen_primary',
            hand_signal: isPinching ? 'PINCH detected' : 'POINT gesture',
            head_signal: 'NOMINAL',
            context_signal: 'DESK_WORKSPACE'
          },
          explanation: isPinching ? 'Direct manipulation of virtual workspace screen.' : 'Inspection of active window.'
        },
        safety: {
          risk_level: 'SAFE',
          confidence: 0.98,
          closest_obstacle_id: 'obj_desk_main',
          time_to_impact_sec: 12.4,
          distance_to_boundary_m: 1.2,
          recommended_response: 'NOMINAL',
          collision_ray: {
            origin: { x: headX, y: headY, z: headZ },
            direction: { x: 0, y: 0, z: -1 },
            length: 1.2
          }
        },
        latency: {
          sensor_capture_ms: 1.1,
          sync_and_calibration_ms: 0.4,
          preprocessing_ms: 0.8,
          inference_ms: 3.4,
          sensor_fusion_ms: 0.6,
          temporal_prediction_ms: 0.3,
          scene_update_ms: 0.5,
          render_submission_ms: 1.0,
          total_motion_to_photon_ms: 8.1,
          target_budget_ms: 11.1,
          budget_met: true
        },
        active_events: isPinching ? ['PINCH_ENGAGED', 'WINDOW_TRANSFORM_BEGIN'] : ['GAZE_DWELL']
      });
    }

    this.recordedSession.set({
      session_id: 'session_demo_rec_01',
      session_name: 'Interactive Gaze & Pinch Spatial Manipulation Test',
      started_at: baseTime,
      duration_seconds: 120,
      total_frames: 120,
      frames
    });
  }
}
