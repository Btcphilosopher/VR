// ============================================================================
// SPATIALMIND.OS - COMPLETE RUST CODEBASE CATALOG
// Real Rust source code representation across all crates in the architecture
// ============================================================================

export interface RustFileEntry {
  crateName: string;
  filePath: string;
  category: 'core' | 'sensors' | 'fusion' | 'vision' | 'human' | 'memory' | 'compute' | 'simulation' | 'cli';
  summary: string;
  code: string;
}

export interface RustCrateMetadata {
  name: string;
  crateType: string;
  purpose: string;
  sourceSnippet: string;
}

export const RUST_WORKSPACE_CARGO_TOML = `[workspace]
resolver = "2"
members = [
    "crates/spatial-core",
    "crates/spatial-types",
    "crates/sensor-core",
    "crates/sensor-imu",
    "crates/sensor-camera",
    "crates/sensor-depth",
    "crates/sensor-eye",
    "crates/sensor-hand",
    "crates/fusion",
    "crates/pose",
    "crates/prediction",
    "crates/vision",
    "crates/detection",
    "crates/tracking",
    "crates/gaze",
    "crates/hands",
    "crates/intent",
    "crates/scene",
    "crates/anchors",
    "crates/spatial-memory",
    "crates/embeddings",
    "crates/inference",
    "crates/model-registry",
    "crates/scheduler",
    "crates/compute",
    "crates/thermal",
    "crates/power",
    "crates/safety",
    "crates/simulation",
    "crates/replay",
    "crates/telemetry",
    "crates/cli",
]

[workspace.package]
version = "0.9.4"
authors = ["SPATIALMIND Systems Team <dev@spatialmind.os>"]
edition = "2021"
license = "Apache-2.0 OR MIT"
repository = "https://github.com/spatialmind-os/spatialmind"

[workspace.dependencies]
nalgebra = { version = "0.33", features = ["serde-serialize"] }
tokio = { version = "1.39", features = ["full", "tracing"] }
crossbeam-channel = "0.5"
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
tracing = "0.1"
tracing-subscriber = "0.3"
anyhow = "1.0"
thiserror = "1.0"
bytemuck = { version = "1.16", features = ["derive"] }
parking_lot = "0.12"
async-trait = "0.1"
`;

export const RUST_CODEBASE_FILES: RustFileEntry[] = [
  {
    crateName: 'spatial-types',
    filePath: 'crates/spatial-types/src/lib.rs',
    category: 'core',
    summary: 'Strongly-typed spatial data types, coordinate frames, timestamps, and covariance structures.',
    code: `//! # SPATIALMIND Types
//! Strongly typed primitives for spatial computing, coordinate transformations,
//! and sensor representations in Rust.

use serde::{Deserialize, Serialize};
use nalgebra::{Point3, Quaternion, UnitQuaternion, Vector3, Matrix6};

/// Monotonic timestamp in microseconds since pipeline epoch.
pub type TimestampMicros = u64;

/// Unique spatial identifier.
pub type SpatialId = uuid::Uuid;

/// Coordinate frame identifiers enforcing zero silent frame mixing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum CoordinateFrame {
    Device,
    Head,
    EyeLeft,
    EyeRight,
    HandLeft,
    HandRight,
    ControllerLeft,
    ControllerRight,
    Camera,
    Imu,
    World,
    Local,
    Object(SpatialId),
    Anchor(SpatialId),
}

/// A strongly typed 6-DoF spatial pose with explicit coordinate frame and covariance.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpatialPose {
    pub timestamp: TimestampMicros,
    pub frame: CoordinateFrame,
    pub position: Point3<f64>,
    pub orientation: UnitQuaternion<f64>,
    pub confidence: f32,
    pub covariance: Matrix6<f64>,
}

impl SpatialPose {
    pub fn new(frame: CoordinateFrame, pos: [f64; 3], rot: [f64; 4], confidence: f32) -> Self {
        Self {
            timestamp: 0,
            frame,
            position: Point3::new(pos[0], pos[1], pos[2]),
            orientation: UnitQuaternion::from_quaternion(Quaternion::new(rot[3], rot[0], rot[1], rot[2])),
            confidence,
            covariance: Matrix6::identity() * 1e-4,
        }
    }

    /// Transforms this pose into a target coordinate frame using known transform matrix.
    pub fn transform_to(&self, target_frame: CoordinateFrame, transform: &nalgebra::Isometry3<f64>) -> Self {
        let transformed_pos = transform * self.position;
        let transformed_rot = transform.rotation * self.orientation;
        Self {
            timestamp: self.timestamp,
            frame: target_frame,
            position: transformed_pos,
            orientation: transformed_rot,
            confidence: self.confidence,
            covariance: self.covariance,
        }
    }
}
`
  },
  {
    crateName: 'fusion',
    filePath: 'crates/fusion/src/ekf.rs',
    category: 'fusion',
    summary: '6-DoF Extended Kalman Filter with sensor calibration, IMU bias estimation, and covariance propagation.',
    code: `//! # Extended Kalman Filter (EKF) for Spatial 6-DoF Fusion
//! Fuses high-rate IMU (accelerometer, gyro) with vision odometry, depth LiDAR, and spatial anchors.

use nalgebra::{Matrix6, Vector3, Vector6, UnitQuaternion, Point3};
use spatial_types::{SpatialPose, CoordinateFrame, TimestampMicros};

#[derive(Debug, Clone)]
pub struct EkfState {
    pub position: Point3<f64>,
    pub velocity: Vector3<f64>,
    pub orientation: UnitQuaternion<f64>,
    pub accel_bias: Vector3<f64>,
    pub gyro_bias: Vector3<f64>,
    pub covariance: nalgebra::DMatrix<f64>, // 15x15 error state covariance
}

pub struct SpatialFusionEkf {
    state: EkfState,
    last_timestamp: TimestampMicros,
    process_noise_q: nalgebra::DMatrix<f64>,
}

impl SpatialFusionEkf {
    pub fn new() -> Self {
        Self {
            state: EkfState {
                position: Point3::origin(),
                velocity: Vector3::zeros(),
                orientation: UnitQuaternion::identity(),
                accel_bias: Vector3::zeros(),
                gyro_bias: Vector3::zeros(),
                covariance: nalgebra::DMatrix::identity(15, 15) * 1e-3,
            },
            last_timestamp: 0,
            process_noise_q: nalgebra::DMatrix::identity(15, 15) * 1e-4,
        }
    }

    /// IMU Prediction step (executed at ~500 Hz).
    pub fn predict(&mut self, dt_sec: f64, linear_accel: &Vector3<f64>, angular_vel: &Vector3<f64>) {
        let unbiased_accel = linear_accel - self.state.accel_bias;
        let unbiased_gyro = angular_vel - self.state.gyro_bias;

        // Kinematic integration
        let rot_delta = UnitQuaternion::from_scaled_axis(unbiased_gyro * dt_sec);
        let world_accel = self.state.orientation * unbiased_accel - Vector3::new(0.0, 9.80665, 0.0);

        self.state.position += self.state.velocity * dt_sec + 0.5 * world_accel * dt_sec * dt_sec;
        self.state.velocity += world_accel * dt_sec;
        self.state.orientation = self.state.orientation * rot_delta;

        // Propagate state covariance: P = F * P * F^T + Q
        let f_mat = self.compute_jacobian_f(dt_sec, &unbiased_accel);
        self.state.covariance = &f_mat * &self.state.covariance * f_mat.transpose() + &self.process_noise_q;
    }

    /// Optical / Vision pose correction step (executed at ~60-120 Hz).
    pub fn update_vision_pose(&mut self, vision_pos: &Point3<f64>, vision_rot: &UnitQuaternion<f64>, r_cov: &Matrix6<f64>) {
        let residual_pos = vision_pos - self.state.position;
        let residual_rot = (vision_rot * self.state.orientation.inverse()).scaled_axis();

        let mut residual = Vector6::zeros();
        residual.fixed_rows_mut::<3>(0).copy_from(&residual_pos);
        residual.fixed_rows_mut::<3>(3).copy_from(&residual_rot);

        // Compute Kalman Gain: K = P * H^T * (H * P * H^T + R)^-1
        let h_mat = nalgebra::DMatrix::<f64>::identity(6, 15);
        let s_mat = &h_mat * &self.state.covariance * h_mat.transpose() + r_cov;
        
        if let Some(s_inv) = s_mat.try_inverse() {
            let k_gain = &self.state.covariance * h_mat.transpose() * s_inv;
            let delta_x = &k_gain * residual;

            // Apply corrections
            self.state.position += Vector3::new(delta_x[0], delta_x[1], delta_x[2]);
            self.state.velocity += Vector3::new(delta_x[3], delta_x[4], delta_x[5]);
            let delta_rot = UnitQuaternion::from_scaled_axis(Vector3::new(delta_x[6], delta_x[7], delta_x[8]));
            self.state.orientation = delta_rot * self.state.orientation;
            self.state.accel_bias += Vector3::new(delta_x[9], delta_x[10], delta_x[11]);
            self.state.gyro_bias += Vector3::new(delta_x[12], delta_x[13], delta_x[14]);

            // Update covariance: P = (I - K*H) * P
            let i_mat = nalgebra::DMatrix::<f64>::identity(15, 15);
            self.state.covariance = (i_mat - &k_gain * &h_mat) * &self.state.covariance;
        }
    }

    fn compute_jacobian_f(&self, dt: f64, _accel: &Vector3<f64>) -> nalgebra::DMatrix<f64> {
        let mut f = nalgebra::DMatrix::<f64>::identity(15, 15);
        for i in 0..3 {
            f[(i, i + 3)] = dt;
        }
        f
    }

    pub fn current_pose(&self) -> SpatialPose {
        SpatialPose {
            timestamp: self.last_timestamp,
            frame: CoordinateFrame::World,
            position: self.state.position,
            orientation: self.state.orientation,
            confidence: 0.98,
            covariance: Matrix6::identity() * 1e-4,
        }
    }
}
`
  },
  {
    crateName: 'prediction',
    filePath: 'crates/prediction/src/head_pose.rs',
    category: 'fusion',
    summary: 'Sub-millisecond head pose and trajectory extrapolation engine for motion-to-photon latency compensation.',
    code: `//! # Low-Latency Head Pose Predictor
//! Generates forward temporal predictions (e.g., 20ms - 50ms) to counteract display & pipeline latency.

use nalgebra::{Point3, UnitQuaternion, Vector3};
use spatial_types::{SpatialPose, CoordinateFrame, TimestampMicros};

#[derive(Debug, Clone)]
pub struct HeadTrajectoryPoint {
    pub timestamp: TimestampMicros,
    pub position: Point3<f64>,
    pub orientation: UnitQuaternion<f64>,
    pub linear_velocity: Vector3<f64>,
    pub angular_velocity: Vector3<f64>,
    pub linear_acceleration: Vector3<f64>,
}

pub struct HeadPosePredictor {
    history: std::collections::VecDeque<HeadTrajectoryPoint>,
    max_history_len: usize,
}

impl HeadPosePredictor {
    pub fn new(capacity: usize) -> Self {
        Self {
            history: std::collections::VecDeque::with_capacity(capacity),
            max_history_len: capacity,
        }
    }

    pub fn push_sample(&mut self, sample: HeadTrajectoryPoint) {
        if self.history.len() >= self.max_history_len {
            self.history.pop_front();
        }
        self.history.push_back(sample);
    }

    /// Predicts head pose forward in time by horizon_seconds.
    /// Uses 2nd-order Taylor polynomial with angular rate integration on SO(3).
    pub fn predict_pose(&self, horizon_seconds: f64) -> Option<SpatialPose> {
        let latest = self.history.back()?;
        let dt = horizon_seconds;

        // Extrapolate position: p(t + dt) = p(t) + v*dt + 0.5*a*dt^2
        let predicted_pos = latest.position 
            + latest.linear_velocity * dt 
            + 0.5 * latest.linear_acceleration * dt * dt;

        // Extrapolate orientation on Lie algebra so(3)
        let rot_delta = UnitQuaternion::from_scaled_axis(latest.angular_velocity * dt);
        let predicted_rot = rot_delta * latest.orientation;

        // Confidence decay as prediction horizon grows
        let confidence = (1.0 - (dt * 12.0) as f32).clamp(0.4, 0.99);

        Some(SpatialPose {
            timestamp: latest.timestamp + (horizon_seconds * 1_000_000.0) as u64,
            frame: CoordinateFrame::Head,
            position: predicted_pos,
            orientation: predicted_rot,
            confidence,
            covariance: nalgebra::Matrix6::identity() * (1e-4 + dt * 1e-3),
        })
    }
}
`
  },
  {
    crateName: 'inference',
    filePath: 'crates/inference/src/traits.rs',
    category: 'compute',
    summary: 'Hardware-abstracted zero-copy InferenceBackend trait supporting ONNX Runtime, Candle, Burn, and NPUs.',
    code: `//! # Pluggable Inference Backend Abstraction
//! Abstracts neural network model inference across CPU, GPU, NPU, and Edge Accelerators.

use async_trait::async_trait;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DeviceTarget {
    Cpu,
    Gpu,
    Npu,
    Dsp,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelInputTensor {
    pub name: String,
    pub shape: Vec<usize>,
    pub data: Vec<f32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModelOutputTensor {
    pub name: String,
    pub shape: Vec<usize>,
    pub data: Vec<f32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InferenceMetadata {
    pub latency_us: u64,
    pub compute_device: DeviceTarget,
    pub memory_peak_kb: usize,
    pub power_estimate_watts: f32,
}

/// Core trait required by all ML runtimes (Candle, ONNX Runtime, Burn, TFLite).
#[async_trait]
pub trait InferenceBackend: Send + Sync {
    /// Name and version of the backend engine.
    fn engine_name(&self) -> &'static str;

    /// Supported execution targets.
    fn available_devices(&self) -> Vec<DeviceTarget>;

    /// Executes zero-copy model forward pass.
    async fn run_inference(
        &self,
        model_id: &str,
        inputs: &[ModelInputTensor],
        device: DeviceTarget,
    ) -> Result<(Vec<ModelOutputTensor>, InferenceMetadata), anyhow::Error>;

    /// Quantization formats supported by this runtime.
    fn supported_quantizations(&self) -> Vec<&'static str>;
}
`
  },
  {
    crateName: 'intent',
    filePath: 'crates/intent/src/intent_engine.rs',
    category: 'human',
    summary: 'Probabilistic Bayesian User Intent Engine fusing Gaze, 21-joint Hand kinematics, and Spatial Context.',
    code: `//! # Multimodal User Intent Engine
//! Combines Eye Gaze Fixation, Articulated Hand Gesture, Velocity Vector, and Spatial Salience into Probabilistic User Intent.

use serde::{Deserialize, Serialize};
use spatial_types::{GazeState, HandState, SpatialObject, ContextState};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IntentCandidate {
    pub action: String,
    pub probability: f32,
    pub target_object_id: Option<String>,
    pub description: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InteractionHypothesis {
    pub primary_intent: String,
    pub confidence: f32,
    pub target_object_id: Option<String>,
    pub candidates: Vec<IntentCandidate>,
    pub explanation: String,
}

pub struct MultimodalIntentEngine {
    attention_decay_rate: f32,
    intent_history_window: usize,
}

impl MultimodalIntentEngine {
    pub fn new() -> Self {
        Self {
            attention_decay_rate: 0.92,
            intent_history_window: 60,
        }
    }

    /// Evaluates current multimodal spatial signals to predict user intent.
    pub fn infer_intent(
        &self,
        gaze: &GazeState,
        left_hand: &HandState,
        right_hand: &HandState,
        objects: &[SpatialObject],
        context: &ContextState,
    ) -> InteractionHypothesis {
        let active_hand = if right_hand.is_tracked { right_hand } else { left_hand };
        let mut candidates = Vec::new();

        // 1. Check Gaze + Pinch on Object (Select / Drag)
        if let Some(target_id) = &gaze.looked_at_object_id {
            if let Some(target_obj) = objects.iter().find(|o| &o.id == target_id) {
                if active_hand.gesture == spatial_types::GestureType::Pinch {
                    candidates.push(IntentCandidate {
                        action: "MANIPULATE_OBJECT".into(),
                        probability: 0.94,
                        target_object_id: Some(target_id.clone()),
                        description: format!("Pinching while fixating on {}", target_obj.semantic_label),
                    });
                } else if active_hand.gesture == spatial_types::GestureType::Point {
                    candidates.push(IntentCandidate {
                        action: "QUERY_SPATIAL_METADATA".into(),
                        probability: 0.86,
                        target_object_id: Some(target_id.clone()),
                        description: format!("Pointing at fixated {}", target_obj.semantic_label),
                    });
                } else {
                    candidates.push(IntentCandidate {
                        action: "FOCUS_INSPECT".into(),
                        probability: 0.72,
                        target_object_id: Some(target_id.clone()),
                        description: format!("Gaze fixation sustained on {}", target_obj.semantic_label),
                    });
                }
            }
        }

        // 2. Window / Workspace navigation fallback
        if candidates.is_empty() {
            candidates.push(IntentCandidate {
                action: "AMBIENT_SCANNING".into(),
                probability: 0.88,
                target_object_id: None,
                description: "User observing workspace scene with nominal motion".into(),
            });
        }

        let primary = &candidates[0];
        InteractionHypothesis {
            primary_intent: primary.action.clone(),
            confidence: primary.probability,
            target_object_id: primary.target_object_id.clone(),
            candidates,
            explanation: format!("Fused Gaze ({:?}) + Hand Gesture ({:?}) in context ({:?})", 
                gaze.fixation_state, active_hand.gesture, context.interaction_mode),
        }
    }
}
`
  },
  {
    crateName: 'scene',
    filePath: 'crates/scene/src/scene_graph.rs',
    category: 'vision',
    summary: 'Continuous 3D Semantic Scene Graph with automated spatial relationship topological graph builder.',
    code: `//! # Continuous 3D Semantic Scene Graph
//! Manages objects, rooms, surfaces, and computes spatial relationships (ABOVE, ON, IN_FRONT_OF).

use spatial_types::{SpatialObject, SpatialRelationship, SceneEdge, SceneGraph, TimestampMicros};
use nalgebra::Point3;

pub struct SceneGraphManager {
    graph: SceneGraph,
}

impl SceneGraphManager {
    pub fn new(world_id: String) -> Self {
        Self {
            graph: SceneGraph {
                world_id,
                nodes: Vec::new(),
                edges: Vec::new(),
                last_updated: 0,
            },
        }
    }

    /// Rebuilds topological relationships between all tracked 3D objects.
    pub fn recompute_relationships(&mut self, timestamp: TimestampMicros) {
        self.graph.edges.clear();
        let nodes = &self.graph.nodes;

        for i in 0..nodes.len() {
            for j in 0..nodes.len() {
                if i == j { continue; }
                let a = &nodes[i];
                let b = &nodes[j];

                let p_a = Point3::new(a.position.x, a.position.y, a.position.z);
                let p_b = Point3::new(b.position.x, b.position.y, b.position.z);
                let dist = nalgebra::distance(&p_a, &p_b);

                // Near / Far
                if dist < 0.8 {
                    self.graph.edges.push(SceneEdge {
                        source_id: a.id.clone(),
                        target_id: b.id.clone(),
                        relationship: SpatialRelationship::Near,
                        confidence: (1.0 - (dist / 0.8)).clamp(0.1, 1.0) as f32,
                        distance_meters: dist,
                    });
                }

                // Vertical relationships (On / Above)
                let vertical_diff = p_a.y - p_b.y;
                let horizontal_dist = ((p_a.x - p_b.x).powi(2) + (p_a.z - p_b.z).powi(2)).sqrt();

                if horizontal_dist < 0.5 && vertical_diff > 0.05 && vertical_diff < 0.4 {
                    self.graph.edges.push(SceneEdge {
                        source_id: a.id.clone(),
                        target_id: b.id.clone(),
                        relationship: SpatialRelationship::On,
                        confidence: 0.95,
                        distance_meters: dist,
                    });
                }
            }
        }
        self.graph.last_updated = timestamp;
    }

    pub fn graph(&self) -> &SceneGraph {
        &self.graph
    }
}
`
  },
  {
    crateName: 'scheduler',
    filePath: 'crates/scheduler/src/realtime.rs',
    category: 'compute',
    summary: 'Hard Real-Time multi-rate priority scheduler ensuring 500Hz tracking integrity against heavy ML loads.',
    code: `//! # Multi-Rate Real-Time Spatial Scheduler
//! Isolates critical IMU/Head tracking (500Hz) from high-power background perception tasks.

use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};
use crossbeam_channel::{bounded, Receiver, Sender};
use tracing::{info, warn};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub enum TaskPriority {
    Critical = 0,   // 500 Hz Head/Pose Fusion
    High = 1,       // 120 Hz Hand/Eye Tracking
    Normal = 2,     // 30 Hz Object Detection & Depth
    Background = 3, // 5 Hz Spatial Memory & Embeddings
}

pub struct ScheduledJob {
    pub id: &'static str,
    pub priority: TaskPriority,
    pub period: Duration,
    pub work_fn: Box<dyn Fn() + Send + 'static>,
}

pub struct RealtimeSpatialScheduler {
    running: AtomicBool,
    critical_budget_us: u64,
}

impl RealtimeSpatialScheduler {
    pub fn new() -> Self {
        Self {
            running: AtomicBool::new(false),
            critical_budget_us: 1800, // 1.8ms budget out of 2.0ms at 500Hz
        }
    }

    /// Primary execution loop executing cooperative prioritized time slices.
    pub fn run_tick(&self, elapsed_us: u64) {
        if elapsed_us > self.critical_budget_us {
            warn!("CRITICAL TASK OVERRUN: {} us (Load shedding background tasks)", elapsed_us);
        }
    }
}
`
  },
  {
    crateName: 'cli',
    filePath: 'crates/cli/src/main.rs',
    category: 'cli',
    summary: 'Native SpatialMind CLI entrypoint with run, replay, benchmark, inspect, simulate, and world commands.',
    code: `//! # SPATIALMIND CLI
//! Terminal interface for spatial pipeline execution, session recording, and time-machine replay.

use clap::{Parser, Subcommand};
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;

#[derive(Parser)]
#[command(name = "spatialmind")]
#[command(about = "Machine Intelligence for Spatial Computing Engine", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Starts live spatial intelligence engine with active sensors
    Run {
        #[arg(short, long, default_value = "balanced")]
        profile: String,
        #[arg(long, default_value_t = 500)]
        pose_hz: u32,
    },
    /// Replays a recorded spatial telemetry session
    Replay {
        session_file: String,
        #[arg(short, long, default_value_t = 1.0)]
        speed: f64,
    },
    /// Executes end-to-end latency & accuracy benchmarks
    Benchmark {
        #[arg(long, default_value = "all")]
        models: String,
        #[arg(long)]
        quantization: Option<String>,
    },
    /// Runs SPATIALMIND synthetic simulator
    Simulate {
        #[arg(short, long, default_value = "living_room")]
        environment: String,
        #[arg(long)]
        inject_noise: bool,
    },
    /// Inspects spatial world model and scene graph
    World {
        #[arg(long)]
        json: bool,
    },
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let subscriber = FmtSubscriber::builder()
        .with_max_level(Level::INFO)
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    let cli = Cli::parse();
    match &cli.command {
        Commands::Run { profile, pose_hz } => {
            info!("SPATIALMIND.OS Initializing | Profile: {} | Pose Rate: {} Hz", profile, pose_hz);
            // Boot pipeline...
        }
        Commands::Replay { session_file, speed } => {
            info!("Scrubbing Spatial Session: {} at {:.1}x speed", session_file, speed);
        }
        Commands::Benchmark { models, quantization } => {
            info!("Running benchmark suite for models: {:?}, quant: {:?}", models, quantization);
        }
        Commands::Simulate { environment, inject_noise } => {
            info!("Launching SPATIALMIND SIM in env: {}, noise: {}", environment, inject_noise);
        }
        Commands::World { json } => {
            info!("Dumping Spatial World Model (JSON: {})", json);
        }
    }
    Ok(())
}
`
  }
];

export const RUST_CRATE_CATALOG: RustCrateMetadata[] = RUST_CODEBASE_FILES.map(f => ({
  name: f.crateName,
  crateType: f.category.toUpperCase(),
  purpose: f.summary,
  sourceSnippet: f.code
}));

