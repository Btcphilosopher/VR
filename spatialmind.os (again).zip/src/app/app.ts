import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from './core/rust-engine.service';
import { PowerMode } from './core/types';

// Components
import { SpatialViewport } from './components/spatial-viewport/spatial-viewport';
import { PipelineFlow } from './components/pipeline-flow/pipeline-flow';
import { TelemetryPanel } from './components/telemetry-panel/telemetry-panel';
import { IntentInspector } from './components/intent-inspector/intent-inspector';
import { ModelRouterRegistry } from './components/model-router-registry/model-router-registry';
import { SimDigitalTwin } from './components/sim-digital-twin/sim-digital-twin';
import { SpatialTimeMachine } from './components/spatial-time-machine/spatial-time-machine';
import { RustCodeBrowser } from './components/rust-code-browser/rust-code-browser';
import { CliTerminal } from './components/cli-terminal/cli-terminal';

type ActiveTab = 
  | 'SPATIAL_3D' 
  | 'PIPELINE' 
  | 'TELEMETRY' 
  | 'INTENT' 
  | 'MODELS' 
  | 'SIM_TWIN' 
  | 'RUST_CRATES' 
  | 'TERMINAL';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    SpatialViewport,
    PipelineFlow,
    TelemetryPanel,
    IntentInspector,
    ModelRouterRegistry,
    SimDigitalTwin,
    SpatialTimeMachine,
    RustCodeBrowser,
    CliTerminal
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly engine = inject(RustEngineService);
  readonly activeTab = signal<ActiveTab>('SPATIAL_3D');
  readonly PowerMode = PowerMode;

  setTab(tab: ActiveTab) {
    this.activeTab.set(tab);
  }

  resetSpatialWorld() {
    this.engine.restoreAllSensors();
    this.engine.logEvent('INFO', 'system', 'Spatial world re-centered and sensor buffers cleared.');
  }
}
