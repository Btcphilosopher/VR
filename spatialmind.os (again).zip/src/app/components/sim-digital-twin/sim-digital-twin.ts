import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';
import { SensorType } from '../../core/types';

@Component({
  selector: 'app-sim-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-teal-500/10 text-teal-400 border border-teal-500/20">
            <mat-icon class="text-base">science</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Simulation Digital Twin & Fault Injection</h2>
            <p class="text-[10px] text-slate-400 font-mono">Simulated Hardware HAL & Graceful Degradation Testing</p>
          </div>
        </div>

        <button 
          (click)="restoreAllSensors()"
          class="flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-mono font-medium bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 transition-all"
        >
          <mat-icon class="text-xs">restore</mat-icon>
          <span>Restore All Sensors</span>
        </button>
      </div>

      <!-- Environment Preset Selection -->
      <div class="flex flex-col gap-1.5">
        <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Simulation Environment Preset</span>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
          @for (env of environments; track env.id) {
            <button 
              (click)="setEnvironment(env.id)"
              class="p-2.5 rounded-xl border text-left transition-all flex flex-col gap-1"
              [class]="selectedEnv === env.id ? 'bg-cyan-950/50 border-cyan-500 text-cyan-200 shadow-md' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'"
            >
              <div class="flex items-center justify-between">
                <mat-icon class="text-base text-cyan-400">{{ env.icon }}</mat-icon>
                <span class="text-[9px] font-mono px-1 rounded bg-slate-900 text-slate-400">{{ env.scale }}</span>
              </div>
              <strong class="text-xs font-bold mt-1">{{ env.name }}</strong>
              <span class="text-[10px] text-slate-400 leading-tight">{{ env.desc }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Sensor Stream Status & Anomaly Injection Grid -->
      <div class="flex flex-col gap-1.5">
        <div class="flex items-center justify-between">
          <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Live Sensor Stream Health & Fault Injector</span>
          <span class="text-[10px] font-mono text-slate-500">Click to inject failure / restore</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          <!-- IMU -->
          <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-slate-200">6-DoF IMU</span>
              <span class="w-2 h-2 rounded-full" [class]="getSensorStatus(SensorType.IMU_6DOF) === 'ONLINE' ? 'bg-emerald-400' : 'bg-red-500'"></span>
            </div>
            <div class="text-[10px] font-mono text-slate-400">
              <span>Rate: 500 Hz | Noise: ±0.02 m/s²</span>
            </div>
            <div class="flex gap-1 mt-auto pt-1">
              <button 
                (click)="toggleSensorFault(SensorType.IMU_6DOF, 'DEGRADED')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30"
              >Drift Bias</button>
              <button 
                (click)="toggleSensorFault(SensorType.IMU_6DOF, 'OFFLINE')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-red-500/20 text-red-300 border border-red-500/30 hover:bg-red-500/30"
              >Kill IMU</button>
            </div>
          </div>

          <!-- RGB Camera -->
          <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-slate-200">Stereo RGB Cam</span>
              <span class="w-2 h-2 rounded-full" [class]="getSensorStatus(SensorType.CAMERA_STEREO) === 'ONLINE' ? 'bg-emerald-400' : 'bg-red-500'"></span>
            </div>
            <div class="text-[10px] font-mono text-slate-400">
              <span>Rate: 60 FPS | 2048x1536</span>
            </div>
            <div class="flex gap-1 mt-auto pt-1">
              <button 
                (click)="toggleSensorFault(SensorType.CAMERA_STEREO, 'DEGRADED')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30"
              >Occlude</button>
              <button 
                (click)="toggleSensorFault(SensorType.CAMERA_STEREO, 'OFFLINE')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-red-500/20 text-red-300 border border-red-500/30 hover:bg-red-500/30"
              >Drop Frames</button>
            </div>
          </div>

          <!-- Depth LiDAR -->
          <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-slate-200">ToF LiDAR</span>
              <span class="w-2 h-2 rounded-full" [class]="getSensorStatus(SensorType.LIDAR_TOF) === 'ONLINE' ? 'bg-emerald-400' : 'bg-red-500'"></span>
            </div>
            <div class="text-[10px] font-mono text-slate-400">
              <span>Rate: 30 Hz | Range: 0.1 - 5.0m</span>
            </div>
            <div class="flex gap-1 mt-auto pt-1">
              <button 
                (click)="toggleSensorFault(SensorType.LIDAR_TOF, 'DEGRADED')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30"
              >Reflectance Drop</button>
              <button 
                (click)="toggleSensorFault(SensorType.LIDAR_TOF, 'OFFLINE')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-red-500/20 text-red-300 border border-red-500/30 hover:bg-red-500/30"
              >Kill LiDAR</button>
            </div>
          </div>

          <!-- Eye Trackers -->
          <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono font-bold text-slate-200">Dual IR Gaze</span>
              <span class="w-2 h-2 rounded-full" [class]="getSensorStatus(SensorType.EYE_TRACKER_IR) === 'ONLINE' ? 'bg-emerald-400' : 'bg-red-500'"></span>
            </div>
            <div class="text-[10px] font-mono text-slate-400">
              <span>Rate: 120 Hz | Accuracy: ±0.5°</span>
            </div>
            <div class="flex gap-1 mt-auto pt-1">
              <button 
                (click)="toggleSensorFault(SensorType.EYE_TRACKER_IR, 'DEGRADED')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30"
              >Blink Glitch</button>
              <button 
                (click)="toggleSensorFault(SensorType.EYE_TRACKER_IR, 'OFFLINE')"
                class="flex-1 py-1 rounded text-[9px] font-mono bg-red-500/20 text-red-300 border border-red-500/30 hover:bg-red-500/30"
              >Kill Eye</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SimDigitalTwin {
  readonly engine = inject(RustEngineService);
  readonly SensorType = SensorType;

  selectedEnv = 'DESK_WORKSPACE';

  readonly environments = [
    {
      id: 'DESK_WORKSPACE',
      name: 'Workstation Lab',
      desc: 'Ergonomic desk, dual curved screens, task chair, spatial windows',
      scale: '4x4m',
      icon: 'desktop_windows'
    },
    {
      id: 'VR_TESTING_CHAMBER',
      name: 'VR Chamber',
      desc: 'High-contrast calibration grid, motion tracking markers',
      scale: '6x6m',
      icon: 'view_in_ar'
    },
    {
      id: 'FACTORY_FLOOR',
      name: 'Smart Factory MR',
      desc: 'Industrial conveyor, robotic arms, spatial warning hazard volumes',
      scale: '15x15m',
      icon: 'precision_manufacturing'
    },
    {
      id: 'STREET_AR',
      name: 'Urban Outdoor AR',
      desc: 'Sidewalk surfaces, buildings, dynamic pedestrian obstacles',
      scale: '30x30m',
      icon: 'navigation'
    }
  ];

  setEnvironment(envId: string) {
    this.selectedEnv = envId;
    this.engine.logEvent('INFO', 'sim', `Loaded simulation digital twin environment preset: ${envId}`);
  }

  getSensorStatus(type: SensorType): string {
    const s = this.engine.sensorHealthMap().find(item => item.sensor_id === type);
    if (!s) return 'ONLINE';
    if (!s.availability) return 'OFFLINE';
    if (s.calibration_state === 'DEGRADED') return 'DEGRADED';
    return 'ONLINE';
  }

  toggleSensorFault(type: SensorType, faultStatus: 'DEGRADED' | 'OFFLINE') {
    this.engine.setSensorStatus(type, faultStatus);
  }

  restoreAllSensors() {
    this.engine.restoreAllSensors();
  }
}
