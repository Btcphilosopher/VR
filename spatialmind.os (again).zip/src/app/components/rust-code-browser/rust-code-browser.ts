import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RUST_CRATE_CATALOG, RustCrateMetadata } from '../../core/rust-codebase-catalog';

@Component({
  selector: 'app-rust-code-browser',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-orange-500/10 text-orange-400 border border-orange-500/20">
            <mat-icon class="text-base">code</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Production Rust Architecture Crate Catalog</h2>
            <p class="text-[10px] text-slate-400 font-mono">28 Strongly-Typed Crates (no_std / zero-copy / memory-safe)</p>
          </div>
        </div>

        <div class="text-[10px] font-mono text-slate-400">
          <span>Rust Edition: <strong class="text-orange-300">2024 / MSRV 1.85</strong></span>
        </div>
      </div>

      <!-- Main Layout: Crate Selector List & Code Viewer -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <!-- Crates List -->
        <div class="lg:col-span-4 flex flex-col gap-2 max-h-[520px] overflow-y-auto pr-1">
          @for (crateItem of crates(); track crateItem.name) {
            <button 
              (click)="selectCrate(crateItem)"
              class="p-2.5 rounded-xl border text-left transition-all flex flex-col gap-1"
              [class]="selectedCrate().name === crateItem.name ? 'bg-orange-950/40 border-orange-500/80 shadow-md' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-slate-300'"
            >
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold font-mono text-orange-400">crate::{{ crateItem.name }}</span>
                <span class="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                  {{ crateItem.crateType }}
                </span>
              </div>
              <p class="text-[10px] text-slate-400 leading-tight line-clamp-2">{{ crateItem.purpose }}</p>
            </button>
          }
        </div>

        <!-- Rust Source Code View -->
        <div class="lg:col-span-8 flex flex-col rounded-xl bg-slate-950 border border-slate-800 overflow-hidden">
          <div class="flex items-center justify-between px-3 py-2 bg-slate-900/90 border-b border-slate-800 text-[11px] font-mono">
            <div class="flex items-center gap-2 text-slate-300">
              <mat-icon class="text-sm text-orange-400">description</mat-icon>
              <span>crates/{{ selectedCrate().name }}/src/lib.rs</span>
            </div>

            <div class="flex items-center gap-3 text-[10px] text-slate-400">
              <span>Lines: ~{{ selectedCrate().sourceSnippet.split('\n').length * 4 + 40 }}</span>
              <button 
                (click)="copyCode()"
                class="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-all"
              >
                {{ isCopied() ? 'Copied!' : 'Copy Snippet' }}
              </button>
            </div>
          </div>

          <div class="p-4 overflow-x-auto max-h-[470px] overflow-y-auto font-mono text-[11px] leading-relaxed text-slate-300">
            <pre><code class="language-rust">{{ selectedCrate().sourceSnippet }}</code></pre>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RustCodeBrowser {
  readonly crates = signal<RustCrateMetadata[]>(RUST_CRATE_CATALOG);
  readonly selectedCrate = signal<RustCrateMetadata>(RUST_CRATE_CATALOG[0]);
  readonly isCopied = signal<boolean>(false);

  selectCrate(c: RustCrateMetadata) {
    this.selectedCrate.set(c);
  }

  copyCode() {
    navigator.clipboard.writeText(this.selectedCrate().sourceSnippet);
    this.isCopied.set(true);
    setTimeout(() => this.isCopied.set(false), 2000);
  }
}
