import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';
import { PowerMode } from '../../core/types';

interface TerminalLine {
  type: 'CMD' | 'OUT' | 'ERR' | 'SYS';
  text: string;
}

@Component({
  selector: 'app-cli-terminal',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <mat-icon class="text-base">terminal</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">SpatialMind Rust CLI & Event Bus Stream</h2>
            <p class="text-[10px] text-slate-400 font-mono">Interactive Shell & Lock-Free IPC Bus Inspector</p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="clearTerminal()"
            class="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono transition-all"
          >Clear Terminal</button>
        </div>
      </div>

      <!-- Main CLI Window & Live Stream Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3">
        <!-- Interactive Terminal (Left 7 cols) -->
        <div class="lg:col-span-7 flex flex-col h-80 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] overflow-hidden">
          <div #termScroll class="flex-1 p-3 overflow-y-auto flex flex-col gap-1 text-slate-300">
            @for (line of terminalLines(); track $index) {
              <div class="leading-relaxed">
                @if (line.type === 'CMD') {
                  <span class="text-cyan-400 font-bold">spatialmind:~$ </span>
                  <span class="text-slate-100">{{ line.text }}</span>
                } @else if (line.type === 'ERR') {
                  <span class="text-red-400 font-semibold">{{ line.text }}</span>
                } @else if (line.type === 'SYS') {
                  <span class="text-purple-400">{{ line.text }}</span>
                } @else {
                  <span class="text-slate-300 whitespace-pre-wrap">{{ line.text }}</span>
                }
              </div>
            }
          </div>

          <!-- Input prompt -->
          <div class="p-2.5 bg-slate-900/90 border-t border-slate-800 flex items-center gap-2">
            <span class="text-cyan-400 font-bold">spatialmind:~$</span>
            <input 
              #cliInput
              type="text"
              placeholder="type 'help' or 'status' or 'bench'..."
              (keydown.enter)="executeCommand(cliInput.value); cliInput.value = ''"
              class="flex-1 bg-transparent text-slate-100 placeholder-slate-600 focus:outline-none font-mono text-[11px]"
            />
          </div>
        </div>

        <!-- Live Event Bus Telemetry Stream (Right 5 cols) -->
        <div class="lg:col-span-5 flex flex-col h-80 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[10px] overflow-hidden">
          <div class="px-3 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-slate-400">
            <div class="flex items-center gap-1.5 text-cyan-300 font-bold">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>LIVE RUST EVENT BUS (IPC)</span>
            </div>
            <span>{{ engine.eventStream().length }} events</span>
          </div>

          <div class="flex-1 p-2.5 overflow-y-auto flex flex-col gap-1.5 text-slate-300">
            @for (ev of engine.eventStream(); track $index) {
              <div class="p-1.5 rounded bg-slate-900/60 border border-slate-800/80 flex flex-col gap-0.5">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-cyan-400">[{{ ev.module }}]</span>
                  <span class="text-[9px] text-slate-500">{{ ev.timestamp }}</span>
                </div>
                <div class="flex items-center justify-between text-slate-300">
                  <span class="truncate">{{ ev.message }}</span>
                  <span class="px-1 rounded text-[9px]"
                    [class]="ev.level === 'CRIT' ? 'bg-red-500/20 text-red-300' :
                             ev.level === 'WARN' ? 'bg-amber-500/20 text-amber-300' :
                             'bg-slate-800 text-slate-400'">
                    {{ ev.level }}
                  </span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class CliTerminal {
  @ViewChild('termScroll') termScroll!: ElementRef<HTMLDivElement>;

  readonly engine = inject(RustEngineService);

  readonly terminalLines = signal<TerminalLine[]>([
    { type: 'SYS', text: 'SPATIALMIND.OS [v0.9.4-rust-stable] Initialized on target: aarch64-unknown-linux-musl' },
    { type: 'SYS', text: 'Type "help" for a list of available spatial inspection commands.' },
    { type: 'CMD', text: 'spatialmind status' },
    { type: 'OUT', text: 'Engine: ONLINE | Hard Real-Time 500Hz EKF: ACTIVE | Objects: 5 | Anchors: 3 | M2P Latency: 4.8ms' }
  ]);

  clearTerminal() {
    this.terminalLines.set([
      { type: 'SYS', text: 'Terminal cleared. Type "help" for commands.' }
    ]);
  }

  async executeCommand(cmd: string) {
    const trimmed = cmd.trim();
    if (!trimmed) return;

    this.terminalLines.update(lines => [...lines, { type: 'CMD', text: trimmed }]);

    const parts = trimmed.split(' ');
    const root = parts[0].toLowerCase();
    const sub = parts[1]?.toLowerCase();
    const arg = parts.slice(2).join(' ');

    if (root === 'help') {
      this.terminalLines.update(lines => [
        ...lines,
        {
          type: 'OUT',
          text: `Available Commands:
  • spatialmind status         - Check core engine state, M2P latency & thread health
  • spatialmind inspect <id>   - Inspect 3D pose, bounding box, and confidence of object
  • spatialmind bench          - Execute sub-millisecond inference benchmark suite
  • spatialmind memory <query> - Vector similarity query across persistent spatial memory
  • spatialmind power <mode>   - Set power profile: PERF | BALANCED | ECO | ULTRA
  • spatialmind reset-pose     - Zero-center spatial 6-DoF world origin
  • clear                      - Clear terminal display`
        }
      ]);
    } else if (root === 'clear') {
      this.clearTerminal();
    } else if (root === 'spatialmind') {
      if (sub === 'status' || !sub) {
        const p = this.engine.headPose();
        const pred = this.engine.predictedHeadPose();
        const lat = this.engine.latencyBreakdown();
        const velMag = Math.sqrt(pred.predicted_velocity.x ** 2 + pred.predicted_velocity.y ** 2 + pred.predicted_velocity.z ** 2);
        this.terminalLines.update(lines => [
          ...lines,
          {
            type: 'OUT',
            text: `[SPATIALMIND.OS STATUS]
- Head Pose: [x: ${p.position.x.toFixed(3)}, y: ${p.position.y.toFixed(3)}, z: ${p.position.z.toFixed(3)}]
- Linear Velocity: ${velMag.toFixed(3)} m/s (Predicted)
- Motion-to-Photon Latency: ${lat.total_motion_to_photon_ms.toFixed(2)} ms (Budget: ${lat.target_budget_ms} ms)
- Active Power Mode: ${this.engine.activePowerMode()}
- Registered Objects: ${this.engine.spatialObjects().length}
- Spatial Memory Status: HEALTHY (Sync lock-free)`
          }
        ]);
      } else if (sub === 'bench') {
        this.terminalLines.update(lines => [
          ...lines,
          { type: 'SYS', text: 'Running micro-benchmark suite on NPU & GPU...' }
        ]);
        try {
          const res = await fetch('/api/spatialmind/benchmark-suite', { method: 'POST' });
          const data = await res.json();
          let txt = 'Benchmark Results:\n';
          data.benchmarks.forEach((b: any) => {
            txt += `  • ${b.model.padEnd(28)} [${b.quant}] -> ${b.latency_ms}ms (${b.throughput_fps} fps, ${b.power_w}W)\n`;
          });
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: txt }]);
        } catch (e: any) {
          this.terminalLines.update(lines => [...lines, { type: 'ERR', text: 'Bench failed: ' + e.message }]);
        }
      } else if (sub === 'memory') {
        const query = arg || parts.slice(1).join(' ');
        this.terminalLines.update(lines => [
          ...lines,
          { type: 'SYS', text: `Querying persistent 3D spatial memory for: "${query}"...` }
        ]);
        try {
          const res = await fetch('/api/spatialmind/query-spatial-memory', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query })
          });
          const data = await res.json();
          let txt = `Results found (${data.results_found.length}) [${data.vector_search_latency_us}µs]:\n`;
          data.results_found.forEach((item: any) => {
            txt += `  • ${item.name} (${item.class}) @ [${item.pos.x}, ${item.pos.y}, ${item.pos.z}] - Conf: ${(item.confidence * 100).toFixed(0)}%\n`;
          });
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: txt }]);
        } catch (e: any) {
          this.terminalLines.update(lines => [...lines, { type: 'ERR', text: 'Query failed: ' + e.message }]);
        }
      } else if (sub === 'power') {
        const mode = arg.toUpperCase();
        if (mode === 'PERF' || mode === 'PERFORMANCE') {
          this.engine.setPowerMode(PowerMode.PERFORMANCE);
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: 'Power mode switched to: PERFORMANCE' }]);
        } else if (mode === 'ECO' || mode === 'BATTERY') {
          this.engine.setPowerMode(PowerMode.BATTERY);
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: 'Power mode switched to: BATTERY (ECO)' }]);
        } else if (mode === 'ULTRA' || mode === 'ULTRA_LOW_POWER') {
          this.engine.setPowerMode(PowerMode.ULTRA_LOW_POWER);
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: 'Power mode switched to: ULTRA_LOW_POWER' }]);
        } else {
          this.engine.setPowerMode(PowerMode.BALANCED);
          this.terminalLines.update(lines => [...lines, { type: 'OUT', text: 'Power mode switched to: BALANCED' }]);
        }
      } else if (sub === 'inspect') {
        const obj = this.engine.spatialObjects()[0];
        if (obj) {
          this.terminalLines.update(lines => [
            ...lines,
            {
              type: 'OUT',
              text: `Object: ${obj.semantic_label} [${obj.id}]\n  Class: ${obj.class_name}\n  Position: [${obj.position.x}, ${obj.position.y}, ${obj.position.z}]\n  Confidence: ${(obj.confidence * 100).toFixed(1)}%\n  Tracking: ${obj.tracking_state}`
            }
          ]);
        }
      } else if (sub === 'reset-pose') {
        this.engine.logEvent('INFO', 'fusion', 'Recalibrated spatial 6-DoF origin to [0, 1.5, 0].');
        this.terminalLines.update(lines => [...lines, { type: 'OUT', text: 'Spatial world origin reset to nominal headset height.' }]);
      } else {
        this.terminalLines.update(lines => [
          ...lines,
          { type: 'ERR', text: `Unknown subcommand: "${sub}". Type "help" for syntax.` }
        ]);
      }
    } else {
      this.terminalLines.update(lines => [
        ...lines,
        { type: 'ERR', text: `Command not found: "${trimmed}". Type "help" for instructions.` }
      ]);
    }

    setTimeout(() => {
      if (this.termScroll) {
        this.termScroll.nativeElement.scrollTop = this.termScroll.nativeElement.scrollHeight;
      }
    }, 50);
  }
}
