import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  OnDestroy,
  OnInit,
  ViewChild,
  inject,
  signal
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import * as THREE from 'three';
import { RustEngineService } from '../../core/rust-engine.service';
import { SemanticClass } from '../../core/types';

@Component({
  selector: 'app-spatial-viewport',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full bg-slate-950 rounded-2xl overflow-hidden border border-slate-800/80 shadow-2xl flex flex-col">
      <!-- Top HUD Header -->
      <div class="absolute top-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none">
        <div class="flex items-center gap-2 pointer-events-auto bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg text-xs font-mono">
          <span class="flex h-2.5 w-2.5 relative">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span class="text-slate-300 font-semibold">3D SPATIAL WORLD</span>
          <span class="text-slate-500">|</span>
          <span class="text-cyan-400">FRAME: {{ engine.headPose().frame }}</span>
          <span class="text-slate-500">|</span>
          <span class="text-slate-400">CONF: {{(engine.headPose().confidence * 100).toFixed(1)}}%</span>
        </div>

        <div class="flex items-center gap-2 pointer-events-auto bg-slate-900/85 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-700/60 shadow-lg text-xs">
          <button 
            (click)="toggleCameraView()"
            class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all"
            [class]="cameraView() === 'ORBIT' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'"
          >
            <mat-icon class="text-sm">videocam</mat-icon>
            {{ cameraView() === 'ORBIT' ? 'Third-Person Orbit' : 'Headset POV (First-Person)' }}
          </button>

          <button 
            (click)="toggleWireframes()"
            class="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
            [class.border]="showWireframes()"
            [class.border-cyan-500]="showWireframes()"
          >
            <mat-icon class="text-sm">grid_4x4</mat-icon>
            {{ showWireframes() ? 'Wireframe ON' : 'Wireframe OFF' }}
          </button>
        </div>
      </div>

      <!-- 3D WebGL Canvas -->
      <div #canvasContainer class="w-full h-full cursor-grab active:cursor-grabbing"></div>

      <!-- Bottom Overlays (Gaze & Prediction telemetry) -->
      <div class="absolute bottom-3 left-3 right-3 z-10 flex items-center justify-between pointer-events-none text-xs font-mono">
        <div class="pointer-events-auto bg-slate-900/85 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-4">
          <div class="flex items-center gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            <span class="text-slate-400">Head (t):</span>
            <span class="text-slate-200">[{{ engine.headPose().position.x.toFixed(2) }}, {{ engine.headPose().position.y.toFixed(2) }}, {{ engine.headPose().position.z.toFixed(2) }}]</span>
          </div>

          <div class="flex items-center gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
            <span class="text-slate-400">Predicted (t+40ms):</span>
            <span class="text-amber-300">[{{ engine.predictedHeadPose().predicted_position.x.toFixed(2) }}, {{ engine.predictedHeadPose().predicted_position.y.toFixed(2) }}, {{ engine.predictedHeadPose().predicted_position.z.toFixed(2) }}]</span>
          </div>
        </div>

        <div class="pointer-events-auto bg-slate-900/85 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-700/60 shadow-lg flex items-center gap-3">
          <span class="text-slate-400">Gaze Fixation:</span>
          <span class="text-emerald-400 font-semibold">{{ engine.gazeState().looked_at_object_id || 'Free Scan' }}</span>
          <span class="text-slate-500">|</span>
          <span class="text-slate-400">Vergence:</span>
          <span class="text-slate-200">{{ engine.gazeState().vergence_distance.toFixed(2) }}m</span>
        </div>
      </div>
    </div>
  `
})
export class SpatialViewport implements OnInit, OnDestroy {
  @ViewChild('canvasContainer', { static: true }) canvasContainer!: ElementRef<HTMLDivElement>;

  readonly engine = inject(RustEngineService);
  readonly cameraView = signal<'ORBIT' | 'HEADSET_POV'>('ORBIT');
  readonly showWireframes = signal<boolean>(true);

  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private povCamera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private animationFrameId: number | null = null;
  private resizeObserver!: ResizeObserver;

  // 3D Visual Objects
  private headsetMesh!: THREE.Group;
  private predictedPathLine!: THREE.Line;
  private gazeRayLine!: THREE.Line;
  private gazeFixationMesh!: THREE.Mesh;
  private rightHandMesh!: THREE.Group;
  private leftHandMesh!: THREE.Group;
  private sceneObjectsGroup!: THREE.Group;
  private anchorGroup!: THREE.Group;
  private collisionConeMesh!: THREE.Mesh;

  // Orbit controls state
  private isMouseDown = false;
  private prevMousePos = { x: 0, y: 0 };
  private sphericalAngles = { theta: 0.2, phi: 1.1, radius: 4.2 };

  ngOnInit() {
    this.initThree();
    this.setupEventListeners();
    this.startRenderLoop();
  }

  ngOnDestroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    if (this.resizeObserver) {
      this.resizeObserver.disconnect();
    }
    this.renderer.dispose();
  }

  toggleCameraView() {
    this.cameraView.update(v => (v === 'ORBIT' ? 'HEADSET_POV' : 'ORBIT'));
  }

  toggleWireframes() {
    this.showWireframes.update(v => !v);
  }

  private initThree() {
    const container = this.canvasContainer.nativeElement;
    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x020617); // Slate 950
    this.scene.fog = new THREE.FogExp2(0x020617, 0.12);

    // Orbit Camera
    this.camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    this.updateCameraPosition();

    // POV Camera
    this.povCamera = new THREE.PerspectiveCamera(80, width / height, 0.05, 50);

    // Renderer
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(this.renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x334155, 1.5);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x38bdf8, 2.5);
    dirLight.position.set(3, 6, 4);
    dirLight.castShadow = true;
    this.scene.add(dirLight);

    const pointLight = new THREE.PointLight(0xa855f7, 2.0, 10);
    pointLight.position.set(-2, 3, -1);
    this.scene.add(pointLight);

    // Spatial Ground Grid & Coordinates
    const gridHelper = new THREE.GridHelper(12, 24, 0x06b6d4, 0x1e293b);
    gridHelper.position.y = 0;
    this.scene.add(gridHelper);

    // Create Subsystem Visualizers
    this.createHeadsetAndPrediction();
    this.createGazeVisualizer();
    this.createHandAvatars();
    this.createSpatialObjects();
    this.createSpatialAnchors();
    this.createCollisionVisualizer();

    // Resize Observer
    this.resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.povCamera.aspect = w / h;
        this.povCamera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });
    this.resizeObserver.observe(container);
  }

  private createHeadsetAndPrediction() {
    this.headsetMesh = new THREE.Group();

    // Headset Body (Vision Pro / Quest 3 style)
    const bodyGeo = new THREE.BoxGeometry(0.24, 0.12, 0.14);
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      metalness: 0.8,
      roughness: 0.2
    });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    this.headsetMesh.add(body);

    // Front Glass Visor
    const glassGeo = new THREE.BoxGeometry(0.22, 0.1, 0.02);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4,
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.85,
      transparent: true,
      opacity: 0.9
    });
    const visor = new THREE.Mesh(glassGeo, glassMat);
    visor.position.z = -0.07;
    this.headsetMesh.add(visor);

    // Forward direction arrow
    const arrow = new THREE.ArrowHelper(new THREE.Vector3(0, 0, -1), new THREE.Vector3(0, 0, -0.08), 0.3, 0x06b6d4, 0.08, 0.04);
    this.headsetMesh.add(arrow);

    this.scene.add(this.headsetMesh);

    // Prediction Forward Trajectory line
    const lineGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(6); // 2 points: Current pose -> Predicted pose
    lineGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const lineMat = new THREE.LineDashedMaterial({
      color: 0xf59e0b,
      dashSize: 0.05,
      gapSize: 0.02,
      linewidth: 2
    });
    this.predictedPathLine = new THREE.Line(lineGeo, lineMat);
    this.scene.add(this.predictedPathLine);
  }

  private createGazeVisualizer() {
    // Gaze ray line
    const lineGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(6);
    lineGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.75,
      linewidth: 2
    });
    this.gazeRayLine = new THREE.Line(lineGeo, lineMat);
    this.scene.add(this.gazeRayLine);

    // Gaze fixation target sphere
    const sphereGeo = new THREE.SphereGeometry(0.035, 16, 16);
    const sphereMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      wireframe: true
    });
    this.gazeFixationMesh = new THREE.Mesh(sphereGeo, sphereMat);
    this.scene.add(this.gazeFixationMesh);
  }

  private createHandAvatars() {
    this.rightHandMesh = new THREE.Group();
    this.leftHandMesh = new THREE.Group();

    // Palm nodes
    const palmGeo = new THREE.SphereGeometry(0.04, 12, 12);
    const palmMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.4 });

    const rightPalm = new THREE.Mesh(palmGeo, palmMat);
    this.rightHandMesh.add(rightPalm);

    const leftPalm = new THREE.Mesh(palmGeo, palmMat);
    this.leftHandMesh.add(leftPalm);

    // Thumb and index tip spheres
    const tipGeo = new THREE.SphereGeometry(0.015, 8, 8);
    const tipMat = new THREE.MeshStandardMaterial({ color: 0xec4899 });

    const rThumb = new THREE.Mesh(tipGeo, tipMat);
    rThumb.name = 'thumb_tip';
    this.rightHandMesh.add(rThumb);

    const rIndex = new THREE.Mesh(tipGeo, tipMat);
    rIndex.name = 'index_tip';
    this.rightHandMesh.add(rIndex);

    this.scene.add(this.rightHandMesh);
    this.scene.add(this.leftHandMesh);
  }

  private createSpatialObjects() {
    this.sceneObjectsGroup = new THREE.Group();

    const objects = this.engine.spatialObjects();
    objects.forEach(obj => {
      const group = new THREE.Group();
      group.name = obj.id;

      // Object Box
      const geo = new THREE.BoxGeometry(obj.scale.x, obj.scale.y, obj.scale.z);
      const mat = new THREE.MeshStandardMaterial({
        color: obj.color ? parseInt(obj.color.replace('#', '0x')) : 0x0284c7,
        transparent: true,
        opacity: obj.class_name === SemanticClass.SCREEN ? 0.75 : 0.65,
        roughness: 0.3
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      group.add(mesh);

      // Bounding Box Wireframe
      const edges = new THREE.EdgesGeometry(geo);
      const lineMat = new THREE.LineBasicMaterial({
        color: obj.color ? parseInt(obj.color.replace('#', '0x')) : 0x38bdf8,
        linewidth: 2
      });
      const wireframe = new THREE.LineSegments(edges, lineMat);
      group.add(wireframe);

      group.position.set(obj.position.x, obj.position.y, obj.position.z);
      group.quaternion.set(obj.orientation.x, obj.orientation.y, obj.orientation.z, obj.orientation.w);

      this.sceneObjectsGroup.add(group);
    });

    this.scene.add(this.sceneObjectsGroup);
  }

  private createSpatialAnchors() {
    this.anchorGroup = new THREE.Group();
    const ringGeo = new THREE.RingGeometry(0.08, 0.12, 24);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xec4899, side: THREE.DoubleSide });

    this.engine.spatialAnchors().forEach(anchor => {
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.set(anchor.pose.position.x, anchor.pose.position.y, anchor.pose.position.z);
      ring.rotation.x = Math.PI / 2;
      this.anchorGroup.add(ring);
    });

    this.scene.add(this.anchorGroup);
  }

  private createCollisionVisualizer() {
    const coneGeo = new THREE.ConeGeometry(0.3, 1.2, 16, 1, true);
    coneGeo.rotateX(-Math.PI / 2);
    const coneMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.25,
      wireframe: true
    });
    this.collisionConeMesh = new THREE.Mesh(coneGeo, coneMat);
    this.scene.add(this.collisionConeMesh);
  }

  private setupEventListeners() {
    const el = this.canvasContainer.nativeElement;

    el.addEventListener('mousedown', (e) => {
      this.isMouseDown = true;
      this.prevMousePos = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isMouseDown = false;
    });

    window.addEventListener('mousemove', (e) => {
      if (!this.isMouseDown || this.cameraView() === 'HEADSET_POV') return;

      const deltaX = e.clientX - this.prevMousePos.x;
      const deltaY = e.clientY - this.prevMousePos.y;
      this.prevMousePos = { x: e.clientX, y: e.clientY };

      this.sphericalAngles.theta -= deltaX * 0.006;
      this.sphericalAngles.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.sphericalAngles.phi + deltaY * 0.006));
      this.updateCameraPosition();
    });

    el.addEventListener('wheel', (e) => {
      if (this.cameraView() === 'HEADSET_POV') return;
      e.preventDefault();
      this.sphericalAngles.radius = Math.max(1.5, Math.min(10, this.sphericalAngles.radius + e.deltaY * 0.005));
      this.updateCameraPosition();
    });
  }

  private updateCameraPosition() {
    const { theta, phi, radius } = this.sphericalAngles;
    const target = new THREE.Vector3(0, 1.2, -0.4);

    this.camera.position.x = target.x + radius * Math.sin(phi) * Math.sin(theta);
    this.camera.position.y = target.y + radius * Math.cos(phi);
    this.camera.position.z = target.z + radius * Math.sin(phi) * Math.cos(theta);
    this.camera.lookAt(target);
  }

  private startRenderLoop() {
    const animate = () => {
      this.animationFrameId = requestAnimationFrame(animate);
      this.updateSceneState();

      const activeCam = this.cameraView() === 'ORBIT' ? this.camera : this.povCamera;
      this.renderer.render(this.scene, activeCam);
    };
    animate();
  }

  private updateSceneState() {
    const head = this.engine.headPose();
    const pred = this.engine.predictedHeadPose();
    const gaze = this.engine.gazeState();
    const rHand = this.engine.rightHand();
    const lHand = this.engine.leftHand();
    const safety = this.engine.safetyState();

    // 1. Update Headset Mesh
    this.headsetMesh.position.set(head.position.x, head.position.y, head.position.z);
    this.headsetMesh.quaternion.set(head.orientation.x, head.orientation.y, head.orientation.z, head.orientation.w);

    // 2. Update POV Camera
    this.povCamera.position.set(head.position.x, head.position.y, head.position.z);
    this.povCamera.quaternion.set(head.orientation.x, head.orientation.y, head.orientation.z, head.orientation.w);

    // 3. Update Prediction Line
    const predPos = this.predictedPathLine.geometry.attributes['position'] as THREE.BufferAttribute;
    predPos.setXYZ(0, head.position.x, head.position.y, head.position.z);
    predPos.setXYZ(1, pred.predicted_position.x, pred.predicted_position.y, pred.predicted_position.z);
    predPos.needsUpdate = true;

    // 4. Update Gaze Line & Target
    const gazePos = this.gazeRayLine.geometry.attributes['position'] as THREE.BufferAttribute;
    gazePos.setXYZ(0, gaze.origin.x, gaze.origin.y, gaze.origin.z);
    gazePos.setXYZ(1, gaze.target_point.x, gaze.target_point.y, gaze.target_point.z);
    gazePos.needsUpdate = true;

    this.gazeFixationMesh.position.set(gaze.target_point.x, gaze.target_point.y, gaze.target_point.z);

    // 5. Update Hands
    this.rightHandMesh.position.set(rHand.palm_position.x, rHand.palm_position.y, rHand.palm_position.z);
    this.leftHandMesh.position.set(lHand.palm_position.x, lHand.palm_position.y, lHand.palm_position.z);

    const rThumb = this.rightHandMesh.getObjectByName('thumb_tip');
    if (rThumb) {
      rThumb.position.set(0.02, 0.02, -0.04);
    }
    const rIndex = this.rightHandMesh.getObjectByName('index_tip');
    if (rIndex) {
      rIndex.position.set(0.01, 0.03, -0.04 - rHand.pinch_distance);
    }

    // 6. Update Collision Cone
    this.collisionConeMesh.position.set(head.position.x, head.position.y, head.position.z);
    if (safety.risk_level === 'HIGH_RISK') {
      (this.collisionConeMesh.material as THREE.MeshBasicMaterial).color.setHex(0xef4444);
    } else if (safety.risk_level === 'CAUTION') {
      (this.collisionConeMesh.material as THREE.MeshBasicMaterial).color.setHex(0xf59e0b);
    } else {
      (this.collisionConeMesh.material as THREE.MeshBasicMaterial).color.setHex(0x10b981);
    }
  }
}
