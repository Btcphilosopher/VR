import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';
import { MLModelProfile, QuantizationFormat } from '../../core/types';

@Component({
  selector: 'app-model-router-registry',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <mat-icon class="text-base">hub</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Model Registry & Adaptive Router</h2>
            <p class="text-[10px] text-slate-400 font-mono">InferenceBackend Runtimes (ONNX / Candle / Burn / TFLite)</p>
          </div>
        </div>

        <button 
          (click)="runBenchmarkSuite()"
          [disabled]="isBenchmarking()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-black shadow-md transition-all disabled:opacity-50"
        >
          <mat-icon class="text-sm">{{ isBenchmarking() ? 'sync' : 'network_check' }}</mat-icon>
          <span>{{ isBenchmarking() ? 'Benchmarking...' : 'Run Benchmark Suite' }}</span>
        </button>
      </div>

      <!-- Model Profiles Table -->
      <div class="overflow-x-auto">
        <table class="w-full text-left text-[11px] font-mono border-collapse">
          <thead>
            <tr class="text-slate-500 border-b border-slate-800 text-[10px]">
              <th class="py-1.5 px-2">MODEL IDENTITY</th>
              <th class="py-1.5 px-2">TASK</th>
              <th class="py-1.5 px-2">BACKEND</th>
              <th class="py-1.5 px-2">QUANT</th>
              <th class="py-1.5 px-2">DEVICE</th>
              <th class="py-1.5 px-2">LATENCY</th>
              <th class="py-1.5 px-2">POWER</th>
              <th class="py-1.5 px-2">ACCURACY</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800/50 text-slate-300">
            @for (model of engine.modelRegistry(); track model.id) {
              <tr class="hover:bg-slate-800/30 transition-colors">
                <td class="py-2.5 px-2 font-bold text-slate-100 flex items-center gap-1.5">
                  <span class="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
                  {{ model.name }}
                  <span class="text-[9px] text-slate-500 font-normal">({{ model.version }})</span>
                </td>
                <td class="py-2.5 px-2 text-slate-400 text-[10px]">{{ model.task_category }}</td>
                <td class="py-2.5 px-2 font-semibold text-purple-300">{{ model.backend_engine }}</td>
                <td class="py-2.5 px-2">
                  <span class="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-cyan-300 border border-slate-700">
                    {{ model.quantization }}
                  </span>
                </td>
                <td class="py-2.5 px-2 font-semibold text-amber-300">{{ model.device_target }}</td>
                <td class="py-2.5 px-2 font-mono text-emerald-400 font-bold">{{ model.typical_latency_ms }} ms</td>
                <td class="py-2.5 px-2 text-slate-400">{{ model.power_draw_watts }} W</td>
                <td class="py-2.5 px-2 text-slate-200">{{ (model.accuracy_map * 100).toFixed(1) }}%</td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <!-- Adaptive Router Decision Rules Matrix -->
      <div class="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Adaptive Model Routing Rules Matrix</span>
          <span class="text-[10px] font-mono text-cyan-400">Active Mode: {{ engine.activePowerMode() }}</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-2 text-[10px] font-mono pt-1">
          <div class="p-2 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-cyan-400 font-bold block mb-1">HIGH MOTION</span>
            <span class="text-slate-400 block">Angular vel &gt; 1.5 rad/s</span>
            <strong class="text-emerald-300 mt-1 block">→ Low-Latency FP16 Model @ 120Hz</strong>
          </div>

          <div class="p-2 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-purple-400 font-bold block mb-1">STATIC SCENE</span>
            <span class="text-slate-400 block">Scene change &lt; 2%</span>
            <strong class="text-emerald-300 mt-1 block">→ Throttle Vision to 5Hz (Save 60% power)</strong>
          </div>

          <div class="p-2 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-amber-400 font-bold block mb-1">THERMAL &gt; 55°C</span>
            <span class="text-slate-400 block">Junction throttling</span>
            <strong class="text-amber-300 mt-1 block">→ Swap to INT8 Quantized DSP runtime</strong>
          </div>

          <div class="p-2 rounded-lg bg-slate-900 border border-slate-800">
            <span class="text-emerald-400 font-bold block mb-1">BATTERY &lt; 20%</span>
            <span class="text-slate-400 block">Eco threshold</span>
            <strong class="text-purple-300 mt-1 block">→ Load-shed background embeddings</strong>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ModelRouterRegistry {
  readonly engine = inject(RustEngineService);
  readonly isBenchmarking = signal<boolean>(false);

  async runBenchmarkSuite() {
    this.isBenchmarking.set(true);
    try {
      const response = await fetch('/api/spatialmind/benchmark-suite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (response.ok) {
        this.engine.logEvent('INFO', 'model-router', 'Benchmark Suite completed across all 5 ML models with zero-copy data paths.');
      }
    } catch (e) {
      console.error(e);
    } finally {
      this.isBenchmarking.set(false);
    }
  }
}
