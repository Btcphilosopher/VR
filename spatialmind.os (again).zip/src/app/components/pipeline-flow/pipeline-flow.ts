import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';

interface PipelineStage {
  id: string;
  name: string;
  subtitle: string;
  icon: string;
  rateHz: string;
  latencyMs: number;
  confidence: number;
  coordinateFrame: string;
  modelVersion: string;
  details: string;
}

@Component({
  selector: 'app-pipeline-flow',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
      <!-- Section Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <mat-icon class="text-base">account_tree</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Primary 11-Stage Pipeline</h2>
            <p class="text-[10px] text-slate-400 font-mono">Sensors → Fusion → World Model → Prediction → Intent → OS State</p>
          </div>
        </div>

        <div class="flex items-center gap-3 text-[11px] font-mono">
          <div class="flex items-center gap-1.5 text-slate-300">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>Total M2P: <strong class="text-emerald-300">{{ engine.latencyBreakdown().total_motion_to_photon_ms.toFixed(1) }} ms</strong></span>
          </div>
          <span class="text-slate-600">|</span>
          <span class="text-slate-400">Budget: {{ engine.latencyBreakdown().target_budget_ms }} ms</span>
        </div>
      </div>

      <!-- Horizontal Scrolling Flow Chart -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-11 gap-2 pt-1">
        @for (stage of stages(); track stage.id) {
          <div 
            (click)="selectStage(stage)"
            class="group relative flex flex-col p-2.5 rounded-xl border transition-all cursor-pointer select-none"
            [class]="selectedStageId() === stage.id ? 'bg-cyan-950/40 border-cyan-500/80 shadow-md shadow-cyan-950/50' : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/60'"
          >
            <!-- Stage Number badge -->
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[9px] font-mono font-bold text-slate-500 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800">
                #{{ $index + 1 }}
              </span>
              <span class="text-[9px] font-mono text-cyan-400">{{ stage.rateHz }}</span>
            </div>

            <!-- Icon & Name -->
            <div class="flex items-center gap-1.5 mb-1 text-slate-200">
              <mat-icon class="text-sm text-cyan-400">{{ stage.icon }}</mat-icon>
              <h3 class="text-xs font-bold truncate leading-tight">{{ stage.name }}</h3>
            </div>

            <p class="text-[10px] text-slate-400 truncate mb-2">{{ stage.subtitle }}</p>

            <!-- Metrics -->
            <div class="mt-auto flex flex-col gap-1 text-[9px] font-mono border-t border-slate-800/60 pt-1.5">
              <div class="flex items-center justify-between text-slate-400">
                <span>Latency:</span>
                <span class="text-slate-200 font-semibold">{{ stage.latencyMs }}ms</span>
              </div>
              <div class="flex items-center justify-between text-slate-400">
                <span>Conf:</span>
                <span class="text-emerald-400 font-semibold">{{ (stage.confidence * 100).toFixed(0) }}%</span>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Expanded Stage Inspector Details -->
      @if (currentSelectedStage(); as activeStage) {
        <div class="mt-1 p-3 rounded-xl bg-slate-950/80 border border-slate-800/90 text-xs flex flex-wrap items-center justify-between gap-4 font-mono">
          <div class="flex items-center gap-3">
            <span class="text-cyan-400 font-bold uppercase">[{{ activeStage.name }}]</span>
            <span class="text-slate-400 text-xs">{{ activeStage.details }}</span>
          </div>
          <div class="flex items-center gap-4 text-slate-400 text-[11px]">
            <span>Frame: <strong class="text-slate-200">{{ activeStage.coordinateFrame }}</strong></span>
            <span>Model: <strong class="text-cyan-300">{{ activeStage.modelVersion }}</strong></span>
            <span>Rate: <strong class="text-emerald-400">{{ activeStage.rateHz }}</strong></span>
          </div>
        </div>
      }
    </div>
  `
})
export class PipelineFlow {
  readonly engine = inject(RustEngineService);
  readonly selectedStageId = signal<string>('stage_fusion');

  readonly stages = signal<PipelineStage[]>([
    {
      id: 'stage_sensor',
      name: 'Sensors',
      subtitle: 'IMU / Cam / LiDAR / IR',
      icon: 'sensors',
      rateHz: '500-1000 Hz',
      latencyMs: 1.1,
      confidence: 0.99,
      coordinateFrame: 'DEVICE',
      modelVersion: 'Hardware-HAL-v2',
      details: 'Async ingestion ring buffers for 6-DoF IMU, stereo RGB cameras, Time-of-Flight LiDAR, and dual IR eye trackers.'
    },
    {
      id: 'stage_sync',
      name: 'Sync & Drift',
      subtitle: 'Temporal Alignment',
      icon: 'sync',
      rateHz: '500 Hz',
      latencyMs: 0.4,
      confidence: 0.99,
      coordinateFrame: 'DEVICE',
      modelVersion: 'PTP-TemporalBuffer-v1',
      details: 'Resolves out-of-order packets, variable sampling rates, hardware clock drift, and jitter interpolation.'
    },
    {
      id: 'stage_calib',
      name: 'Calibration',
      subtitle: 'Extrinsics & Bias',
      icon: 'tune',
      rateHz: '500 Hz',
      latencyMs: 0.3,
      confidence: 0.98,
      coordinateFrame: 'DEVICE',
      modelVersion: 'OnlineCalib-v3',
      details: 'Applies online factory & real-time extrinsics matrices, optical lens distortion correction, and gyro bias stripping.'
    },
    {
      id: 'stage_prep',
      name: 'Preprocess',
      subtitle: 'Zero-Copy Rectify',
      icon: 'transform',
      rateHz: '120 Hz',
      latencyMs: 0.8,
      confidence: 0.98,
      coordinateFrame: 'CAMERA',
      modelVersion: 'FastWarp-SIMD',
      details: 'Zero-copy memory pool rectification, stereo disparity pyramid construction, and depth point-cloud generation.'
    },
    {
      id: 'stage_features',
      name: 'Features',
      subtitle: 'Edges / Corners / Rays',
      icon: 'hub',
      rateHz: '120 Hz',
      latencyMs: 0.9,
      confidence: 0.96,
      coordinateFrame: 'LOCAL',
      modelVersion: 'SpatialFeatures-FP16',
      details: 'Extracts 3D keypoint anchors, surface normals, optical flow vectors, and eye gaze pupil centroids.'
    },
    {
      id: 'stage_perception',
      name: 'Perception',
      subtitle: 'YOLO / HandNet / IR',
      icon: 'visibility',
      rateHz: '30-120 Hz',
      latencyMs: 3.4,
      confidence: 0.95,
      coordinateFrame: 'LOCAL',
      modelVersion: 'SpatialNet-3D-YOLOv4',
      details: 'Neural networks identify 3D bounding boxes, 21 articulated hand joints, and eye gaze vergence vectors.'
    },
    {
      id: 'stage_fusion',
      name: 'Spatial Fusion',
      subtitle: '6-DoF EKF Engine',
      icon: 'merge',
      rateHz: '500 Hz',
      latencyMs: 0.6,
      confidence: 0.99,
      coordinateFrame: 'WORLD',
      modelVersion: 'SpatialFusionEkf-v2',
      details: 'Extended Kalman Filter fuses high-rate IMU kinematics with vision odometry, depth LiDAR, and persistent anchors.'
    },
    {
      id: 'stage_world',
      name: 'World Model',
      subtitle: '3D Scene Graph',
      icon: 'domain',
      rateHz: '30 Hz',
      latencyMs: 0.5,
      confidence: 0.97,
      coordinateFrame: 'WORLD',
      modelVersion: 'SemanticSceneGraph-v3',
      details: 'Maintains continuous topological spatial relationships (ABOVE, ON, NEAR, IN_FRONT_OF) between objects.'
    },
    {
      id: 'stage_prediction',
      name: 'Prediction',
      subtitle: '40ms Extrapolation',
      icon: 'fast_forward',
      rateHz: '500 Hz',
      latencyMs: 0.3,
      confidence: 0.96,
      coordinateFrame: 'HEAD',
      modelVersion: 'PoseTransformer-Temporal',
      details: 'Predicts head pose, eye saccades, and hand trajectory forward in time to eliminate perceived display lag.'
    },
    {
      id: 'stage_intent',
      name: 'User Intent',
      subtitle: 'Bayesian Multimodal',
      icon: 'psychology',
      rateHz: '120 Hz',
      latencyMs: 1.2,
      confidence: 0.94,
      coordinateFrame: 'HEAD',
      modelVersion: 'MultimodalIntent-Transformer',
      details: 'Probabilistic engine combines Gaze fixation + Pinch/Point kinematics + Spatial Context into actionable intent.'
    },
    {
      id: 'stage_os_state',
      name: 'OS Response',
      subtitle: 'Spatial Display',
      icon: 'desktop_windows',
      rateHz: '120 Hz',
      latencyMs: 1.0,
      confidence: 1.0,
      coordinateFrame: 'WORLD',
      modelVersion: 'SpatialOS-Compositor',
      details: 'Renders low-latency spatial UI, adjusts window anchors, provides collision safety alerts, and feeds VR/AR compositor.'
    }
  ]);

  selectStage(stage: PipelineStage) {
    this.selectedStageId.set(stage.id);
  }

  currentSelectedStage() {
    return this.stages().find(s => s.id === this.selectedStageId());
  }
}
