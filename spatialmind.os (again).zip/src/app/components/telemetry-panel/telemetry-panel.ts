import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';
import { PowerMode } from '../../core/types';

@Component({
  selector: 'app-telemetry-panel',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <mat-icon class="text-base">speed</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Telemetry & Real-Time Scheduler</h2>
            <p class="text-[10px] text-slate-400 font-mono">Multi-Rate Hard Scheduling & Thermal Governor</p>
          </div>
        </div>

        <!-- Power Mode selector -->
        <div class="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-[10px] font-mono">
          <button 
            (click)="setPowerMode(PowerMode.PERFORMANCE)"
            class="px-2 py-0.5 rounded-lg transition-all"
            [class]="engine.activePowerMode() === PowerMode.PERFORMANCE ? 'bg-cyan-500 text-black font-bold shadow' : 'text-slate-400 hover:text-slate-200'"
          >PERF</button>
          <button 
            (click)="setPowerMode(PowerMode.BALANCED)"
            class="px-2 py-0.5 rounded-lg transition-all"
            [class]="engine.activePowerMode() === PowerMode.BALANCED ? 'bg-cyan-500 text-black font-bold shadow' : 'text-slate-400 hover:text-slate-200'"
          >BALANCED</button>
          <button 
            (click)="setPowerMode(PowerMode.BATTERY)"
            class="px-2 py-0.5 rounded-lg transition-all"
            [class]="engine.activePowerMode() === PowerMode.BATTERY ? 'bg-amber-500 text-black font-bold shadow' : 'text-slate-400 hover:text-slate-200'"
          >ECO</button>
          <button 
            (click)="setPowerMode(PowerMode.ULTRA_LOW_POWER)"
            class="px-2 py-0.5 rounded-lg transition-all"
            [class]="engine.activePowerMode() === PowerMode.ULTRA_LOW_POWER ? 'bg-emerald-500 text-black font-bold shadow' : 'text-slate-400 hover:text-slate-200'"
          >ULTRA</button>
        </div>
      </div>

      <!-- Top Metric Cards -->
      <div class="grid grid-cols-2 md:grid-cols-4 gap-2.5">
        <!-- 1. Motion to Photon -->
        <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-1">
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400">
            <span>MOTION-TO-PHOTON</span>
            <mat-icon class="text-xs text-cyan-400">timer</mat-icon>
          </div>
          <div class="flex items-baseline gap-1.5">
            <span class="text-lg font-mono font-bold text-slate-100">{{ engine.latencyBreakdown().total_motion_to_photon_ms.toFixed(1) }}</span>
            <span class="text-[10px] text-slate-400 font-mono">ms</span>
            <span class="ml-auto text-[10px] px-1.5 py-0.5 rounded font-mono font-bold"
              [class]="engine.latencyBreakdown().budget_met ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'">
              {{ engine.latencyBreakdown().budget_met ? 'BUDGET MET' : 'OVERRUN' }}
            </span>
          </div>
          <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
            <div 
              class="h-full bg-cyan-400 rounded-full transition-all duration-300"
              [style.width.%]="(engine.latencyBreakdown().total_motion_to_photon_ms / engine.latencyBreakdown().target_budget_ms) * 100"
            ></div>
          </div>
        </div>

        <!-- 2. Display Refresh FPS -->
        <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-1">
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400">
            <span>COMPOSITOR FPS</span>
            <mat-icon class="text-xs text-emerald-400">display_settings</mat-icon>
          </div>
          <div class="flex items-baseline gap-1.5">
            <span class="text-lg font-mono font-bold text-emerald-400">{{ engine.digitalTwin().fps.toFixed(1) }}</span>
            <span class="text-[10px] text-slate-400 font-mono">Hz / Target: 120</span>
          </div>
          <p class="text-[9px] text-slate-500 font-mono mt-1">Zero jitter display swapchain</p>
        </div>

        <!-- 3. SoC Thermal State -->
        <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-1">
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400">
            <span>SoC TEMPERATURE</span>
            <mat-icon class="text-xs text-amber-400">thermostat</mat-icon>
          </div>
          <div class="flex items-baseline gap-1.5">
            <span class="text-lg font-mono font-bold text-amber-300">{{ engine.digitalTwin().soc_temperature_c.toFixed(1) }}°C</span>
            <span class="text-[10px] text-slate-400 font-mono">/ Max 65°C</span>
          </div>
          <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-1">
            <div 
              class="h-full rounded-full transition-all duration-300"
              [class]="engine.digitalTwin().soc_temperature_c > 50 ? 'bg-amber-400' : 'bg-emerald-400'"
              [style.width.%]="(engine.digitalTwin().soc_temperature_c / 65) * 100"
            ></div>
          </div>
        </div>

        <!-- 4. Power Consumption -->
        <div class="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col gap-1">
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400">
            <span>POWER DRAW</span>
            <mat-icon class="text-xs text-purple-400">bolt</mat-icon>
          </div>
          <div class="flex items-baseline gap-1.5">
            <span class="text-lg font-mono font-bold text-purple-300">{{ engine.digitalTwin().power_consumption_watts.toFixed(1) }}</span>
            <span class="text-[10px] text-slate-400 font-mono">Watts</span>
            <span class="ml-auto text-[10px] text-slate-400 font-mono">Bat: {{ engine.digitalTwin().battery_level }}%</span>
          </div>
          <p class="text-[9px] text-slate-500 font-mono mt-1">NPU + GPU Active Domains</p>
        </div>
      </div>

      <!-- Real-Time Scheduler Multi-Rate Table -->
      <div class="flex flex-col gap-2">
        <h3 class="text-[11px] font-bold text-slate-300 font-mono uppercase tracking-wider">Multi-Rate Priority Task Scheduling</h3>
        <div class="overflow-x-auto">
          <table class="w-full text-left text-[11px] font-mono border-collapse">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 text-[10px]">
                <th class="py-1.5 px-2">TASK SUBSYSTEM</th>
                <th class="py-1.5 px-2">PRIORITY</th>
                <th class="py-1.5 px-2">TARGET RATE</th>
                <th class="py-1.5 px-2">ACTUAL RATE</th>
                <th class="py-1.5 px-2">TIME SLICE</th>
                <th class="py-1.5 px-2">STATE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/50 text-slate-300">
              @for (task of engine.scheduledTasks(); track task.name) {
                <tr class="hover:bg-slate-800/30 transition-colors">
                  <td class="py-2 px-2 font-bold text-slate-200">{{ task.name }}</td>
                  <td class="py-2 px-2">
                    <span class="px-1.5 py-0.5 rounded text-[9px] font-bold"
                      [class]="task.priority === 'CRITICAL' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                               task.priority === 'HIGH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                               task.priority === 'NORMAL' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' :
                               'bg-slate-800 text-slate-400'">
                      {{ task.priority }}
                    </span>
                  </td>
                  <td class="py-2 px-2 text-slate-400">{{ task.target_frequency_hz }} Hz</td>
                  <td class="py-2 px-2 font-semibold text-emerald-400">{{ task.actual_frequency_hz.toFixed(1) }} Hz</td>
                  <td class="py-2 px-2 text-slate-400">{{ task.execution_duration_us }} µs</td>
                  <td class="py-2 px-2">
                    <span class="inline-flex items-center gap-1 text-emerald-400 text-[10px]">
                      <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      {{ task.state }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class TelemetryPanel {
  readonly engine = inject(RustEngineService);
  readonly PowerMode = PowerMode;

  setPowerMode(mode: PowerMode) {
    this.engine.setPowerMode(mode);
  }
}
