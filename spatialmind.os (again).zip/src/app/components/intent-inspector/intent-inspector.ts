import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';

@Component({
  selector: 'app-intent-inspector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-4">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <mat-icon class="text-base">psychology</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Multimodal User Intent & Attention Engine</h2>
            <p class="text-[10px] text-slate-400 font-mono">Probabilistic Inference (Gaze + Hands + Motion + Context)</p>
          </div>
        </div>

        <button 
          (click)="triggerAiSpatialReasoning()"
          [disabled]="isAiAnalyzing()"
          class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-black shadow-md transition-all disabled:opacity-50"
        >
          <mat-icon class="text-sm">{{ isAiAnalyzing() ? 'hourglass_top' : 'auto_awesome' }}</mat-icon>
          <span>{{ isAiAnalyzing() ? 'Reasoning...' : 'AI Spatial Reasoning' }}</span>
        </button>
      </div>

      <!-- Main Intent Card -->
      <div class="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex flex-col gap-2">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-[10px] font-mono text-slate-500 uppercase tracking-wider">PRIMARY INFERRED INTENT</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              CONFIDENCE: {{(engine.userIntent().confidence * 100).toFixed(1)}}%
            </span>
          </div>

          <span class="text-[10px] font-mono text-purple-400">Target: {{ engine.userIntent().target_object_id || 'Global Workspace' }}</span>
        </div>

        <h3 class="text-base font-bold text-slate-100 font-mono tracking-tight flex items-center gap-2">
          <span class="text-cyan-400">▶</span> {{ engine.userIntent().primary_intent }}
        </h3>

        <p class="text-xs text-slate-300 leading-relaxed">{{ engine.userIntent().explanation }}</p>

        <!-- Trigger Signals Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono">
          <div class="flex items-center gap-2 text-slate-400">
            <mat-icon class="text-xs text-emerald-400">visibility</mat-icon>
            <span class="text-slate-500">Gaze:</span>
            <span class="text-slate-200 truncate">{{ engine.userIntent().trigger_signals.gaze_signal }}</span>
          </div>

          <div class="flex items-center gap-2 text-slate-400">
            <mat-icon class="text-xs text-cyan-400">back_hand</mat-icon>
            <span class="text-slate-500">Hand:</span>
            <span class="text-slate-200 truncate">{{ engine.userIntent().trigger_signals.hand_signal }}</span>
          </div>

          <div class="flex items-center gap-2 text-slate-400">
            <mat-icon class="text-xs text-amber-400">explore</mat-icon>
            <span class="text-slate-500">Head:</span>
            <span class="text-slate-200 truncate">{{ engine.userIntent().trigger_signals.head_signal }}</span>
          </div>

          <div class="flex items-center gap-2 text-slate-400">
            <mat-icon class="text-xs text-purple-400">category</mat-icon>
            <span class="text-slate-500">Context:</span>
            <span class="text-slate-200 truncate">{{ engine.userIntent().trigger_signals.context_signal }}</span>
          </div>
        </div>
      </div>

      <!-- Candidate Intent Distribution & Attention -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <!-- Candidate Probabilities -->
        <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col gap-2">
          <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Candidate Action Probability</span>
          <div class="flex flex-col gap-2">
            @for (cand of engine.userIntent().candidate_actions; track cand.action) {
              <div class="flex flex-col gap-1">
                <div class="flex items-center justify-between text-[11px] font-mono">
                  <span class="text-slate-300">{{ cand.action }}</span>
                  <span class="text-cyan-400 font-bold">{{ (cand.probability * 100).toFixed(0) }}%</span>
                </div>
                <div class="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div 
                    class="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full transition-all duration-300"
                    [style.width.%]="cand.probability * 100"
                  ></div>
                </div>
                <span class="text-[9px] text-slate-500 truncate">{{ cand.description }}</span>
              </div>
            }
          </div>
        </div>

        <!-- Eye-Gaze & Attention Salience -->
        <div class="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex flex-col gap-2">
          <span class="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">Spatial Attention Salience</span>
          
          <div class="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800 font-mono text-[11px]">
            <span class="text-slate-400">Attention Score:</span>
            <span class="text-emerald-400 font-bold text-sm">{{ (engine.gazeState().attention_score * 100).toFixed(0) }} / 100</span>
          </div>

          <div class="grid grid-cols-2 gap-2 text-[10px] font-mono text-slate-300">
            <div class="p-2 rounded-lg bg-slate-900/50 border border-slate-800/80">
              <span class="text-slate-500 block">Fixation Dwell:</span>
              <strong class="text-slate-100 text-xs">{{ engine.gazeState().duration_ms }} ms</strong>
            </div>
            <div class="p-2 rounded-lg bg-slate-900/50 border border-slate-800/80">
              <span class="text-slate-500 block">Saccade Rate:</span>
              <strong class="text-slate-100 text-xs">{{ engine.gazeState().velocity_deg_per_sec.toFixed(1) }} °/s</strong>
            </div>
          </div>

          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-800/60">
            <span>Fixation State:</span>
            <span class="px-1.5 py-0.5 rounded font-bold"
              [class]="engine.gazeState().fixation_state === 'FIXATION' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'">
              {{ engine.gazeState().fixation_state }}
            </span>
          </div>
        </div>
      </div>

      <!-- AI Spatial Reasoning Assessment Card (Dynamic Output) -->
      @if (aiAssessment(); as ai) {
        <div class="p-3.5 rounded-xl bg-gradient-to-br from-purple-950/40 via-slate-950 to-cyan-950/40 border border-purple-500/40 shadow-lg flex flex-col gap-2">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-1.5 text-xs font-mono text-purple-300 font-bold">
              <mat-icon class="text-sm">auto_awesome</mat-icon>
              <span>GEMINI SPATIAL REASONING CORE</span>
            </div>
            <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
              CONF: {{ (ai.confidence * 100).toFixed(0) }}%
            </span>
          </div>

          <p class="text-xs text-slate-200 leading-relaxed font-sans">{{ ai.spatial_insight }}</p>

          <div class="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] font-mono flex flex-col gap-1 text-slate-300">
            <div class="flex items-center gap-1.5 text-cyan-400 font-bold">
              <mat-icon class="text-xs">touch_app</mat-icon>
              <span>Recommended Proactive OS Action:</span>
            </div>
            <span class="text-slate-200">{{ ai.proactive_action }}</span>
            <div class="text-[10px] text-slate-400 pt-1 mt-1 border-t border-slate-800/80">
              Optimal Anchor Position: [x: {{ ai.recommended_window_pose.x }}, y: {{ ai.recommended_window_pose.y }}, z: {{ ai.recommended_window_pose.z }}]
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class IntentInspector {
  readonly engine = inject(RustEngineService);
  readonly isAiAnalyzing = signal<boolean>(false);

  readonly aiAssessment = signal<{
    spatial_insight: string;
    proactive_action: string;
    confidence: number;
    recommended_window_pose: { x: number; y: number; z: number };
  } | null>({
    spatial_insight: "Workstation desk surface detected at 0.75m elevation. User gaze fixation and 1.8cm pinch gap on right hand indicates active window manipulation request.",
    proactive_action: "Anchor Spatial Telemetry HUD at +0.75m lateral offset, 1.45m height with 20° inward vergence angle.",
    confidence: 0.96,
    recommended_window_pose: { x: 0.75, y: 1.45, z: -0.9 }
  });

  async triggerAiSpatialReasoning() {
    this.isAiAnalyzing.set(true);
    try {
      const response = await fetch('/api/spatialmind/analyze-scene', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scene_objects: this.engine.spatialObjects(),
          gaze_target: this.engine.gazeState(),
          user_intent: this.engine.userIntent(),
          context: { interaction_mode: 'DIRECT_MANIPULATION', location: 'DESK_WORKSPACE' }
        })
      });

      if (response.ok) {
        const data = await response.json();
        this.aiAssessment.set(data);
        this.engine.logEvent('INFO', 'intent', `AI Spatial Reasoning updated. Recommended action: ${data.proactive_action}`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      this.isAiAnalyzing.set(false);
    }
  }
}
