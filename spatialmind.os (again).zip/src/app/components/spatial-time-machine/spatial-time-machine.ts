import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RustEngineService } from '../../core/rust-engine.service';

@Component({
  selector: 'app-spatial-time-machine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bg-slate-900/90 backdrop-blur-md rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-slate-800/80 pb-3">
        <div class="flex items-center gap-2">
          <div class="p-1.5 rounded-lg bg-pink-500/10 text-pink-400 border border-pink-500/20">
            <mat-icon class="text-base">history_toggle_drop_down</mat-icon>
          </div>
          <div>
            <h2 class="text-xs font-bold text-slate-100 uppercase tracking-wider">Spatial Time Machine & Deterministic Replay</h2>
            <p class="text-[10px] text-slate-400 font-mono">Microsecond-Accurate Ring Buffer ({{ engine.recordedFrames().length }} frames recorded)</p>
          </div>
        </div>

        <!-- Mode Badge -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="px-2.5 py-0.5 rounded-full font-bold"
            [class]="engine.isRecordingLive() ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'">
            {{ engine.isRecordingLive() ? 'LIVE STREAMING (REC)' : 'REPLAY / SCRUBBING' }}
          </span>
        </div>
      </div>

      <!-- Playback Controls -->
      <div class="flex items-center justify-between gap-4 p-2 rounded-xl bg-slate-950/80 border border-slate-800">
        <div class="flex items-center gap-2">
          <button 
            (click)="engine.togglePlayPause()"
            class="p-2 rounded-lg bg-cyan-500 text-black font-bold hover:bg-cyan-400 transition-all flex items-center justify-center shadow"
          >
            <mat-icon class="text-base">{{ engine.isRecordingLive() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>

          <button 
            (click)="engine.resumeLive()"
            class="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono font-medium flex items-center gap-1 transition-all"
          >
            <mat-icon class="text-xs text-red-400">fiber_manual_record</mat-icon>
            Jump to Live
          </button>
        </div>

        <!-- Timeline Scrubber -->
        <div class="flex-1 flex flex-col gap-1">
          <div class="flex items-center justify-between text-[10px] font-mono text-slate-400">
            <span>Frame #0</span>
            <span class="text-cyan-400 font-bold">Current: Frame #{{ engine.replayIndex() }}</span>
            <span>Frame #{{ engine.recordedFrames().length > 0 ? engine.recordedFrames().length - 1 : 0 }}</span>
          </div>

          <input 
            type="range"
            min="0"
            [max]="engine.recordedFrames().length > 0 ? engine.recordedFrames().length - 1 : 0"
            [value]="engine.replayIndex()"
            (input)="onScrub($event)"
            class="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        <!-- Speed Selectors -->
        <div class="flex items-center gap-1 text-[10px] font-mono bg-slate-900 p-1 rounded-lg border border-slate-800">
          <button 
            (click)="engine.setPlaybackSpeed(0.25)"
            class="px-1.5 py-0.5 rounded transition-all"
            [class]="engine.playbackSpeed() === 0.25 ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-slate-200'"
          >0.25x</button>
          <button 
            (click)="engine.setPlaybackSpeed(0.5)"
            class="px-1.5 py-0.5 rounded transition-all"
            [class]="engine.playbackSpeed() === 0.5 ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-slate-200'"
          >0.5x</button>
          <button 
            (click)="engine.setPlaybackSpeed(1.0)"
            class="px-1.5 py-0.5 rounded transition-all"
            [class]="engine.playbackSpeed() === 1.0 ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-slate-200'"
          >1.0x</button>
          <button 
            (click)="engine.setPlaybackSpeed(2.0)"
            class="px-1.5 py-0.5 rounded transition-all"
            [class]="engine.playbackSpeed() === 2.0 ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-slate-200'"
          >2.0x</button>
        </div>
      </div>
    </div>
  `
})
export class SpatialTimeMachine {
  readonly engine = inject(RustEngineService);

  onScrub(e: Event) {
    const target = e.target as HTMLInputElement;
    this.engine.seekToFrame(parseInt(target.value, 10));
  }
}
