// ============================================================================
// SPATIALMIND.OS — CORE ENGINE SERVICE
// Real-time Spatial Intelligence, Sensor Fusion, Prediction & Adaptive Computing
// ============================================================================

import { Injectable, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { 
  SpatialPose, 
  SpatialVelocity, 
  SensorHealth, 
  SpatialObject, 
  SpatialAnchor, 
  GazeState, 
  HandState, 
  HandJoint,
  InteractionState, 
  SceneGraph, 
  SpatialRelationshipEdge, 
  SafetyState, 
  ModelProfile, 
  SystemTelemetry, 
  SpatialEvent, 
  ReplayKeyframe, 
  SpatialSessionRecording, 
  ComputeDevice, 
  PowerMode, 
  ThermalState, 
  UserIntentType,
  HandGesture,
  CollisionRiskLevel,
  Vec3
} from '../core/types';
import { SpatialMath, ExtendedKalmanFilter6DoF } from '../core/math-utils';

@Injectable({
  providedIn: 'root',
})
export class SpatialEngineService {
  // Engine execution state
  readonly isRunning = signal<boolean>(true);
  readonly isSimulation = signal<boolean>(true);
  readonly isReplaying = signal<boolean>(false);
  readonly activeTab = signal<'viewport' | 'pipeline' | 'digital-twin' | 'intent' | 'memory' | 'timemachine' | 'cli' | 'rust-crates'>('viewport');

  // Head Pose & Predictions
  readonly headPose = signal<SpatialPose>({
    position: SpatialMath.vec3(0, 1.65, 0),
    orientation: SpatialMath.quatIdentity(),
    coordinate_frame: 'HEAD',
    timestamp_ns: 0,
    confidence: 0.985,
  });

  readonly predictedHeadPose = signal<SpatialPose>({
    position: SpatialMath.vec3(0, 1.65, 0),
    orientation: SpatialMath.quatIdentity(),
    coordinate_frame: 'HEAD',
    timestamp_ns: 0,
    confidence: 0.962,
  });

  readonly headVelocity = signal<SpatialVelocity>({
    linear: SpatialMath.vec3(0, 0, 0),
    angular: SpatialMath.vec3(0, 0, 0),
    coordinate_frame: 'HEAD',
    timestamp_ns: 0,
  });

  readonly predictionHorizonMs = signal<number>(18.5); // Configurable 5ms - 50ms for display motion-to-photon latency

  // Eye Gaze
  readonly gazeState = signal<GazeState>({
    origin: SpatialMath.vec3(0, 1.65, 0),
    direction: SpatialMath.vec3(0, 0, -1),
    target_object_id: 'obj-screen-01',
    target_point: SpatialMath.vec3(0, 1.45, -1.8),
    confidence: 0.94,
    vergence_distance_m: 1.8,
    angular_velocity_deg_s: 4.2,
    fixation_duration_ms: 380,
    classification: 'FIXATION',
    pupil_diameter_mm: { left: 3.8, right: 3.8 },
    attention_salience: 0.88,
    timestamp_ns: 0,
  });

  // Hands (Left & Right 26-Joint Kinematics)
  readonly leftHand = signal<HandState>(this.createInitialHandState('LEFT'));
  readonly rightHand = signal<HandState>(this.createInitialHandState('RIGHT'));

  // Multimodal User Intent
  readonly intentState = signal<InteractionState>({
    estimated_intent: 'SELECT_OBJECT',
    intent_confidence: 0.91,
    target_object_id: 'obj-screen-01',
    candidate_actions: [
      { action: 'FOCUS_WORKSPACE', target_id: 'obj-screen-01', probability: 0.91, suggested_ui_feedback: 'Haptic Click + Reticle Bloom' },
      { action: 'DRAG_WINDOW', target_id: 'obj-screen-01', probability: 0.06, suggested_ui_feedback: 'Surface Highlight' },
      { action: 'DISMISS_VIEW', target_id: 'obj-screen-01', probability: 0.03, suggested_ui_feedback: 'Fade Out' },
    ],
    multimodal_signals: {
      gaze_alignment: 0.94,
      hand_proximity: 0.88,
      head_trajectory_alignment: 0.82,
      voice_event_active: false,
      dwell_time_ms: 420,
    },
    suggested_os_action: 'HIGHLIGHT_AND_PREPARE_GESTURE_CAPTURE',
    timestamp_ns: 0,
  });

  // Spatial World Model (Objects, Anchors, Planes)
  readonly spatialObjects = signal<SpatialObject[]>(this.createInitialSpatialObjects());
  readonly spatialAnchors = signal<SpatialAnchor[]>(this.createInitialAnchors());

  // Scene Graph & Relational Graph
  readonly sceneGraph = signal<SceneGraph>({
    version: 142,
    last_updated_ns: 0,
    room_name: 'Studio Lab 04 (Mixed Reality Space)',
    relationships: [],
    root_node_id: 'room-root',
  });

  // Safety & Predictive Collision Model
  readonly safetyState = signal<SafetyState>({
    risk_level: 'SAFE',
    nearest_obstacle_id: 'obj-table-01',
    nearest_obstacle_distance_m: 0.94,
    time_to_impact_s: 4.8,
    guardian_boundary_distance_m: 1.45,
    rapid_approach_detected: false,
    recommended_haptic_pulse_intensity: 0.0,
    recommended_visual_alert: null,
  });

  // Sensors Health & Failure Simulation
  readonly sensorsHealth = signal<SensorHealth[]>(this.createInitialSensorsHealth());

  // Model Registry & Adaptive Router
  readonly models = signal<ModelProfile[]>(this.createInitialModelProfiles());
  readonly activeComputeDevice = signal<ComputeDevice>('NPU');
  readonly powerMode = signal<PowerMode>('BALANCED');
  readonly thermalState = signal<ThermalState>('NOMINAL');

  // Telemetry & Latency Profiling
  readonly telemetry = signal<SystemTelemetry>({
    fps: 90,
    end_to_end_latency_ms: 8.4,
    sensor_latency_ms: 1.8,
    fusion_latency_ms: 1.2,
    inference_latency_ms: 3.6,
    prediction_latency_ms: 0.8,
    render_submission_latency_ms: 1.0,
    battery_level_pct: 88,
    battery_drain_rate_w: 4.2,
    device_temperature_c: 34.2,
    thermal_state: 'NOMINAL',
    power_mode: 'BALANCED',
    active_compute_device: 'NPU',
    dropped_frames_total: 0,
    timestamp_ns: 0,
  });

  // Event Bus & Logs
  readonly recentEvents = signal<SpatialEvent[]>([]);

  // Time Machine & Replay Buffer (Stores last 30 seconds of high-fidelity state)
  readonly replaySession = signal<SpatialSessionRecording>({
    session_id: 'session-live-001',
    device_model: 'SpatialMind Pro Glass-1 / HMD Reference',
    start_time_iso: new Date().toISOString(),
    duration_ms: 0,
    total_frames: 0,
    keyframes: [],
  });
  readonly replayScrubIndex = signal<number>(0);

  // EKF Estimator
  private platformId = inject(PLATFORM_ID);
  private isBrowser = isPlatformBrowser(this.platformId);
  private ekf = new ExtendedKalmanFilter6DoF();
  private animationFrameId: number | null = null;
  private lastTickMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
  private simTimeSec = 0;
  private eventCounter = 0;

  constructor() {
    this.updateSceneGraphRelationships();
    if (this.isBrowser) {
      this.startEngineLoop();
    }
  }

  // ==========================================================================
  // REAL-TIME MULTI-RATE PIPELINE EXECUTION
  // ==========================================================================
  startEngineLoop(): void {
    if (!this.isBrowser || typeof requestAnimationFrame === 'undefined') return;

    const loop = (now: number) => {
      const dtSec = Math.min(0.05, (now - this.lastTickMs) / 1000);
      this.lastTickMs = now;

      if (this.isRunning() && !this.isReplaying()) {
        this.simTimeSec += dtSec;
        this.stepSimulation(dtSec);
      }

      this.animationFrameId = requestAnimationFrame(loop);
    };
    this.animationFrameId = requestAnimationFrame(loop);
  }

  stopEngineLoop(): void {
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  toggleRunning(): void {
    this.isRunning.update((v) => !v);
  }

  /**
   * Main simulation and estimation step
   */
  private stepSimulation(dt: number): void {
    const t = this.simTimeSec;

    // 1. Simulate Human Head Kinematics (gentle natural micro-saccades and sway)
    const headX = Math.sin(t * 0.4) * 0.35 + Math.sin(t * 1.2) * 0.04;
    const headY = 1.65 + Math.cos(t * 0.6) * 0.05 + Math.sin(t * 2.1) * 0.01;
    const headZ = -0.2 + Math.cos(t * 0.3) * 0.25;

    const yaw = Math.sin(t * 0.5) * 0.38 + Math.sin(t * 1.5) * 0.05;
    const pitch = Math.sin(t * 0.7) * 0.12 - 0.08; // slightly looking down at desk
    const roll = Math.sin(t * 0.9) * 0.03;

    const simulatedOrientation = SpatialMath.quatFromEuler(roll, pitch, yaw);

    // 2. High-Rate IMU (500Hz equivalent) + EKF fusion
    const accelNoise = {
      x: (Math.random() - 0.5) * 0.04,
      y: (Math.random() - 0.5) * 0.04,
      z: (Math.random() - 0.5) * 0.04,
    };
    const gyroNoise = {
      x: (Math.random() - 0.5) * 0.01,
      y: (Math.random() - 0.5) * 0.01,
      z: (Math.random() - 0.5) * 0.01,
    };

    const accelRaw = SpatialMath.add(SpatialMath.vec3(0, 9.81, 0), accelNoise);
    const gyroRaw = SpatialMath.add(SpatialMath.vec3(roll, pitch, yaw), gyroNoise);

    this.ekf.predict(accelRaw, gyroRaw, dt);
    this.ekf.updateVisualSLAM(
      SpatialMath.vec3(headX, headY, headZ),
      simulatedOrientation,
      0.95
    );

    const fusedPose = this.ekf.getState('HEAD');
    this.headPose.set(fusedPose);

    // 3. Head Pose Temporal Prediction (Extrapolation to beat motion-to-photon latency)
    const horizonSec = this.predictionHorizonMs() / 1000;
    const vel = this.ekf.getVelocity();
    this.headVelocity.set({
      linear: vel,
      angular: SpatialMath.vec3(0.08, 0.12, 0.02),
      coordinate_frame: 'HEAD',
      timestamp_ns: performance.now() * 1e6,
    });

    const predPos = SpatialMath.add(fusedPose.position, SpatialMath.scale(vel, horizonSec));
    // Predict orientation extrapolation
    const predRot = SpatialMath.quatSlerp(
      fusedPose.orientation,
      SpatialMath.quatFromEuler(roll + 0.02 * horizonSec, pitch, yaw + 0.05 * horizonSec),
      0.98
    );

    this.predictedHeadPose.set({
      position: predPos,
      orientation: predRot,
      coordinate_frame: 'HEAD',
      timestamp_ns: performance.now() * 1e6 + this.predictionHorizonMs() * 1e6,
      confidence: Math.max(0.88, fusedPose.confidence - 0.03),
    });

    // 4. Update Right & Left Hand Kinematics & Gestures
    this.updateSimulatedHands(t, dt, fusedPose);

    // 5. Update Eye Gaze State & Target Object Intersections
    this.updateSimulatedGaze(t, fusedPose);

    // 6. Update Dynamic Objects (e.g. coffee cup pickup, dynamic person passing by)
    this.updateDynamicObjects(t);

    // 7. Multimodal User Intent Engine Inference
    this.inferUserIntent();

    // 8. Spatial Attention Computation
    this.computeSpatialAttention();

    // 9. Safety Boundary & Collision Prediction
    this.updateSafetyState();

    // 10. Update System Telemetry, Battery & Thermal Dynamics
    this.updateTelemetryAndThermals(dt);

    // 11. Record Keyframe into Spatial Time Machine
    this.recordKeyframe();
  }

  // ==========================================================================
  // HAND TRACKING & 26-JOINT KINEMATICS
  // ==========================================================================
  private updateSimulatedHands(t: number, dt: number, head: SpatialPose): void {
    // Right Hand (Active Interaction Hand)
    // Moves towards the screen or interactive widget with pinch cycles
    const pinchCycle = (Math.sin(t * 1.5) + 1) * 0.5; // 0.0 (pinched) to 1.0 (open)
    const isPinching = pinchCycle < 0.25;

    const rHandBaseX = head.position.x + 0.22 + Math.sin(t * 1.1) * 0.08;
    const rHandBaseY = head.position.y - 0.28 + Math.cos(t * 1.3) * 0.06;
    const rHandBaseZ = head.position.z - 0.55 + Math.sin(t * 0.8) * 0.12;

    const rGesture: HandGesture = isPinching ? 'PINCH' : pinchCycle < 0.5 ? 'TAP' : 'POINT';
    const rPinchDist = isPinching ? 2.5 : 8.0 + pinchCycle * 55.0;

    const rHand: HandState = {
      handedness: 'RIGHT',
      is_tracked: true,
      wrist_position: SpatialMath.vec3(rHandBaseX, rHandBaseY, rHandBaseZ),
      palm_normal: SpatialMath.vec3(0, 0.9, -0.4),
      palm_direction: SpatialMath.vec3(0, 0.4, -0.9),
      pinch_position: SpatialMath.vec3(rHandBaseX - 0.02, rHandBaseY + 0.06, rHandBaseZ - 0.08),
      pinch_distance_mm: rPinchDist,
      velocity: SpatialMath.vec3(0.04 * Math.cos(t), 0.02 * Math.sin(t), 0.06 * Math.cos(t)),
      gesture: rGesture,
      gesture_confidence: isPinching ? 0.97 : 0.89,
      joints: this.generate26Joints(rHandBaseX, rHandBaseY, rHandBaseZ, isPinching, 'RIGHT'),
      timestamp_ns: performance.now() * 1e6,
    };

    // Left Hand (Resting or Steady Auxiliary Hand)
    const lHandBaseX = head.position.x - 0.28 + Math.sin(t * 0.4) * 0.02;
    const lHandBaseY = head.position.y - 0.38 + Math.cos(t * 0.5) * 0.02;
    const lHandBaseZ = head.position.z - 0.42;

    const lHand: HandState = {
      handedness: 'LEFT',
      is_tracked: true,
      wrist_position: SpatialMath.vec3(lHandBaseX, lHandBaseY, lHandBaseZ),
      palm_normal: SpatialMath.vec3(0.3, 0.8, -0.5),
      palm_direction: SpatialMath.vec3(0.2, 0.3, -0.9),
      pinch_position: SpatialMath.vec3(lHandBaseX + 0.02, lHandBaseY + 0.04, lHandBaseZ - 0.06),
      pinch_distance_mm: 64.0,
      velocity: SpatialMath.vec3(0.005, 0.002, 0.003),
      gesture: 'OPEN_HAND',
      gesture_confidence: 0.94,
      joints: this.generate26Joints(lHandBaseX, lHandBaseY, lHandBaseZ, false, 'LEFT'),
      timestamp_ns: performance.now() * 1e6,
    };

    this.rightHand.set(rHand);
    this.leftHand.set(lHand);
  }

  private generate26Joints(bx: number, by: number, bz: number, isPinch: boolean, side: 'LEFT' | 'RIGHT'): HandJoint[] {
    const joints: HandJoint[] = [];
    const sign = side === 'RIGHT' ? 1 : -1;

    // Wrist & Palm
    joints.push({ name: 'wrist', position: SpatialMath.vec3(bx, by, bz), orientation: SpatialMath.quatIdentity(), confidence: 0.99 });
    joints.push({ name: 'palm', position: SpatialMath.vec3(bx + 0.01 * sign, by + 0.03, bz - 0.04), orientation: SpatialMath.quatIdentity(), confidence: 0.98 });

    // 5 Fingers x 4-5 joints each = 24 skeletal nodes
    const fingers = ['thumb', 'index', 'middle', 'ring', 'pinky'];
    fingers.forEach((finger, fIdx) => {
      const fingerSpread = (fIdx - 2) * 0.018 * sign;
      for (let j = 0; j < 4; j++) {
        let pinchOffset = 0;
        if (isPinch && (finger === 'thumb' || finger === 'index') && j >= 2) {
          pinchOffset = (finger === 'thumb' ? 0.012 : -0.012) * sign;
        }

        joints.push({
          name: `${finger}_joint_${j}`,
          position: SpatialMath.vec3(
            bx + fingerSpread + (j * 0.012 * sign) + pinchOffset,
            by + 0.04 + (j * 0.016),
            bz - 0.04 - (j * 0.022)
          ),
          orientation: SpatialMath.quatIdentity(),
          confidence: 0.93 - j * 0.02,
        });
      }
    });

    return joints;
  }

  // ==========================================================================
  // EYE GAZE & SPATIAL RAYCASTING
  // ==========================================================================
  private updateSimulatedGaze(t: number, head: SpatialPose): void {
    // Gaze forward vector transformed by head orientation
    const gazeForward = SpatialMath.quatRotateVector(
      head.orientation,
      SpatialMath.vec3(Math.sin(t * 0.8) * 0.08, Math.sin(t * 1.1) * 0.05, -1)
    );
    const normalizedGaze = SpatialMath.normalize(gazeForward);

    // Raycast against all spatial objects
    let closestHitObject: SpatialObject | null = null;
    let minHitDistance = Infinity;
    let hitPoint: Vec3 | null = null;

    const objects = this.spatialObjects();
    for (const obj of objects) {
      const halfDim = SpatialMath.scale(obj.bounding_volume.dimensions, 0.5);
      const boxMin = SpatialMath.sub(obj.position, halfDim);
      const boxMax = SpatialMath.add(obj.position, halfDim);

      const hit = SpatialMath.rayIntersectsAABB(head.position, normalizedGaze, boxMin, boxMax);
      if (hit.hit && hit.distance < minHitDistance) {
        minHitDistance = hit.distance;
        closestHitObject = obj;
        hitPoint = hit.point || null;
      }
    }

    const gazeAngVel = Math.abs(Math.sin(t * 2.5)) * 18.0;
    const isFixation = gazeAngVel < 20.0;

    this.gazeState.set({
      origin: { ...head.position },
      direction: normalizedGaze,
      target_object_id: closestHitObject ? closestHitObject.id : null,
      target_point: hitPoint || SpatialMath.add(head.position, SpatialMath.scale(normalizedGaze, 2.0)),
      confidence: 0.95,
      vergence_distance_m: minHitDistance < 10 ? minHitDistance : 2.0,
      angular_velocity_deg_s: gazeAngVel,
      fixation_duration_ms: isFixation ? 450 + Math.floor(Math.sin(t) * 120) : 40,
      classification: isFixation ? 'FIXATION' : 'SACCADE',
      pupil_diameter_mm: { left: 3.8 + Math.sin(t * 0.5) * 0.2, right: 3.8 + Math.sin(t * 0.5) * 0.2 },
      attention_salience: closestHitObject ? 0.92 : 0.45,
      timestamp_ns: performance.now() * 1e6,
    });
  }

  // ==========================================================================
  // DYNAMIC OBJECTS & SCENE GRAPH
  // ==========================================================================
  private updateDynamicObjects(t: number): void {
    const head = this.headPose();
    this.spatialObjects.update((objs) => {
      return objs.map((obj) => {
        const newPos = { ...obj.position };

        // If person, simulate walking across room
        if (obj.semantic_class === 'PERSON') {
          newPos.x = 1.8 + Math.sin(t * 0.2) * 1.2;
          newPos.z = -2.8 + Math.cos(t * 0.2) * 0.8;
        }

        // Calculate distance to user
        const dist = SpatialMath.distance(head.position, newPos);

        return {
          ...obj,
          position: newPos,
          distance_to_user_m: parseFloat(dist.toFixed(2)),
          last_seen_ns: performance.now() * 1e6,
        };
      });
    });
  }

  // ==========================================================================
  // MULTIMODAL INTENT ENGINE
  // ==========================================================================
  private inferUserIntent(): void {
    const gaze = this.gazeState();
    const rHand = this.rightHand();
    const targetObjId = gaze.target_object_id;

    let intent: UserIntentType = 'IDLE_OBSERVE';
    let conf = 0.75;
    let suggestedAction = 'OBSERVE_PASSIVE';

    if (targetObjId && rHand.gesture === 'PINCH') {
      intent = 'SELECT_OBJECT';
      conf = 0.94;
      suggestedAction = 'DISPATCH_SELECT_EVENT_TO_APP';
    } else if (targetObjId && rHand.gesture === 'POINT') {
      intent = 'INSPECT_ENVIRONMENT';
      conf = 0.88;
      suggestedAction = 'PROJECT_RETICLE_AND_AFFORDANCES';
    } else if (rHand.gesture === 'SWIPE') {
      intent = 'DISMISS_VIEW';
      conf = 0.86;
      suggestedAction = 'TRIGGER_DISMISS_ANIMATION';
    } else if (targetObjId && gaze.fixation_duration_ms > 300) {
      intent = 'SELECT_OBJECT';
      conf = 0.82;
      suggestedAction = 'PRE_ACTIVATE_HOVER_FEEDBACK';
    }

    const candidateActions = targetObjId
      ? [
          { action: 'SELECT_OR_ACTIVATE', target_id: targetObjId, probability: conf, suggested_ui_feedback: 'Haptic Click + Reticle Bloom' },
          { action: 'MOVE_OR_REPOSITION', target_id: targetObjId, probability: parseFloat((1 - conf).toFixed(2)), suggested_ui_feedback: 'Surface Bounding Halo' },
        ]
      : [
          { action: 'SCAN_SPACE', target_id: 'world', probability: 0.85, suggested_ui_feedback: 'Subtle Spatial Grid' },
        ];

    this.intentState.set({
      estimated_intent: intent,
      intent_confidence: conf,
      target_object_id: targetObjId,
      candidate_actions: candidateActions,
      multimodal_signals: {
        gaze_alignment: gaze.target_object_id ? 0.95 : 0.3,
        hand_proximity: rHand.is_tracked ? 0.88 : 0.1,
        head_trajectory_alignment: 0.84,
        voice_event_active: false,
        dwell_time_ms: gaze.fixation_duration_ms,
      },
      suggested_os_action: suggestedAction,
      timestamp_ns: performance.now() * 1e6,
    });

    // Fire intent event if changed
    if (Math.random() < 0.01) {
      this.emitEvent('INTENT_CHANGED', 'User Intent Engine', conf, `Intent identified: ${intent} on ${targetObjId || 'None'}`);
    }
  }

  // ==========================================================================
  // SPATIAL ATTENTION MODEL
  // ==========================================================================
  private computeSpatialAttention(): void {
    const gaze = this.gazeState();
    const rHand = this.rightHand();

    this.spatialObjects.update((objs) => {
      return objs.map((obj) => {
        let score = 0.1;
        // Gaze intersection boost
        if (gaze.target_object_id === obj.id) {
          score += 0.55 * (gaze.fixation_duration_ms / 500);
        }
        // Hand proximity boost
        const handDist = SpatialMath.distance(rHand.wrist_position, obj.position);
        if (handDist < 0.6) {
          score += (0.6 - handDist) * 0.5;
        }
        // Distance attenuation
        score *= Math.max(0.2, 1.0 - (obj.distance_to_user_m / 6.0));

        return {
          ...obj,
          attention_score: parseFloat(Math.min(0.99, Math.max(0.05, score)).toFixed(3)),
        };
      });
    });
  }

  // ==========================================================================
  // SAFETY & COLLISION PREDICTION (GUARDIAN)
  // ==========================================================================
  private updateSafetyState(): void {
    const objects = this.spatialObjects();
    let minObstacleDist = Infinity;
    let nearestId: string | null = null;

    for (const obj of objects) {
      if (obj.semantic_class === 'WALL' || obj.semantic_class === 'TABLE' || obj.semantic_class === 'PERSON') {
        if (obj.distance_to_user_m < minObstacleDist) {
          minObstacleDist = obj.distance_to_user_m;
          nearestId = obj.id;
        }
      }
    }

    const userSpeed = SpatialMath.length(this.headVelocity().linear);
    const timeToImpact = userSpeed > 0.05 ? minObstacleDist / userSpeed : 99.0;

    let risk: CollisionRiskLevel = 'SAFE';
    let haptic = 0.0;
    let visualAlert: string | null = null;

    if (minObstacleDist < 0.45 || timeToImpact < 1.0) {
      risk = 'HIGH_RISK';
      haptic = 1.0;
      visualAlert = 'CRITICAL: IMMINENT PROXIMITY TO OBSTACLE';
    } else if (minObstacleDist < 0.85 || timeToImpact < 2.5) {
      risk = 'CAUTION';
      haptic = 0.4;
      visualAlert = 'CAUTION: Boundary Proximity';
    }

    this.safetyState.set({
      risk_level: risk,
      nearest_obstacle_id: nearestId,
      nearest_obstacle_distance_m: parseFloat(minObstacleDist.toFixed(2)),
      time_to_impact_s: parseFloat(timeToImpact.toFixed(1)),
      guardian_boundary_distance_m: parseFloat(Math.max(0.1, minObstacleDist - 0.3).toFixed(2)),
      rapid_approach_detected: userSpeed > 0.8,
      recommended_haptic_pulse_intensity: haptic,
      recommended_visual_alert: visualAlert,
    });
  }

  // ==========================================================================
  // TELEMETRY & THERMALS
  // ==========================================================================
  private updateTelemetryAndThermals(dt: number): void {
    const currentTelem = this.telemetry();
    const batteryDrain = this.powerMode() === 'PERFORMANCE' ? 5.8 : this.powerMode() === 'BATTERY' ? 2.6 : 3.8;
    const targetTemp = this.powerMode() === 'PERFORMANCE' ? 39.5 : this.powerMode() === 'BATTERY' ? 31.0 : 34.0;

    const newTemp = currentTelem.device_temperature_c + (targetTemp - currentTelem.device_temperature_c) * 0.02;
    const newBattery = Math.max(1, currentTelem.battery_level_pct - (batteryDrain * dt * 0.005));

    let thermState: ThermalState = 'NOMINAL';
    if (newTemp > 42.0) thermState = 'CRITICAL_THROTTLED';
    else if (newTemp > 37.0) thermState = 'WARM';

    this.thermalState.set(thermState);

    this.telemetry.set({
      fps: this.powerMode() === 'BATTERY' ? 60 : 90,
      end_to_end_latency_ms: parseFloat((7.8 + Math.random() * 1.2).toFixed(1)),
      sensor_latency_ms: 1.8,
      fusion_latency_ms: 1.1,
      inference_latency_ms: parseFloat((3.2 + Math.random() * 0.8).toFixed(1)),
      prediction_latency_ms: 0.8,
      render_submission_latency_ms: 1.1,
      battery_level_pct: parseFloat(newBattery.toFixed(1)),
      battery_drain_rate_w: batteryDrain,
      device_temperature_c: parseFloat(newTemp.toFixed(1)),
      thermal_state: thermState,
      power_mode: this.powerMode(),
      active_compute_device: this.activeComputeDevice(),
      dropped_frames_total: currentTelem.dropped_frames_total,
      timestamp_ns: performance.now() * 1e6,
    });
  }

  // ==========================================================================
  // SPATIAL TIME MACHINE & RECORDING
  // ==========================================================================
  private recordKeyframe(): void {
    const session = this.replaySession();
    const keyframes = session.keyframes;

    // Record at ~30Hz downsampled for memory efficiency
    if (keyframes.length > 0 && (performance.now() * 1e6 - keyframes[keyframes.length - 1].timestamp_ns) < 33e6) {
      return;
    }

    const newKf: ReplayKeyframe = {
      timestamp_ns: performance.now() * 1e6,
      relative_time_ms: session.duration_ms + 33,
      head_pose: this.headPose(),
      predicted_head_pose: this.predictedHeadPose(),
      left_hand: this.leftHand(),
      right_hand: this.rightHand(),
      gaze: this.gazeState(),
      objects: JSON.parse(JSON.stringify(this.spatialObjects())),
      intent: this.intentState(),
      telemetry: this.telemetry(),
      safety: this.safetyState(),
    };

    // Keep ring buffer of last 500 keyframes (~16 seconds)
    const updated = [...keyframes, newKf].slice(-500);

    this.replaySession.set({
      ...session,
      duration_ms: session.duration_ms + 33,
      total_frames: updated.length,
      keyframes: updated,
    });
  }

  scrubTimeMachine(index: number): void {
    const kfs = this.replaySession().keyframes;
    if (index >= 0 && index < kfs.length) {
      this.replayScrubIndex.set(index);
      const kf = kfs[index];
      this.headPose.set(kf.head_pose);
      this.predictedHeadPose.set(kf.predicted_head_pose);
      this.leftHand.set(kf.left_hand);
      this.rightHand.set(kf.right_hand);
      this.gazeState.set(kf.gaze);
      this.spatialObjects.set(kf.objects);
      this.intentState.set(kf.intent);
      this.safetyState.set(kf.safety);
      this.telemetry.set(kf.telemetry);
    }
  }

  // ==========================================================================
  // SENSOR FAULT INJECTION (GRACEFUL DEGRADATION TESTING)
  // ==========================================================================
  toggleSensorHealth(sensorId: string): void {
    this.sensorsHealth.update((sensors) => {
      return sensors.map((s) => {
        if (s.sensor_id === sensorId) {
          const nextActive = !s.is_active;
          const nextState = nextActive ? 'CALIBRATED' : 'FAILED';
          this.emitEvent(
            'SENSOR_DEGRADED',
            'Fault Injection Harness',
            0.99,
            `Sensor ${s.sensor_type} toggled to ${nextActive ? 'ACTIVE' : 'FAILED'}`
          );
          return {
            ...s,
            is_active: nextActive,
            is_degraded: !nextActive,
            calibration_state: nextState,
          };
        }
        return s;
      });
    });
  }

  setPowerMode(mode: PowerMode): void {
    this.powerMode.set(mode);
    this.emitEvent('MODEL_CHANGED', 'Power Orchestrator', 0.98, `Power mode adjusted to ${mode}`);
  }

  setComputeDevice(device: ComputeDevice): void {
    this.activeComputeDevice.set(device);
    this.emitEvent('MODEL_CHANGED', 'Adaptive Model Router', 0.99, `Execution device routed to ${device}`);
  }

  setPredictionHorizon(ms: number): void {
    this.predictionHorizonMs.set(ms);
  }

  // ==========================================================================
  // SPATIAL MEMORY & VECTOR SEARCH
  // ==========================================================================
  querySpatialMemory(queryText: string): { object: SpatialObject; similarity: number }[] {
    // Generate query embedding (hash-based projection for instantaneous deterministic similarity)
    const queryVector = this.generateDeterministicEmbedding(queryText.toLowerCase());

    const results = this.spatialObjects().map((obj) => {
      const sim = SpatialMath.cosineSimilarity(queryVector, obj.embedding_vector);
      // Keyword match bonus
      let bonus = 0;
      if (queryText.toLowerCase().includes(obj.semantic_label.toLowerCase()) ||
          queryText.toLowerCase().includes(obj.semantic_class.toLowerCase())) {
        bonus = 0.45;
      }
      return {
        object: obj,
        similarity: parseFloat(Math.min(0.99, sim + bonus).toFixed(3)),
      };
    });

    return results.sort((a, b) => b.similarity - a.similarity);
  }

  private generateDeterministicEmbedding(text: string): number[] {
    const vec: number[] = new Array(128).fill(0);
    for (let i = 0; i < text.length; i++) {
      const charCode = text.charCodeAt(i);
      const idx1 = (charCode * 7 + i) % 128;
      const idx2 = (charCode * 13 + i * 3) % 128;
      vec[idx1] += Math.sin(charCode);
      vec[idx2] += Math.cos(charCode);
    }
    // Normalize
    const norm = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0)) || 1;
    return vec.map((v) => v / norm);
  }

  // ==========================================================================
  // EVENT BUS
  // ==========================================================================
  emitEvent(type: SpatialEvent['type'], source: string, confidence: number, summary: string, data: unknown = null): void {
    const event: SpatialEvent = {
      id: `evt-${++this.eventCounter}`,
      type,
      timestamp_ns: performance.now() * 1e6,
      source_module: source,
      confidence,
      summary,
      data,
    };
    this.recentEvents.update((evts) => [event, ...evts.slice(0, 49)]);
  }

  // ==========================================================================
  // RELATIONAL GRAPH INITIALIZATION
  // ==========================================================================
  private updateSceneGraphRelationships(): void {
    const edges: SpatialRelationshipEdge[] = [
      { from_id: 'obj-laptop-01', to_id: 'obj-table-01', relationship: 'ON', confidence: 0.98, distance_m: 0.05 },
      { from_id: 'obj-phone-01', to_id: 'obj-table-01', relationship: 'ON', confidence: 0.97, distance_m: 0.04 },
      { from_id: 'obj-cup-01', to_id: 'obj-table-01', relationship: 'ON', confidence: 0.96, distance_m: 0.03 },
      { from_id: 'obj-screen-01', to_id: 'obj-table-01', relationship: 'ABOVE', confidence: 0.95, distance_m: 0.4 },
      { from_id: 'obj-chair-01', to_id: 'obj-table-01', relationship: 'NEAR', confidence: 0.92, distance_m: 0.65 },
      { from_id: 'obj-whiteboard-01', to_id: 'obj-wall-north', relationship: 'CONNECTED_TO', confidence: 0.99, distance_m: 0.02 },
      { from_id: 'obj-person-01', to_id: 'obj-door-01', relationship: 'IN_FRONT_OF', confidence: 0.88, distance_m: 0.8 },
    ];

    this.sceneGraph.set({
      version: 143,
      last_updated_ns: performance.now() * 1e6,
      room_name: 'Studio Lab 04 (Mixed Reality Space)',
      relationships: edges,
      root_node_id: 'room-root',
    });
  }

  // ==========================================================================
  // INITIAL MOCK / SEED DATA
  // ==========================================================================
  private createInitialHandState(side: 'LEFT' | 'RIGHT'): HandState {
    const bx = side === 'RIGHT' ? 0.22 : -0.28;
    return {
      handedness: side,
      is_tracked: true,
      wrist_position: SpatialMath.vec3(bx, 1.35, -0.55),
      palm_normal: SpatialMath.vec3(0, 0.9, -0.4),
      palm_direction: SpatialMath.vec3(0, 0.4, -0.9),
      pinch_position: SpatialMath.vec3(bx, 1.41, -0.63),
      pinch_distance_mm: 32.0,
      velocity: SpatialMath.vec3(0, 0, 0),
      gesture: 'OPEN_HAND',
      gesture_confidence: 0.92,
      joints: this.generate26Joints(bx, 1.35, -0.55, false, side),
      timestamp_ns: 0,
    };
  }

  private createInitialSpatialObjects(): SpatialObject[] {
    return [
      {
        id: 'obj-screen-01',
        semantic_class: 'SCREEN',
        semantic_label: 'Primary Spatial Workspace (4K OLED Float)',
        position: SpatialMath.vec3(0, 1.5, -1.8),
        orientation: SpatialMath.quatIdentity(),
        scale: SpatialMath.vec3(1.2, 0.75, 0.04),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'OBB', dimensions: SpatialMath.vec3(1.2, 0.75, 0.04), center: SpatialMath.vec3(0, 1.5, -1.8) },
        confidence: 0.99,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        anchor_id: 'anchor-workspace',
        embedding_vector: this.generateDeterministicEmbedding('screen display monitor workstation 4k floating workspace'),
        affordances: ['INTERACTABLE', 'SCREEN_DISPLAY', 'FOCUSABLE'],
        is_dynamic: false,
        distance_to_user_m: 1.8,
        attention_score: 0.92,
      },
      {
        id: 'obj-table-01',
        semantic_class: 'TABLE',
        semantic_label: 'Oak Workstation Desk',
        position: SpatialMath.vec3(0, 0.75, -1.5),
        orientation: SpatialMath.quatIdentity(),
        scale: SpatialMath.vec3(1.6, 0.75, 0.9),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'AABB', dimensions: SpatialMath.vec3(1.6, 0.75, 0.9), center: SpatialMath.vec3(0, 0.75, -1.5) },
        confidence: 0.98,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        anchor_id: 'anchor-desk',
        embedding_vector: this.generateDeterministicEmbedding('table desk wooden oak furniture surface'),
        affordances: ['SURFACE', 'COLLIDER', 'SUPPORT'],
        is_dynamic: false,
        distance_to_user_m: 1.5,
        attention_score: 0.35,
      },
      {
        id: 'obj-laptop-01',
        semantic_class: 'LAPTOP',
        semantic_label: 'MacBook Pro M3 Max',
        position: SpatialMath.vec3(-0.35, 0.8, -1.4),
        orientation: SpatialMath.quatFromEuler(0, 0.15, 0),
        scale: SpatialMath.vec3(0.32, 0.22, 0.02),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'OBB', dimensions: SpatialMath.vec3(0.32, 0.22, 0.02), center: SpatialMath.vec3(-0.35, 0.8, -1.4) },
        confidence: 0.96,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('laptop macbook computer keyboard device screen'),
        affordances: ['INTERACTABLE', 'KEYBOARD_INPUT'],
        is_dynamic: false,
        distance_to_user_m: 1.45,
        attention_score: 0.42,
      },
      {
        id: 'obj-cup-01',
        semantic_class: 'COFFEE_CUP',
        semantic_label: 'Ceramic Espresso Mug',
        position: SpatialMath.vec3(0.42, 0.82, -1.3),
        orientation: SpatialMath.quatIdentity(),
        scale: SpatialMath.vec3(0.09, 0.1, 0.09),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'SPHERE', dimensions: SpatialMath.vec3(0.09, 0.1, 0.09), center: SpatialMath.vec3(0.42, 0.82, -1.3), radius: 0.05 },
        confidence: 0.94,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('coffee cup mug espresso ceramic drink beverage'),
        affordances: ['GRABBABLE', 'INTERACTABLE'],
        is_dynamic: true,
        distance_to_user_m: 1.35,
        attention_score: 0.28,
      },
      {
        id: 'obj-whiteboard-01',
        semantic_class: 'WHITEBOARD',
        semantic_label: 'Architecture Design Board',
        position: SpatialMath.vec3(-2.4, 1.6, -1.2),
        orientation: SpatialMath.quatFromEuler(0, 1.57, 0),
        scale: SpatialMath.vec3(2.0, 1.2, 0.05),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'OBB', dimensions: SpatialMath.vec3(2.0, 1.2, 0.05), center: SpatialMath.vec3(-2.4, 1.6, -1.2) },
        confidence: 0.97,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('whiteboard architecture diagrams notes design canvas'),
        affordances: ['SURFACE', 'DRAWABLE'],
        is_dynamic: false,
        distance_to_user_m: 2.68,
        attention_score: 0.15,
      },
      {
        id: 'obj-chair-01',
        semantic_class: 'CHAIR',
        semantic_label: 'Ergonomic Task Chair',
        position: SpatialMath.vec3(0, 0.5, -0.7),
        orientation: SpatialMath.quatIdentity(),
        scale: SpatialMath.vec3(0.65, 0.95, 0.65),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'AABB', dimensions: SpatialMath.vec3(0.65, 0.95, 0.65), center: SpatialMath.vec3(0, 0.5, -0.7) },
        confidence: 0.96,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('chair seating ergonomic mesh office chair'),
        affordances: ['SEATING', 'COLLIDER'],
        is_dynamic: false,
        distance_to_user_m: 0.9,
        attention_score: 0.12,
      },
      {
        id: 'obj-person-01',
        semantic_class: 'PERSON',
        semantic_label: 'Anonymous Human Presence #41',
        position: SpatialMath.vec3(1.8, 1.7, -2.8),
        orientation: SpatialMath.quatFromEuler(0, -0.8, 0),
        scale: SpatialMath.vec3(0.5, 1.75, 0.35),
        velocity: SpatialMath.vec3(-0.2, 0, 0.1),
        bounding_volume: { type: 'AABB', dimensions: SpatialMath.vec3(0.5, 1.75, 0.35), center: SpatialMath.vec3(1.8, 1.7, -2.8) },
        confidence: 0.92,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('person human colleague user walking presence avatar'),
        affordances: ['COMMUNICATION', 'COLLIDER', 'ANONYMOUS_PRESENCE'],
        is_dynamic: true,
        distance_to_user_m: 3.35,
        attention_score: 0.38,
      },
      {
        id: 'obj-door-01',
        semantic_class: 'DOOR',
        semantic_label: 'Lab Entry Portal',
        position: SpatialMath.vec3(2.5, 1.1, -3.2),
        orientation: SpatialMath.quatFromEuler(0, 0, 0),
        scale: SpatialMath.vec3(0.9, 2.1, 0.1),
        velocity: SpatialMath.vec3(0, 0, 0),
        bounding_volume: { type: 'AABB', dimensions: SpatialMath.vec3(0.9, 2.1, 0.1), center: SpatialMath.vec3(2.5, 1.1, -3.2) },
        confidence: 0.98,
        last_seen_ns: 0,
        tracking_state: 'TRACKING',
        embedding_vector: this.generateDeterministicEmbedding('door exit entrance portal egress room'),
        affordances: ['PORTAL', 'EGRESS'],
        is_dynamic: false,
        distance_to_user_m: 4.1,
        attention_score: 0.08,
      },
    ];
  }

  private createInitialAnchors(): SpatialAnchor[] {
    return [
      {
        id: 'anchor-workspace',
        pose: {
          position: SpatialMath.vec3(0, 1.5, -1.8),
          orientation: SpatialMath.quatIdentity(),
          coordinate_frame: 'WORLD',
          timestamp_ns: 0,
          confidence: 0.99,
        },
        world_id: 'world-main-lab',
        confidence: 0.99,
        persistence: 'PERSISTENT',
        semantic_context: 'Primary 4K spatial display anchor above desk',
        created_at_ns: performance.now() * 1e6 - 3600e9,
        last_observed_ns: performance.now() * 1e6,
        drift_radius_m: 0.003,
      },
      {
        id: 'anchor-desk',
        pose: {
          position: SpatialMath.vec3(0, 0.75, -1.5),
          orientation: SpatialMath.quatIdentity(),
          coordinate_frame: 'WORLD',
          timestamp_ns: 0,
          confidence: 0.98,
        },
        world_id: 'world-main-lab',
        confidence: 0.98,
        persistence: 'PERSISTENT',
        semantic_context: 'Physical table plane anchor',
        created_at_ns: performance.now() * 1e6 - 7200e9,
        last_observed_ns: performance.now() * 1e6,
        drift_radius_m: 0.005,
      },
    ];
  }

  private createInitialSensorsHealth(): SensorHealth[] {
    return [
      {
        sensor_id: 'imu-head-01',
        sensor_type: 'IMU_6DOF',
        is_active: true,
        is_degraded: false,
        latency_ms: 0.8,
        jitter_ms: 0.05,
        drop_rate_pct: 0.01,
        noise_floor: 0.002,
        calibration_state: 'CALIBRATED',
        temperature_c: 34.5,
        sample_rate_hz: 500,
        last_sample_ns: performance.now() * 1e6,
      },
      {
        sensor_id: 'cam-stereo-passthrough',
        sensor_type: 'CAMERA_STEREO',
        is_active: true,
        is_degraded: false,
        latency_ms: 3.2,
        jitter_ms: 0.2,
        drop_rate_pct: 0.05,
        noise_floor: 0.01,
        calibration_state: 'CALIBRATED',
        temperature_c: 36.2,
        sample_rate_hz: 90,
        last_sample_ns: performance.now() * 1e6,
      },
      {
        sensor_id: 'lidar-depth-tof',
        sensor_type: 'DEPTH_LIDAR',
        is_active: true,
        is_degraded: false,
        latency_ms: 4.1,
        jitter_ms: 0.3,
        drop_rate_pct: 0.08,
        noise_floor: 0.015,
        calibration_state: 'CALIBRATED',
        temperature_c: 35.0,
        sample_rate_hz: 30,
        last_sample_ns: performance.now() * 1e6,
      },
      {
        sensor_id: 'eye-tracker-ir',
        sensor_type: 'EYE_TRACKER',
        is_active: true,
        is_degraded: false,
        latency_ms: 2.1,
        jitter_ms: 0.1,
        drop_rate_pct: 0.02,
        noise_floor: 0.008,
        calibration_state: 'CALIBRATED',
        temperature_c: 33.8,
        sample_rate_hz: 120,
        last_sample_ns: performance.now() * 1e6,
      },
      {
        sensor_id: 'hand-tracker-optical',
        sensor_type: 'HAND_TRACKER',
        is_active: true,
        is_degraded: false,
        latency_ms: 4.5,
        jitter_ms: 0.4,
        drop_rate_pct: 0.12,
        noise_floor: 0.02,
        calibration_state: 'CALIBRATED',
        temperature_c: 35.8,
        sample_rate_hz: 90,
        last_sample_ns: performance.now() * 1e6,
      },
    ];
  }

  private createInitialModelProfiles(): ModelProfile[] {
    return [
      {
        model_id: 'model-head-ekf-v4',
        name: 'HeadPose EKF + Polynomial Extrapolator',
        task: 'HEAD_POSE_EKF',
        target_device: 'DSP',
        quantization: 'FP32',
        latency_ms: 0.4,
        power_mw: 85,
        memory_mb: 2.4,
        accuracy_map: 0.994,
        is_active: true,
      },
      {
        model_id: 'model-yolo-spatial-v9',
        name: 'SpatialYOLO-3D Instance Segmenter',
        task: 'OBJECT_DETECTION',
        target_device: 'NPU',
        quantization: 'INT8',
        latency_ms: 4.8,
        power_mw: 420,
        memory_mb: 28.5,
        accuracy_map: 0.942,
        is_active: true,
      },
      {
        model_id: 'model-hand-kinematics-v3',
        name: '26-Joint Dual Hand Skeletal Kinematics',
        task: 'HAND_KINEMATICS',
        target_device: 'NPU',
        quantization: 'FP16',
        latency_ms: 2.2,
        power_mw: 190,
        memory_mb: 14.2,
        accuracy_map: 0.978,
        is_active: true,
      },
      {
        model_id: 'model-gaze-vergence-v2',
        name: 'Biconvergent Gaze & Attention Salience',
        task: 'GAZE_ESTIMATION',
        target_device: 'NPU',
        quantization: 'FP16',
        latency_ms: 1.2,
        power_mw: 110,
        memory_mb: 8.6,
        accuracy_map: 0.965,
        is_active: true,
      },
      {
        model_id: 'model-multimodal-intent-v5',
        name: 'Temporal Multimodal Intent Transformer',
        task: 'INTENT_PREDICTOR',
        target_device: 'NPU',
        quantization: 'INT8',
        latency_ms: 1.8,
        power_mw: 140,
        memory_mb: 16.0,
        accuracy_map: 0.938,
        is_active: true,
      },
    ];
  }

  // ==========================================================================
  // PUBLIC SIMULATION ACTIONS & TRIGGERS
  // ==========================================================================
  simulatePinchGesture(): void {
    this.rightHand.update(h => ({
      ...h,
      gesture: 'PINCH',
      pinch_distance_mm: 2.4,
      confidence: 0.99
    }));
    this.intentState.update(i => ({
      ...i,
      estimated_intent: 'SELECT_OBJECT',
      intent_confidence: 0.98,
      suggested_os_action: 'DISPATCH_SELECT_EVENT'
    }));
    setTimeout(() => {
      this.rightHand.update(h => ({
        ...h,
        gesture: 'POINT',
        pinch_distance_mm: 28.0
      }));
    }, 1200);
  }

  simulateHeadMotion(): void {
    const current = this.headPose();
    this.headPose.update(h => ({
      ...h,
      orientation: SpatialMath.quatFromEuler(0.12, -0.25, 0.04),
      velocity: SpatialMath.vec3(0.15, 0.05, -0.1)
    }));
    setTimeout(() => {
      this.headPose.set(current);
    }, 1500);
  }

  createSpatialAnchor(label: string, context = 'USER_INTERACTION'): void {
    const head = this.headPose();
    const newAnchor: SpatialAnchor = {
      id: `anchor-custom-${Date.now().toString().slice(-4)}`,
      pose: {
        position: SpatialMath.vec3(head.position.x, head.position.y, head.position.z - 1.0),
        orientation: SpatialMath.quatIdentity(),
        confidence: 0.98,
        timestamp_ns: Date.now() * 1000000,
        coordinate_frame: 'WORLD'
      },
      world_id: 'world-main-lab',
      persistence: 'PERSISTENT',
      confidence: 0.98,
      drift_radius_m: 0.002,
      created_at_ns: Date.now() * 1000000,
      last_observed_ns: Date.now() * 1000000,
      semantic_context: `${label} (${context})`
    };
    this.spatialAnchors.update(a => [newAnchor, ...a]);
  }
}
