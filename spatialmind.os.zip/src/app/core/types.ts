// ============================================================================
// SPATIALMIND.OS — CORE TYPES & ARCHITECTURAL INTERFACES
// Machine Intelligence for Spatial Computing (VR/AR/MR Operating Systems)
// ============================================================================

export type CoordinateFrame = 
  | 'DEVICE'
  | 'HEAD'
  | 'EYE_LEFT'
  | 'EYE_RIGHT'
  | 'HAND_LEFT'
  | 'HAND_RIGHT'
  | 'CONTROLLER_LEFT'
  | 'CONTROLLER_RIGHT'
  | 'CAMERA'
  | 'IMU'
  | 'WORLD'
  | 'LOCAL'
  | 'OBJECT'
  | 'ANCHOR';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface Quaternion {
  x: number;
  y: number;
  z: number;
  w: number;
}

export interface Mat4 {
  elements: number[]; // 16 elements column-major
}

export interface SpatialPose {
  position: Vec3;
  orientation: Quaternion; // normalized
  coordinate_frame: CoordinateFrame;
  timestamp_ns: number;
  confidence: number; // 0.0 - 1.0
  covariance?: number[][]; // 6x6 pose covariance matrix
}

export interface SpatialVelocity {
  linear: Vec3; // m/s
  angular: Vec3; // rad/s
  coordinate_frame: CoordinateFrame;
  timestamp_ns: number;
}

export interface SpatialAcceleration {
  linear: Vec3; // m/s^2
  angular: Vec3; // rad/s^2
  timestamp_ns: number;
}

export type SensorType = 
  | 'IMU_6DOF'
  | 'IMU_9DOF'
  | 'CAMERA_RGB'
  | 'CAMERA_STEREO'
  | 'CAMERA_MONO'
  | 'DEPTH_LIDAR'
  | 'DEPTH_STRUCTURED_LIGHT'
  | 'EYE_TRACKER'
  | 'HAND_TRACKER'
  | 'CONTROLLER_6DOF'
  | 'AUDIO_ARRAY'
  | 'SPATIAL_ANCHORS';

export interface SensorSample<T = unknown> {
  sensor_id: string;
  sensor_type: SensorType;
  timestamp_ns: number;
  sequence_number: number;
  coordinate_frame: CoordinateFrame;
  payload: T;
  quality: number; // 0.0 - 1.0
  calibration_version: string;
}

export interface IMUPayload {
  accel: Vec3; // m/s^2
  gyro: Vec3;  // rad/s
  mag?: Vec3;  // uT
  temperature_c: number;
}

export interface CameraFramePayload {
  width: number;
  height: number;
  format: 'RGB8' | 'MONO8' | 'DEPTH16' | 'FEATURE_POINTS';
  exposure_us: number;
  gain_db: number;
  features_detected?: number;
}

export interface SensorHealth {
  sensor_id: string;
  sensor_type: SensorType;
  is_active: boolean;
  is_degraded: boolean;
  latency_ms: number;
  jitter_ms: number;
  drop_rate_pct: number;
  noise_floor: number;
  calibration_state: 'CALIBRATED' | 'DRIFTING' | 'UNCALIBRATED' | 'FAILED';
  temperature_c: number;
  sample_rate_hz: number;
  last_sample_ns: number;
}

export type SemanticClass = 
  | 'TABLE'
  | 'CHAIR'
  | 'WALL'
  | 'DOOR'
  | 'WINDOW'
  | 'SCREEN'
  | 'PERSON'
  | 'HAND'
  | 'FLOOR'
  | 'CEILING'
  | 'VEHICLE'
  | 'TREE'
  | 'CONTROLLER'
  | 'LAPTOP'
  | 'SMARTPHONE'
  | 'COFFEE_CUP'
  | 'WHITEBOARD';

export interface BoundingVolume {
  type: 'AABB' | 'OBB' | 'SPHERE';
  dimensions: Vec3; // width, height, depth
  center: Vec3;
  orientation?: Quaternion;
  radius?: number;
}

export type TrackingState = 'TRACKING' | 'OCCLUDED' | 'LOST' | 'PREDICTED';

export interface SpatialObject {
  id: string;
  semantic_class: SemanticClass;
  semantic_label: string;
  position: Vec3;
  orientation: Quaternion;
  scale: Vec3;
  velocity: Vec3;
  bounding_volume: BoundingVolume;
  confidence: number;
  last_seen_ns: number;
  tracking_state: TrackingState;
  anchor_id?: string;
  embedding_vector: number[]; // 128-dim spatial embedding
  affordances: string[]; // e.g. ['INTERACTABLE', 'SURFACE', 'COLLIDER', 'SCREEN_DISPLAY']
  is_dynamic: boolean;
  distance_to_user_m: number;
  attention_score: number; // 0.0 - 1.0 calculated attention
}

export type AnchorPersistence = 'PERSISTENT' | 'SESSION' | 'SHARED' | 'LOCAL';

export interface SpatialAnchor {
  id: string;
  pose: SpatialPose;
  world_id: string;
  confidence: number;
  persistence: AnchorPersistence;
  semantic_context: string;
  created_at_ns: number;
  last_observed_ns: number;
  drift_radius_m: number;
}

export type GazeClassification = 'FIXATION' | 'SACCADE' | 'PURSUIT' | 'BLINK';

export interface GazeState {
  origin: Vec3;
  direction: Vec3; // unit vector
  target_object_id: string | null;
  target_point: Vec3 | null;
  confidence: number;
  vergence_distance_m: number;
  angular_velocity_deg_s: number;
  fixation_duration_ms: number;
  classification: GazeClassification;
  pupil_diameter_mm: { left: number; right: number };
  attention_salience: number;
  timestamp_ns: number;
}

export type HandGesture = 
  | 'PINCH'
  | 'GRAB'
  | 'POINT'
  | 'OPEN_HAND'
  | 'FIST'
  | 'SWIPE'
  | 'ROTATE'
  | 'TAP'
  | 'DRAG'
  | 'RELEASE';

export interface HandJoint {
  name: string;
  position: Vec3;
  orientation: Quaternion;
  confidence: number;
}

export interface HandState {
  handedness: 'LEFT' | 'RIGHT';
  is_tracked: boolean;
  wrist_position: Vec3;
  palm_normal: Vec3;
  palm_direction: Vec3;
  pinch_position: Vec3;
  pinch_distance_mm: number;
  velocity: Vec3;
  gesture: HandGesture;
  gesture_confidence: number;
  joints: HandJoint[]; // 26 joints
  timestamp_ns: number;
}

export type UserIntentType = 
  | 'SELECT_OBJECT'
  | 'DRAG_WINDOW'
  | 'RESIZE_SURFACE'
  | 'DISMISS_VIEW'
  | 'INSPECT_ENVIRONMENT'
  | 'PLACE_ANCHOR'
  | 'ENGAGE_PERSON'
  | 'ZOOM_PERSPECTIVE'
  | 'IDLE_OBSERVE';

export interface CandidateAction {
  action: string;
  target_id: string;
  probability: number;
  suggested_ui_feedback: string;
}

export interface InteractionState {
  estimated_intent: UserIntentType;
  intent_confidence: number;
  target_object_id: string | null;
  candidate_actions: CandidateAction[];
  multimodal_signals: {
    gaze_alignment: number;
    hand_proximity: number;
    head_trajectory_alignment: number;
    voice_event_active: boolean;
    dwell_time_ms: number;
  };
  suggested_os_action: string;
  timestamp_ns: number;
}

export type SpatialRelationshipType = 
  | 'ABOVE'
  | 'BELOW'
  | 'LEFT_OF'
  | 'RIGHT_OF'
  | 'NEAR'
  | 'FAR'
  | 'INSIDE'
  | 'OUTSIDE'
  | 'ON'
  | 'UNDER'
  | 'BEHIND'
  | 'IN_FRONT_OF'
  | 'CONNECTED_TO'
  | 'OCCUPIED_BY';

export interface SpatialRelationshipEdge {
  from_id: string;
  to_id: string;
  relationship: SpatialRelationshipType;
  confidence: number;
  distance_m: number;
}

export interface SceneGraph {
  version: number;
  last_updated_ns: number;
  room_name: string;
  relationships: SpatialRelationshipEdge[];
  root_node_id: string;
}

export type CollisionRiskLevel = 'SAFE' | 'CAUTION' | 'HIGH_RISK';

export interface SafetyState {
  risk_level: CollisionRiskLevel;
  nearest_obstacle_id: string | null;
  nearest_obstacle_distance_m: number;
  time_to_impact_s: number;
  guardian_boundary_distance_m: number;
  rapid_approach_detected: boolean;
  recommended_haptic_pulse_intensity: number; // 0.0 - 1.0
  recommended_visual_alert: string | null;
}

export type ComputeDevice = 'CPU' | 'GPU' | 'NPU' | 'DSP' | 'EDGE_ACCELERATOR';
export type PowerMode = 'PERFORMANCE' | 'BALANCED' | 'BATTERY' | 'ULTRA_LOW_POWER';
export type ThermalState = 'NOMINAL' | 'WARM' | 'HOT' | 'CRITICAL_THROTTLED';
export type QuantizationType = 'FP32' | 'FP16' | 'BF16' | 'INT8';

export interface ModelProfile {
  model_id: string;
  name: string;
  task: 'HEAD_POSE_EKF' | 'OBJECT_DETECTION' | 'DEPTH_ESTIMATION' | 'HAND_KINEMATICS' | 'GAZE_ESTIMATION' | 'INTENT_PREDICTOR' | 'SCENE_SEMANTICS';
  target_device: ComputeDevice;
  quantization: QuantizationType;
  latency_ms: number;
  power_mw: number;
  memory_mb: number;
  accuracy_map: number; // mAP or tracking fidelity 0.0 - 1.0
  is_active: boolean;
}

export interface SystemTelemetry {
  fps: number;
  end_to_end_latency_ms: number;
  sensor_latency_ms: number;
  fusion_latency_ms: number;
  inference_latency_ms: number;
  prediction_latency_ms: number;
  render_submission_latency_ms: number;
  battery_level_pct: number;
  battery_drain_rate_w: number;
  device_temperature_c: number;
  thermal_state: ThermalState;
  power_mode: PowerMode;
  active_compute_device: ComputeDevice;
  dropped_frames_total: number;
  timestamp_ns: number;
}

export type SystemEventType = 
  | 'POSE_UPDATED'
  | 'GAZE_UPDATED'
  | 'HAND_UPDATED'
  | 'OBJECT_DETECTED'
  | 'OBJECT_MOVED'
  | 'SCENE_CHANGED'
  | 'ANCHOR_UPDATED'
  | 'INTENT_CHANGED'
  | 'SENSOR_DEGRADED'
  | 'MODEL_CHANGED'
  | 'THERMAL_WARNING'
  | 'BATTERY_WARNING'
  | 'SPATIAL_RISK';

export interface SpatialEvent {
  id: string;
  type: SystemEventType;
  timestamp_ns: number;
  source_module: string;
  confidence: number;
  summary: string;
  data: unknown;
}

export interface ReplayKeyframe {
  timestamp_ns: number;
  relative_time_ms: number;
  head_pose: SpatialPose;
  predicted_head_pose: SpatialPose;
  left_hand: HandState;
  right_hand: HandState;
  gaze: GazeState;
  objects: SpatialObject[];
  intent: InteractionState;
  telemetry: SystemTelemetry;
  safety: SafetyState;
}

export interface SpatialSessionRecording {
  session_id: string;
  device_model: string;
  start_time_iso: string;
  duration_ms: number;
  total_frames: number;
  keyframes: ReplayKeyframe[];
}
