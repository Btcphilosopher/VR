// ============================================================================
// SPATIALMIND.OS — HIGH PERFORMANCE SPATIAL MATH & ESTIMATION UTILITIES
// ============================================================================

import { Vec3, Quaternion, SpatialPose, CoordinateFrame } from './types';

export class SpatialMath {
  // Vector math
  static vec3(x = 0, y = 0, z = 0): Vec3 {
    return { x, y, z };
  }

  static add(a: Vec3, b: Vec3): Vec3 {
    return { x: a.x + b.x, y: a.y + b.y, z: a.z + b.z };
  }

  static sub(a: Vec3, b: Vec3): Vec3 {
    return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
  }

  static scale(v: Vec3, s: number): Vec3 {
    return { x: v.x * s, y: v.y * s, z: v.z * s };
  }

  static dot(a: Vec3, b: Vec3): number {
    return a.x * b.x + a.y * b.y + a.z * b.z;
  }

  static cross(a: Vec3, b: Vec3): Vec3 {
    return {
      x: a.y * b.z - a.z * b.y,
      y: a.z * b.x - a.x * b.z,
      z: a.x * b.y - a.y * b.x,
    };
  }

  static length(v: Vec3): number {
    return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
  }

  static distance(a: Vec3, b: Vec3): number {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dz = a.z - b.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  static normalize(v: Vec3): Vec3 {
    const len = this.length(v);
    if (len === 0) return { x: 0, y: 0, z: 0 };
    return { x: v.x / len, y: v.y / len, z: v.z / len };
  }

  static lerp(a: Vec3, b: Vec3, t: number): Vec3 {
    return {
      x: a.x + (b.x - a.x) * t,
      y: a.y + (b.y - a.y) * t,
      z: a.z + (b.z - a.z) * t,
    };
  }

  // Quaternion math
  static quatIdentity(): Quaternion {
    return { x: 0, y: 0, z: 0, w: 1 };
  }

  static quatFromEuler(rollRad: number, pitchRad: number, yawRad: number): Quaternion {
    const cr = Math.cos(rollRad * 0.5);
    const sr = Math.sin(rollRad * 0.5);
    const cp = Math.cos(pitchRad * 0.5);
    const sp = Math.sin(pitchRad * 0.5);
    const cy = Math.cos(yawRad * 0.5);
    const sy = Math.sin(yawRad * 0.5);

    return {
      w: cr * cp * cy + sr * sp * sy,
      x: sr * cp * cy - cr * sp * sy,
      y: cr * sp * cy + sr * cp * sy,
      z: cr * cp * sy - sr * sp * cy,
    };
  }

  static quatMultiply(a: Quaternion, b: Quaternion): Quaternion {
    return {
      w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
      x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
      y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
      z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
    };
  }

  static quatSlerp(qa: Quaternion, qb: Quaternion, t: number): Quaternion {
    let cosHalfTheta = qa.w * qb.w + qa.x * qb.x + qa.y * qb.y + qa.z * qb.z;

    let targetB = { ...qb };
    if (cosHalfTheta < 0) {
      targetB = { x: -qb.x, y: -qb.y, z: -qb.z, w: -qb.w };
      cosHalfTheta = -cosHalfTheta;
    }

    if (Math.abs(cosHalfTheta) >= 1.0) {
      return { ...qa };
    }

    const halfTheta = Math.acos(Math.min(Math.max(cosHalfTheta, -1), 1));
    const sinHalfTheta = Math.sqrt(1.0 - cosHalfTheta * cosHalfTheta);

    if (Math.abs(sinHalfTheta) < 0.001) {
      return {
        w: qa.w * 0.5 + targetB.w * 0.5,
        x: qa.x * 0.5 + targetB.x * 0.5,
        y: qa.y * 0.5 + targetB.y * 0.5,
        z: qa.z * 0.5 + targetB.z * 0.5,
      };
    }

    const ratioA = Math.sin((1 - t) * halfTheta) / sinHalfTheta;
    const ratioB = Math.sin(t * halfTheta) / sinHalfTheta;

    return {
      w: qa.w * ratioA + targetB.w * ratioB,
      x: qa.x * ratioA + targetB.x * ratioB,
      y: qa.y * ratioA + targetB.y * ratioB,
      z: qa.z * ratioA + targetB.z * ratioB,
    };
  }

  static quatRotateVector(q: Quaternion, v: Vec3): Vec3 {
    const qv = { x: q.x, y: q.y, z: q.z };
    const uv = this.cross(qv, v);
    const uuv = this.cross(qv, uv);
    return this.add(v, this.add(this.scale(uv, 2 * q.w), this.scale(uuv, 2)));
  }

  // Ray-AABB intersection for gaze picking
  static rayIntersectsAABB(
    rayOrigin: Vec3,
    rayDir: Vec3,
    boxMin: Vec3,
    boxMax: Vec3
  ): { hit: boolean; distance: number; point?: Vec3 } {
    let tmin = (boxMin.x - rayOrigin.x) / (rayDir.x === 0 ? 1e-6 : rayDir.x);
    let tmax = (boxMax.x - rayOrigin.x) / (rayDir.x === 0 ? 1e-6 : rayDir.x);

    if (tmin > tmax) [tmin, tmax] = [tmax, tmin];

    let tymin = (boxMin.y - rayOrigin.y) / (rayDir.y === 0 ? 1e-6 : rayDir.y);
    let tymax = (boxMax.y - rayOrigin.y) / (rayDir.y === 0 ? 1e-6 : rayDir.y);

    if (tymin > tymax) [tymin, tymax] = [tymax, tymin];

    if (tmin > tymax || tymin > tmax) return { hit: false, distance: Infinity };

    if (tymin > tmin) tmin = tymin;
    if (tymax < tmax) tmax = tymax;

    let tzmin = (boxMin.z - rayOrigin.z) / (rayDir.z === 0 ? 1e-6 : rayDir.z);
    let tzmax = (boxMax.z - rayOrigin.z) / (rayDir.z === 0 ? 1e-6 : rayDir.z);

    if (tzmin > tzmax) [tzmin, tzmax] = [tzmax, tzmin];

    if (tmin > tzmax || tzmin > tmax) return { hit: false, distance: Infinity };

    if (tzmin > tmin) tmin = tzmin;
    if (tzmax < tmax) tmax = tzmax;

    if (tmin < 0 && tmax < 0) return { hit: false, distance: Infinity };

    const dist = tmin >= 0 ? tmin : tmax;
    const hitPoint = this.add(rayOrigin, this.scale(rayDir, dist));
    return { hit: true, distance: dist, point: hitPoint };
  }

  // Vector Cosine Similarity (for 128-dim spatial embeddings)
  static cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length || a.length === 0) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
  }
}

/**
 * 6-DoF Extended Kalman Filter (EKF) for Real-Time Head & Sensor Fusion
 * Fuses high-rate IMU (gyro + accel) with low-rate Visual-Inertial Odometry / SLAM
 */
export class ExtendedKalmanFilter6DoF {
  // State vector: [x, y, z, vx, vy, vz, qx, qy, qz, qw, bgx, bgy, bgz, bax, bay, baz]
  // 16 state elements: Position(3), Velocity(3), Orientation(4), GyroBias(3), AccelBias(3)
  private state = {
    pos: SpatialMath.vec3(0, 1.65, 0), // 1.65m average eye height
    vel: SpatialMath.vec3(0, 0, 0),
    rot: SpatialMath.quatIdentity(),
    gyroBias: SpatialMath.vec3(0.001, -0.002, 0.001),
    accelBias: SpatialMath.vec3(0.01, -0.01, 0.02),
  };

  // Covariance trace metric
  private covarianceNorm = 0.012;
  private lastUpdateNs = 0;

  constructor() {
    this.lastUpdateNs = performance.now() * 1e6;
  }

  predict(accelRaw: Vec3, gyroRaw: Vec3, dt: number): void {
    if (dt <= 0 || dt > 0.1) dt = 0.002; // 500Hz nominal fallback

    // Correct IMU inputs with bias
    const omega = SpatialMath.sub(gyroRaw, this.state.gyroBias);
    const accelBody = SpatialMath.sub(accelRaw, this.state.accelBias);

    // Rotate body acceleration to World frame (subtract gravity [0, -9.81, 0])
    const accelWorld = SpatialMath.sub(
      SpatialMath.quatRotateVector(this.state.rot, accelBody),
      SpatialMath.vec3(0, -9.81, 0)
    );

    // Numerical integration (Euler / Verlet)
    this.state.pos = SpatialMath.add(
      this.state.pos,
      SpatialMath.add(
        SpatialMath.scale(this.state.vel, dt),
        SpatialMath.scale(accelWorld, 0.5 * dt * dt)
      )
    );
    this.state.vel = SpatialMath.add(this.state.vel, SpatialMath.scale(accelWorld, dt));

    // Orientation integration via quaternion derivative
    const halfDt = 0.5 * dt;
    const deltaQ: Quaternion = {
      x: omega.x * halfDt,
      y: omega.y * halfDt,
      z: omega.z * halfDt,
      w: 1.0,
    };
    this.state.rot = SpatialMath.quatMultiply(this.state.rot, deltaQ);
    
    // Re-normalize quaternion
    const qlen = Math.sqrt(
      this.state.rot.x ** 2 + this.state.rot.y ** 2 + this.state.rot.z ** 2 + this.state.rot.w ** 2
    );
    if (qlen > 0) {
      this.state.rot.x /= qlen;
      this.state.rot.y /= qlen;
      this.state.rot.z /= qlen;
      this.state.rot.w /= qlen;
    }

    // Process noise accumulation
    this.covarianceNorm += 0.00005 * dt;
  }

  updateVisualSLAM(observedPos: Vec3, observedRot: Quaternion, visualConfidence: number): void {
    // Kalman gain computed based on visual covariance vs IMU drift
    const K = Math.max(0.05, Math.min(0.4, visualConfidence * 0.35));

    this.state.pos = SpatialMath.lerp(this.state.pos, observedPos, K);
    this.state.rot = SpatialMath.quatSlerp(this.state.rot, observedRot, K);

    // Innovation reduces covariance uncertainty
    this.covarianceNorm = Math.max(0.002, this.covarianceNorm * (1.0 - K * 0.5));
  }

  getState(frame: CoordinateFrame = 'HEAD'): SpatialPose {
    return {
      position: { ...this.state.pos },
      orientation: { ...this.state.rot },
      coordinate_frame: frame,
      timestamp_ns: performance.now() * 1e6,
      confidence: Math.max(0.85, 1.0 - this.covarianceNorm),
    };
  }

  getVelocity(): Vec3 {
    return { ...this.state.vel };
  }

  getCovarianceNorm(): number {
    return this.covarianceNorm;
  }

  reset(position: Vec3 = SpatialMath.vec3(0, 1.65, 0)): void {
    this.state.pos = { ...position };
    this.state.vel = SpatialMath.vec3(0, 0, 0);
    this.state.rot = SpatialMath.quatIdentity();
    this.covarianceNorm = 0.01;
  }
}
