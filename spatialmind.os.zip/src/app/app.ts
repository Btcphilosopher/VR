import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from './services/spatial-engine.service';
import { Viewport3dComponent } from './components/viewport-3d/viewport-3d.component';
import { PipelineViewComponent } from './components/pipeline-view/pipeline-view.component';
import { DigitalTwinComponent } from './components/digital-twin/digital-twin.component';
import { IntentInspectorComponent } from './components/intent-inspector/intent-inspector.component';
import { SpatialMemoryComponent } from './components/spatial-memory/spatial-memory.component';
import { TimeMachineComponent } from './components/time-machine/time-machine.component';
import { CliTerminalComponent } from './components/cli-terminal/cli-terminal.component';
import { RustArchitectureComponent } from './components/rust-architecture/rust-architecture.component';

export type WorkspaceTab = 
  | 'VIEWPORT_3D' 
  | 'PIPELINE' 
  | 'DIGITAL_TWIN' 
  | 'INTENT' 
  | 'SPATIAL_MEMORY' 
  | 'TIME_MACHINE' 
  | 'CLI_TERMINAL' 
  | 'RUST_BLUEPRINT';

@Component({
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    Viewport3dComponent,
    PipelineViewComponent,
    DigitalTwinComponent,
    IntentInspectorComponent,
    SpatialMemoryComponent,
    TimeMachineComponent,
    CliTerminalComponent,
    RustArchitectureComponent
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly engine = inject(SpatialEngineService);

  readonly activeTab = signal<WorkspaceTab>('VIEWPORT_3D');

  readonly tabs: { id: WorkspaceTab; label: string; icon: string; badge?: string }[] = [
    { id: 'VIEWPORT_3D', label: '3D Spatial Viewport', icon: 'view_in_ar' },
    { id: 'PIPELINE', label: '11-Stage Pipeline', icon: 'schema' },
    { id: 'DIGITAL_TWIN', label: 'Hardware Digital Twin', icon: 'memory' },
    { id: 'INTENT', label: 'Multimodal Intent', icon: 'psychology' },
    { id: 'SPATIAL_MEMORY', label: 'Spatial Memory & Graph', icon: 'hub' },
    { id: 'TIME_MACHINE', label: 'Time Machine Replay', icon: 'history' },
    { id: 'CLI_TERMINAL', label: 'CLI Terminal', icon: 'terminal' },
    { id: 'RUST_BLUEPRINT', label: 'Rust Blueprint', icon: 'code' }
  ];

  setTab(tab: WorkspaceTab): void {
    this.activeTab.set(tab);
  }

  triggerPinch(): void {
    this.engine.simulatePinchGesture();
  }

  triggerHeadNod(): void {
    this.engine.simulateHeadMotion();
  }

  triggerNewAnchor(): void {
    this.engine.createSpatialAnchor('User Pin: Custom Hologram Anchor', 'USER_INTERACTION');
  }
}
