import { Component, ChangeDetectionStrategy, inject, signal, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';

interface TerminalLine {
  type: 'COMMAND' | 'OUTPUT' | 'SUCCESS' | 'WARNING' | 'ERROR';
  text: string;
}

@Component({
  selector: 'app-cli-terminal',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col bg-[#0A0B0E] border border-[#1E2028] rounded-lg overflow-hidden font-mono text-xs">
      <!-- Terminal Header (High Density) -->
      <div class="bg-[#13151A] border-b border-[#1E2028] px-3 py-2 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <div class="flex gap-1.5">
            <span class="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block"></span>
            <span class="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block"></span>
            <span class="w-2.5 h-2.5 rounded-full bg-[#00FF85]/80 inline-block"></span>
          </div>
          <span class="text-[#00F0FF] font-bold text-xs ml-1">spatialmind-cli — v0.9.4-release</span>
        </div>

        <div class="text-[10px] text-[#5A5E67]">
          Target: x86_64-unknown-linux-gnu / aarch64-apple-darwin
        </div>
      </div>

      <!-- Quick Commands Strip -->
      <div class="bg-[#13151A]/60 border-b border-[#1E2028] px-3 py-1.5 flex flex-wrap items-center gap-1.5">
        <span class="text-[9px] text-[#5A5E67] font-bold">QUICK EXEC:</span>
        @for (cmd of quickCommands; track cmd) {
          <button
            (click)="runCommand(cmd)"
            class="px-2 py-0.5 rounded bg-[#1A1D24] hover:bg-[#2E323D] border border-[#1E2028] text-[#00FF85] hover:text-[#00F0FF] text-[10px] transition-colors cursor-pointer">
            {{ cmd }}
          </button>
        }
      </div>

      <!-- Terminal Output Window -->
      <div #terminalScroll class="flex-1 p-3 overflow-y-auto space-y-1 text-[#E0E2E6]">
        @for (line of lines(); track $index) {
          <div [ngClass]="{
            'text-[#00FF85] font-bold': line.type === 'COMMAND',
            'text-[#A0A5B0]': line.type === 'OUTPUT',
            'text-[#00F0FF]': line.type === 'SUCCESS',
            'text-[#F27D26]': line.type === 'WARNING',
            'text-red-400': line.type === 'ERROR'
          }">
            <pre class="font-mono whitespace-pre-wrap leading-relaxed text-[11px]">{{ line.text }}</pre>
          </div>
        }
      </div>

      <!-- Input Line -->
      <div class="bg-[#13151A] border-t border-[#1E2028] px-3 py-2 flex items-center gap-2">
        <span class="text-[#00F0FF] font-bold text-xs">spatialmind&gt;</span>
        <input
          type="text"
          [formControl]="inputControl"
          (keyup.enter)="onEnter()"
          placeholder="Type a command (e.g., 'spatialmind benchmark', 'spatialmind sensors', 'help')..."
          class="flex-1 bg-transparent border-none outline-none text-[#E0E2E6] font-mono text-xs placeholder-[#5A5E67]"
        />
        <button
          (click)="onEnter()"
          class="px-3 py-1 bg-[#00F0FF] hover:bg-[#00F0FF]/80 text-[#0A0B0E] font-bold text-xs rounded transition-all cursor-pointer">
          EXEC
        </button>
      </div>
    </div>
  `
})
export class CliTerminalComponent implements AfterViewChecked {
  protected readonly engine = inject(SpatialEngineService);

  @ViewChild('terminalScroll') terminalScrollRef!: ElementRef<HTMLDivElement>;

  readonly inputControl = new FormControl('', { nonNullable: true });
  readonly quickCommands = [
    'spatialmind benchmark',
    'spatialmind sensors',
    'spatialmind models',
    'spatialmind world',
    'spatialmind inspect --head',
    'spatialmind validate'
  ];

  readonly lines = signal<TerminalLine[]>([
    { type: 'OUTPUT', text: 'SPATIALMIND.OS KERNEL RUNTIME v0.9.4 [x86_64 / aarch64]' },
    { type: 'OUTPUT', text: 'Machine Intelligence Engine for Spatial Computing (VR/AR/MR)' },
    { type: 'SUCCESS', text: 'Initialized: 6-DoF EKF, 26-Joint Kinematics, Multimodal Intent Engine.' },
    { type: 'OUTPUT', text: 'Type "help" or select a quick command to begin.' }
  ]);

  ngAfterViewChecked(): void {
    if (this.terminalScrollRef) {
      const el = this.terminalScrollRef.nativeElement;
      el.scrollTop = el.scrollHeight;
    }
  }

  onEnter(): void {
    const cmd = this.inputControl.value.trim();
    if (!cmd) return;
    this.inputControl.setValue('');
    this.runCommand(cmd);
  }

  runCommand(cmd: string): void {
    this.lines.update(l => [...l, { type: 'COMMAND', text: `$ ${cmd}` }]);

    const lower = cmd.toLowerCase().trim();

    if (lower === 'help' || lower === 'spatialmind --help') {
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: 'SPATIALMIND CLI COMMANDS:' },
        { type: 'OUTPUT', text: '  spatialmind run               Start real-time spatial intelligence loop' },
        { type: 'OUTPUT', text: '  spatialmind benchmark         Run full latency & throughput benchmark across CPU/GPU/NPU' },
        { type: 'OUTPUT', text: '  spatialmind sensors           List active sensors, sample rates, noise & calibration' },
        { type: 'OUTPUT', text: '  spatialmind models            Inspect active quantized neural models and routing' },
        { type: 'OUTPUT', text: '  spatialmind world             Dump current spatial world entities & SE(3) coordinates' },
        { type: 'OUTPUT', text: '  spatialmind inspect --head    Display real-time EKF head pose & 18.5ms prediction' },
        { type: 'OUTPUT', text: '  spatialmind validate          Run property tests and invariant safety checks' },
        { type: 'OUTPUT', text: '  spatialmind replay [file]     Replay deterministic spatial session recording' },
        { type: 'OUTPUT', text: '  clear                         Clear terminal output buffer' }
      ]);
    } else if (lower === 'clear') {
      this.lines.set([]);
    } else if (lower.includes('benchmark')) {
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: '--- SPATIALMIND END-TO-END PIPELINE BENCHMARK ---' },
        { type: 'OUTPUT', text: 'Task                  | Device | Latency | Target Budget | Margin' },
        { type: 'OUTPUT', text: '----------------------+--------+---------+---------------+-------' },
        { type: 'SUCCESS', text: 'IMU Ingestion & EKF   | DSP    | 0.82 ms | <= 2.00 ms    | +1.18 ms' },
        { type: 'SUCCESS', text: 'Stereo Feature Track  | GPU    | 1.45 ms | <= 3.50 ms    | +2.05 ms' },
        { type: 'SUCCESS', text: 'YOLO-3D Perception    | NPU    | 4.20 ms | <= 6.00 ms    | +1.80 ms' },
        { type: 'SUCCESS', text: 'Hand Kinematics (26J) | NPU    | 2.10 ms | <= 3.00 ms    | +0.90 ms' },
        { type: 'SUCCESS', text: 'Gaze Vergence Calc    | NPU    | 1.15 ms | <= 2.00 ms    | +0.85 ms' },
        { type: 'SUCCESS', text: 'Head Pose Predictor   | DSP    | 0.35 ms | <= 1.00 ms    | +0.65 ms' },
        { type: 'SUCCESS', text: 'Multimodal Intent     | NPU    | 1.20 ms | <= 2.50 ms    | +1.30 ms' },
        { type: 'OUTPUT', text: '----------------------+--------+---------+---------------+-------' },
        { type: 'SUCCESS', text: `TOTAL MOTION-TO-PHOTON: ${this.engine.telemetry().end_to_end_latency_ms} ms (Target <= 11.1ms @ 90 FPS) [PASS]` }
      ]);
    } else if (lower.includes('sensors')) {
      const sensors = this.engine.sensorsHealth();
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: 'SENSOR SUBSYSTEM STATUS:' },
        ...sensors.map(s => ({
          type: (s.is_active ? 'SUCCESS' : 'ERROR') as TerminalLine['type'],
          text: `[${s.sensor_id}] ${s.sensor_type} @ ${s.sample_rate_hz}Hz | Latency: ${s.latency_ms}ms | State: ${s.calibration_state}`
        }))
      ]);
    } else if (lower.includes('models')) {
      const models = this.engine.models();
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: 'QUANTIZED MODEL REGISTRY:' },
        ...models.map(m => ({
          type: 'SUCCESS' as TerminalLine['type'],
          text: `[${m.model_id}] ${m.name} | Device: ${m.target_device} | Quant: ${m.quantization} | Latency: ${m.latency_ms}ms | Power: ${m.power_mw}mW`
        }))
      ]);
    } else if (lower.includes('world')) {
      const objs = this.engine.spatialObjects();
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: `SPATIAL WORLD GRAPH (Origin: WORLD_ENU, Room: ${this.engine.sceneGraph().room_name}):` },
        ...objs.map(o => ({
          type: 'OUTPUT' as TerminalLine['type'],
          text: `* [${o.id}] ${o.semantic_label} (${o.semantic_class}) at [${o.position.x}, ${o.position.y}, ${o.position.z}] | Dist: ${o.distance_to_user_m}m | Attn: ${(o.attention_score * 100).toFixed(0)}%`
        }))
      ]);
    } else if (lower.includes('validate')) {
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: 'RUNNING RUST INVARIANT & PROPERTY TESTS (cargo test)...' },
        { type: 'SUCCESS', text: 'test prop_timestamp_monotonicity ... ok' },
        { type: 'SUCCESS', text: 'test prop_se3_transform_invertibility ... ok' },
        { type: 'SUCCESS', text: 'test prop_quaternion_normalization_bound ... ok' },
        { type: 'SUCCESS', text: 'test prop_ekf_covariance_positive_definite ... ok' },
        { type: 'SUCCESS', text: 'test prop_sensor_failure_graceful_degradation ... ok' },
        { type: 'SUCCESS', text: 'test prop_spatial_memory_vector_norm ... ok' },
        { type: 'SUCCESS', text: 'test prop_safety_boundary_collision_invariant ... ok' },
        { type: 'SUCCESS', text: 'TEST RESULT: 7 passed; 0 failed; 0 ignored; finished in 14.2ms' }
      ]);
    } else if (lower.includes('inspect')) {
      const head = this.engine.headPose();
      const pred = this.engine.predictedHeadPose();
      this.lines.update(l => [
        ...l,
        { type: 'OUTPUT', text: 'REAL-TIME 6-DoF HEAD POSE & PREDICTION:' },
        { type: 'OUTPUT', text: `Current Position:   [${head.position.x.toFixed(4)}, ${head.position.y.toFixed(4)}, ${head.position.z.toFixed(4)}]` },
        { type: 'OUTPUT', text: `Predicted Position: [${pred.position.x.toFixed(4)}, ${pred.position.y.toFixed(4)}, ${pred.position.z.toFixed(4)}] (Horizon: ${this.engine.predictionHorizonMs()}ms)` },
        { type: 'OUTPUT', text: `Orientation Quat:   [${head.orientation.x.toFixed(3)}, ${head.orientation.y.toFixed(3)}, ${head.orientation.z.toFixed(3)}, ${head.orientation.w.toFixed(3)}]` },
        { type: 'SUCCESS', text: `Filter Confidence:  ${(head.confidence * 100).toFixed(2)}% | Status: TRACKING_OPTIMAL` }
      ]);
    } else {
      this.lines.update(l => [
        ...l,
        { type: 'WARNING', text: `Unrecognized command: '${cmd}'. Type 'help' for available commands.` }
      ]);
    }
  }
}
