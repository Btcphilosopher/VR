import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';

@Component({
  selector: 'app-intent-inspector',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-y-auto pr-1">
      <!-- Intent Header (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#00F0FF]">
            <mat-icon class="text-base">psychology</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                MULTIMODAL INTENT & ATTENTION MATRIX
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                PROBABILISTIC INFERENCE
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Fuses Eye Gaze dwell, 26-joint Hand kinematics, Head trajectory & Scene affordances
            </p>
          </div>
        </div>

        <div class="bg-[#0A0B0E] px-2.5 py-1 rounded border border-[#1E2028] font-mono text-xs flex items-center gap-2">
          <span class="text-[9px] text-[#5A5E67] font-bold uppercase">INFERRED INTENT:</span>
          <span class="text-[#00FF85] font-bold">{{ engine.intentState().estimated_intent }}</span>
          <span class="text-[#5A5E67] text-[10px]">({{ (engine.intentState().intent_confidence * 100).toFixed(0) }}%)</span>
        </div>
      </div>

      <!-- Top Grid: Intent Breakdown & Multimodal Weights -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-2.5">
        <!-- Multimodal Signal Weights -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
          <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#00F0FF] font-bold flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5">tune</mat-icon> MULTIMODAL FEATURE SIGNALS
          </h3>

          <div class="space-y-2 pt-1 text-[10px] font-mono">
            <div>
              <div class="flex justify-between text-[#5A5E67] mb-0.5">
                <span>GAZE ALIGNMENT:</span>
                <span class="text-[#00FF85] font-bold">{{ (engine.intentState().multimodal_signals.gaze_alignment * 100).toFixed(0) }}%</span>
              </div>
              <div class="w-full bg-[#0A0B0E] h-1 rounded-full overflow-hidden border border-[#1E2028]">
                <div class="h-full bg-[#00FF85]" [style.width.%]="engine.intentState().multimodal_signals.gaze_alignment * 100"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between text-[#5A5E67] mb-0.5">
                <span>HAND PROXIMITY:</span>
                <span class="text-[#00F0FF] font-bold">{{ (engine.intentState().multimodal_signals.hand_proximity * 100).toFixed(0) }}%</span>
              </div>
              <div class="w-full bg-[#0A0B0E] h-1 rounded-full overflow-hidden border border-[#1E2028]">
                <div class="h-full bg-[#00F0FF]" [style.width.%]="engine.intentState().multimodal_signals.hand_proximity * 100"></div>
              </div>
            </div>

            <div>
              <div class="flex justify-between text-[#5A5E67] mb-0.5">
                <span>HEAD TRAJECTORY ALIGNMENT:</span>
                <span class="text-[#F27D26] font-bold">{{ (engine.intentState().multimodal_signals.head_trajectory_alignment * 100).toFixed(0) }}%</span>
              </div>
              <div class="w-full bg-[#0A0B0E] h-1 rounded-full overflow-hidden border border-[#1E2028]">
                <div class="h-full bg-[#F27D26]" [style.width.%]="engine.intentState().multimodal_signals.head_trajectory_alignment * 100"></div>
              </div>
            </div>

            <div class="pt-1.5 border-t border-[#1E2028] flex justify-between">
              <span class="text-[#5A5E67]">GAZE DWELL DURATION:</span>
              <span class="text-[#E0E2E6] font-bold">{{ engine.intentState().multimodal_signals.dwell_time_ms }} ms</span>
            </div>
          </div>
        </div>

        <!-- Candidate Actions Probability Distribution -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
          <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#00FF85] font-bold flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5">format_list_bulleted</mat-icon> CANDIDATE OS ACTIONS
          </h3>

          <div class="space-y-1.5 pt-1">
            @for (cand of engine.intentState().candidate_actions; track cand.action) {
              <div class="bg-[#1A1D24] p-2 rounded border border-[#1E2028] flex flex-col gap-0.5">
                <div class="flex items-center justify-between text-[11px] font-mono">
                  <span class="text-[#E0E2E6] font-bold">{{ cand.action }}</span>
                  <span class="text-[#00FF85] font-bold">{{ (cand.probability * 100).toFixed(0) }}%</span>
                </div>
                <div class="text-[9px] text-[#5A5E67] font-mono">Feedback: {{ cand.suggested_ui_feedback }}</div>
              </div>
            }
          </div>
        </div>

        <!-- Right Hand Skeletal & Gesture State -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col justify-between">
          <div>
            <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#00F0FF] font-bold flex items-center gap-1 mb-1.5">
              <mat-icon class="text-xs !w-3.5 !h-3.5">back_hand</mat-icon> 26-JOINT HAND KINEMATICS
            </h3>

            <div class="space-y-1 text-[10px] font-mono">
              <div class="flex justify-between py-1 border-b border-[#1E2028]">
                <span class="text-[#5A5E67]">RIGHT GESTURE:</span>
                <span class="text-[#00FF85] font-bold">{{ engine.rightHand().gesture }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-[#1E2028]">
                <span class="text-[#5A5E67]">PINCH DISTANCE:</span>
                <span class="text-[#E0E2E6] font-semibold">{{ engine.rightHand().pinch_distance_mm.toFixed(1) }} mm</span>
              </div>
              <div class="flex justify-between py-1 border-b border-[#1E2028]">
                <span class="text-[#5A5E67]">PALM VELOCITY:</span>
                <span class="text-[#00F0FF] font-semibold">0.08 m/s</span>
              </div>
              <div class="flex justify-between py-1">
                <span class="text-[#5A5E67]">SKELETAL JOINTS:</span>
                <span class="text-[#F27D26] font-semibold">26 Tracked</span>
              </div>
            </div>
          </div>

          <div class="bg-[#0A0B0E] p-1.5 rounded border border-[#1E2028] text-[10px] text-[#5A5E67] font-mono mt-1.5">
            Suggested Dispatch: <span class="text-[#F27D26] font-bold">{{ engine.intentState().suggested_os_action }}</span>
          </div>
        </div>
      </div>

      <!-- Bottom: Spatial Attention Heatmap Table -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
        <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#F27D26] font-bold flex items-center gap-1">
          <mat-icon class="text-xs !w-3.5 !h-3.5">radar</mat-icon> REAL-TIME SPATIAL ATTENTION SCORES
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-[11px] font-mono">
            <thead>
              <tr class="text-[#5A5E67] border-b border-[#1E2028] text-[9px] uppercase tracking-wider">
                <th class="pb-1.5">ENTITY</th>
                <th class="pb-1.5">CLASS</th>
                <th class="pb-1.5">DISTANCE</th>
                <th class="pb-1.5">ATTENTION SCORE</th>
                <th class="pb-1.5">TRACKING</th>
                <th class="pb-1.5">AFFORDANCES</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#1E2028]">
              @for (obj of engine.spatialObjects(); track obj.id) {
                <tr class="hover:bg-[#1A1D24] transition-colors"
                    [class.bg-[#00F0FF]/10]="obj.id === engine.gazeState().target_object_id">
                  <td class="py-1.5 text-[#E0E2E6] font-semibold flex items-center gap-1.5">
                    @if (obj.id === engine.gazeState().target_object_id) {
                      <span class="w-1.5 h-1.5 rounded-full bg-[#00F0FF] animate-ping"></span>
                    }
                    {{ obj.semantic_label }}
                  </td>
                  <td class="py-1.5 text-[#5A5E67]">{{ obj.semantic_class }}</td>
                  <td class="py-1.5 text-[#00F0FF]">{{ obj.distance_to_user_m }}m</td>
                  <td class="py-1.5">
                    <div class="flex items-center gap-2">
                      <div class="w-20 bg-[#0A0B0E] h-1.5 rounded-full overflow-hidden border border-[#1E2028]">
                        <div class="h-full bg-[#F27D26]" [style.width.%]="obj.attention_score * 100"></div>
                      </div>
                      <span class="text-[#F27D26] font-bold text-[10px]">{{ (obj.attention_score * 100).toFixed(0) }}%</span>
                    </div>
                  </td>
                  <td class="py-1.5 text-[#00FF85]">{{ obj.tracking_state }}</td>
                  <td class="py-1.5">
                    <div class="flex flex-wrap gap-1">
                      @for (aff of obj.affordances; track aff) {
                        <span class="text-[9px] px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#5A5E67] border border-[#1E2028]">
                          {{ aff }}
                        </span>
                      }
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class IntentInspectorComponent {
  protected readonly engine = inject(SpatialEngineService);
}
