import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { SpatialEngineService } from '../../services/spatial-engine.service';

@Component({
  selector: 'app-spatial-memory',
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-y-auto pr-1">
      <!-- Header (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#00F0FF]">
            <mat-icon class="text-base">hub</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                SPATIAL MEMORY & RELATIONAL SCENE GRAPH
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                128-DIM EMBEDDINGS
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Persistent spatial world model, topological relationships & semantic vector search
            </p>
          </div>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="text-[9px] text-[#5A5E67] font-bold">GRAPH:</span>
          <span class="text-[#00F0FF] font-bold">v{{ engine.sceneGraph().version }}</span>
          <span class="text-[9px] text-[#5A5E67] font-bold ml-2">ROOM:</span>
          <span class="text-[#00FF85] font-bold">{{ engine.sceneGraph().room_name }}</span>
        </div>
      </div>

      <!-- Natural Language Spatial Search Bar -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2.5">
        <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#00F0FF] font-bold flex items-center gap-1">
          <mat-icon class="text-xs !w-3.5 !h-3.5">search</mat-icon> NATURAL LANGUAGE SPATIAL QUERY ENGINE
        </h3>

        <div class="flex gap-2">
          <input
            type="text"
            [formControl]="searchControl"
            (keyup.enter)="executeSearch()"
            placeholder="e.g. 'find my desk', 'what is near the table?', 'where did I leave the coffee cup?'"
            class="flex-1 bg-[#0A0B0E] border border-[#1E2028] rounded px-3 py-1.5 text-xs text-[#E0E2E6] placeholder-[#5A5E67] focus:outline-none focus:border-[#00F0FF] font-mono"
          />
          <button
            (click)="executeSearch()"
            [disabled]="isQuerying()"
            class="px-3.5 py-1.5 bg-[#00F0FF] hover:bg-[#00F0FF]/80 disabled:opacity-50 text-[#0A0B0E] font-bold text-xs rounded font-mono flex items-center gap-1.5 transition-all cursor-pointer">
            <mat-icon class="text-xs !w-3.5 !h-3.5">psychology</mat-icon>
            {{ isQuerying() ? 'REASONING...' : 'QUERY MEMORY' }}
          </button>
        </div>

        <!-- Quick Query Chips -->
        <div class="flex flex-wrap gap-1.5 pt-0.5">
          @for (preset of quickQueries; track preset) {
            <button
              (click)="searchControl.setValue(preset); executeSearch()"
              class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#1A1D24] hover:bg-[#2E323D] border border-[#1E2028] text-[#5A5E67] hover:text-[#00F0FF] transition-colors cursor-pointer">
              {{ preset }}
            </button>
          }
        </div>

        <!-- Spatial AI Reasoning Output -->
        @if (aiReasoningResult()) {
          <div class="p-2.5 rounded bg-[#0A0B0E] border border-[#00F0FF]/30 text-xs font-mono flex flex-col gap-1">
            <div class="flex items-center justify-between text-[10px] text-[#00F0FF]">
              <span class="font-bold flex items-center gap-1">
                <mat-icon class="text-xs !w-3 !h-3">auto_awesome</mat-icon> SPATIAL REASONER INFERENCE
              </span>
              <span class="px-1.5 py-0.2 rounded bg-[#13151A] text-[#00FF85] border border-[#1E2028]">
                CONFIDENCE: 98%
              </span>
            </div>
            <p class="text-[#E0E2E6] text-[11px] leading-relaxed">{{ aiReasoningResult() }}</p>
          </div>
        }
      </div>

      <!-- Relational Graph & Vector Search Results -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-2.5">
        <!-- Relational Graph Edges -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
          <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#00F0FF] font-bold flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5">account_tree</mat-icon> EXPLICIT SPATIAL RELATIONSHIPS (SE3 RELATIONS)
          </h3>

          <div class="space-y-1.5 overflow-y-auto max-h-[300px] pr-1">
            @for (edge of engine.sceneGraph().relationships; track edge.from_id + edge.to_id) {
              <div class="bg-[#1A1D24] p-2 rounded border border-[#1E2028] flex items-center justify-between text-[11px] font-mono">
                <div class="flex items-center gap-1.5">
                  <span class="text-[#E0E2E6] font-bold">{{ getEntityLabel(edge.from_id) }}</span>
                  <span class="px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#00F0FF] font-bold border border-[#1E2028] text-[9px]">
                    {{ edge.relationship }}
                  </span>
                  <span class="text-[#5A5E67] font-semibold">{{ getEntityLabel(edge.to_id) }}</span>
                </div>
                <div class="text-[10px] text-[#5A5E67]">
                  <span class="text-[#00FF85]">{{ edge.distance_m }}m</span> &bull; {{ (edge.confidence * 100).toFixed(0) }}%
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Persistent Spatial Anchors -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
          <h3 class="text-[9px] font-mono uppercase tracking-wider text-[#F27D26] font-bold flex items-center gap-1">
            <mat-icon class="text-xs !w-3.5 !h-3.5">anchor</mat-icon> PERSISTENT SPATIAL ANCHORS
          </h3>

          <div class="space-y-1.5 overflow-y-auto max-h-[300px] pr-1">
            @for (anchor of engine.spatialAnchors(); track anchor.id) {
              <div class="bg-[#1A1D24] p-2 rounded border border-[#1E2028] flex flex-col gap-1">
                <div class="flex items-center justify-between text-[11px] font-mono">
                  <span class="text-[#F27D26] font-bold">{{ anchor.id }}</span>
                  <span class="text-[9px] px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#00FF85] border border-[#1E2028]">
                    {{ anchor.persistence }}
                  </span>
                </div>
                <p class="text-[10px] text-[#5A5E67] font-mono">{{ anchor.semantic_context }}</p>
                <div class="flex justify-between text-[9px] font-mono text-[#5A5E67] pt-1 border-t border-[#1E2028]">
                  <span>Drift Radius: <span class="text-[#00F0FF]">{{ (anchor.drift_radius_m * 1000).toFixed(1) }} mm</span></span>
                  <span>Confidence: <span class="text-[#00FF85]">{{ (anchor.confidence * 100).toFixed(0) }}%</span></span>
                </div>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `
})
export class SpatialMemoryComponent {
  protected readonly engine = inject(SpatialEngineService);
  private http = inject(HttpClient);

  readonly searchControl = new FormControl('find my desk and what is on it', { nonNullable: true });
  readonly isQuerying = signal<boolean>(false);
  readonly aiReasoningResult = signal<string | null>(
    'The Workstation Desk is at coordinate [0.0, 0.75, -1.5] (World frame). It currently supports: MacBook Pro M3 Max, Ceramic Espresso Mug, and Primary 4K OLED Float workspace. Probable Intent: Focus on workspace.'
  );

  readonly quickQueries = [
    'find my desk and what is on it',
    'where is the coffee cup?',
    'show spatial anchor for floating 4k screen',
    'what is near the lab entrance?'
  ];

  getEntityLabel(id: string): string {
    const obj = this.engine.spatialObjects().find(o => o.id === id);
    if (obj) return obj.semantic_label;
    if (id === 'obj-wall-north') return 'North Boundary Wall';
    return id;
  }

  executeSearch(): void {
    const query = this.searchControl.value.trim();
    if (!query) return;
    this.isQuerying.set(true);

    const sceneContext = {
      objects: this.engine.spatialObjects().map(o => ({
        label: o.semantic_label,
        class: o.semantic_class,
        pos: o.position,
        dist: o.distance_to_user_m
      })),
      gaze: this.engine.gazeState().target_object_id,
      intent: this.engine.intentState().estimated_intent
    };

    this.http.post<{ response: string }>('/api/spatial-reasoning', {
      query,
      sceneContext
    }).subscribe({
      next: (res) => {
        this.aiReasoningResult.set(res.response);
        this.isQuerying.set(false);
      },
      error: () => {
        // Fallback local memory search
        const matches = this.engine.querySpatialMemory(query);
        if (matches.length > 0) {
          const top = matches[0].object;
          this.aiReasoningResult.set(
            `Located ${top.semantic_label} at ${top.position.x}m, ${top.position.y}m, ${top.position.z}m. Distance: ${top.distance_to_user_m}m. Relationship score: ${(matches[0].similarity * 100).toFixed(0)}%.`
          );
        } else {
          this.aiReasoningResult.set('No spatial entities matched query vector.');
        }
        this.isQuerying.set(false);
      }
    });
  }
}
