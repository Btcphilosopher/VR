import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';

interface PipelineStage {
  id: string;
  name: string;
  category: 'INGESTION' | 'CALIBRATION' | 'PERCEPTION' | 'FUSION' | 'PREDICTION' | 'INTENT' | 'OUTPUT';
  hz: number;
  latency_ms: number;
  device: string;
  confidence: number;
  status: 'ACTIVE' | 'OPTIMAL' | 'THROTTLED';
  description: string;
  inputs: string[];
  outputs: string[];
  provenance: string;
}

@Component({
  selector: 'app-pipeline-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-hidden">
      <!-- Pipeline Status Header (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#00F0FF]">
            <mat-icon class="text-base">schema</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                PRIMARY SPATIAL PIPELINE
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                11 STAGES ACTIVE
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Multi-rate spatial intelligence stream &bull; Motion-to-Photon Budget: &le; 11.1ms (90Hz)
            </p>
          </div>
        </div>

        <div class="flex items-center gap-3 font-mono text-xs">
          <div class="bg-[#0A0B0E] px-2.5 py-1 rounded border border-[#1E2028] flex items-center gap-1.5">
            <span class="text-[9px] uppercase text-[#5A5E67] font-bold">TOTAL LATENCY:</span>
            <span class="text-[#00F0FF] font-bold">{{ engine.telemetry().end_to_end_latency_ms }} ms</span>
          </div>
          <div class="bg-[#0A0B0E] px-2.5 py-1 rounded border border-[#1E2028] flex items-center gap-1.5">
            <span class="text-[9px] uppercase text-[#5A5E67] font-bold">DEVICE:</span>
            <span class="text-[#F27D26] font-bold">{{ engine.activeComputeDevice() }}</span>
          </div>
        </div>
      </div>

      <!-- Interactive Stage Graph & Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-3 flex-1 overflow-hidden min-h-0">
        <!-- Stage List Column -->
        <div class="lg:col-span-2 flex flex-col gap-1.5 overflow-y-auto pr-1">
          @for (stage of stages; track stage.id) {
            <button 
              type="button"
              (click)="selectedStage.set(stage)"
              class="group relative p-2.5 rounded border text-left w-full transition-all cursor-pointer flex items-center justify-between gap-3"
              [class.bg-[#1A1D24]]="selectedStage()?.id === stage.id"
              [class.border-[#00F0FF]]="selectedStage()?.id === stage.id"
              [class.border-l-4]="selectedStage()?.id === stage.id"
              [class.border-l-[#00F0FF]]="selectedStage()?.id === stage.id"
              [class.bg-[#13151A]]="selectedStage()?.id !== stage.id"
              [class.border-[#1E2028]]="selectedStage()?.id !== stage.id"
              [class.hover:border-[#2E323D]]="selectedStage()?.id !== stage.id">
              
              <div class="flex items-center gap-2.5">
                <div 
                  class="w-5 h-5 rounded flex items-center justify-center font-mono text-[10px] font-bold"
                  [class.bg-[#0A0B0E]]="selectedStage()?.id !== stage.id"
                  [class.text-[#5A5E67]]="selectedStage()?.id !== stage.id"
                  [class.bg-[#00F0FF]/20]="selectedStage()?.id === stage.id"
                  [class.text-[#00F0FF]]="selectedStage()?.id === stage.id">
                  {{ $index + 1 }}
                </div>

                <div>
                  <div class="text-[11px] font-bold text-[#E0E2E6] flex items-center gap-2">
                    {{ stage.name }}
                    <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#5A5E67] border border-[#1E2028]">
                      {{ stage.category }}
                    </span>
                  </div>
                  <div class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
                    Target: <span class="text-[#00FF85] font-semibold">{{ stage.hz }} Hz</span> &bull; 
                    Device: <span class="text-[#00F0FF]">{{ stage.device }}</span>
                  </div>
                </div>
              </div>

              <div class="flex items-center gap-3 font-mono text-xs">
                <div class="text-right">
                  <div class="text-[#E0E2E6] font-bold text-[11px]">{{ stage.latency_ms }} ms</div>
                  <div class="text-[9px] text-[#00FF85]">{{ (stage.confidence * 100).toFixed(0) }}% Conf</div>
                </div>
                <mat-icon class="text-xs !w-3.5 !h-3.5 text-[#5A5E67] group-hover:text-[#00F0FF] transition-colors">chevron_right</mat-icon>
              </div>
            </button>
          }
        </div>

        <!-- Stage Inspector Panel -->
        <div class="lg:col-span-1 bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-3 overflow-y-auto">
          @if (selectedStage(); as stage) {
            <div>
              <div class="flex items-center justify-between">
                <span class="text-[9px] font-mono uppercase tracking-widest text-[#00F0FF] font-bold">STAGE INSPECTOR</span>
                <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#1E2028] text-[#00FF85] border border-[#2E323D]">
                  {{ stage.status }}
                </span>
              </div>
              <h3 class="text-xs font-bold text-[#E0E2E6] mt-1">{{ stage.name }}</h3>
              <p class="text-[10px] text-[#5A5E67] mt-1 leading-relaxed font-mono">{{ stage.description }}</p>
            </div>

            <div class="space-y-1.5 pt-2 border-t border-[#1E2028] text-[10px] font-mono">
              <div class="flex justify-between py-1 border-b border-[#1E2028]/60">
                <span class="text-[#5A5E67]">EXECUTION DOMAIN:</span>
                <span class="text-[#00F0FF] font-semibold">{{ stage.device }}</span>
              </div>
              <div class="flex justify-between py-1 border-b border-[#1E2028]/60">
                <span class="text-[#5A5E67]">UPDATE FREQUENCY:</span>
                <span class="text-[#00FF85] font-semibold">{{ stage.hz }} Hz</span>
              </div>
              <div class="flex justify-between py-1 border-b border-[#1E2028]/60">
                <span class="text-[#5A5E67]">STAGE LATENCY:</span>
                <span class="text-[#E0E2E6] font-semibold">{{ stage.latency_ms }} ms</span>
              </div>
              <div class="flex justify-between py-1 border-b border-[#1E2028]/60">
                <span class="text-[#5A5E67]">PROVENANCE:</span>
                <span class="text-[#F27D26] font-semibold truncate max-w-[140px]">{{ stage.provenance }}</span>
              </div>
            </div>

            <!-- In / Out Ports -->
            <div class="pt-1 border-t border-[#1E2028] space-y-2 text-[10px]">
              <div>
                <span class="text-[9px] font-mono uppercase text-[#5A5E67] font-bold block mb-1">INPUT STREAMS</span>
                <div class="flex flex-wrap gap-1">
                  @for (inp of stage.inputs; track inp) {
                    <span class="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#0A0B0E] text-[#00F0FF] border border-[#1E2028]">
                      &rarr; {{ inp }}
                    </span>
                  }
                </div>
              </div>

              <div>
                <span class="text-[9px] font-mono uppercase text-[#5A5E67] font-bold block mb-1">OUTPUT STREAMS</span>
                <div class="flex flex-wrap gap-1">
                  @for (out of stage.outputs; track out) {
                    <span class="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#0A0B0E] text-[#00FF85] border border-[#1E2028]">
                      &larr; {{ out }}
                    </span>
                  }
                </div>
              </div>
            </div>
          } @else {
            <div class="h-full flex flex-col items-center justify-center text-center text-[#5A5E67] p-4">
              <mat-icon class="text-2xl mb-1 text-[#2E323D]">touch_app</mat-icon>
              <p class="text-[10px] font-mono">Select a pipeline stage to inspect telemetry and execution domains.</p>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class PipelineViewComponent {
  protected readonly engine = inject(SpatialEngineService);

  readonly stages: PipelineStage[] = [
    {
      id: 'stg-1',
      name: '1. Multi-Sensor Ingestion Buffer',
      category: 'INGESTION',
      hz: 500,
      latency_ms: 0.4,
      device: 'HARDWARE_DMA',
      confidence: 0.99,
      status: 'OPTIMAL',
      description: 'Ingests synchronized packet streams from IMU (500Hz), Stereo Cameras (90Hz), LiDAR ToF (30Hz), Eye IR (120Hz), and Hand Tracking (90Hz).',
      inputs: ['IMU_SPI', 'MIPI_CSI_CAM', 'I2C_EYE_IR'],
      outputs: ['SensorSample<T>[]', 'TemporalBuffer'],
      provenance: 'Rust sensor-core crate'
    },
    {
      id: 'stg-2',
      name: '2. Timestamp Synchronisation & Jitter Shield',
      category: 'CALIBRATION',
      hz: 500,
      latency_ms: 0.2,
      device: 'CPU_CORE_0',
      confidence: 0.99,
      status: 'OPTIMAL',
      description: 'Compensates for sensor clock drift, out-of-order packet arrival, and variable sampling latencies with monotonic nanosecond normalization.',
      inputs: ['Raw Timestamps', 'Hardware PLL Clock'],
      outputs: ['NormalizedMonotonicEpochNs'],
      provenance: 'Rust spatial-time crate'
    },
    {
      id: 'stg-3',
      name: '3. SE(3) Transform & Coordinate Engine',
      category: 'CALIBRATION',
      hz: 500,
      latency_ms: 0.2,
      device: 'DSP',
      confidence: 0.99,
      status: 'OPTIMAL',
      description: 'Maintains rigorous 4x4 homogeneous transformation tree across 14 coordinate frames: WORLD, LOCAL, HEAD, DEVICE, EYE_L, EYE_R, HAND_L, HAND_R, etc.',
      inputs: ['CalibrationMatrices', 'Extrinsics'],
      outputs: ['SE3TransformTree'],
      provenance: 'Rust coordinate-engine crate'
    },
    {
      id: 'stg-4',
      name: '4. Feature Extraction & Optical Flow',
      category: 'PERCEPTION',
      hz: 90,
      latency_ms: 1.4,
      device: 'GPU_COMPUTE',
      confidence: 0.96,
      status: 'OPTIMAL',
      description: 'Extracts 2D FAST/Harris corners, Shi-Tomasi feature tracks, and depth gradients for visual odometry and SLAM keyframing.',
      inputs: ['StereoCameraFrames', 'DepthMap'],
      outputs: ['TrackedFeatures2D', 'SparsePointCloud'],
      provenance: 'Rust vision-core crate'
    },
    {
      id: 'stg-5',
      name: '5. Neural Perception Models (YOLO-3D / Gaze / Hands)',
      category: 'PERCEPTION',
      hz: 90,
      latency_ms: 2.8,
      device: 'NPU',
      confidence: 0.95,
      status: 'OPTIMAL',
      description: 'Concurrent quantized neural inference: 3D Object Bounding Boxes, Bi-convergent Eye Gaze Vergence, and 26-joint Hand Skeletal Kinematics.',
      inputs: ['CameraTensors', 'IR_EyeTensors'],
      outputs: ['SpatialObjects[]', 'GazeState', 'HandState'],
      provenance: 'Rust inference-runtime (Candle/ONNX)'
    },
    {
      id: 'stg-6',
      name: '6. 6-DoF Extended Kalman Filter (EKF Fusion)',
      category: 'FUSION',
      hz: 500,
      latency_ms: 0.8,
      device: 'DSP',
      confidence: 0.98,
      status: 'OPTIMAL',
      description: 'Tightly-coupled fusion of high-rate IMU angular velocities and accelerations with visual-inertial odometry innovations.',
      inputs: ['IMU (500Hz)', 'VisualOdometry (90Hz)'],
      outputs: ['SpatialPose', 'SpatialVelocity', 'Covariance6x6'],
      provenance: 'Rust fusion crate'
    },
    {
      id: 'stg-7',
      name: '7. Spatial World Model & Relational Graph',
      category: 'FUSION',
      hz: 30,
      latency_ms: 0.6,
      device: 'CPU_CORE_1',
      confidence: 0.97,
      status: 'OPTIMAL',
      description: 'Maintains the semantic scene graph with persistent spatial anchors, room boundaries, dynamic entities, and spatial relationships (ON, ABOVE, NEAR).',
      inputs: ['SpatialObjects', 'Anchors'],
      outputs: ['SpatialWorld', 'SceneGraph'],
      provenance: 'Rust scene-graph crate'
    },
    {
      id: 'stg-8',
      name: '8. Head & Hand Temporal Extrapolator',
      category: 'PREDICTION',
      hz: 500,
      latency_ms: 0.3,
      device: 'DSP',
      confidence: 0.96,
      status: 'OPTIMAL',
      description: 'Predicts head and hand poses forward by 18.5ms using polynomial Kalman extrapolation to eliminate perceived display lag.',
      inputs: ['SpatialPose', 'Velocity', 'Acceleration'],
      outputs: ['PredictedPose(t + 18.5ms)'],
      provenance: 'Rust prediction crate'
    },
    {
      id: 'stg-9',
      name: '9. Multimodal User Intent Engine',
      category: 'INTENT',
      hz: 90,
      latency_ms: 0.9,
      device: 'NPU',
      confidence: 0.93,
      status: 'OPTIMAL',
      description: 'Fuses gaze fixation target, hand pinch gesture proximity, and dwell time to infer probabilistic OS action candidates (SELECT, DRAG, DISMISS).',
      inputs: ['GazeState', 'HandState', 'SceneGraph'],
      outputs: ['InteractionState', 'CandidateActions[]'],
      provenance: 'Rust intent-engine crate'
    },
    {
      id: 'stg-10',
      name: '10. Adaptive Model Router & Thermal Orchestrator',
      category: 'INTENT',
      hz: 10,
      latency_ms: 0.2,
      device: 'CPU_CORE_0',
      confidence: 0.99,
      status: 'OPTIMAL',
      description: 'Dynamically routes ML workloads between NPU, GPU, and DSP based on device battery, skin temperature, and motion dynamics.',
      inputs: ['ThermalSensors', 'BatteryState', 'LatencyMetrics'],
      outputs: ['ModelRoutingPlan', 'PowerBudget'],
      provenance: 'Rust scheduler crate'
    },
    {
      id: 'stg-11',
      name: '11. OS Spatial State & Render Submission',
      category: 'OUTPUT',
      hz: 90,
      latency_ms: 0.6,
      device: 'GPU_DISPLAY',
      confidence: 0.99,
      status: 'OPTIMAL',
      description: 'Publishes predicted spatial matrices to the VR/AR compositor for time-warp reprojection and asynchronous shader dispatch.',
      inputs: ['PredictedPose', 'SceneGraph', 'InteractionState'],
      outputs: ['CompositorState', 'UI_Events'],
      provenance: 'Rust spatial-os-state crate'
    }
  ];

  readonly selectedStage = signal<PipelineStage | null>(this.stages[4]);
}
