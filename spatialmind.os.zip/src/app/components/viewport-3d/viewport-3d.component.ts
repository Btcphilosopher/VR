import { 
  Component, 
  ElementRef, 
  OnInit, 
  OnDestroy, 
  ViewChild, 
  inject, 
  ChangeDetectionStrategy,
  signal,
  effect,
  PLATFORM_ID
} from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';
import { HandState } from '../../core/types';
import * as THREE from 'three';

@Component({
  selector: 'app-viewport-3d',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-full min-h-[520px] bg-[#0A0B0E] rounded-xl border border-[#1E2028] overflow-hidden flex flex-col">
      <!-- 3D Canvas Container -->
      <div #canvasContainer class="relative flex-1 w-full h-full min-h-[440px] cursor-grab active:cursor-grabbing bg-[#000000]">
        <!-- Radial Dot Matrix background effect -->
        <div class="absolute inset-0 opacity-15 pointer-events-none" style="background-image: radial-gradient(#00F0FF 1px, transparent 1px); background-size: 20px 20px;"></div>
        
        <canvas #webglCanvas class="w-full h-full block relative z-0"></canvas>

        <!-- Overlaid Heads-Up Display (HUD) Top-Left -->
        <div class="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none z-10">
          <div class="flex items-center gap-2">
            <span class="bg-[#00F0FF]/10 text-[#00F0FF] text-[10px] px-2 py-0.5 border border-[#00F0FF]/30 rounded font-mono font-bold tracking-wider">
              VIEW: SPATIAL_TOPOLOGY
            </span>
            <span class="bg-[#1E2028] text-[10px] px-2 py-0.5 rounded text-[#E0E2E6] font-mono border border-[#2E323D]">
              FPS: {{ engine.telemetry().fps }}
            </span>
          </div>

          <!-- Active Coordinate Frame Badge -->
          <div class="bg-[#13151A]/90 backdrop-blur-sm px-2.5 py-1 rounded border border-[#1E2028] text-[10px] font-mono text-[#5A5E67]">
            FRAME: <span class="text-[#00F0FF] font-bold">WORLD_SE3 (ENU)</span> | SLAM DENSITY: <span class="text-[#00FF85] font-semibold">1,420 pts</span>
          </div>
        </div>

        <!-- Right Overlay: Focus Target Inspector -->
        @if (engine.gazeState().target_object_id; as targetId) {
          <div class="absolute top-3 right-3 max-w-xs bg-[#13151A]/95 backdrop-blur-md p-2.5 rounded-lg border border-[#00F0FF]/40 shadow-xl pointer-events-none z-10">
            <div class="flex items-center justify-between gap-2 mb-1">
              <span class="text-[9px] uppercase font-mono tracking-widest text-[#00F0FF] font-bold flex items-center gap-1">
                <mat-icon class="text-xs !w-3 !h-3">visibility</mat-icon> GAZE FIXATION TARGET
              </span>
              <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#00FF85] border border-[#1E2028]">
                {{ (engine.gazeState().confidence * 100).toFixed(0) }}% CONF
              </span>
            </div>
            <div class="text-xs font-bold text-[#E0E2E6] truncate font-mono">{{ getTargetObjectName(targetId) }}</div>
            <div class="text-[10px] text-[#5A5E67] font-mono mt-1 flex justify-between">
              <span>Dist: <span class="text-[#00F0FF]">{{ engine.gazeState().vergence_distance_m.toFixed(2) }}m</span></span>
              <span>Dwell: <span class="text-[#00FF85]">{{ engine.gazeState().fixation_duration_ms }}ms</span></span>
            </div>
            <div class="mt-1.5 pt-1 border-t border-[#1E2028] text-[10px] text-[#F27D26] font-mono flex items-center gap-1">
              <mat-icon class="text-xs !w-3 !h-3">touch_app</mat-icon>
              Intent: {{ engine.intentState().estimated_intent }}
            </div>
          </div>
        }

        <!-- Bottom Left: Pose Prediction Metric Block -->
        <div class="absolute bottom-3 left-3 bg-black/85 backdrop-blur-sm p-2 rounded border border-[#1E2028] flex gap-4 pointer-events-none z-10 font-mono">
          <div>
            <p class="text-[9px] text-[#5A5E67] uppercase font-bold tracking-wider">Pose Prediction</p>
            <p class="text-xs text-[#E0E2E6] font-mono">+{{ engine.predictionHorizonMs() }}ms Horizon</p>
          </div>
          <div class="border-l border-[#1E2028] pl-3">
            <p class="text-[9px] text-[#5A5E67] uppercase font-bold tracking-wider">Confidence</p>
            <p class="text-xs text-[#00FF85] font-bold">{{ (engine.headPose().confidence * 100).toFixed(1) }}%</p>
          </div>
        </div>

        <!-- Bottom Right: World Density Block -->
        <div class="absolute bottom-3 right-3 text-right pointer-events-none z-10 font-mono bg-black/85 backdrop-blur-sm px-2.5 py-1.5 rounded border border-[#1E2028]">
          <p class="text-[9px] text-[#5A5E67] uppercase font-bold tracking-wider">World Density</p>
          <p class="text-sm font-bold text-[#00F0FF]">2.4M pts/sec</p>
        </div>

        <!-- Bottom Center Overlay: Hand Gesture Indicator -->
        <div class="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-3 bg-[#13151A]/95 backdrop-blur-md px-3 py-1.5 rounded border border-[#1E2028] pointer-events-none z-10">
          <div class="flex items-center gap-1.5">
            <mat-icon class="text-xs text-[#00F0FF] !w-3.5 !h-3.5">front_hand</mat-icon>
            <div class="text-[11px] font-mono">
              <span class="text-[#5A5E67]">L:</span> 
              <span class="text-[#E0E2E6] font-semibold ml-1">{{ engine.leftHand().gesture }}</span>
            </div>
          </div>
          <div class="h-3 w-px bg-[#1E2028]"></div>
          <div class="flex items-center gap-1.5">
            <mat-icon class="text-xs text-[#00FF85] !w-3.5 !h-3.5">touch_app</mat-icon>
            <div class="text-[11px] font-mono">
              <span class="text-[#5A5E67]">R:</span> 
              <span class="text-[#00FF85] font-bold ml-1">{{ engine.rightHand().gesture }}</span>
              <span class="text-[9px] text-[#5A5E67] ml-1">({{ engine.rightHand().pinch_distance_mm.toFixed(0) }}mm)</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Viewport Controls & Layers Toolbar -->
      <div class="bg-[#13151A] border-t border-[#1E2028] px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div class="flex flex-wrap items-center gap-1.5">
          <button 
            (click)="toggleLayer('gaze')"
            class="px-2 py-1 rounded border font-mono text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-[#00F0FF]/15]="showGaze()"
            [class.border-[#00F0FF]]="showGaze()"
            [class.text-[#00F0FF]]="showGaze()"
            [class.bg-[#1A1D24]]="!showGaze()"
            [class.border-[#1E2028]]="!showGaze()"
            [class.text-[#5A5E67]]="!showGaze()">
            <mat-icon class="text-xs !w-3.5 !h-3.5">remove_red_eye</mat-icon> Gaze Rays
          </button>

          <button 
            (click)="toggleLayer('hands')"
            class="px-2 py-1 rounded border font-mono text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-[#00FF85]/15]="showHands()"
            [class.border-[#00FF85]]="showHands()"
            [class.text-[#00FF85]]="showHands()"
            [class.bg-[#1A1D24]]="!showHands()"
            [class.border-[#1E2028]]="!showHands()"
            [class.text-[#5A5E67]]="!showHands()">
            <mat-icon class="text-xs !w-3.5 !h-3.5">back_hand</mat-icon> Hand Skeleton
          </button>

          <button 
            (click)="toggleLayer('prediction')"
            class="px-2 py-1 rounded border font-mono text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-[#F27D26]/15]="showPrediction()"
            [class.border-[#F27D26]]="showPrediction()"
            [class.text-[#F27D26]]="showPrediction()"
            [class.bg-[#1A1D24]]="!showPrediction()"
            [class.border-[#1E2028]]="!showPrediction()"
            [class.text-[#5A5E67]]="!showPrediction()">
            <mat-icon class="text-xs !w-3.5 !h-3.5">trending_up</mat-icon> Head Prediction ({{ engine.predictionHorizonMs() }}ms)
          </button>

          <button 
            (click)="toggleLayer('bounds')"
            class="px-2 py-1 rounded border font-mono text-[11px] flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-[#00F0FF]/15]="showBounds()"
            [class.border-[#00F0FF]]="showBounds()"
            [class.text-[#00F0FF]]="showBounds()"
            [class.bg-[#1A1D24]]="!showBounds()"
            [class.border-[#1E2028]]="!showBounds()"
            [class.text-[#5A5E67]]="!showBounds()">
            <mat-icon class="text-xs !w-3.5 !h-3.5">crop_free</mat-icon> 3D Bounding Volumes
          </button>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="resetCamera()"
            class="px-2.5 py-1 rounded bg-[#1A1D24] hover:bg-[#2E323D] border border-[#1E2028] text-[#E0E2E6] font-mono text-[11px] flex items-center gap-1 transition-all cursor-pointer">
            <mat-icon class="text-xs !w-3.5 !h-3.5 text-[#00F0FF]">center_focus_strong</mat-icon> Reset View
          </button>
        </div>
      </div>
    </div>
  `
})
export class Viewport3dComponent implements OnInit, OnDestroy {
  protected readonly engine = inject(SpatialEngineService);

  @ViewChild('webglCanvas', { static: true }) canvasRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('canvasContainer', { static: true }) containerRef!: ElementRef<HTMLDivElement>;

  readonly showGaze = signal<boolean>(true);
  readonly showHands = signal<boolean>(true);
  readonly showPrediction = signal<boolean>(true);
  readonly showBounds = signal<boolean>(true);

  // Three.js instances
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private animationId: number | null = null;

  // Scene Objects References
  private hmdMesh!: THREE.Group;
  private predictedHmdMesh!: THREE.Group;
  private gazeLine!: THREE.Line;
  private gazeFocalPoint!: THREE.Mesh;
  private leftHandGroup!: THREE.Group;
  private rightHandGroup!: THREE.Group;
  private objectMeshes = new Map<string, THREE.Group>();
  private slamPointCloud!: THREE.Points;

  // Interaction Orbit
  private platformId = inject(PLATFORM_ID);
  private isDragging = false;
  private previousMousePosition = { x: 0, y: 0 };
  private spherical = { radius: 4.8, phi: Math.PI / 3.2, theta: Math.PI / 4.0 };
  private targetCenter = new THREE.Vector3(0, 1.2, -1.0);

  constructor() {
    // Effect to update 3D scene whenever state changes
    effect(() => {
      if (isPlatformBrowser(this.platformId)) {
        this.updateSceneEntities();
      }
    });
  }

  ngOnInit(): void {
    if (isPlatformBrowser(this.platformId)) {
      this.initThreeJS();
      this.setupEventListeners();
    }
  }

  ngOnDestroy(): void {
    if (this.animationId && typeof cancelAnimationFrame !== 'undefined') {
      cancelAnimationFrame(this.animationId);
    }
    if (this.renderer) {
      this.renderer.dispose();
    }
  }

  toggleLayer(layer: 'gaze' | 'hands' | 'prediction' | 'bounds'): void {
    if (layer === 'gaze') this.showGaze.update(v => !v);
    if (layer === 'hands') this.showHands.update(v => !v);
    if (layer === 'prediction') this.showPrediction.update(v => !v);
    if (layer === 'bounds') this.showBounds.update(v => !v);
  }

  resetCamera(): void {
    this.spherical = { radius: 4.8, phi: Math.PI / 3.2, theta: Math.PI / 4.0 };
    this.targetCenter.set(0, 1.2, -1.0);
    this.updateCameraPosition();
  }

  getTargetObjectName(id: string): string {
    const obj = this.engine.spatialObjects().find(o => o.id === id);
    return obj ? obj.semantic_label : id;
  }

  private initThreeJS(): void {
    const canvas = this.canvasRef.nativeElement;
    const container = this.containerRef.nativeElement;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || 500;

    // 1. Scene & Renderer
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x090a0f);
    this.scene.fog = new THREE.FogExp2(0x090a0f, 0.08);

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    // 2. Camera
    this.camera = new THREE.PerspectiveCamera(55, width / height, 0.1, 50);
    this.updateCameraPosition();

    // 3. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x10b981, 1.2);
    dirLight.position.set(4, 8, 4);
    this.scene.add(dirLight);

    const blueLight = new THREE.PointLight(0x06b6d4, 1.5, 12);
    blueLight.position.set(-2, 3, -2);
    this.scene.add(blueLight);

    // 4. Build Environment (Room Grid, SLAM Points, Boundary)
    this.buildRoomEnvironment();
    this.buildHMDModels();
    this.buildGazeVisualizer();
    this.buildHandModels();
    this.buildSpatialObjects();
    this.buildSLAMPointCloud();

    // 5. Render Loop
    const animate = () => {
      this.animationId = requestAnimationFrame(animate);
      this.renderer.render(this.scene, this.camera);
    };
    animate();

    // Resize observer
    const resizeObserver = new ResizeObserver(() => {
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
      }
    });
    resizeObserver.observe(container);
  }

  private updateCameraPosition(): void {
    const x = this.targetCenter.x + this.spherical.radius * Math.sin(this.spherical.phi) * Math.sin(this.spherical.theta);
    const y = this.targetCenter.y + this.spherical.radius * Math.cos(this.spherical.phi);
    const z = this.targetCenter.z + this.spherical.radius * Math.sin(this.spherical.phi) * Math.cos(this.spherical.theta);

    this.camera.position.set(x, y, z);
    this.camera.lookAt(this.targetCenter);
  }

  private buildRoomEnvironment(): void {
    // Cybernetic Grid Floor
    const gridHelper = new THREE.GridHelper(10, 20, 0x10b981, 0x1e293b);
    gridHelper.position.y = 0;
    this.scene.add(gridHelper);

    // Guardian Safety Floor Circle (Radius 2.2m)
    const ringGeo = new THREE.RingGeometry(2.18, 2.22, 64);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x10b981, side: THREE.DoubleSide, transparent: true, opacity: 0.4 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2;
    ring.position.set(0, 0.01, 0);
    this.scene.add(ring);
  }

  private buildHMDModels(): void {
    // Main User Headset
    this.hmdMesh = new THREE.Group();

    const visorGeo = new THREE.BoxGeometry(0.22, 0.11, 0.14);
    const visorMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.2,
      metalness: 0.8,
      emissive: 0x10b981,
      emissiveIntensity: 0.2
    });
    const visor = new THREE.Mesh(visorGeo, visorMat);
    this.hmdMesh.add(visor);

    // Coordinate Axes (RGB = XYZ)
    const axes = new THREE.AxesHelper(0.2);
    this.hmdMesh.add(axes);

    this.scene.add(this.hmdMesh);

    // Predicted HMD Pose Ghost (Future horizon)
    this.predictedHmdMesh = new THREE.Group();
    const ghostGeo = new THREE.BoxGeometry(0.22, 0.11, 0.14);
    const ghostMat = new THREE.MeshBasicMaterial({
      color: 0xa855f7,
      wireframe: true,
      transparent: true,
      opacity: 0.6
    });
    this.predictedHmdMesh.add(new THREE.Mesh(ghostGeo, ghostMat));
    this.scene.add(this.predictedHmdMesh);
  }

  private buildGazeVisualizer(): void {
    // Gaze Line
    const gazeGeo = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, 0, -2)
    ]);
    const gazeMat = new THREE.LineBasicMaterial({ color: 0x10b981, linewidth: 2, transparent: true, opacity: 0.8 });
    this.gazeLine = new THREE.Line(gazeGeo, gazeMat);
    this.scene.add(this.gazeLine);

    // Focal Point Reticle
    const focalGeo = new THREE.RingGeometry(0.02, 0.035, 32);
    const focalMat = new THREE.MeshBasicMaterial({ color: 0x34d399, side: THREE.DoubleSide, transparent: true, opacity: 0.9 });
    this.gazeFocalPoint = new THREE.Mesh(focalGeo, focalMat);
    this.scene.add(this.gazeFocalPoint);
  }

  private buildHandModels(): void {
    this.leftHandGroup = new THREE.Group();
    this.rightHandGroup = new THREE.Group();
    this.scene.add(this.leftHandGroup);
    this.scene.add(this.rightHandGroup);
  }

  private buildSLAMPointCloud(): void {
    const pointCount = 600;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);

    for (let i = 0; i < pointCount; i++) {
      // Scatter random feature points on room walls and surfaces
      positions[i * 3] = (Math.random() - 0.5) * 6;
      positions[i * 3 + 1] = Math.random() * 3;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 6;

      colors[i * 3] = 0.06;
      colors[i * 3 + 1] = 0.72;
      colors[i * 3 + 2] = 0.5;
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({ size: 0.035, vertexColors: true, transparent: true, opacity: 0.6 });
    this.slamPointCloud = new THREE.Points(geometry, material);
    this.scene.add(this.slamPointCloud);
  }

  private buildSpatialObjects(): void {
    const objects = this.engine.spatialObjects();
    for (const obj of objects) {
      const group = new THREE.Group();

      const dims = obj.bounding_volume.dimensions;
      let geometry: THREE.BufferGeometry;
      let material: THREE.Material;

      if (obj.semantic_class === 'SCREEN') {
        geometry = new THREE.BoxGeometry(dims.x, dims.y, dims.z);
        material = new THREE.MeshStandardMaterial({
          color: 0x0f172a,
          emissive: 0x0284c7,
          emissiveIntensity: 0.4,
          roughness: 0.2
        });
      } else if (obj.semantic_class === 'TABLE') {
        geometry = new THREE.BoxGeometry(dims.x, dims.y, dims.z);
        material = new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 });
      } else if (obj.semantic_class === 'PERSON') {
        geometry = new THREE.CapsuleGeometry(0.25, dims.y - 0.5, 8, 16);
        material = new THREE.MeshStandardMaterial({ color: 0x64748b, wireframe: true });
      } else if (obj.semantic_class === 'COFFEE_CUP') {
        geometry = new THREE.CylinderGeometry(0.04, 0.035, dims.y, 16);
        material = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
      } else {
        geometry = new THREE.BoxGeometry(dims.x, dims.y, dims.z);
        material = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.6 });
      }

      const mainMesh = new THREE.Mesh(geometry, material);
      group.add(mainMesh);

      // Bounding box wireframe
      const bboxGeo = new THREE.BoxGeometry(dims.x * 1.02, dims.y * 1.02, dims.z * 1.02);
      const bboxMat = new THREE.MeshBasicMaterial({ color: 0x10b981, wireframe: true, transparent: true, opacity: 0.35 });
      const bboxMesh = new THREE.Mesh(bboxGeo, bboxMat);
      bboxMesh.name = 'bbox';
      group.add(bboxMesh);

      group.position.set(obj.position.x, obj.position.y, obj.position.z);
      this.scene.add(group);
      this.objectMeshes.set(obj.id, group);
    }
  }

  private updateSceneEntities(): void {
    if (!this.hmdMesh) return;

    // 1. Update User HMD Pose
    const head = this.engine.headPose();
    this.hmdMesh.position.set(head.position.x, head.position.y, head.position.z);
    this.hmdMesh.quaternion.set(head.orientation.x, head.orientation.y, head.orientation.z, head.orientation.w);

    // 2. Update Predicted HMD Pose Ghost
    if (this.predictedHmdMesh) {
      this.predictedHmdMesh.visible = this.showPrediction();
      const pred = this.engine.predictedHeadPose();
      this.predictedHmdMesh.position.set(pred.position.x, pred.position.y, pred.position.z);
      this.predictedHmdMesh.quaternion.set(pred.orientation.x, pred.orientation.y, pred.orientation.z, pred.orientation.w);
    }

    // 3. Update Gaze Ray & Target
    if (this.gazeLine && this.gazeFocalPoint) {
      const gaze = this.engine.gazeState();
      this.gazeLine.visible = this.showGaze();
      this.gazeFocalPoint.visible = this.showGaze();

      const origin = new THREE.Vector3(gaze.origin.x, gaze.origin.y, gaze.origin.z);
      const targetPoint = gaze.target_point
        ? new THREE.Vector3(gaze.target_point.x, gaze.target_point.y, gaze.target_point.z)
        : origin.clone().add(new THREE.Vector3(gaze.direction.x, gaze.direction.y, gaze.direction.z).multiplyScalar(2));

      this.gazeLine.geometry.setFromPoints([origin, targetPoint]);
      this.gazeFocalPoint.position.copy(targetPoint);
      this.gazeFocalPoint.lookAt(this.camera.position);
    }

    // 4. Update Hand Skeletal Joints
    this.updateHandSkeleton(this.leftHandGroup, this.engine.leftHand(), 0x06b6d4);
    this.updateHandSkeleton(this.rightHandGroup, this.engine.rightHand(), 0x10b981);

    // 5. Update Dynamic Objects
    const objects = this.engine.spatialObjects();
    for (const obj of objects) {
      const group = this.objectMeshes.get(obj.id);
      if (group) {
        group.position.set(obj.position.x, obj.position.y, obj.position.z);
        const bbox = group.getObjectByName('bbox');
        if (bbox) {
          bbox.visible = this.showBounds();
          // Glow bounding box if active gaze target
          const isTarget = this.engine.gazeState().target_object_id === obj.id;
          (bbox as THREE.Mesh).material = new THREE.MeshBasicMaterial({
            color: isTarget ? 0x34d399 : 0x10b981,
            wireframe: true,
            transparent: true,
            opacity: isTarget ? 0.9 : 0.25
          });
        }
      }
    }
  }

  private updateHandSkeleton(group: THREE.Group, hand: HandState, colorHex: number): void {
    group.visible = this.showHands();
    if (!this.showHands()) return;

    // Clear old children and re-render skeletal nodes
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    // Wrist & joints
    const jointMat = new THREE.MeshBasicMaterial({ color: colorHex });
    const jointGeo = new THREE.SphereGeometry(0.012, 8, 8);

    for (const joint of hand.joints) {
      const mesh = new THREE.Mesh(jointGeo, jointMat);
      mesh.position.set(joint.position.x, joint.position.y, joint.position.z);
      group.add(mesh);
    }

    // Pinch halo ring
    if (hand.gesture === 'PINCH' || hand.pinch_distance_mm < 15) {
      const pinchGeo = new THREE.RingGeometry(0.02, 0.03, 16);
      const pinchMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b, side: THREE.DoubleSide });
      const pinchRing = new THREE.Mesh(pinchGeo, pinchMat);
      pinchRing.position.set(hand.pinch_position.x, hand.pinch_position.y, hand.pinch_position.z);
      pinchRing.lookAt(this.camera.position);
      group.add(pinchRing);
    }
  }

  private setupEventListeners(): void {
    const canvas = this.canvasRef.nativeElement;

    canvas.addEventListener('mousedown', (e) => {
      this.isDragging = true;
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    window.addEventListener('mouseup', () => {
      this.isDragging = false;
    });

    canvas.addEventListener('mousemove', (e) => {
      if (!this.isDragging) return;

      const deltaX = e.clientX - this.previousMousePosition.x;
      const deltaY = e.clientY - this.previousMousePosition.y;

      this.spherical.theta -= deltaX * 0.008;
      this.spherical.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, this.spherical.phi - deltaY * 0.008));

      this.updateCameraPosition();
      this.previousMousePosition = { x: e.clientX, y: e.clientY };
    });

    canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      this.spherical.radius = Math.max(1.5, Math.min(12.0, this.spherical.radius + e.deltaY * 0.005));
      this.updateCameraPosition();
    }, { passive: false });
  }
}
