import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';
import { ComputeDevice, PowerMode } from '../../core/types';

@Component({
  selector: 'app-digital-twin',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-y-auto pr-1">
      <!-- Digital Twin Header & Device Specs (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#00F0FF]">
            <mat-icon class="text-base">memory</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                SPATIAL DEVICE DIGITAL TWIN
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                MODEL: SPATIALMIND PRO-HMD
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Hardware simulation of 16nm NPU (18.4 TOPS), 6-core ARM CPU, Dual-Eye IR, and 500Hz IMU MEMS
            </p>
          </div>
        </div>

        <!-- Power Mode Selector -->
        <div class="flex items-center gap-1 bg-[#0A0B0E] p-0.5 rounded border border-[#1E2028]">
          @for (mode of powerModes; track mode) {
            <button
              (click)="engine.setPowerMode(mode)"
              class="px-2 py-1 text-[10px] font-mono rounded transition-all cursor-pointer flex items-center gap-1"
              [class.bg-[#1E2028]]="engine.powerMode() === mode"
              [class.text-[#00F0FF]]="engine.powerMode() === mode"
              [class.border]="engine.powerMode() === mode"
              [class.border-[#2E323D]]="engine.powerMode() === mode"
              [class.text-[#5A5E67]]="engine.powerMode() !== mode">
              {{ mode }}
            </button>
          }
        </div>
      </div>

      <!-- Real-Time Thermal, Battery & Latency Gauges -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
        <!-- Battery Level -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[9px] text-[#5A5E67] font-mono uppercase font-bold tracking-wider">BATTERY CELL</span>
            <mat-icon class="text-[#00FF85] text-xs !w-3.5 !h-3.5">battery_charging_full</mat-icon>
          </div>
          <div class="my-1.5">
            <div class="text-xl font-bold font-mono text-[#E0E2E6]">{{ engine.telemetry().battery_level_pct }}%</div>
            <div class="text-[10px] text-[#5A5E67] font-mono">Drain: {{ engine.telemetry().battery_drain_rate_w }} Watts</div>
          </div>
          <div class="w-full bg-[#0A0B0E] h-1.5 rounded-full overflow-hidden border border-[#1E2028]">
            <div 
              class="h-full bg-[#00FF85] rounded-full transition-all duration-300"
              [style.width.%]="engine.telemetry().battery_level_pct">
            </div>
          </div>
        </div>

        <!-- Thermal State -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[9px] text-[#5A5E67] font-mono uppercase font-bold tracking-wider">SKIN TEMPERATURE</span>
            <mat-icon [class.text-[#00FF85]]="engine.telemetry().thermal_state === 'NOMINAL'"
                      [class.text-[#F27D26]]="engine.telemetry().thermal_state === 'WARM'"
                      [class.text-red-400]="engine.telemetry().thermal_state === 'CRITICAL_THROTTLED'"
                      class="text-xs !w-3.5 !h-3.5">thermostat</mat-icon>
          </div>
          <div class="my-1.5">
            <div class="text-xl font-bold font-mono text-[#E0E2E6]">{{ engine.telemetry().device_temperature_c }} &deg;C</div>
            <div class="text-[10px] text-[#5A5E67] font-mono">State: <span class="text-[#00FF85]">{{ engine.telemetry().thermal_state }}</span></div>
          </div>
          <div class="w-full bg-[#0A0B0E] h-1.5 rounded-full overflow-hidden border border-[#1E2028]">
            <div 
              class="h-full rounded-full transition-all duration-300"
              [class.bg-[#00FF85]]="engine.telemetry().thermal_state === 'NOMINAL'"
              [class.bg-[#F27D26]]="engine.telemetry().thermal_state === 'WARM'"
              [class.bg-red-400]="engine.telemetry().thermal_state === 'CRITICAL_THROTTLED'"
              [style.width.%]="Math.min(100, (engine.telemetry().device_temperature_c / 45) * 100)">
            </div>
          </div>
        </div>

        <!-- End-to-End Latency -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[9px] text-[#5A5E67] font-mono uppercase font-bold tracking-wider">MOTION-TO-PHOTON</span>
            <mat-icon class="text-[#00F0FF] text-xs !w-3.5 !h-3.5">speed</mat-icon>
          </div>
          <div class="my-1.5">
            <div class="text-xl font-bold font-mono text-[#00F0FF]">{{ engine.telemetry().end_to_end_latency_ms }} ms</div>
            <div class="text-[10px] text-[#5A5E67] font-mono">Budget: &le; 11.1ms (90 FPS)</div>
          </div>
          <div class="w-full bg-[#0A0B0E] h-1.5 rounded-full overflow-hidden border border-[#1E2028]">
            <div class="h-full bg-[#00F0FF] rounded-full" [style.width.%]="(engine.telemetry().end_to_end_latency_ms / 11.1) * 100"></div>
          </div>
        </div>

        <!-- Active Compute Device -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col justify-between">
          <div class="flex items-center justify-between">
            <span class="text-[9px] text-[#5A5E67] font-mono uppercase font-bold tracking-wider">ROUTED ACCELERATOR</span>
            <mat-icon class="text-[#F27D26] text-xs !w-3.5 !h-3.5">developer_board</mat-icon>
          </div>
          <div class="my-1.5">
            <div class="text-xl font-bold font-mono text-[#F27D26]">{{ engine.activeComputeDevice() }}</div>
            <div class="text-[10px] text-[#5A5E67] font-mono">Adaptive INT8 Quantization</div>
          </div>
          <div class="flex gap-1">
            @for (dev of computeDevices; track dev) {
              <button
                (click)="engine.setComputeDevice(dev)"
                class="flex-1 py-0.5 text-[9px] font-mono rounded bg-[#0A0B0E] border border-[#1E2028] hover:border-[#2E323D] cursor-pointer"
                [class.text-[#F27D26]]="engine.activeComputeDevice() === dev"
                [class.border-[#F27D26]]="engine.activeComputeDevice() === dev"
                [class.text-[#5A5E67]]="engine.activeComputeDevice() !== dev">
                {{ dev }}
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Sensor Failure Injection Harness (Adversarial Testing) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2.5">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-xs font-bold text-[#E0E2E6] flex items-center gap-1.5 uppercase tracking-wider">
              <mat-icon class="text-[#F27D26] text-xs !w-3.5 !h-3.5">warning</mat-icon>
              SENSOR FAULT INJECTION & GRACEFUL DEGRADATION HARNESS
            </h3>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Simulate hardware sensor loss or noise to observe how the EKF and spatial engine gracefully fallback.
            </p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
          @for (sensor of engine.sensorsHealth(); track sensor.sensor_id) {
            <div class="bg-[#1A1D24] border p-2.5 rounded flex flex-col justify-between gap-2"
                 [class.border-[#1E2028]]="sensor.is_active"
                 [class.border-l-2]="true"
                 [class.border-l-[#00FF85]]="sensor.is_active"
                 [class.border-red-500/60]="!sensor.is_active"
                 [class.border-l-red-500]="!sensor.is_active"
                 [class.bg-red-950/10]="!sensor.is_active">
              <div class="flex items-center justify-between">
                <span class="text-[11px] font-mono font-bold text-[#E0E2E6]">{{ sensor.sensor_type }}</span>
                <span class="text-[9px] font-mono px-1.5 py-0.2 rounded"
                      [class.bg-[#0A0B0E]]="true"
                      [class.text-[#00FF85]]="sensor.is_active"
                      [class.border]="true"
                      [class.border-[#1E2028]]="sensor.is_active"
                      [class.text-red-400]="!sensor.is_active"
                      [class.border-red-800]="!sensor.is_active">
                  {{ sensor.calibration_state }}
                </span>
              </div>

              <div class="text-[10px] text-[#5A5E67] font-mono space-y-0.5">
                <div class="flex justify-between">
                  <span>Rate: <span class="text-[#E0E2E6]">{{ sensor.sample_rate_hz }} Hz</span></span>
                  <span>Latency: <span class="text-[#00F0FF]">{{ sensor.latency_ms }} ms</span></span>
                </div>
                <div class="flex justify-between">
                  <span>Noise: {{ sensor.noise_floor }}</span>
                  <span>Drop: <span class="text-[#F27D26]">{{ sensor.drop_rate_pct }}%</span></span>
                </div>
              </div>

              <button
                (click)="engine.toggleSensorHealth(sensor.sensor_id)"
                class="w-full mt-0.5 py-1 rounded text-[10px] font-mono flex items-center justify-center gap-1 transition-all border cursor-pointer"
                [class.bg-[#0A0B0E]]="true"
                [class.border-red-900/60]="sensor.is_active"
                [class.text-red-400]="sensor.is_active"
                [class.hover:bg-red-950/30]="sensor.is_active"
                [class.border-[#00FF85]/40]="!sensor.is_active"
                [class.text-[#00FF85]]="!sensor.is_active"
                [class.hover:bg-[#00FF85]/10]="!sensor.is_active">
                <mat-icon class="text-xs !w-3 !h-3">{{ sensor.is_active ? 'flash_off' : 'flash_on' }}</mat-icon>
                {{ sensor.is_active ? 'Inject Sensor Failure' : 'Restore Sensor' }}
              </button>
            </div>
          }
        </div>
      </div>

      <!-- Multi-Rate Scheduling Matrix -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
        <h3 class="text-xs font-bold text-[#E0E2E6] flex items-center gap-1.5 uppercase tracking-wider">
          <mat-icon class="text-[#00F0FF] text-xs !w-3.5 !h-3.5">tune</mat-icon>
          MULTI-RATE ML SCHEDULER MATRIX & PRIORITIES
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-2 text-xs font-mono">
          <div class="bg-[#1A1D24] p-2.5 rounded border border-[#1E2028] border-l-2 border-l-red-400">
            <div class="text-red-400 font-bold text-[10px] mb-0.5">CRITICAL DOMAIN (500Hz)</div>
            <p class="text-[10px] text-[#5A5E67] leading-tight">IMU fusion, 6-DoF EKF State Estimation, 18.5ms Head Prediction</p>
          </div>
          <div class="bg-[#1A1D24] p-2.5 rounded border border-[#1E2028] border-l-2 border-l-[#F27D26]">
            <div class="text-[#F27D26] font-bold text-[10px] mb-0.5">HIGH DOMAIN (90-120Hz)</div>
            <p class="text-[10px] text-[#5A5E67] leading-tight">26-Joint Hand Kinematics, Eye Gaze Vergence, Gesture Detection</p>
          </div>
          <div class="bg-[#1A1D24] p-2.5 rounded border border-[#1E2028] border-l-2 border-l-[#00F0FF]">
            <div class="text-[#00F0FF] font-bold text-[10px] mb-0.5">NORMAL DOMAIN (30Hz)</div>
            <p class="text-[10px] text-[#5A5E67] leading-tight">3D Object Detection, SLAM Keyframing, Spatial Safety Guardian</p>
          </div>
          <div class="bg-[#1A1D24] p-2.5 rounded border border-[#1E2028] border-l-2 border-l-[#00FF85]">
            <div class="text-[#00FF85] font-bold text-[10px] mb-0.5">BACKGROUND (1-5Hz)</div>
            <p class="text-[10px] text-[#5A5E67] leading-tight">Semantic Segmentation, 128-dim Embedding Indexing, Auto-Tuning</p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DigitalTwinComponent {
  protected readonly engine = inject(SpatialEngineService);
  protected readonly Math = Math;

  readonly powerModes: PowerMode[] = ['PERFORMANCE', 'BALANCED', 'BATTERY', 'ULTRA_LOW_POWER'];
  readonly computeDevices: ComputeDevice[] = ['NPU', 'GPU', 'DSP', 'CPU'];
}
