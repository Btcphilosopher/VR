import { Component, ChangeDetectionStrategy, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

interface RustCrateInfo {
  name: string;
  version: string;
  description: string;
  features: string[];
  allocPolicy: string;
  snippet: string;
}

@Component({
  selector: 'app-rust-architecture',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-y-auto pr-1">
      <!-- Header (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#F27D26]">
            <mat-icon class="text-base">code</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#F27D26]">
                RUST KERNEL ARCHITECTURE & EMBEDDED MEMORY DESIGN
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                #![no_std] CAPABLE
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Zero-allocation hot loops, lock-free ring buffers, SIMD intrinsics & strict SE(3) invariants
            </p>
          </div>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="text-[9px] text-[#5A5E67] font-bold">WORKSPACE:</span>
          <span class="text-[#00F0FF] font-bold text-xs">spatialmind-core-workspace</span>
        </div>
      </div>

      <!-- Main Layout: Crate List + Code Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-2.5 flex-1 min-h-[400px]">
        <!-- Crate Selector -->
        <div class="space-y-2">
          @for (crateItem of crates; track crateItem.name) {
            <button
              type="button"
              (click)="selectedCrate.set(crateItem)"
              class="p-2.5 rounded-lg border text-left w-full transition-all cursor-pointer flex flex-col gap-1"
              [class.bg-[#13151A]]="selectedCrate().name !== crateItem.name"
              [class.bg-[#1A1D24]]="selectedCrate().name === crateItem.name"
              [class.border-[#1E2028]]="selectedCrate().name !== crateItem.name"
              [class.border-[#F27D26]]="selectedCrate().name === crateItem.name">
              <div class="flex items-center justify-between">
                <span class="text-xs font-mono font-bold text-[#E0E2E6] flex items-center gap-1.5">
                  <mat-icon class="text-xs !w-3.5 !h-3.5" [class.text-[#F27D26]]="selectedCrate().name === crateItem.name" [class.text-[#5A5E67]]="selectedCrate().name !== crateItem.name">folder_zip</mat-icon>
                  {{ crateItem.name }}
                </span>
                <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#5A5E67] border border-[#1E2028]">
                  v{{ crateItem.version }}
                </span>
              </div>
              <p class="text-[10px] text-[#5A5E67] leading-tight">{{ crateItem.description }}</p>
              <div class="text-[9px] font-mono text-[#5A5E67] flex justify-between pt-0.5 border-t border-[#1E2028]">
                <span>Alloc: <span class="text-[#00FF85]">{{ crateItem.allocPolicy }}</span></span>
              </div>
            </button>
          }
        </div>

        <!-- Rust Code Viewer -->
        <div class="lg:col-span-2 bg-[#13151A] border border-[#1E2028] rounded-lg p-3 flex flex-col gap-2 font-mono text-xs overflow-hidden">
          <div class="flex items-center justify-between border-b border-[#1E2028] pb-1.5">
            <span class="text-[#00F0FF] font-bold flex items-center gap-1.5 text-xs">
              <mat-icon class="text-xs !w-3.5 !h-3.5">terminal</mat-icon>
              {{ selectedCrate().name }} / src/lib.rs
            </span>
            <div class="flex gap-1">
              @for (feat of selectedCrate().features; track feat) {
                <span class="text-[9px] px-1.5 py-0.2 rounded bg-[#0A0B0E] text-[#00FF85] border border-[#1E2028]">
                  +{{ feat }}
                </span>
              }
            </div>
          </div>

          <!-- Code Body -->
          <div class="flex-1 overflow-y-auto bg-[#0A0B0E] p-2.5 rounded border border-[#1E2028]">
            <pre class="text-[#E0E2E6] whitespace-pre font-mono text-[11px] leading-relaxed">{{ selectedCrate().snippet }}</pre>
          </div>

          <div class="text-[10px] text-[#5A5E67] bg-[#0A0B0E] px-2.5 py-1.5 rounded border border-[#1E2028] flex items-center justify-between">
            <span>&bull; Invariant: Deterministic heap-free execution in 500Hz loop</span>
            <span class="text-[#00FF85] font-bold">Cargo test: PASS</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RustArchitectureComponent {
  readonly crates: RustCrateInfo[] = [
    {
      name: 'spatialmind-fusion',
      version: '0.9.4',
      description: '6-DoF Extended Kalman Filter & IMU/Visual Odometry tightly-coupled fusion.',
      features: ['simd-neon', 'simd-avx512', 'no_std'],
      allocPolicy: 'Zero Heap (Static Array Pools)',
      snippet: `//! spatialmind-fusion: 6-DoF EKF State Estimator
#![no_std]

use nalgebra::{Matrix6, Vector6, Vector3, UnitQuaternion};

#[repr(C, align(64))]
pub struct ExtendedKalmanFilter6DoF {
    pub state_x: Vector6<f32>,     // [pos_x, pos_y, pos_z, vel_x, vel_y, vel_z]
    pub orientation: UnitQuaternion<f32>,
    pub covariance: Matrix6<f32>,
    pub process_noise_q: Matrix6<f32>,
    pub measurement_noise_r: Matrix6<f32>,
}

impl ExtendedKalmanFilter6DoF {
    #[inline(always)]
    pub fn predict_imu(&mut self, accel: Vector3<f32>, gyro: Vector3<f32>, dt: f32) {
        // High-rate 500Hz propagation step without heap allocations
        let rot_delta = UnitQuaternion::from_scaled_axis(gyro * dt);
        self.orientation = self.orientation * rot_delta;
        
        let world_accel = self.orientation.transform_vector(&accel) - Vector3::new(0.0, 9.81, 0.0);
        self.state_x.fixed_rows_mut::<3>(0).add_assign(self.state_x.fixed_rows::<3>(3) * dt);
        self.state_x.fixed_rows_mut::<3>(3).add_assign(world_accel * dt);
    }
}`
    },
    {
      name: 'spatialmind-time',
      version: '0.9.4',
      description: 'Monotonic nanosecond timestamp synchronizer & lock-free ring buffers.',
      features: ['crossbeam-epoch', 'atomic-fence'],
      allocPolicy: 'Lock-Free Ring Buffer',
      snippet: `//! spatialmind-time: Real-time Multi-Rate Sensor Synchronizer
pub struct TimeMachineRingBuffer<T, const CAP: usize> {
    buffer: [Option<T>; CAP],
    head: core::sync::atomic::AtomicUsize,
    tail: core::sync::atomic::AtomicUsize,
}

impl<T: Copy, const CAP: usize> TimeMachineRingBuffer<T, CAP> {
    pub const fn new() -> Self {
        Self {
            buffer: [None; CAP],
            head: core::sync::atomic::AtomicUsize::new(0),
            tail: core::sync::atomic::AtomicUsize::new(0),
        }
    }
}`
    },
    {
      name: 'spatialmind-intent',
      version: '0.9.4',
      description: 'Multimodal probabilistic intent classifier & action dispatcher.',
      features: ['quantized-int8', 'lut-tables'],
      allocPolicy: 'Static Scratchpad',
      snippet: `//! spatialmind-intent: Multimodal Probabilistic Inference
pub enum OSIntent {
    SelectObject { entity_id: u32, confidence: f32 },
    DragWindow { translation: [f32; 3] },
    Dismiss,
    Idle,
}

pub struct IntentClassifier {
    dwell_threshold_ms: u32,
    pinch_trigger_mm: f32,
}`
    },
    {
      name: 'spatialmind-scene',
      version: '0.9.4',
      description: '128-dim Spatial Memory Embeddings & Relational Scene Graph.',
      features: ['hnsw-index', 'se3-transforms'],
      allocPolicy: 'Preallocated Arena',
      snippet: `//! spatialmind-scene: Spatial World Model & Relational Graph
pub struct SpatialEntity {
    pub id: u64,
    pub class_id: u16,
    pub transform: [f32; 16], // 4x4 Row-major homogeneous matrix
    pub embedding_128: [f32; 128],
    pub attention_score: f32,
}`
    }
  ];

  readonly selectedCrate = signal<RustCrateInfo>(this.crates[0]);
}
