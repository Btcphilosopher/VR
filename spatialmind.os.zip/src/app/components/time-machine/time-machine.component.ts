import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpatialEngineService } from '../../services/spatial-engine.service';

@Component({
  selector: 'app-time-machine',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-3 overflow-y-auto pr-1">
      <!-- Header (High Density) -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded bg-[#0A0B0E] border border-[#1E2028] flex items-center justify-center text-[#00F0FF]">
            <mat-icon class="text-base">history</mat-icon>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xs font-bold uppercase tracking-wider text-[#00F0FF]">
                SPATIAL TIME MACHINE & REPLAY ENGINE
              </h2>
              <span class="text-[9px] px-2 py-0.2 rounded bg-[#1E2028] text-[#00FF85] font-mono font-bold border border-[#2E323D]">
                BUFFER: {{ engine.replaySession().keyframes.length }} FRAMES
              </span>
            </div>
            <p class="text-[10px] text-[#5A5E67] font-mono mt-0.5">
              Deterministic scrub backwards and forwards through real-time kinematics, gaze, intent & sensor state
            </p>
          </div>
        </div>

        <!-- Play / Scrub Controls -->
        <div class="flex items-center gap-2 font-mono text-xs">
          <button
            (click)="toggleReplayMode()"
            class="px-3 py-1.5 rounded font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer border"
            [class.bg-[#00F0FF]]="engine.isReplaying()"
            [class.text-[#0A0B0E]]="engine.isReplaying()"
            [class.border-[#00F0FF]]="engine.isReplaying()"
            [class.bg-[#1A1D24]]="!engine.isReplaying()"
            [class.text-[#E0E2E6]]="!engine.isReplaying()"
            [class.border-[#1E2028]]="!engine.isReplaying()">
            <mat-icon class="text-xs !w-3.5 !h-3.5">{{ engine.isReplaying() ? 'pause' : 'play_arrow' }}</mat-icon>
            {{ engine.isReplaying() ? 'SCRUB ACTIVE' : 'SCRUB TIME MACHINE' }}
          </button>
        </div>
      </div>

      <!-- Scrubber Bar & Controls -->
      <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-2">
        <div class="flex items-center justify-between font-mono text-[11px]">
          <span class="text-[#5A5E67]">
            TIMELINE SCRUBBER: 
            <span class="text-[#00F0FF] font-bold">
              FRAME {{ engine.replayScrubIndex() }} / {{ Math.max(1, engine.replaySession().keyframes.length) }}
            </span>
          </span>
          <span class="text-[#5A5E67]">
            RECORDED: <span class="text-[#00FF85] font-bold">{{ (engine.replaySession().duration_ms / 1000).toFixed(1) }}s</span>
          </span>
        </div>

        <!-- Slider -->
        <input
          type="range"
          min="0"
          [max]="Math.max(0, engine.replaySession().keyframes.length - 1)"
          [value]="engine.replayScrubIndex()"
          (input)="onScrub($event)"
          class="w-full accent-[#00F0FF] cursor-pointer h-1.5 bg-[#0A0B0E] rounded border border-[#1E2028]"
        />

        <div class="flex items-center justify-between text-[10px] font-mono pt-0.5">
          <div class="flex items-center gap-1.5">
            <button 
              (click)="stepFrame(-1)"
              class="px-2 py-0.5 rounded bg-[#1A1D24] hover:bg-[#2E323D] text-[#E0E2E6] border border-[#1E2028] flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-xs !w-3 !h-3">skip_previous</mat-icon> Prev Frame
            </button>
            <button 
              (click)="stepFrame(1)"
              class="px-2 py-0.5 rounded bg-[#1A1D24] hover:bg-[#2E323D] text-[#E0E2E6] border border-[#1E2028] flex items-center gap-1 cursor-pointer">
              <mat-icon class="text-xs !w-3 !h-3">skip_next</mat-icon> Next Frame
            </button>
          </div>

          <span class="text-[9px] text-[#5A5E67]">
            Replay updates 3D Viewport, Skeletal nodes, and Intent inferences synchronously
          </span>
        </div>
      </div>

      <!-- Current Scrubbed Snapshot State Inspector -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2.5">
        <!-- Head & Prediction Snapshot -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-1.5 font-mono text-[11px]">
          <h3 class="text-[#00F0FF] font-bold flex items-center gap-1 border-b border-[#1E2028] pb-1.5 text-[9px] uppercase tracking-wider">
            <mat-icon class="text-xs !w-3.5 !h-3.5">view_in_ar</mat-icon> HEAD POSE & PREDICTION
          </h3>
          <div class="space-y-1 pt-0.5 text-[#5A5E67] text-[10px]">
            <div class="flex justify-between"><span>Pos X:</span> <span class="text-[#00FF85] font-bold">{{ engine.headPose().position.x.toFixed(3) }}m</span></div>
            <div class="flex justify-between"><span>Pos Y:</span> <span class="text-[#00FF85] font-bold">{{ engine.headPose().position.y.toFixed(3) }}m</span></div>
            <div class="flex justify-between"><span>Pos Z:</span> <span class="text-[#00FF85] font-bold">{{ engine.headPose().position.z.toFixed(3) }}m</span></div>
            <div class="flex justify-between"><span>Predicted Pos Z:</span> <span class="text-[#00F0FF] font-bold">{{ engine.predictedHeadPose().position.z.toFixed(3) }}m</span></div>
            <div class="flex justify-between border-t border-[#1E2028] pt-1"><span>Confidence:</span> <span class="text-[#00FF85] font-bold">{{ (engine.headPose().confidence * 100).toFixed(1) }}%</span></div>
          </div>
        </div>

        <!-- Gaze & Attention Snapshot -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-1.5 font-mono text-[11px]">
          <h3 class="text-[#00FF85] font-bold flex items-center gap-1 border-b border-[#1E2028] pb-1.5 text-[9px] uppercase tracking-wider">
            <mat-icon class="text-xs !w-3.5 !h-3.5">visibility</mat-icon> GAZE & VERGENCE
          </h3>
          <div class="space-y-1 pt-0.5 text-[#5A5E67] text-[10px]">
            <div class="flex justify-between"><span>Target Object:</span> <span class="text-[#00FF85] font-bold">{{ engine.gazeState().target_object_id || 'None' }}</span></div>
            <div class="flex justify-between"><span>Vergence Dist:</span> <span class="text-[#00F0FF] font-bold">{{ engine.gazeState().vergence_distance_m.toFixed(2) }}m</span></div>
            <div class="flex justify-between"><span>Dwell Duration:</span> <span class="text-[#E0E2E6] font-bold">{{ engine.gazeState().fixation_duration_ms }} ms</span></div>
            <div class="flex justify-between"><span>Classification:</span> <span class="text-[#F27D26] font-bold">{{ engine.gazeState().classification }}</span></div>
            <div class="flex justify-between border-t border-[#1E2028] pt-1"><span>Pupil Left:</span> <span class="text-[#5A5E67]">{{ engine.gazeState().pupil_diameter_mm.left.toFixed(1) }} mm</span></div>
          </div>
        </div>

        <!-- Intent & Telemetry Snapshot -->
        <div class="bg-[#13151A] border border-[#1E2028] p-3 rounded-lg flex flex-col gap-1.5 font-mono text-[11px]">
          <h3 class="text-[#F27D26] font-bold flex items-center gap-1 border-b border-[#1E2028] pb-1.5 text-[9px] uppercase tracking-wider">
            <mat-icon class="text-xs !w-3.5 !h-3.5">touch_app</mat-icon> INTENT & SAFETY SNAPSHOT
          </h3>
          <div class="space-y-1 pt-0.5 text-[#5A5E67] text-[10px]">
            <div class="flex justify-between"><span>Inferred Intent:</span> <span class="text-[#F27D26] font-bold">{{ engine.intentState().estimated_intent }}</span></div>
            <div class="flex justify-between"><span>Gesture:</span> <span class="text-[#00FF85] font-bold">{{ engine.rightHand().gesture }}</span></div>
            <div class="flex justify-between"><span>Safety Level:</span> <span class="text-[#00FF85] font-bold">{{ engine.safetyState().risk_level }}</span></div>
            <div class="flex justify-between"><span>Obstacle:</span> <span class="text-[#00F0FF] font-bold">{{ engine.safetyState().nearest_obstacle_distance_m }}m</span></div>
            <div class="flex justify-between border-t border-[#1E2028] pt-1"><span>E2E Latency:</span> <span class="text-[#00FF85] font-bold">{{ engine.telemetry().end_to_end_latency_ms }} ms</span></div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TimeMachineComponent {
  protected readonly engine = inject(SpatialEngineService);
  protected readonly Math = Math;

  toggleReplayMode(): void {
    const isRep = this.engine.isReplaying();
    this.engine.isReplaying.set(!isRep);
  }

  onScrub(e: Event): void {
    const target = e.target as HTMLInputElement;
    const idx = parseInt(target.value, 10);
    this.engine.isReplaying.set(true);
    this.engine.scrubTimeMachine(idx);
  }

  stepFrame(delta: number): void {
    const nextIdx = this.engine.replayScrubIndex() + delta;
    this.engine.isReplaying.set(true);
    this.engine.scrubTimeMachine(nextIdx);
  }
}
