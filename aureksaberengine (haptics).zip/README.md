# AUREK SABER ENGINE

A physical, systemic lightsaber-duelling **combat simulation core**, written in
Python. This is the first-playable-prototype slice of the master design brief:
one arena, two humanoid combatants, two lightsaber-style weapons, AI vs AI (or
scripted/player-driven), with blade physics, footwork, guard, parry, feints,
stamina, balance, procedural reactions, an adaptive AI opponent model, a
camera rig, and a deterministic replay/self-play harness — all driven off one
authoritative tick loop, not animation events.

```
DOES THE BLADE EXIST AS A REAL SIMULATION OBJECT?         YES.
CAN TWO BLADES ACTUALLY COLLIDE?                            YES.
CAN THE PLAYER / AI MISS?                                   YES.
CAN A PARRY RESULT FROM ACTUAL TIMING?                       YES.
CAN THE PLAYER / AI FEINT?                                   YES.
CAN THE AI LEARN THE OPPONENT'S HABITS?                       YES.
DOES FOOTWORK / DISTANCE / FATIGUE / BALANCE MATTER?          YES.
CAN A DUEL DEVELOP DIFFERENTLY EVERY TIME?                    YES.
DOES THE SIMULATION STAY AUTHORITATIVE OVER ANIMATION?        YES.
```

## Quick start

```bash
pip install -r requirements.txt

# Run one AI-vs-AI duel, print the event log, write a replay JSON:
python examples/run_duel.py --a-archetype DUELIST --b-archetype AGGRESSOR --seed 42

# Run many duels across archetype matchups and report balance metrics:
python examples/self_play_balance.py --n 20

# Run a duel with haptic feedback logging (no hardware required):
python examples/run_duel_with_haptics.py --seed 3 --a-archetype BERSERKER --b-archetype DEFENDER

# Run the test suite:
pytest aurek_saber/tests -q
```

## What this actually is (honest scope)

The 114-section brief asks for an AAA product: skeletal motion-matching
animation, a renderer with dynamic blade lighting, spatial audio, a netcode
stack, and a full cinematic camera pipeline. Those are genuine **engine and
art-pipeline** features (Unreal/Unity/a custom C++ or Rust runtime, a
character rig, motion-capture or hand-keyed animation data, a DSP/audio
engine) — they cannot be honestly delivered as pure Python in one pass, and
pretending otherwise would just mean stub functions with no real behaviour
behind them.

What **is** delivered, fully working and tested, is the part of the brief
that is genuinely a simulation/gameplay-programming problem — the part the
brief itself insists is the actual point: *"the engine is a physical
duelling engine... the blade has position, the fighter has position, the
opponent has intent."* Specifically:

| Layer | Status | Notes |
|---|---|---|
| Fixed-timestep deterministic simulation (§60, §71) | **Implemented** | 120 Hz, seeded, replay-verified (`replay/recorder.py::verify_determinism`) |
| Blade as a physical object + continuous collision (§04, §06-07) | **Implemented** | swept-segment capsule sweeps, blade-blade and blade-body |
| Guard system read off real blade pose (§12-13) | **Implemented** | no guard "menu" — the blade transform *is* the guard |
| Contact classification + physics response (§08-11) | **Implemented** | perfect parry / parry / block / glancing / edge / failed / direct / lock, each with real deflection/stagger/opening math |
| Attack trajectories with real phases + feints (§14-18) | **Implemented** | windup → acceleration → contact → follow-through → recovery, abortable/redirectable mid-flight |
| Footwork, distance model, circling (§20-23) | **Implemented** | no snapping; bounded acceleration/yaw-rate; distance zones drive both AI and controller |
| Stamina & balance (§30-31) | **Implemented** | soft degradation of speed/guard/recovery, not a hard gate |
| Procedural hit reactions (§29) | **Implemented** | computed from contact type + balance + momentum, not animation-name switches |
| 2-bone analytic IK, ground-foot IK (§26-27) | **Implemented (numeric utility)** | real law-of-cosines solver; there is no skeleton to drive with it yet |
| AI perception/prediction/opponent-model/personality/decision loop (§33-40, §108-109) | **Implemented** | delayed+noisy perception, pattern-memory opponent model, utility-scored action selection, 8 archetypes, 4 difficulty tiers with humanly-bounded reaction time |
| Combat event bus + replay + determinism check (§59-61, §97) | **Implemented** | `EventBus`, `ReplayRecorder`/`ReplayPlayer`, frame-advance/rewind/slow-motion scrubbing |
| Training dojo + analytics (§62-63) | **Implemented** | static target / droid / apprentice / master presets, reaction/parry/accuracy stats off the real event stream |
| Self-play & balancing harness (§98-100) | **Implemented** | `examples/self_play_balance.py` runs N duels per archetype matchup and reports win rate, duel length, parry rate, attack accuracy |
| Content layer: Forms I–VII, generic archetypes (§106-107) | **Implemented (data-driven, Pydantic-validated)** | no hardcoded copyrighted character identities |
| Haptics (`haptics/`) | **Implemented** | `CombatEvent`-driven discrete cues (ADSR-enveloped, per-viewer: attacker vs defender feel a contact differently) + a continuous blade-hum/heartbeat/balance-tremble layer, mixed with audio-style ducking, output through a pluggable `HapticDevice` (gamepad rumble backends included; VR/vest are the same interface — see below) |
| Camera framing math (§47-50) | **Implemented (data layer only)** | position/look-at/FOV computed each tick; no renderer to actually draw a frame |
| Procedural pose blending (§16, §28) | **Implemented (numeric utility)** | layered pose dict + blend, honestly labelled as a stand-in for a real rig/motion-matching database |
| Skeletal rendering, motion matching, lighting, audio DSP, netcode | **Not implemented** | these require a rendering/audio engine and asset pipeline outside a Python-only deliverable; the simulation layer is built so a real engine integration is a straightforward consumer of `DuelState`/`CombatEvent`, not a rewrite |
| Dismemberment / consequence content | **Scaffolded only** | `core.enums.BodyZone` and `ConsequenceType` exist; actual per-zone content is intentionally left to a content package (§43 asks for this to be content-configurable, not hardcoded) |

**A known tuning gap, surfaced honestly by the tooling built for exactly this
purpose:** in the current baseline weights, AI fighters feint/attack very
frequently and successful *PARRY* events are rare relative to direct hits —
`examples/self_play_balance.py` reports this (see its `avg parry rate`
column) rather than hiding it. This is precisely the kind of imbalance
§98-100 asks the self-play harness to surface; the next tuning pass is to
raise the `PARRY` action's utility weight in `ai/decision.py` and/or widen
`PERFECT_PARRY_WINDOW` in `combat/parry.py`, then re-run the harness to
confirm parry rate rises without collapsing attack accuracy to zero.

## Architecture

```
aurek_saber/
  core/        math, fixed-timestep clock, event bus, shared enums, canonical DuelState
  combat/      blade, continuous collision, distance, guard, parry, attacks, balance, stamina, duel (orchestrator)
  character/   controller (footwork+blade+attack binding), locomotion, stance table, procedural reaction, IK
  ai/          perception (delayed+noisy), prediction, opponent_model (pattern memory), personality/archetypes, decision loop
  animation/   procedural pose-blend utility (numeric layer, no renderer)
  camera/      duel camera framing math (no renderer)
  replay/      deterministic recorder/player + determinism verifier
  training/    DuelingDojo scenarios + TrainingAnalytics
  content/     data-driven Forms I-VII and fighter archetypes (Pydantic-validated)
  haptics/     event-driven + continuous haptic cue generation, mixing, and pluggable device backends
    cues.py         ADSR envelopes + per-ContactType/EventType cue templates (attacker vs. defender feel)
    continuous.py    blade-hum / low-stamina heartbeat / critical-balance tremble, sampled off live state
    mixer.py         per-fighter mixer: sums discrete cues over the continuous layer, with audio-style ducking
    channels.py      HapticChannel (MAIN_HAND/OFF_HAND/CHEST/BACK/WHOLE_BODY) + MotorBand (LOW/HIGH)
    controller.py    HapticsController: binds EventBus + per-fighter mixers + devices, ticked alongside the sim
    devices/         HapticDevice ABC + NullHapticDevice/LoggingHapticDevice + SDL2 + Windows XInput backends
  tests/       pytest suite covering math, collision, distance/guard, parry/balance/stamina, AI decision, replay determinism, full-duel smoke tests, haptic cues/mixer/controller

examples/
  run_duel.py               one AI-vs-AI duel: readable event log + summary + replay JSON
  self_play_balance.py      N duels per archetype matchup: win rate / duel length / parry rate / attack accuracy
  run_duel_with_haptics.py  one duel with per-fighter haptic feedback logged live (no hardware required)
```

**Dependency direction is strictly downward** (`core` → `combat` → `character`
→ `ai` → everything else) specifically so nothing has to special-case a
circular import, and so a future rendering/audio/netcode integration can sit
entirely *outside* `core`/`combat` and just consume `DuelState` and the
`CombatEvent` stream.

### The authoritative tick (design doc §112)

Every simulation tick, `combat.duel.DuelSimulation.tick()` does, in order:

1. **Observe** — each AI samples a delayed, noisy view of its opponent (`ai/perception.py`).
2. **Predict** — estimate attack probability/direction/timing from the perceived blade trajectory + pattern memory (`ai/prediction.py`).
3. **Decide** — utility-score `{ATTACK, FEINT, PARRY, RETREAT, ADVANCE, CIRCLE_LEFT/RIGHT, WAIT, COUNTER}` by personality, stamina, balance, distance and any live "opening" fed back from the last contact (`ai/decision.py`).
4. **Footwork** — bounded-acceleration, bounded-yaw-rate movement toward the decided intent; distance zones and preferences drive spacing, never a teleport (`character/locomotion.py`, `combat/distance.py`).
5. **Blade transform** — the attack trajectory (or resting guard pose) is sampled into a local offset, converted to world space, and the blade's swept trace is updated (`combat/attacks.py`, `combat/blade.py`).
6. **Continuous collision** — swept-segment capsule tests, blade-to-blade and blade-to-body, so a fast swing at 120 Hz cannot tunnel through a target (`combat/collision.py`).
7. **Contact classification + physics response** — real deflection/recoil/stagger/opening math from guard alignment, blade speeds, and reaction timing (`combat/parry.py`).
8. **Procedural reaction** — the defender's (and lightly, the attacker's) physical response is computed, not animation-switched (`character/reaction.py`).
9. **Events + opponent-model update** — every meaningful thing that happened is published on the `EventBus`; each AI's `OpponentModel` updates its pattern memory from the *opponent's* published events, closing the adaptation loop (§108).
10. **Upkeep** — stamina/balance regen, duel-state bookkeeping, intensity tracking, and win/loss check.

### Determinism

`combat.duel.DuelSimulation` is fixed-timestep and every source of
randomness is drawn from a single seeded `random.Random` (the sim's own RNG,
and each AI's perception/decision RNG derived from it in fixed order). This
means: same `FighterSpec`s + same seed + same external inputs ⇒ byte-for-byte
identical outcome, ⁠verified by `replay/recorder.py::verify_determinism`, which
runs the same duel twice and diffs a per-tick state digest.

## Haptics

`haptics/` turns the same `CombatEvent` stream and live controller state
everything else reads into per-fighter, per-channel motor output — the
same "subscribe to the real event stream, don't hardcode a `hit = rumble`
mapping" approach the README already prescribes for audio.

**Two layers, mixed every tick (`haptics/mixer.py`):**

- **Continuous** (`haptics/continuous.py`) — sampled straight off live
  state, no event needed: blade hum scales with the *own* blade's real
  `tip_speed`/`angular_velocity` (design doc §52); a heartbeat-style
  double-pulse appears on the chest channel once stamina drops below
  ~32% and quickens as it bottoms out (§31, §53); a fast low-amplitude
  tremble appears once balance drops into the critical range, growing as
  a stagger/knockdown becomes imminent (§30).
- **Discrete** (`haptics/cues.py`) — one ADSR-enveloped cue per
  meaningful `CombatEvent`, generated *per viewer*: a `PERFECT_PARRY`
  feels sharp and satisfying in the defender's hand and only a light
  "your blade got knocked" tap in the attacker's; `DIRECT_CONTACT` feels
  like nothing to the attacker and a real shock (chest + hand) to the
  defender; `FAILED_PARRY` hits harder than a clean block; `BLADE_LOCK`
  and a mutual clash both fighters equally; a `FEINT` gives only the
  feinting fighter a faint proprioceptive "hitch" (never the opponent —
  that would defeat the point of the feint); `DUEL_ENDED` gives the
  winner a rising double-pulse and the loser a single heavy fall.

A strong discrete cue **ducks** the continuous layer (`ducks_continuous`
on the cue, resolved in the mixer) exactly the way a game ducks music
under an explosion, so a direct hit reads clearly instead of blurring
into the ambient blade buzz.

**Devices** (`haptics/devices/`) are a small `HapticDevice` interface —
`apply(output, dt)` — so the mixer/cue layer never knows what hardware is
attached:

| Backend | Status |
|---|---|
| `NullHapticDevice` | no-op sink; the default for any fighter with no hardware (e.g. AI-only duels) |
| `LoggingHapticDevice` | prints resolved dual-motor values on change — used by `examples/run_duel_with_haptics.py`, and the way to develop/tune cues with zero hardware |
| `SDL2RumbleDevice` | cross-platform gamepad rumble via PySDL2's `SDL_GameControllerRumble` (`pip install PySDL2` + the SDL2 shared library) |
| `XInputRumbleDevice` | Windows-only, stdlib `ctypes` against `XInputSetState` — no extra dependency |

Both real-hardware backends are **structurally correct against their
documented APIs but have not been exercised against physical controllers
in this environment** — validate against real hardware before shipping,
same honesty policy as the rest of this README. `HapticChannel` already
distinguishes `MAIN_HAND`/`OFF_HAND`/`CHEST`/`BACK`/`WHOLE_BODY` so a
future VR-dual-controller or haptic-vest backend is a new class in
`devices/`, not a redesign — `devices/base.py::to_two_handed_motors()` is
already there for a two-controller rig.

**Wiring it up** (see `examples/run_duel_with_haptics.py`): construct
`HapticsController(sim, devices={...})` once, then call
`haptics.tick(dt)` right after `sim.tick(dt)` every frame — same external-
drive pattern as `camera.duel_camera.DuelCamera`. It only *reads*
`DuelState`/`CombatEvent`, never mutates simulation state.

## Extending this into a full game

The layering here is deliberate: `DuelState`/`CombatEvent` are the seam a
real engine integration plugs into.

- **Rendering**: drive a skinned rig from `character.ik` targets and
  `animation.procedural` layered poses; subscribe to `CombatEvent` for VFX
  (sparks, blade trail intensity from `blade.tip_speed`/`angular_velocity`).
- **Audio**: subscribe to the same event stream; blade hum/whoosh pitch from
  `blade.tip_speed`, contact stingers keyed by `ContactType`.
- **Haptics**: already implemented end-to-end — see the Haptics section above.
- **Networking**: the simulation is already server-authoritative-shaped —
  `DuelSimulation.tick(dt)` plus `set_external_intent()` is the whole
  input surface; a rollback client just needs to re-simulate from a snapshot.
- **Content**: add new `content.archetypes.FighterArchetype`/`LightsaberForm`
  entries (Pydantic-validated) rather than touching engine code.
