"""
aurek_saber.ai.perception
============================
design doc §34, §25. What the AI actually "sees" of the opponent —
sampled with reaction latency and noise from difficulty (§83), so the AI
genuinely can misread the player (§35) rather than reading ground-truth
state.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Deque, Optional
from collections import deque

from ..character.controller import CombatantController
from ..core.math import Vec3
from .personality import DifficultyModifiers


@dataclass
class PerceivedSample:
    time: float
    blade_tip: Vec3
    blade_base: Vec3
    blade_velocity: Vec3
    body_position: Vec3
    body_forward: Vec3
    distance: float


@dataclass
class AIPerception:
    difficulty: DifficultyModifiers
    rng: random.Random
    history: Deque[PerceivedSample] = field(default_factory=lambda: deque(maxlen=90))  # ~0.75s at 120Hz

    def observe(self, sim_time: float, opponent: CombatantController, self_pos: Vec3) -> PerceivedSample:
        noise = self.difficulty.perception_noise
        jitter = lambda v: v + Vec3_noise(self.rng, noise * 0.05)

        distance = float(((opponent.position - self_pos) ** 2).sum() ** 0.5)
        sample = PerceivedSample(
            time=sim_time,
            blade_tip=jitter(opponent.blade.tip_position.copy()),
            blade_base=jitter(opponent.blade.base_position.copy()),
            blade_velocity=jitter(opponent.blade.velocity.copy()),
            body_position=jitter(opponent.position.copy()),
            body_forward=opponent.body_forward.copy(),
            distance=distance,
        )
        self.history.append(sample)
        return sample

    def delayed_sample(self, sim_time: float) -> Optional[PerceivedSample]:
        """Returns the most recent sample at least `reaction_time_s` old —
        this is what actually gates AI reaction speed (design doc §86),
        rather than an artificial per-tick decision cooldown."""
        target_time = sim_time - self.difficulty.reaction_time_s
        chosen = None
        for s in self.history:
            if s.time <= target_time:
                chosen = s
            else:
                break
        return chosen or (self.history[0] if self.history else None)


def Vec3_noise(rng: random.Random, scale: float) -> Vec3:
    import numpy as np

    if scale <= 0:
        return np.array([0.0, 0.0, 0.0])
    return np.array([rng.gauss(0, scale), rng.gauss(0, scale), rng.gauss(0, scale)])
