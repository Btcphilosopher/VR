"""
aurek_saber.ai.opponent_model
================================
design doc §33, §36, §108. Pattern memory the AI builds up over the course
of a duel (and can be seeded/persisted across duels for meta-progression).
This is what turns "attack every few seconds" into a real adaptive
opponent: the AI's guard bias and prediction confidence shift toward
whatever the tracked opponent actually does.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Deque, Optional

from ..core.enums import AttackType, GuardZone
from ..core.events import CombatEvent, EventType
from ..core.math import clamp


@dataclass
class OpponentModel:
    """Tracks one specific opponent's habits (design doc §36)."""

    attack_direction_counts: Counter = field(default_factory=Counter)
    feint_count: int = 0
    attack_count: int = 0
    retreats_after_parry: int = 0
    parries_suffered: int = 0
    aggression_when_low_stamina: int = 0
    low_stamina_samples: int = 0
    recent_openings_taken: Deque[bool] = field(default_factory=lambda: deque(maxlen=20))

    adaptability: float = 0.5  # how fast counts are allowed to bias guard (personality trait)

    def observe_event(self, event: CombatEvent, opponent_id: str, opponent_stamina_ratio: float) -> None:
        if event.source != opponent_id:
            return
        if event.type == EventType.ATTACK_STARTED:
            self.attack_count += 1
            zone = event.data.get("target_zone")
            if isinstance(zone, GuardZone):
                self.attack_direction_counts[zone] += 1
            if opponent_stamina_ratio < 0.35:
                self.low_stamina_samples += 1
                self.aggression_when_low_stamina += 1
        elif event.type == EventType.FEINT:
            self.feint_count += 1
        elif event.type in (EventType.PARRY, EventType.PERFECT_PARRY):
            self.parries_suffered += 1
        elif event.type == EventType.RETREAT and self.parries_suffered > 0:
            self.retreats_after_parry += 1

    def favourite_zone(self) -> Optional[GuardZone]:
        if not self.attack_direction_counts:
            return None
        return self.attack_direction_counts.most_common(1)[0][0]

    def zone_bias(self, zone: GuardZone) -> float:
        """0..1 confidence the opponent's next attack targets `zone`,
        weighted by how much of the sample history is trustworthy
        (adaptability) — early in a duel this stays near-uniform, matching
        design doc §35's "maintain uncertainty"."""
        total = sum(self.attack_direction_counts.values())
        if total < 3:
            return 1.0 / len(GuardZone)
        raw = self.attack_direction_counts.get(zone, 0) / total
        uniform = 1.0 / len(GuardZone)
        return clamp(uniform + (raw - uniform) * self.adaptability, 0.0, 1.0)

    def feint_rate(self) -> float:
        total = self.attack_count + self.feint_count
        return self.feint_count / total if total > 0 else 0.15

    def retreats_after_parry_rate(self) -> float:
        return self.retreats_after_parry / self.parries_suffered if self.parries_suffered > 0 else 0.3

    def becomes_aggressive_when_low_stamina(self) -> bool:
        if self.low_stamina_samples < 3:
            return False
        return (self.aggression_when_low_stamina / self.low_stamina_samples) > 0.5
