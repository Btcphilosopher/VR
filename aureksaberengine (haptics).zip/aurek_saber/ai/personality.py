"""
aurek_saber.ai.personality
=============================
design doc §37-38, §83-86. Personality traits parameterise the whole AI
decision pipeline (perception noise, prediction confidence, action utility
weights). Archetypes are just named presets; difficulty is a *second*,
orthogonal modifier layered on top (never a health multiplier — §83).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


@dataclass(frozen=True)
class DuelistPersonality:
    aggression: float = 0.5    # weight toward ATTACK/ADVANCE over WAIT/RETREAT
    patience: float = 0.5      # willingness to hold WAIT/MEASURE instead of acting
    risk: float = 0.5          # tolerance for committing to heavy/low-percentage attacks
    precision: float = 0.5     # timing accuracy on parries/attacks
    reaction: float = 0.5      # base reaction speed (0=slow, 1=fast)
    discipline: float = 0.5    # resistance to baiting/feints
    adaptability: float = 0.5  # how fast the opponent model updates behaviour
    confidence: float = 0.5    # willingness to counter-attack rather than reset


class Archetype(Enum):
    AGGRESSOR = auto()
    DUELIST = auto()
    DEFENDER = auto()
    COUNTER_FIGHTER = auto()
    BERSERKER = auto()
    TACTICIAN = auto()
    ASSASSIN = auto()
    MASTER = auto()


ARCHETYPE_PRESETS = {
    Archetype.AGGRESSOR: DuelistPersonality(aggression=0.85, patience=0.25, risk=0.7, precision=0.5, reaction=0.55, discipline=0.4, adaptability=0.4, confidence=0.7),
    Archetype.DUELIST: DuelistPersonality(aggression=0.5, patience=0.55, risk=0.45, precision=0.65, reaction=0.6, discipline=0.6, adaptability=0.55, confidence=0.55),
    Archetype.DEFENDER: DuelistPersonality(aggression=0.25, patience=0.8, risk=0.2, precision=0.7, reaction=0.55, discipline=0.75, adaptability=0.5, confidence=0.4),
    Archetype.COUNTER_FIGHTER: DuelistPersonality(aggression=0.35, patience=0.7, risk=0.35, precision=0.75, reaction=0.65, discipline=0.7, adaptability=0.6, confidence=0.65),
    Archetype.BERSERKER: DuelistPersonality(aggression=0.95, patience=0.1, risk=0.9, precision=0.35, reaction=0.5, discipline=0.2, adaptability=0.3, confidence=0.85),
    Archetype.TACTICIAN: DuelistPersonality(aggression=0.4, patience=0.75, risk=0.3, precision=0.7, reaction=0.55, discipline=0.7, adaptability=0.8, confidence=0.55),
    Archetype.ASSASSIN: DuelistPersonality(aggression=0.6, patience=0.6, risk=0.55, precision=0.8, reaction=0.75, discipline=0.6, adaptability=0.65, confidence=0.6),
    Archetype.MASTER: DuelistPersonality(aggression=0.5, patience=0.65, risk=0.4, precision=0.9, reaction=0.8, discipline=0.85, adaptability=0.85, confidence=0.7),
}


class Difficulty(Enum):
    EASY = auto()
    NORMAL = auto()
    HARD = auto()
    MASTER = auto()


@dataclass(frozen=True)
class DifficultyModifiers:
    """design doc §84-86 — never a health/damage multiplier. All values
    stay within humanly-plausible bounds even at MASTER (§86)."""

    reaction_time_s: float  # added latency before the AI reacts to a new observation
    perception_noise: float  # 0..1, uncertainty injected into AI reads of opponent state
    mistake_rate: float  # 0..1, chance the AI's chosen action is downgraded/misjudged
    prediction_confidence: float  # 0..1, how much predicted intent influences decisions


DIFFICULTY_TABLE = {
    Difficulty.EASY: DifficultyModifiers(reaction_time_s=0.42, perception_noise=0.35, mistake_rate=0.3, prediction_confidence=0.2),
    Difficulty.NORMAL: DifficultyModifiers(reaction_time_s=0.28, perception_noise=0.2, mistake_rate=0.15, prediction_confidence=0.4),
    Difficulty.HARD: DifficultyModifiers(reaction_time_s=0.18, perception_noise=0.1, mistake_rate=0.07, prediction_confidence=0.6),
    # Even MASTER keeps a nonzero human-plausible reaction floor (design
    # doc §86: "do not give AI impossible reaction times").
    Difficulty.MASTER: DifficultyModifiers(reaction_time_s=0.12, perception_noise=0.04, mistake_rate=0.02, prediction_confidence=0.8),
}
