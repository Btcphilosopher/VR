"""
aurek_saber.ai.decision
==========================
design doc §39-40, §109. The AI duel loop:

    OBSERVE -> PREDICT -> ASSESS -> CHOOSE_INTENT -> EXECUTE -> OBSERVE_RESULT -> UPDATE_MODEL

`decide()` performs OBSERVE..CHOOSE_INTENT and returns an `AIDecision`;
`combat.duel.DuelSimulation` performs EXECUTE against the controller and
then calls `observe_result()` to close the loop (UPDATE_MODEL happens
continuously via `OpponentModel.observe_event`, subscribed to the event
bus).
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, Optional

from ..character.controller import CombatantController
from ..core.enums import AttackType, CombatIntent, DistanceZone, GuardZone
from ..core.math import clamp
from .opponent_model import OpponentModel
from .perception import AIPerception, PerceivedSample
from .personality import DifficultyModifiers, DuelistPersonality
from .prediction import AttackPrediction, predict

_ATTACK_ZONES = [GuardZone.HIGH_LEFT, GuardZone.HIGH_RIGHT, GuardZone.LOW_LEFT, GuardZone.LOW_RIGHT, GuardZone.CENTER]
_ATTACK_TYPE_FOR_ZONE = {
    GuardZone.HIGH_LEFT: AttackType.DIAGONAL,
    GuardZone.HIGH_RIGHT: AttackType.DIAGONAL,
    GuardZone.LOW_LEFT: AttackType.RISING,
    GuardZone.LOW_RIGHT: AttackType.RISING,
    GuardZone.CENTER: AttackType.THRUST,
}


@dataclass
class AIDecision:
    intent: CombatIntent
    attack_type: Optional[AttackType] = None
    target_zone: Optional[GuardZone] = None
    is_feint: bool = False
    scores: Dict[CombatIntent, float] = field(default_factory=dict)


class AIDecisionLoop:
    def __init__(self, personality: DuelistPersonality, difficulty: DifficultyModifiers, seed: int = 0):
        self.personality = personality
        self.difficulty = difficulty
        self.rng = random.Random(seed)
        self.perception = AIPerception(difficulty=difficulty, rng=self.rng)
        self.model = OpponentModel(adaptability=personality.adaptability)
        self._prev_sample: Optional[PerceivedSample] = None
        self.last_prediction: Optional[AttackPrediction] = None
        self.pending_opening: float = 0.0  # opening_for_attacker/defender fed back after a contact

    # -------------------------------------------------------------- observe
    def observe(self, sim_time: float, opponent: CombatantController, self_pos) -> PerceivedSample:
        sample = self.perception.observe(sim_time, opponent, self_pos)
        return sample

    def notify_opening(self, magnitude: float) -> None:
        """Called by combat.duel right after a contact resolves, if this
        AI is the one who was handed an exploitable opening."""
        self.pending_opening = max(self.pending_opening, magnitude)

    # ------------------------------------------------------------- decide
    def decide(
        self,
        sim_time: float,
        self_ctrl: CombatantController,
        opponent_ctrl: CombatantController,
        distance: float,
        distance_zone: DistanceZone,
    ) -> AIDecision:
        delayed = self.perception.delayed_sample(sim_time)
        prediction = predict(delayed, self._prev_sample, self.model, self.difficulty) if delayed else AttackPrediction(0.1, None, 0.3, 0.1)
        self._prev_sample = delayed
        self.last_prediction = prediction

        scores = self._score_actions(self_ctrl, opponent_ctrl, distance, distance_zone, prediction)

        # Mistake rate: with some probability pick a worse action than the
        # true best one (design doc §83, "mistake rate") — never a random
        # illegal action, just a suboptimal legal one.
        ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
        if self.rng.random() < self.difficulty.mistake_rate and len(ranked) > 1:
            chosen_intent, _ = ranked[self.rng.randint(1, min(2, len(ranked) - 1))]
        else:
            chosen_intent, _ = ranked[0]

        decision = AIDecision(intent=chosen_intent, scores=scores)

        if chosen_intent in (CombatIntent.ATTACK, CombatIntent.FEINT, CombatIntent.COUNTER):
            zone = self._choose_attack_zone(opponent_ctrl)
            decision.target_zone = zone
            decision.attack_type = _ATTACK_TYPE_FOR_ZONE[zone]
            decision.is_feint = chosen_intent == CombatIntent.FEINT

        self.pending_opening *= 0.5  # decays if unused
        return decision

    def _score_actions(
        self,
        self_ctrl: CombatantController,
        opponent_ctrl: CombatantController,
        distance: float,
        distance_zone: DistanceZone,
        prediction: AttackPrediction,
    ) -> Dict[CombatIntent, float]:
        p = self.personality
        stamina_ratio = self_ctrl.stamina.ratio
        balance_ratio = self_ctrl.balance.stability_factor()
        in_range = self_ctrl.distance_ctrl.in_attack_range(distance)
        too_close = distance < self_ctrl.distance_ctrl.prefs.minimum * 1.4

        scores: Dict[CombatIntent, float] = {}

        # WAIT / measuring — patience & discipline reward standing still
        # and reading the opponent (design doc §94, §109).
        scores[CombatIntent.WAIT] = 0.15 + p.patience * 0.5 + (0.3 if prediction.confidence < 0.3 else 0.0)

        # ATTACK
        opening = self.pending_opening
        attack_score = p.aggression * 0.6 + opening * 0.9 - (1 - p.risk) * 0.25
        if not in_range:
            attack_score -= 0.6
        if stamina_ratio < 0.3:
            attack_score -= 0.4 * (1 - p.risk)
        if self.model.attack_count > 0 and self.model.retreats_after_parry_rate() > 0.6:
            attack_score += 0.1  # opponent folds after being parried -> pressure them
        scores[CombatIntent.ATTACK] = attack_score

        # FEINT — most valuable against a disciplined-looking defender
        # (one who reliably guards the predicted zone) with enough
        # stamina margin to afford the cheaper feint cost.
        feint_score = p.risk * 0.4 + p.aggression * 0.2 + (0.25 if in_range else -0.4)
        feint_score += 0.15 if self.model.feint_rate() < 0.2 else -0.1  # I haven't feinted much -> element of surprise
        scores[CombatIntent.FEINT] = feint_score

        # COUNTER — only meaningfully scored high right after an opening.
        scores[CombatIntent.COUNTER] = p.confidence * 0.5 + opening * 1.1 + (0.2 if in_range else -0.5)

        # PARRY — reactive weight rises sharply with predicted attack probability.
        scores[CombatIntent.PARRY] = prediction.attack_probability * (0.6 + p.precision * 0.6) * prediction.confidence

        # RETREAT
        retreat_score = (1 - p.aggression) * 0.3 + (0.5 if stamina_ratio < 0.25 else 0.0) + (0.4 if balance_ratio < 0.4 else 0.0)
        if too_close and not in_range:
            retreat_score += 0.2
        scores[CombatIntent.RETREAT] = retreat_score

        # ADVANCE
        scores[CombatIntent.ADVANCE] = (p.aggression * 0.4) + (0.4 if not in_range and distance_zone in (DistanceZone.MEASURE, DistanceZone.LONG_RANGE) else 0.0)

        # CIRCLE — tacticians/patient fighters reposition rather than
        # standing on the centreline.
        circle_score = p.patience * 0.3 + (0.15 if in_range else 0.0)
        scores[CombatIntent.CIRCLE_LEFT] = circle_score + (0.05 if self.rng.random() < 0.5 else 0.0)
        scores[CombatIntent.CIRCLE_RIGHT] = circle_score + (0.05 if self.rng.random() < 0.5 else 0.0)

        return scores

    def _choose_attack_zone(self, opponent_ctrl: CombatantController) -> GuardZone:
        """Pick where to attack: bias toward the opponent's weakest
        covered zone (their current guard's opposite), tempered by the
        fighter's own risk trait for how exploitative to be."""
        opp_guard = opponent_ctrl.guard
        opposite = {
            GuardZone.HIGH_LEFT: GuardZone.LOW_RIGHT,
            GuardZone.HIGH_RIGHT: GuardZone.LOW_LEFT,
            GuardZone.LOW_LEFT: GuardZone.HIGH_RIGHT,
            GuardZone.LOW_RIGHT: GuardZone.HIGH_LEFT,
            GuardZone.CENTER: GuardZone.HIGH_LEFT,
            GuardZone.OPEN: GuardZone.CENTER,
        }
        target = opposite.get(opp_guard, GuardZone.CENTER)
        if self.rng.random() > self.personality.precision:
            target = self.rng.choice(_ATTACK_ZONES)
        return target
