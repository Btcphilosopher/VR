"""
aurek_saber.ai.prediction
============================
design doc §35. Estimates attack probability/direction/timing from the
*perceived* (delayed, noisy) blade trajectory derivative plus the
opponent model's pattern bias — and always keeps genuine uncertainty
rather than reading the opponent's true intent flag.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from ..core.enums import GuardZone
from ..core.math import clamp, length
from .opponent_model import OpponentModel
from .perception import PerceivedSample
from .personality import DifficultyModifiers


@dataclass
class AttackPrediction:
    attack_probability: float  # 0..1, likelihood opponent attacks soon
    predicted_zone: Optional[GuardZone]
    predicted_timing_s: float  # estimated seconds until contact
    confidence: float  # 0..1


def predict(
    current: PerceivedSample,
    previous: Optional[PerceivedSample],
    model: OpponentModel,
    difficulty: DifficultyModifiers,
) -> AttackPrediction:
    if previous is None or current.time <= previous.time:
        return AttackPrediction(0.1, model.favourite_zone(), 0.6, difficulty.prediction_confidence * 0.3)

    dt = current.time - previous.time
    blade_accel_signal = length(current.blade_velocity - previous.blade_velocity) / max(dt, 1e-3)
    blade_speed = length(current.blade_velocity)

    # A rising blade speed reads as "winding up" — a crude but genuine
    # signal derived from perceived motion, not from a hidden state flag.
    raw_probability = clamp(blade_speed / 4.0 + blade_accel_signal / 20.0, 0.0, 1.0)

    # Fold in pattern memory: an opponent who attacks often from this
    # distance band nudges probability up.
    pattern_component = clamp(model.attack_count / 12.0, 0.0, 0.4)
    probability = clamp(raw_probability * 0.7 + pattern_component, 0.0, 1.0)

    zone = model.favourite_zone()

    est_timing = clamp(0.35 - blade_speed * 0.05, 0.08, 0.35)

    confidence = clamp(difficulty.prediction_confidence * (0.5 + 0.5 * min(1.0, model.attack_count / 6.0)), 0.0, 1.0)

    return AttackPrediction(probability, zone, est_timing, confidence)
