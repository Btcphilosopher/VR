"""
aurek_saber.content.archetypes
=================================
design doc §106-107. A separate, data-driven "Star Wars content layer".
Nothing here hardcodes a copyrighted character identity — archetypes and
Forms are generic gameplay-style presets (tagged with generic labels like
"JEDI"/"SITH" as flavour strings only) that a content team plugs concrete
characters/hilts/animations into. Pydantic validates the config shape so
bad content data fails fast with a readable error rather than corrupting a
duel mid-simulation.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field

from ..ai.personality import Archetype, DuelistPersonality
from ..combat.distance import DistancePreferences
from ..core.enums import Stance


class LightsaberForm(BaseModel):
    """design doc §107 — treated as configurable gameplay archetypes, not
    cosmetic labels: each Form genuinely shifts stance, distance
    preference, and risk tolerance."""

    name: str
    description: str
    default_stance: Stance
    distance_preferred: float = Field(gt=0)
    distance_minimum: float = Field(gt=0)
    risk_bias: float = Field(ge=0.0, le=1.0)
    defensive_bias: float = Field(ge=0.0, le=1.0)
    mobility_bias: float = Field(ge=0.0, le=1.0)

    def to_distance_prefs(self) -> DistancePreferences:
        return DistancePreferences(
            preferred=self.distance_preferred,
            minimum=self.distance_minimum,
            attack=self.distance_preferred + 0.35,
            retreat=self.distance_minimum + 0.5,
        )


FORM_I = LightsaberForm(
    name="FORM_I", description="Foundational, broad basic strikes; favours simple committed attacks and a wide stance.",
    default_stance=Stance.TWO_HANDED, distance_preferred=1.9, distance_minimum=0.7, risk_bias=0.4, defensive_bias=0.4, mobility_bias=0.4,
)
FORM_II = LightsaberForm(
    name="FORM_II", description="Precise, duelist-focused fencing; rewards clean timing and controlled distance.",
    default_stance=Stance.DUELIST, distance_preferred=1.7, distance_minimum=0.6, risk_bias=0.45, defensive_bias=0.55, mobility_bias=0.45,
)
FORM_III = LightsaberForm(
    name="FORM_III", description="Maximally defensive; minimal exposure, patient counter-fighting.",
    default_stance=Stance.DEFENSIVE, distance_preferred=1.4, distance_minimum=0.5, risk_bias=0.2, defensive_bias=0.85, mobility_bias=0.35,
)
FORM_IV = LightsaberForm(
    name="FORM_IV", description="Highly mobile, acrobatic pressure; closes distance fast, trades safety for tempo.",
    default_stance=Stance.MOBILE, distance_preferred=1.5, distance_minimum=0.5, risk_bias=0.7, defensive_bias=0.35, mobility_bias=0.9,
)
FORM_V = LightsaberForm(
    name="FORM_V", description="Aggressive counter-offence; parries hard and immediately answers with power.",
    default_stance=Stance.POWER, distance_preferred=1.6, distance_minimum=0.55, risk_bias=0.6, defensive_bias=0.6, mobility_bias=0.4,
)
FORM_VI = LightsaberForm(
    name="FORM_VI", description="Balanced generalist form with no strong bias in any direction.",
    default_stance=Stance.NEUTRAL, distance_preferred=1.7, distance_minimum=0.6, risk_bias=0.5, defensive_bias=0.5, mobility_bias=0.5,
)
FORM_VII = LightsaberForm(
    name="FORM_VII", description="Ferocious, high-risk aggression; embraces openings in exchange for overwhelming tempo.",
    default_stance=Stance.AGGRESSIVE, distance_preferred=1.3, distance_minimum=0.45, risk_bias=0.85, defensive_bias=0.25, mobility_bias=0.6,
)

ALL_FORMS = {f.name: f for f in (FORM_I, FORM_II, FORM_III, FORM_IV, FORM_V, FORM_VI, FORM_VII)}


class FighterArchetype(BaseModel):
    """design doc §106 — a data-driven fighter template combining an AI
    Archetype (behavioural preset) with a Form (physical/gameplay
    preset) and a generic faction flavour tag."""

    id: str
    display_name: str
    faction_tag: str  # e.g. "JEDI", "SITH", "IMPERIAL", "REBEL", "MANDALORIAN", "INQUISITOR" — flavour only
    ai_archetype: str  # matches ai.personality.Archetype member name
    form: str  # matches ALL_FORMS key

    def resolve(self):
        archetype = Archetype[self.ai_archetype]
        form = ALL_FORMS[self.form]
        return archetype, form


PRESET_FIGHTERS = [
    FighterArchetype(id="duelist_1", display_name="Wandering Duelist", faction_tag="JEDI", ai_archetype="DUELIST", form="FORM_II"),
    FighterArchetype(id="inquisitor_1", display_name="Blade Inquisitor", faction_tag="INQUISITOR", ai_archetype="AGGRESSOR", form="FORM_VII"),
    FighterArchetype(id="guardian_1", display_name="Temple Guardian", faction_tag="JEDI", ai_archetype="DEFENDER", form="FORM_III"),
    FighterArchetype(id="mercenary_1", display_name="Mandalorian Duelist", faction_tag="MANDALORIAN", ai_archetype="COUNTER_FIGHTER", form="FORM_V"),
    FighterArchetype(id="master_1", display_name="Council Master", faction_tag="JEDI", ai_archetype="MASTER", form="FORM_VI"),
]
