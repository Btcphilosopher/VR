from aurek_saber.ai.decision import AIDecisionLoop
from aurek_saber.ai.personality import ARCHETYPE_PRESETS, DIFFICULTY_TABLE, Archetype, Difficulty
from aurek_saber.character.controller import CombatantController
from aurek_saber.core.enums import CombatIntent, DistanceZone
from aurek_saber.core.math import vec3


def _fresh_controller(cid: str, pos) -> CombatantController:
    return CombatantController(combatant_id=cid, position=pos, body_forward=vec3(0, 0, 1))


def test_ai_decision_returns_a_valid_intent():
    loop = AIDecisionLoop(ARCHETYPE_PRESETS[Archetype.DUELIST], DIFFICULTY_TABLE[Difficulty.NORMAL], seed=1)
    self_ctrl = _fresh_controller("a", vec3(0, 0, -1))
    opp_ctrl = _fresh_controller("b", vec3(0, 0, 1))
    loop.observe(0.0, opp_ctrl, self_ctrl.position)
    decision = loop.decide(0.0, self_ctrl, opp_ctrl, distance=2.0, distance_zone=DistanceZone.ENGAGEMENT)
    assert isinstance(decision.intent, CombatIntent)
    assert decision.intent in list(CombatIntent)


def test_pending_opening_increases_attack_and_counter_scores():
    loop = AIDecisionLoop(ARCHETYPE_PRESETS[Archetype.DUELIST], DIFFICULTY_TABLE[Difficulty.NORMAL], seed=2)
    self_ctrl = _fresh_controller("a", vec3(0, 0, -0.5))
    opp_ctrl = _fresh_controller("b", vec3(0, 0, 0.5))
    loop.observe(0.0, opp_ctrl, self_ctrl.position)

    baseline = loop._score_actions(self_ctrl, opp_ctrl, distance=1.0, distance_zone=DistanceZone.ENGAGEMENT, prediction=loop.last_prediction or _dummy_prediction())
    loop.notify_opening(0.9)
    boosted = loop._score_actions(self_ctrl, opp_ctrl, distance=1.0, distance_zone=DistanceZone.ENGAGEMENT, prediction=loop.last_prediction or _dummy_prediction())

    assert boosted[CombatIntent.ATTACK] > baseline[CombatIntent.ATTACK]
    assert boosted[CombatIntent.COUNTER] > baseline[CombatIntent.COUNTER]


def _dummy_prediction():
    from aurek_saber.ai.prediction import AttackPrediction

    return AttackPrediction(0.1, None, 0.3, 0.1)


def test_difficulty_changes_reaction_time_not_health():
    easy = DIFFICULTY_TABLE[Difficulty.EASY]
    master = DIFFICULTY_TABLE[Difficulty.MASTER]
    assert easy.reaction_time_s > master.reaction_time_s
    assert easy.mistake_rate > master.mistake_rate
    # Even MASTER keeps a nonzero, humanly-plausible reaction floor.
    assert master.reaction_time_s > 0.05


def test_master_mode_never_reacts_instantly():
    loop = AIDecisionLoop(ARCHETYPE_PRESETS[Archetype.MASTER], DIFFICULTY_TABLE[Difficulty.MASTER], seed=3)
    assert loop.difficulty.reaction_time_s > 0.0
