from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.combat.duel import DuelSimulation, FighterSpec
from aurek_saber.core.enums import DuelOutcome
from aurek_saber.core.events import EventType
from aurek_saber.core.math import vec3

MAX_TICKS = 120 * 30


def _run(seed: int, a_arch=Archetype.AGGRESSOR, b_arch=Archetype.DEFENDER):
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=a_arch, difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=b_arch, difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id="smoke", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=seed)
    for _ in range(MAX_TICKS):
        sim.tick(1 / 120)
        if sim.is_over():
            break
    return sim


def test_full_duel_runs_without_error_and_produces_events():
    sim = _run(seed=7)
    assert sim.tick_index > 0
    assert any(e.type == EventType.DUEL_STARTED for e in sim.events.log)
    assert any(e.type == EventType.ATTACK_STARTED for e in sim.events.log)


def test_duel_can_reach_a_decisive_outcome():
    """Not guaranteed every seed ends decisively within the cap, but an
    aggressive-vs-defensive matchup across several seeds should produce at
    least one clean finish — proof the whole contact->consequence chain
    actually functions end to end."""
    outcomes = [_run(seed=s).outcome for s in range(10)]
    assert any(o == DuelOutcome.DEFEATED for o in outcomes)


def test_stamina_and_balance_stay_in_bounds_throughout():
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype.BERSERKER, difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype.DEFENDER, difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id="bounds", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=5)
    for _ in range(2000):
        sim.tick(1 / 120)
        for ctrl in sim.controllers.values():
            assert 0.0 <= ctrl.stamina.current <= ctrl.stamina.maximum + 1e-6
            assert 0.0 <= ctrl.balance.value <= 100.0 + 1e-6
        if sim.is_over():
            break


def test_no_teleporting_position_deltas_are_bounded():
    """design doc §88: characters should never snap/teleport. Position
    delta per tick must stay within a physically plausible bound given
    max acceleration/speed caps."""
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype.AGGRESSOR, difficulty=Difficulty.HARD)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype.ASSASSIN, difficulty=Difficulty.HARD)
    sim = DuelSimulation(duel_id="noteleport", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=9)
    prev_positions = {cid: c.position.copy() for cid, c in sim.controllers.items()}
    for _ in range(600):
        sim.tick(1 / 120)
        for cid, ctrl in sim.controllers.items():
            delta = float(((ctrl.position - prev_positions[cid]) ** 2).sum() ** 0.5)
            assert delta < 0.15  # generous per-tick bound at 120Hz
            prev_positions[cid] = ctrl.position.copy()
        if sim.is_over():
            break
