from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.character.controller import CombatantController
from aurek_saber.combat.duel import DuelSimulation, FighterSpec
from aurek_saber.core.math import vec3
from aurek_saber.haptics.channels import HapticChannel, MotorBand
from aurek_saber.haptics.cues import ADSR, HapticCueInstance
from aurek_saber.haptics.devices.base import channel_scalar, to_dual_motor, to_two_handed_motors
from aurek_saber.haptics.devices.null_device import LoggingHapticDevice, NullHapticDevice
from aurek_saber.haptics.controller import HapticsController
from aurek_saber.haptics.mixer import HapticMixer


def _fresh_controller() -> CombatantController:
    return CombatantController(combatant_id="x", position=vec3(0, 0, 0), body_forward=vec3(0, 0, 1))


def test_mixer_output_stays_bounded_with_overlapping_cues():
    mixer = HapticMixer()
    ctrl = _fresh_controller()
    for _ in range(5):
        mixer.trigger(HapticCueInstance(
            name="spam", channels=(HapticChannel.MAIN_HAND,), band_weights={MotorBand.LOW: 1.0, MotorBand.HIGH: 1.0},
            envelope=ADSR(attack=0.001, decay=0.001, sustain_level=1.0, release=0.05),
            triggered_at=0.0, one_shot_duration=0.2,
        ))
    output = mixer.tick(ctrl, sim_time=0.01, dt=1 / 120)
    for bands in output.values():
        for value in bands.values():
            assert 0.0 <= value <= 1.0


def test_finished_cues_are_pruned():
    mixer = HapticMixer()
    ctrl = _fresh_controller()
    mixer.trigger(HapticCueInstance(
        name="short", channels=(HapticChannel.MAIN_HAND,), band_weights={MotorBand.LOW: 1.0},
        envelope=ADSR(attack=0.001, decay=0.001, sustain_level=0.5, release=0.01),
        triggered_at=0.0, one_shot_duration=0.02,
    ))
    mixer.tick(ctrl, sim_time=0.0, dt=1 / 120)
    assert len(mixer.active) == 1
    mixer.tick(ctrl, sim_time=1.0, dt=1 / 120)  # well past release
    assert len(mixer.active) == 0


def test_ducking_reduces_continuous_layer():
    mixer = HapticMixer()
    ctrl = _fresh_controller()
    ctrl.blade.velocity = vec3(0, 0, 9.0)  # fast blade -> strong continuous hum
    ctrl.blade.angular_velocity = 10.0

    baseline = mixer.tick(ctrl, sim_time=0.0, dt=1 / 30)
    baseline_high = baseline.get(HapticChannel.MAIN_HAND, {}).get(MotorBand.HIGH, 0.0)

    mixer.trigger(HapticCueInstance(
        name="impact", channels=(HapticChannel.MAIN_HAND,), band_weights={MotorBand.LOW: 1.0},
        envelope=ADSR(attack=0.001, decay=0.001, sustain_level=1.0, release=0.05),
        triggered_at=0.0, one_shot_duration=0.1, ducks_continuous=True,
    ))
    ducked = mixer.tick(ctrl, sim_time=0.01, dt=1 / 30)
    ducked_high = ducked.get(HapticChannel.MAIN_HAND, {}).get(MotorBand.HIGH, 0.0)

    assert ducked_high <= baseline_high


def test_device_conversion_helpers_stay_bounded():
    output = {HapticChannel.MAIN_HAND: {MotorBand.LOW: 0.9, MotorBand.HIGH: 0.4}, HapticChannel.CHEST: {MotorBand.LOW: 1.0}}
    low, high = to_dual_motor(output)
    assert 0.0 <= low <= 1.0 and 0.0 <= high <= 1.0
    assert low == 1.0  # loudest LOW across channels wins (chest hit)
    scalar = channel_scalar(output, HapticChannel.MAIN_HAND)
    assert 0.0 <= scalar <= 1.0
    ml, mh, ol, oh = to_two_handed_motors(output)
    assert (ml, mh) == (0.9, 0.4)
    assert (ol, oh) == (0.0, 0.0)


def test_null_and_logging_devices_never_raise():
    output = {HapticChannel.MAIN_HAND: {MotorBand.LOW: 0.5, MotorBand.HIGH: 0.5}}
    NullHapticDevice().apply(output, 1 / 120)
    dev = LoggingHapticDevice("test")
    dev.apply(output, 1 / 120)
    dev.shutdown()


def test_haptics_controller_runs_through_a_short_duel_without_error():
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype.AGGRESSOR, difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype.DEFENDER, difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id="haptics_test", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=11)
    haptics = HapticsController(sim, devices={"a": NullHapticDevice(), "b": NullHapticDevice()})

    for _ in range(600):
        sim.tick(1 / 120)
        outputs = haptics.tick(1 / 120)
        for fighter_output in outputs.values():
            for bands in fighter_output.values():
                for value in bands.values():
                    assert 0.0 <= value <= 1.0
        if sim.is_over():
            break

    haptics.shutdown()


def test_haptics_controller_reacts_to_a_hit_event():
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype.AGGRESSOR, difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype.DEFENDER, difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id="haptics_reactivity", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=3)
    haptics = HapticsController(sim, devices={})

    peak_seen = 0.0
    for _ in range(2000):
        sim.tick(1 / 120)
        outputs = haptics.tick(1 / 120)
        for fighter_output in outputs.values():
            for bands in fighter_output.values():
                peak_seen = max(peak_seen, bands.get(MotorBand.LOW, 0.0))
        if sim.is_over():
            break

    # A duel with real contact should, at some point, produce a strong
    # impact pulse well above the idle blade-hum baseline.
    assert peak_seen > 0.5
