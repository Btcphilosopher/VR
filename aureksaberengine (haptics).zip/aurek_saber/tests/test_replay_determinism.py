from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.combat.duel import FighterSpec
from aurek_saber.core.math import vec3
from aurek_saber.replay.recorder import verify_determinism


def _specs():
    a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype.AGGRESSOR, difficulty=Difficulty.NORMAL)
    b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype.DEFENDER, difficulty=Difficulty.NORMAL)
    return a, b


def test_same_seed_reproduces_identical_duel():
    a, b = _specs()
    assert verify_determinism(a, b, seed=123, n_ticks=400)


def test_different_seed_can_diverge():
    """Not a strict requirement of determinism itself, but a sanity check
    that the seed actually matters (otherwise the AI would be silently
    ignoring rng and this test suite's determinism guarantee would be
    trivially true for the wrong reason)."""
    a1, b1 = _specs()
    a2, b2 = _specs()
    from aurek_saber.combat.duel import DuelSimulation

    sim1 = DuelSimulation(duel_id="d1", fighter_a_spec=a1, fighter_b_spec=b1, seed=1)
    sim2 = DuelSimulation(duel_id="d2", fighter_a_spec=a2, fighter_b_spec=b2, seed=999)
    for _ in range(400):
        sim1.tick(1 / 120)
        sim2.tick(1 / 120)

    pos1 = sim1.controllers["a"].position.copy()
    pos2 = sim2.controllers["a"].position.copy()
    assert not (pos1 == pos2).all() or sim1.events.log != sim2.events.log
