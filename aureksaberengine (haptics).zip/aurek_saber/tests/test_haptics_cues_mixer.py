from aurek_saber.haptics.channels import HapticChannel, MotorBand
from aurek_saber.haptics.cues import ADSR, CONTACT_CUE_BUILDERS, HapticCueInstance, duel_end_cue, stagger_cue


def test_adsr_ramps_up_then_settles_to_sustain():
    env = ADSR(attack=0.1, decay=0.1, sustain_level=0.5, release=0.2)
    assert env.value(0.0, None) == 0.0
    assert 0.0 < env.value(0.05, None) < 1.0
    assert abs(env.value(0.1, None) - 1.0) < 1e-6
    assert abs(env.value(0.2, None) - 0.5) < 1e-6  # fully decayed to sustain
    assert abs(env.value(1.0, None) - 0.5) < 1e-6  # holds at sustain indefinitely


def test_adsr_release_fades_to_zero():
    env = ADSR(attack=0.05, decay=0.05, sustain_level=0.6, release=0.1)
    v0 = env.value(1.0, 0.0)
    v_mid = env.value(1.0, 0.05)
    v_end = env.value(1.0, 0.1)
    assert v0 > v_mid > v_end
    assert v_end == 0.0


def test_cue_instance_auto_releases_after_one_shot_duration():
    cue = HapticCueInstance(
        name="test", channels=(HapticChannel.MAIN_HAND,), band_weights={MotorBand.LOW: 1.0},
        envelope=ADSR(attack=0.01, decay=0.01, sustain_level=0.5, release=0.05),
        triggered_at=0.0, one_shot_duration=0.1,
    )
    cue.update_auto_release(0.05)
    assert cue.released_at is None
    cue.update_auto_release(0.1)
    assert cue.released_at == 0.1
    assert not cue.is_finished(0.1)
    assert cue.is_finished(0.16)


def test_all_contact_types_produce_bounded_cues():
    for name, builder in CONTACT_CUE_BUILDERS.items():
        attacker, defender = builder(0.0, energy=0.5)
        for cue in (attacker, defender):
            if cue is None:
                continue
            assert 0.0 <= cue.peak_intensity <= 1.0
            for weight in cue.band_weights.values():
                assert 0.0 <= weight <= 1.0


def test_direct_hit_defender_feels_more_than_attacker():
    attacker, defender = CONTACT_CUE_BUILDERS["DIRECT_CONTACT"](0.0, energy=0.5)
    assert defender.peak_intensity > attacker.peak_intensity


def test_perfect_parry_ducks_continuous_layer():
    attacker, defender = CONTACT_CUE_BUILDERS["PERFECT_PARRY"](0.0, energy=0.5)
    assert defender.ducks_continuous
    assert attacker.ducks_continuous


def test_stagger_cue_scales_with_magnitude():
    small = stagger_cue(0.0, magnitude=5.0)
    large = stagger_cue(0.0, magnitude=40.0)
    assert large.peak_intensity > small.peak_intensity


def test_duel_end_cue_differs_for_winner_and_loser():
    win = duel_end_cue(0.0, won=True)
    lose = duel_end_cue(0.0, won=False)
    assert win.name != lose.name
    assert HapticChannel.CHEST in lose.channels  # defeat lands harder, chest included
