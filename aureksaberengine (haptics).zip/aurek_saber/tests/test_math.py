import math

from aurek_saber.core.math import (
    FORWARD,
    RIGHT,
    UP,
    clamp,
    length,
    lerp,
    move_toward,
    normalize,
    rotate_yaw,
    signed_angle,
    vec3,
    vmove_toward,
)


def test_normalize_zero_vector_uses_fallback():
    v = normalize(vec3(0, 0, 0), fallback=FORWARD)
    assert length(v) == 1.0
    assert (v == FORWARD).all()


def test_clamp_and_lerp():
    assert clamp(5, 0, 3) == 3
    assert clamp(-1, 0, 3) == 0
    assert lerp(0, 10, 0.5) == 5


def test_move_toward_caps_rate_and_does_not_overshoot():
    v = move_toward(0.0, 10.0, 2.0)
    assert v == 2.0
    v2 = move_toward(9.0, 10.0, 2.0)
    assert v2 == 10.0  # doesn't overshoot past the target


def test_vmove_toward_never_overshoots():
    a = vec3(0, 0, 0)
    b = vec3(10, 0, 0)
    step = vmove_toward(a, b, 3.0)
    assert length(step - a) <= 3.0 + 1e-9


def test_rotate_yaw_90_degrees():
    v = rotate_yaw(FORWARD, math.pi / 2)
    # forward (0,0,1) rotated 90 degrees should align closely with +/-x axis
    assert abs(abs(float(v[0])) - 1.0) < 1e-6


def test_signed_angle_sign_consistency():
    a = FORWARD
    b = rotate_yaw(FORWARD, 0.3)
    ang = signed_angle(a, b)
    assert abs(ang - 0.3) < 1e-6 or abs(ang + 0.3) < 1e-6
