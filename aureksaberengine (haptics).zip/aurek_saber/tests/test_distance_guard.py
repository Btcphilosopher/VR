import numpy as np

from aurek_saber.combat.distance import classify_distance, CombatDistanceController, DistancePreferences
from aurek_saber.combat.guard import classify_guard, coverage_against, guard_pose_offset
from aurek_saber.core.enums import DistanceZone, GuardZone


def test_distance_zone_classification_monotonic():
    assert classify_distance(0.3) == DistanceZone.CLINCH
    assert classify_distance(0.9) == DistanceZone.CLOSE
    assert classify_distance(2.0) == DistanceZone.ENGAGEMENT
    assert classify_distance(3.0) == DistanceZone.MEASURE
    assert classify_distance(5.0) == DistanceZone.LONG_RANGE
    assert classify_distance(50.0) == DistanceZone.OUT_OF_RANGE


def test_distance_controller_seeks_preferred_range():
    ctrl = CombatDistanceController(DistancePreferences(preferred=1.7, minimum=0.5, attack=2.0, retreat=1.2))
    # Too far -> should want to close in (positive speed).
    assert ctrl.desired_radial_speed(4.0) > 0
    # Too close -> should want to open up (negative speed).
    assert ctrl.desired_radial_speed(0.3) < 0
    # At preferred range -> deadband, no motion.
    assert ctrl.desired_radial_speed(1.7) == 0.0


def test_distance_controller_never_advances_past_minimum():
    ctrl = CombatDistanceController(DistancePreferences(preferred=1.7, minimum=0.6, attack=2.0, retreat=1.2))
    speed = ctrl.desired_radial_speed(0.65)
    # Closing this much would put us under the minimum; speed must be capped.
    assert 0.65 - speed >= ctrl.prefs.minimum - 1e-9


def test_guard_pose_roundtrips_to_classification():
    for zone in (GuardZone.HIGH_LEFT, GuardZone.HIGH_RIGHT, GuardZone.LOW_LEFT, GuardZone.LOW_RIGHT, GuardZone.CENTER):
        offset = guard_pose_offset(zone)
        # offset is in (right, up, forward) local space already
        classified = classify_guard(offset, blade_extended=True)
        assert classified == zone


def test_open_guard_when_blade_not_extended():
    assert classify_guard(np.array([0.0, 1.0, 0.0]), blade_extended=False) == GuardZone.OPEN


def test_coverage_matching_zone_is_strong():
    cov = coverage_against(GuardZone.HIGH_LEFT, GuardZone.HIGH_LEFT)
    assert cov.alignment == 1.0
    assert not cov.exposed


def test_coverage_open_guard_is_fully_exposed():
    cov = coverage_against(GuardZone.OPEN, GuardZone.HIGH_LEFT)
    assert cov.alignment == 0.0
    assert cov.exposed
