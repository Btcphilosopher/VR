"""
aurek_saber.character.stance
===============================
design doc §19. Stance modifiers table — pure data, consumed by the
controller and by combat systems that need a speed/recovery/stamina
multiplier for the combatant's current stance.
"""

from __future__ import annotations

from dataclasses import dataclass

from ..core.enums import Stance


@dataclass(frozen=True)
class StanceModifiers:
    move_speed: float = 1.0
    attack_speed: float = 1.0
    guard_strength: float = 1.0
    recovery_speed: float = 1.0
    stamina_cost: float = 1.0
    preferred_distance_mult: float = 1.0


STANCE_TABLE = {
    Stance.NEUTRAL: StanceModifiers(1.0, 1.0, 1.0, 1.0, 1.0, 1.0),
    Stance.AGGRESSIVE: StanceModifiers(1.08, 1.15, 0.85, 0.95, 1.2, 0.85),
    Stance.DEFENSIVE: StanceModifiers(0.9, 0.9, 1.25, 1.1, 0.9, 1.1),
    Stance.DUELIST: StanceModifiers(1.05, 1.05, 1.05, 1.05, 1.0, 1.0),
    Stance.POWER: StanceModifiers(0.82, 0.8, 1.15, 0.8, 1.35, 1.15),
    Stance.MOBILE: StanceModifiers(1.25, 0.95, 0.85, 1.15, 1.05, 0.9),
    Stance.TWO_HANDED: StanceModifiers(0.88, 0.9, 1.2, 0.95, 1.15, 1.05),
    Stance.ONE_HANDED: StanceModifiers(1.12, 1.1, 0.9, 1.05, 0.95, 0.9),
}


def get_modifiers(stance: Stance) -> StanceModifiers:
    return STANCE_TABLE.get(stance, STANCE_TABLE[Stance.NEUTRAL])
