"""
aurek_saber.character.ik
===========================
design doc §26-27. This engine has no skeletal renderer, so "IK" here is a
numeric utility layer: solvers that any future rig integration (a game
engine's animation runtime) can call with joint lengths + a world target
and get back real, physically-consistent joint angles — not a stub that
just returns the target.

We implement genuine 2-bone analytic IK (law of cosines) for arm/hand
placement onto the saber handle, plus a simple grounded-foot solver used
by the reaction/locomotion layers to keep feet from floating during
staggers or slopes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..core.math import UP, Vec3, clamp, length, normalize


@dataclass
class TwoBoneIKResult:
    elbow_position: Vec3
    reachable: bool
    stretch: float  # 0 = fully within reach, >0 = target was clamped inward


def solve_two_bone_ik(
    shoulder: Vec3,
    hand_target: Vec3,
    upper_length: float,
    lower_length: float,
    pole_hint: Vec3,
) -> TwoBoneIKResult:
    """Analytic 2-bone IK (shoulder -> elbow -> hand), the standard
    approach for arm placement (design doc §26). `pole_hint` biases which
    way the elbow bends (e.g. toward the character's side/back)."""
    to_target = hand_target - shoulder
    dist = length(to_target)
    max_reach = upper_length + lower_length
    min_reach = abs(upper_length - lower_length)

    stretch = 0.0
    if dist > max_reach:
        stretch = dist - max_reach
        dist = max_reach
        to_target = normalize(to_target) * dist
    elif dist < min_reach:
        stretch = min_reach - dist
        dist = max(min_reach, 1e-4)
        to_target = normalize(to_target) * dist

    if dist < 1e-6:
        return TwoBoneIKResult(shoulder + pole_hint * upper_length, False, stretch)

    # Law of cosines for the angle at the shoulder between the target
    # direction and the upper-arm bone.
    cos_a = (upper_length**2 + dist**2 - lower_length**2) / (2 * upper_length * dist)
    cos_a = clamp(cos_a, -1.0, 1.0)
    angle_a = math.acos(cos_a)

    axis_dir = normalize(to_target)
    # Build a plane basis from the pole hint so the elbow bends the right way.
    side = pole_hint - axis_dir * float(pole_hint @ axis_dir)
    side = normalize(side, UP)
    bend_axis = _cross(axis_dir, side)
    bend_axis = normalize(bend_axis, UP)

    elbow_dir = _rotate_about_axis(axis_dir, bend_axis, angle_a)
    elbow = shoulder + elbow_dir * upper_length

    reachable = stretch <= 1e-6
    return TwoBoneIKResult(elbow, reachable, stretch)


def _cross(a: Vec3, b: Vec3) -> Vec3:
    import numpy as np

    return np.cross(a, b)


def _rotate_about_axis(v: Vec3, axis: Vec3, angle: float) -> Vec3:
    """Rodrigues' rotation formula."""
    axis = normalize(axis)
    cos_t, sin_t = math.cos(angle), math.sin(angle)
    return v * cos_t + _cross(axis, v) * sin_t + axis * float(axis @ v) * (1 - cos_t)


def ground_foot_target(hip_position: Vec3, foot_offset: Vec3, ground_height: float) -> Vec3:
    """Keeps a foot IK target pinned to the ground plane height under a
    (possibly sloped/staggered) hip position, so feet don't float during
    procedural reactions (design doc §27, §29)."""
    target = hip_position + foot_offset
    target[1] = ground_height
    return target
