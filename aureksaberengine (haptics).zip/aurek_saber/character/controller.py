"""
aurek_saber.character.controller
===================================
design doc §101, "CHARACTER" layer. Binds locomotion + stance + blade
transform + stamina + balance into one authoritative per-tick update for a
single combatant. `combat.duel.DuelSimulation` drives two of these and
resolves the interaction (collision/contact) between them; the controller
itself never reaches across to the opponent except to read state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

from ..combat.attacks import AttackTrajectory
from ..combat.balance import CombatBalance
from ..combat.blade import SaberBlade, SaberHandle
from ..combat.distance import CombatDistanceController, DistancePreferences
from ..combat.guard import classify_guard, guard_pose_offset
from ..combat.stamina import (
    COST_ATTACK_HEAVY,
    COST_ATTACK_LIGHT,
    COST_BLOCK,
    COST_PARRY,
    StaminaModel,
)
from ..core.enums import AttackPhase, AttackType, CombatantDuelState, CombatIntent, GuardZone, Stance
from ..core.math import UP, Vec3, clamp, normalize, rotate_yaw, signed_angle, vec3, vmove_toward
from .ik import solve_two_bone_ik
from .locomotion import (
    MAX_ACCEL,
    MAX_LUNGE_SPEED,
    MAX_STEP_SPEED,
    MAX_WALK_SPEED,
    MAX_YAW_RATE,
    backward_step,
    circle_step,
    forward_step,
    lunge,
)
from .reaction import ReactionKind, generate_reaction
from .stance import get_modifiers

HEAVY_ATTACK_TYPES = {AttackType.LONG, AttackType.DESCENDING, AttackType.DIAGONAL}


@dataclass
class CombatantController:
    combatant_id: str
    position: Vec3 = field(default_factory=lambda: vec3(0, 0, 0))
    body_forward: Vec3 = field(default_factory=lambda: vec3(0, 0, 1))
    velocity: Vec3 = field(default_factory=lambda: vec3(0, 0, 0))

    stance: Stance = Stance.NEUTRAL
    guard: GuardZone = GuardZone.CENTER
    stamina: StaminaModel = field(default_factory=StaminaModel)
    balance: CombatBalance = field(default_factory=CombatBalance)
    distance_ctrl: CombatDistanceController = field(default_factory=lambda: CombatDistanceController(DistancePreferences()))

    blade: SaberBlade = field(default_factory=SaberBlade)
    handle: SaberHandle = field(default_factory=SaberHandle)

    current_attack: Optional[AttackTrajectory] = None
    reaction_timer: float = 0.0
    reaction_kind: ReactionKind = ReactionKind.NONE
    duel_state: CombatantDuelState = CombatantDuelState.IDLE
    disarmed: bool = False

    def __post_init__(self):
        self.blade.owner_id = self.combatant_id
        self.blade.set_transform(self._hilt_world_position(), self.body_forward, dt=1.0 / 120.0)

    # ---------------------------------------------------------------- utils
    def right(self) -> Vec3:
        return rotate_yaw(normalize(self.body_forward), -1.5708)

    def _hilt_world_position(self) -> Vec3:
        return self.position + UP * 1.05 + self.body_forward * 0.18

    def _local_to_world_offset(self, local: Vec3) -> Vec3:
        right = self.right()
        return right * local[0] + UP * local[1] + normalize(self.body_forward) * local[2]

    def is_locked(self) -> bool:
        """True while a hard reaction (stagger/knockdown) overrides
        control — matches design doc §29's "uninterruptible" only for the
        physically-forced portion of a reaction, not the whole animation."""
        return self.reaction_timer > 0.0 and self.reaction_kind in (
            ReactionKind.STAGGER,
            ReactionKind.STAGGER_TURN,
            ReactionKind.LOSS_OF_BALANCE,
            ReactionKind.KNOCKDOWN,
        )

    def is_attacking(self) -> bool:
        return self.current_attack is not None and self.current_attack.phase not in (
            AttackPhase.NONE,
            AttackPhase.ABORTED,
        )

    def can_start_action(self) -> bool:
        return not self.is_locked() and not self.disarmed

    # ------------------------------------------------------------- footwork
    def desired_velocity(self, intent: CombatIntent, opponent_pos: Vec3, distance: float, urgency: float = 1.0) -> Vec3:
        mods = get_modifiers(self.stance)
        base_speed = MAX_WALK_SPEED * mods.move_speed * self.stamina.speed_multiplier()
        to_opp = normalize(opponent_pos - self.position)

        if intent == CombatIntent.ADVANCE:
            return forward_step(to_opp, min(MAX_STEP_SPEED, base_speed * 1.6))
        if intent == CombatIntent.RETREAT:
            return backward_step(to_opp, base_speed * 1.4)
        if intent == CombatIntent.CIRCLE_LEFT:
            return circle_step(to_opp, self.body_forward, base_speed, clockwise=False)
        if intent == CombatIntent.CIRCLE_RIGHT:
            return circle_step(to_opp, self.body_forward, base_speed, clockwise=True)
        if intent in (CombatIntent.ATTACK, CombatIntent.COUNTER) and distance > self.distance_ctrl.prefs.attack * 0.6:
            return forward_step(to_opp, base_speed)

        # Default: gentle spacing correction toward preferred distance.
        radial_speed = self.distance_ctrl.desired_radial_speed(distance, urgency)
        return to_opp * radial_speed

    def update_footwork(self, dt: float, intent: CombatIntent, opponent_pos: Vec3, distance: float) -> None:
        if self.is_locked():
            # Physically forced movement (recoil) still integrates but
            # ignores voluntary intent.
            self.velocity = vmove_toward(self.velocity, vec3(0, 0, 0), MAX_ACCEL * 0.6 * dt)
            self.position = self.position + self.velocity * dt
            return

        urgency = clamp(1.0 - 0.4 * self.stamina.fatigue, 0.4, 1.0)
        desired = self.desired_velocity(intent, opponent_pos, distance, urgency)
        self.velocity = vmove_toward(self.velocity, desired, MAX_ACCEL * dt)
        self.position = self.position + self.velocity * dt

        # Facing: body always tracks the opponent's line at a bounded yaw
        # rate — never snaps (design doc §88).
        to_opp = normalize(opponent_pos - self.position, self.body_forward)
        ang = signed_angle(self.body_forward, to_opp)
        step = clamp(ang, -MAX_YAW_RATE * dt, MAX_YAW_RATE * dt)
        self.body_forward = normalize(rotate_yaw(self.body_forward, step))

    # -------------------------------------------------------------- attacks
    def try_begin_attack(self, attack_type: AttackType, target_local_offset: Vec3, as_feint: bool = False, target_zone: Optional[GuardZone] = None) -> bool:
        if not self.can_start_action() or self.is_attacking():
            return False
        cost = COST_ATTACK_HEAVY if attack_type in HEAVY_ATTACK_TYPES else COST_ATTACK_LIGHT
        if as_feint:
            cost *= 0.35
        sufficient = self.stamina.spend(cost)
        mods = get_modifiers(self.stance)
        speed_scale = mods.attack_speed * self.stamina.speed_multiplier() * (0.75 if not sufficient else 1.0)
        start_offset = guard_pose_offset(self.guard)
        self.current_attack = AttackTrajectory(
            attack_type=attack_type,
            attacker_id=self.combatant_id,
            start_local_offset=start_offset,
            target_local_offset=target_local_offset,
            speed_scale=speed_scale,
            is_feint=as_feint,
            target_zone=target_zone,
        )
        self.duel_state = CombatantDuelState.ATTACKING
        return True

    def try_feint_redirect(self, new_type: AttackType, new_target_offset: Vec3) -> bool:
        if self.current_attack is None or not self.current_attack.can_abort():
            return False
        self.current_attack.redirect(new_type, new_target_offset)
        return True

    def abort_attack(self) -> None:
        if self.current_attack is not None:
            self.current_attack.abort()
            self.current_attack = None
            self.duel_state = CombatantDuelState.ENGAGED

    def update_blade(self, dt: float) -> None:
        if self.current_attack is not None:
            still_active = self.current_attack.tick(dt)
            local_offset = self.current_attack.sample_blade_local_offset()
            if not still_active:
                self.current_attack = None
                self.duel_state = CombatantDuelState.ENGAGED
        else:
            local_offset = guard_pose_offset(self.guard)

        world_target = self._hilt_world_position() + self._local_to_world_offset(local_offset) - self.position
        base = self._hilt_world_position()
        direction = normalize(world_target)
        self.blade.set_transform(base, direction, dt)

        # Reflect the actual blade pose back into a read guard zone
        # (design doc §13 — the weapon defines the guard, not a menu).
        local_dir = normalize(np.array([
            float(direction @ self.right()),
            float(direction @ UP),
            float(direction @ normalize(self.body_forward)),
        ]))
        if self.current_attack is None:
            self.guard = classify_guard(local_dir, blade_extended=True)

    # -------------------------------------------------------------- combat
    def apply_reaction(self, kind: ReactionKind, duration: float, impulse_dir: Vec3, impulse_mag: float, torque: float, turn_toward: bool = False) -> None:
        self.reaction_kind = kind
        self.reaction_timer = max(self.reaction_timer, duration * self.stamina.recovery_multiplier())
        self.balance.apply_impulse(impulse_dir, impulse_mag, torque)
        if kind in (ReactionKind.STAGGER, ReactionKind.STAGGER_TURN, ReactionKind.LOSS_OF_BALANCE, ReactionKind.KNOCKDOWN):
            self.duel_state = CombatantDuelState.STAGGERED
        if turn_toward:
            self.body_forward = normalize(rotate_yaw(self.body_forward, 0.35))

    def spend_defense_cost(self, was_parry: bool) -> None:
        self.stamina.spend(COST_PARRY if was_parry else COST_BLOCK)

    # ---------------------------------------------------------------- tick
    def tick(self, dt: float) -> None:
        if self.reaction_timer > 0.0:
            self.reaction_timer = max(0.0, self.reaction_timer - dt)
            if self.reaction_timer == 0.0 and self.duel_state == CombatantDuelState.STAGGERED:
                self.duel_state = CombatantDuelState.ENGAGED
        is_idle = not self.is_attacking() and length_sq(self.velocity) < 0.01
        self.stamina.tick(dt, is_idle)
        self.balance.tick(dt, self.stamina.recovery_multiplier())


def length_sq(v: Vec3) -> float:
    return float(v @ v)
