"""
aurek_saber.haptics.devices.null_device
==========================================
Backends that need no real hardware: a no-op sink (used whenever a fighter
has no controller attached, e.g. an AI-only duel, so `HapticsController`
never has to special-case "no device") and a logging sink for development
— print/inspect what the mixer produced without owning any hardware.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

from ...core.math import clamp
from ..channels import HapticChannel, MotorBand
from .base import ChannelOutput, HapticDevice, to_dual_motor


class NullHapticDevice(HapticDevice):
    """Discards everything. Always "connected" so callers never need a
    None-check — this is the safe default for any fighter/slot that has
    no real haptic hardware attached."""

    @property
    def is_connected(self) -> bool:
        return True

    def apply(self, output: ChannelOutput, dt: float) -> None:
        return


@dataclass
class LoggingHapticDevice(HapticDevice):
    """Prints the resolved dual-motor rumble values whenever they change
    by more than `threshold` — useful for developing/tuning cues without
    any hardware attached, and for the demo script."""

    label: str = "haptics"
    threshold: float = 0.05
    _last: Tuple[float, float] = field(default=(0.0, 0.0), init=False, repr=False)

    @property
    def is_connected(self) -> bool:
        return True

    def apply(self, output: ChannelOutput, dt: float) -> None:
        low, high = to_dual_motor(output)
        if abs(low - self._last[0]) > self.threshold or abs(high - self._last[1]) > self.threshold:
            print(f"[{self.label}] low={low:.2f} high={high:.2f}")
            self._last = (low, high)
