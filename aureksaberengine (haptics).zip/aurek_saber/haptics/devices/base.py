"""
aurek_saber.haptics.devices.base
===================================
Device backends translate the mixer's channel/motor-band output into
whatever a real piece of hardware actually accepts (a dual-motor gamepad
rumble call, a VR controller haptic pulse, ...). Keeping this boundary
explicit means `haptics.mixer`/`haptics.cues` never need to know which
hardware is attached, and a new backend is the *only* thing that needs
adding to support new hardware.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Tuple

from ...core.math import clamp
from ..channels import HapticChannel, MotorBand

ChannelOutput = Dict[HapticChannel, Dict[MotorBand, float]]


class HapticDevice(ABC):
    """A single physical haptic output (one gamepad, one VR controller,
    one vest). `apply()` is called once per tick with the mixer's fully
    resolved output for the fighter this device belongs to."""

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        ...

    @abstractmethod
    def apply(self, output: ChannelOutput, dt: float) -> None:
        ...

    def shutdown(self) -> None:
        """Stop all motors — always safe to call, even if never applied
        anything (e.g. on duel end or device disconnect)."""
        self.apply({}, 0.0)


def channel_scalar(output: ChannelOutput, channel: HapticChannel, low_weight: float = 1.0, high_weight: float = 0.6) -> float:
    """Collapse one channel's two motor bands into a single 0..1 scalar —
    for a simple single-motor device (e.g. a basic VR controller click
    actuator) that has no LOW/HIGH distinction."""
    bands = output.get(channel, {})
    value = bands.get(MotorBand.LOW, 0.0) * low_weight + bands.get(MotorBand.HIGH, 0.0) * high_weight
    return clamp(value, 0.0, 1.0)


def to_dual_motor(output: ChannelOutput) -> Tuple[float, float]:
    """Standard Xbox/PlayStation/SDL dual-motor rumble convention: one
    "strong"/low-frequency motor, one "weak"/high-frequency motor, no
    per-hand distinction (it's one controller). We take the loudest
    channel per band rather than summing everything, so e.g. a chest hit
    on a vest-oriented cue doesn't make the single gamepad rumble twice
    as hard as a hand-only cue."""
    low = 0.0
    high = 0.0
    for bands in output.values():
        low = max(low, bands.get(MotorBand.LOW, 0.0))
        high = max(high, bands.get(MotorBand.HIGH, 0.0))
    return clamp(low, 0.0, 1.0), clamp(high, 0.0, 1.0)


def to_two_handed_motors(output: ChannelOutput) -> Tuple[float, float, float, float]:
    """For a dual-controller/two-hilt VR rig: (main_low, main_high,
    off_low, off_high), each hand's own bands taken independently rather
    than merged, so an off-hand parry is felt in the off hand."""
    main = output.get(HapticChannel.MAIN_HAND, {})
    off = output.get(HapticChannel.OFF_HAND, {})
    return (
        clamp(main.get(MotorBand.LOW, 0.0), 0.0, 1.0),
        clamp(main.get(MotorBand.HIGH, 0.0), 0.0, 1.0),
        clamp(off.get(MotorBand.LOW, 0.0), 0.0, 1.0),
        clamp(off.get(MotorBand.HIGH, 0.0), 0.0, 1.0),
    )
