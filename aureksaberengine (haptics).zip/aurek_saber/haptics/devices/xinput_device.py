"""
aurek_saber.haptics.devices.xinput_device
============================================
Windows-only XInput rumble backend via ctypes (no extra dependency beyond
the OS itself — `xinput1_4.dll` ships with Windows 8+; `XInputSetState`
covers Xbox-family controllers). Loading the DLL and constructing this
class off Windows raises immediately with a clear message rather than
failing obscurely.

Like `sdl2_device.py`, this talks to real hardware and has not been
exercised against a physical Xbox controller in this environment — the
struct layout and call convention below follow Microsoft's documented
XInput ABI, but treat this as a starting point to validate on real
hardware before shipping.
"""

from __future__ import annotations

import ctypes
import sys
from ctypes import wintypes

from .base import ChannelOutput, HapticDevice, to_dual_motor

_IS_WINDOWS = sys.platform == "win32"


class _XINPUT_VIBRATION(ctypes.Structure):
    _fields_ = [
        ("wLeftMotorSpeed", wintypes.WORD if _IS_WINDOWS else ctypes.c_uint16),
        ("wRightMotorSpeed", wintypes.WORD if _IS_WINDOWS else ctypes.c_uint16),
    ]


class XInputRumbleDevice(HapticDevice):
    """One XInput controller slot (0-3). Left motor = low-frequency
    ("strong"), right motor = high-frequency ("weak") — matches the
    LOW/HIGH `MotorBand` convention used throughout `haptics`."""

    def __init__(self, user_index: int = 0):
        if not _IS_WINDOWS:
            raise RuntimeError(
                "XInputRumbleDevice is only available on Windows. Use "
                "haptics.devices.sdl2_device.SDL2RumbleDevice for cross-platform "
                "gamepad rumble, or haptics.devices.null_device for development."
            )
        if not (0 <= user_index <= 3):
            raise ValueError("XInput supports user_index 0-3")
        self.user_index = user_index
        self._dll = self._load_dll()
        self._connected = self._poll_connected()

    @staticmethod
    def _load_dll():
        last_error = None
        for name in ("xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"):
            try:
                return ctypes.WinDLL(name)  # type: ignore[attr-defined]
            except OSError as exc:  # pragma: no cover - Windows-only path
                last_error = exc
        raise RuntimeError(f"Could not load any XInput DLL: {last_error}")

    def _poll_connected(self) -> bool:
        # XInputGetState with a throwaway state struct just to check
        # ERROR_SUCCESS (0) vs ERROR_DEVICE_NOT_CONNECTED.
        class _XINPUT_GAMEPAD(ctypes.Structure):
            _fields_ = [
                ("wButtons", ctypes.c_uint16),
                ("bLeftTrigger", ctypes.c_ubyte),
                ("bRightTrigger", ctypes.c_ubyte),
                ("sThumbLX", ctypes.c_int16),
                ("sThumbLY", ctypes.c_int16),
                ("sThumbRX", ctypes.c_int16),
                ("sThumbRY", ctypes.c_int16),
            ]

        class _XINPUT_STATE(ctypes.Structure):
            _fields_ = [("dwPacketNumber", ctypes.c_uint32), ("Gamepad", _XINPUT_GAMEPAD)]

        state = _XINPUT_STATE()
        result = self._dll.XInputGetState(self.user_index, ctypes.byref(state))
        return result == 0

    @property
    def is_connected(self) -> bool:
        return self._connected

    def apply(self, output: ChannelOutput, dt: float) -> None:
        low, high = to_dual_motor(output)
        vibration = _XINPUT_VIBRATION(
            wLeftMotorSpeed=int(low * 65535),
            wRightMotorSpeed=int(high * 65535),
        )
        result = self._dll.XInputSetState(self.user_index, ctypes.byref(vibration))
        self._connected = result == 0

    def shutdown(self) -> None:
        vibration = _XINPUT_VIBRATION(wLeftMotorSpeed=0, wRightMotorSpeed=0)
        try:
            self._dll.XInputSetState(self.user_index, ctypes.byref(vibration))
        except Exception:
            pass
