"""
aurek_saber.haptics.devices.sdl2_device
==========================================
Cross-platform gamepad rumble via PySDL2 (`pip install PySDL2`, which
needs the SDL2 shared library available on the system — see
https://pypi.org/project/PySDL2/). Uses `SDL_GameControllerRumble`, which
covers Xbox/PlayStation/Switch-Pro-style controllers uniformly.

Import of `sdl2` is guarded: this module always imports cleanly even
without PySDL2 installed, and only raises when you actually try to
construct `SDL2RumbleDevice`. This backend talks to real hardware and has
not been exercised against physical controllers in this environment —
treat it as a documented, structurally-correct starting point rather than
a verified driver.
"""

from __future__ import annotations

from typing import Optional

from .base import ChannelOutput, HapticDevice, to_dual_motor

try:
    import sdl2  # type: ignore
    import sdl2.ext  # type: ignore

    _SDL2_AVAILABLE = True
except ImportError:  # pragma: no cover - exercised only when PySDL2 is installed
    sdl2 = None  # type: ignore
    _SDL2_AVAILABLE = False


class SDL2RumbleDevice(HapticDevice):
    """One gamepad, addressed by SDL joystick index. Rumble calls are
    fire-and-forget with a duration in ms; we re-issue every tick with a
    short duration slightly longer than one simulation tick so back-to-back
    calls overlap smoothly instead of audibly/tactilely stuttering."""

    def __init__(self, joystick_index: int = 0, rumble_duration_ms: int = 60):
        if not _SDL2_AVAILABLE:
            raise RuntimeError(
                "PySDL2 is not installed. `pip install PySDL2` and ensure the SDL2 "
                "shared library is available, or use haptics.devices.null_device "
                "for development without hardware."
            )
        self.joystick_index = joystick_index
        self.rumble_duration_ms = rumble_duration_ms
        self._controller = None
        self._connected = False
        self._connect()

    def _connect(self) -> None:
        if sdl2.SDL_WasInit(sdl2.SDL_INIT_GAMECONTROLLER) == 0:
            sdl2.SDL_Init(sdl2.SDL_INIT_GAMECONTROLLER)
        if sdl2.SDL_IsGameController(self.joystick_index):
            self._controller = sdl2.SDL_GameControllerOpen(self.joystick_index)
            self._connected = self._controller is not None
        else:
            self._connected = False

    @property
    def is_connected(self) -> bool:
        return self._connected

    def apply(self, output: ChannelOutput, dt: float) -> None:
        if not self._connected or self._controller is None:
            return
        low, high = to_dual_motor(output)
        low_u16 = int(low * 0xFFFF)
        high_u16 = int(high * 0xFFFF)
        sdl2.SDL_GameControllerRumble(self._controller, low_u16, high_u16, self.rumble_duration_ms)

    def shutdown(self) -> None:
        if self._connected and self._controller is not None:
            sdl2.SDL_GameControllerRumble(self._controller, 0, 0, 0)

    def close(self) -> None:
        self.shutdown()
        if self._controller is not None:
            sdl2.SDL_GameControllerClose(self._controller)
            self._controller = None
            self._connected = False
