"""
aurek_saber.haptics
======================
Haptic feedback layer for AUREK SABER ENGINE. Subscribes to the same
`CombatEvent` stream and live `DuelState` the camera/audio/replay layers
use (design doc §59, §90: simulation stays authoritative) and turns it
into per-fighter, per-channel motor intensities, applied through a
pluggable `HapticDevice` backend (gamepad rumble today; VR
controllers/haptic vests are the same interface).

Quick start:

    from aurek_saber.haptics.controller import HapticsController
    from aurek_saber.haptics.devices.null_device import LoggingHapticDevice

    haptics = HapticsController(sim, devices={"fighter_a": LoggingHapticDevice("A")})
    ...
    sim.tick(dt)
    haptics.tick(dt)

See `examples/run_duel_with_haptics.py` for a full runnable example, and
this package's section of the top-level README for the design rationale.
"""

from .channels import HapticChannel, MotorBand
from .controller import HapticsController

__all__ = ["HapticChannel", "MotorBand", "HapticsController"]
