"""
aurek_saber.haptics.controller
=================================
`HapticsController` is the seam between the combat simulation and haptic
hardware: one `HapticMixer` per fighter, fed by (a) the shared
`CombatEvent` stream — turned into discrete cues via `haptics.cues` — and
(b) each fighter's own live controller state every tick (continuous
signals, balance-drop detection for staggers). Resolved output is handed
to whatever `HapticDevice` is registered for that fighter.

Like `camera.duel_camera.DuelCamera`, this is driven *externally*: call
`HapticsController.tick(dt)` once per simulation tick, right after
`DuelSimulation.tick(dt)` (see `examples/run_duel_with_haptics.py`). It
never mutates simulation state — it only reads `DuelState`/`CombatEvent`,
matching the "simulation stays authoritative" rule the whole engine
follows (design doc §90).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

from ..combat.duel import DuelSimulation
from ..core.events import CombatEvent, EventType
from ..core.math import clamp
from .cues import (
    CONTACT_CUE_BUILDERS,
    duel_end_cue,
    feint_tell_cue,
    force_ability_cue,
    stagger_cue,
)
from .devices.base import HapticDevice
from .devices.null_device import NullHapticDevice
from .mixer import HapticMixer

# A sudden balance drop bigger than this (out of 100) in a single tick
# reads as a stagger-worthy jolt rather than the small continuous sway
# already covered by haptics.continuous's critical-balance tremble.
STAGGER_BALANCE_DROP_THRESHOLD = 8.0


@dataclass
class HapticsController:
    sim: DuelSimulation
    devices: Dict[str, HapticDevice] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.mixers: Dict[str, HapticMixer] = {cid: HapticMixer() for cid in self.sim.controllers}
        self._prev_balance: Dict[str, float] = {cid: c.balance.value for cid, c in self.sim.controllers.items()}
        self.sim.events.subscribe_all(self._on_event)

    def device_for(self, combatant_id: str) -> HapticDevice:
        return self.devices.get(combatant_id, NullHapticDevice())

    # ------------------------------------------------------------- events
    def _on_event(self, event: CombatEvent) -> None:
        handler = self._handlers.get(event.type)
        if handler is not None:
            handler(self, event)

    def _handle_contact(self, event: CombatEvent) -> None:
        contact_type = event.data.get("contact_type")
        builder = CONTACT_CUE_BUILDERS.get(contact_type)
        if builder is None:
            return
        attacker = self.sim.controllers.get(event.source)
        energy = clamp(attacker.blade.tip_speed / 6.0, 0.0, 1.0) if attacker is not None else 0.5
        attacker_cue, defender_cue = builder(self.sim.sim_time, energy)
        if event.source in self.mixers and attacker_cue is not None:
            self.mixers[event.source].trigger(attacker_cue)
        if event.target in self.mixers and defender_cue is not None:
            self.mixers[event.target].trigger(defender_cue)

    def _handle_feint(self, event: CombatEvent) -> None:
        if event.source in self.mixers:
            self.mixers[event.source].trigger(feint_tell_cue(self.sim.sim_time))

    def _handle_force_ability(self, event: CombatEvent) -> None:
        magnitude = float(event.data.get("magnitude", 1.0))
        if event.target in self.mixers:
            self.mixers[event.target].trigger(force_ability_cue(self.sim.sim_time, event.type.name, magnitude))
        if event.source in self.mixers:
            self.mixers[event.source].trigger(force_ability_cue(self.sim.sim_time, event.type.name, magnitude * 0.4))

    def _handle_duel_ended(self, event: CombatEvent) -> None:
        if event.source in self.mixers:  # winner
            self.mixers[event.source].trigger(duel_end_cue(self.sim.sim_time, won=True))
        if event.target in self.mixers:  # loser
            self.mixers[event.target].trigger(duel_end_cue(self.sim.sim_time, won=False))

    _handlers = {
        EventType.BLADE_CONTACT: _handle_contact,
        EventType.PARRY: _handle_contact,
        EventType.PERFECT_PARRY: _handle_contact,
        EventType.BLOCK: _handle_contact,
        EventType.FAILED_PARRY: _handle_contact,
        EventType.HIT: _handle_contact,
        EventType.BLADE_LOCK: _handle_contact,
        EventType.FEINT: _handle_feint,
        EventType.FORCE_PUSH: _handle_force_ability,
        EventType.FORCE_PULL: _handle_force_ability,
        EventType.DUEL_ENDED: _handle_duel_ended,
    }

    # --------------------------------------------------------------- tick
    def tick(self, dt: float) -> Dict[str, Dict]:
        """Advance every fighter's mixer + device by one tick. Returns
        the resolved per-fighter channel output, mainly for
        logging/tests/UI accessibility indicators (design doc §82:
        colour-independent contact indicators can be driven off the same
        signal that drives rumble)."""
        outputs: Dict[str, Dict] = {}
        for cid, ctrl in self.sim.controllers.items():
            balance = ctrl.balance.value
            drop = self._prev_balance[cid] - balance
            if drop > STAGGER_BALANCE_DROP_THRESHOLD:
                self.mixers[cid].trigger(stagger_cue(self.sim.sim_time, drop))
            self._prev_balance[cid] = balance

            output = self.mixers[cid].tick(ctrl, self.sim.sim_time, dt)
            self.device_for(cid).apply(output, dt)
            outputs[cid] = output
        return outputs

    def shutdown(self) -> None:
        for device in self.devices.values():
            device.shutdown()
