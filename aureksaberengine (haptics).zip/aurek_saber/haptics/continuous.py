"""
aurek_saber.haptics.continuous
=================================
Signals that aren't tied to a discrete `CombatEvent` at all — they're
sampled straight off live simulation state every tick, the same way blade
audio is described as varying with "velocity, movement, stance, combat
intensity" (design doc §52) rather than being a one-shot sound effect.
These form the *base layer* the mixer sums discrete cues on top of, and
get ducked (see `haptics.mixer`) while a strong discrete cue is playing so
a blade-hum buzz doesn't wash out a direct-hit impact.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict

from ..character.controller import CombatantController
from ..core.math import clamp
from .channels import HapticChannel, MotorBand

BladeHumSignal = Dict[HapticChannel, Dict[MotorBand, float]]

# Tunable thresholds — self-play/playtesting territory, same spirit as
# combat/stamina.py's cost constants.
BLADE_HUM_MAX_SPEED = 9.0  # tip m/s at which hum saturates
LOW_STAMINA_THRESHOLD = 0.32
CRITICAL_BALANCE_THRESHOLD = 0.4


@dataclass
class ContinuousState:
    """Per-fighter running state for signals that need memory (heartbeat
    phase, smoothing) rather than being pure functions of instantaneous
    controller state."""

    smoothed_hum: float = 0.0

    def update(self, ctrl: CombatantController, sim_time: float, dt: float) -> BladeHumSignal:
        out: BladeHumSignal = {}

        # --- blade hum: buzzes harder the faster/more violently the
        # blade is currently moving (design doc §52). ---
        raw_speed_signal = clamp(ctrl.blade.tip_speed / BLADE_HUM_MAX_SPEED, 0.0, 1.0)
        raw_swing_signal = clamp(abs(ctrl.blade.angular_velocity) / 12.0, 0.0, 1.0)
        hum_target = clamp(0.06 + raw_speed_signal * 0.5 + raw_swing_signal * 0.3, 0.0, 1.0)
        # Smooth so the hum doesn't buzz-saw tick to tick (a real motor
        # can't instantaneously jump anyway).
        smoothing = clamp(dt * 10.0, 0.0, 1.0)
        self.smoothed_hum += (hum_target - self.smoothed_hum) * smoothing
        _accumulate(out, HapticChannel.MAIN_HAND, MotorBand.HIGH, self.smoothed_hum * 0.6)
        _accumulate(out, HapticChannel.MAIN_HAND, MotorBand.LOW, self.smoothed_hum * 0.15)

        # --- low-stamina heartbeat: a double-pulse whose tempo rises as
        # stamina drains, felt on the chest (design doc §31, §53). ---
        stamina_ratio = ctrl.stamina.ratio
        if stamina_ratio < LOW_STAMINA_THRESHOLD:
            deficit = clamp(1.0 - stamina_ratio / LOW_STAMINA_THRESHOLD, 0.0, 1.0)
            bpm = 70.0 + deficit * 110.0  # 70 -> 180 "bpm" as stamina bottoms out
            beat = _heartbeat_pulse(sim_time, bpm)
            _accumulate(out, HapticChannel.CHEST, MotorBand.LOW, beat * (0.25 + deficit * 0.45))

        # --- critical balance tremble: a fast, low-amplitude shake that
        # grows as balance collapses toward a stagger/fall (design doc §30). ---
        balance_ratio = ctrl.balance.stability_factor()
        if balance_ratio < CRITICAL_BALANCE_THRESHOLD:
            deficit = clamp(1.0 - balance_ratio / CRITICAL_BALANCE_THRESHOLD, 0.0, 1.0)
            tremble = 0.5 + 0.5 * math.sin(sim_time * 55.0)
            _accumulate(out, HapticChannel.WHOLE_BODY, MotorBand.LOW, tremble * deficit * 0.5)
            _accumulate(out, HapticChannel.MAIN_HAND, MotorBand.LOW, tremble * deficit * 0.25)

        return out


def _heartbeat_pulse(sim_time: float, bpm: float) -> float:
    """A lub-dub double-pulse shape repeating at `bpm`, built from two
    offset raised-cosine bumps rather than a plain sine so it actually
    reads as a heartbeat rather than a buzz."""
    period = 60.0 / max(bpm, 1e-3)
    phase = (sim_time % period) / period  # 0..1
    lub = _bump(phase, center=0.08, width=0.07)
    dub = _bump(phase, center=0.28, width=0.09) * 0.7
    return clamp(lub + dub, 0.0, 1.0)


def _bump(phase: float, center: float, width: float) -> float:
    d = abs(phase - center)
    if d > width:
        return 0.0
    return 0.5 * (1.0 + math.cos(math.pi * d / width))


def _accumulate(out: BladeHumSignal, channel: HapticChannel, band: MotorBand, value: float) -> None:
    bands = out.setdefault(channel, {})
    bands[band] = clamp(bands.get(band, 0.0) + value, 0.0, 1.0)
