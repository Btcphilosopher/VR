"""
aurek_saber.haptics.cues
===========================
Turns a `CombatEvent` (from `core.events`) into one or more haptic cue
*instances* — an ADSR-enveloped intensity on specific channels/motor bands
— felt differently depending on whether the viewer *was* the event's
source (attacker) or its target (defender). A perfect parry should feel
sharp and satisfying in the defender's hand and only a light "your blade
got knocked" tap in the attacker's; a direct hit should feel like nothing
in the attacker's hand and a genuine shock in the defender's.

This mirrors the same "simulation is authoritative" rule the rest of the
engine follows (design doc §90): every cue traces back to a real
`ContactType`/`EventType` and the magnitude data the physics layer already
computed in `combat.parry`, never to a fixed "hit = rumble" mapping.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from ..core.events import CombatEvent, EventType
from ..core.math import clamp, lerp
from .channels import HapticChannel, MotorBand


@dataclass
class ADSR:
    """A standard attack/decay/sustain/release envelope, values in
    seconds except `sustain_level` (0..1). `release` governs how long the
    cue takes to fade to zero once released — for a one-shot cue this
    happens automatically after `one_shot_duration` on the owning
    instance; for a held/continuous cue, whoever owns it (haptics.mixer,
    haptics.continuous) controls release explicitly."""

    attack: float = 0.015
    decay: float = 0.05
    sustain_level: float = 0.55
    release: float = 0.12

    def value(self, t_since_trigger: float, t_since_release: Optional[float]) -> float:
        if t_since_release is not None:
            if self.release <= 1e-6:
                return 0.0
            frac = clamp(1.0 - t_since_release / self.release, 0.0, 1.0)
            return self.sustain_level * frac
        if t_since_trigger < 0:
            return 0.0
        if t_since_trigger < self.attack:
            return clamp(t_since_trigger / max(self.attack, 1e-6), 0.0, 1.0)
        t2 = t_since_trigger - self.attack
        if t2 < self.decay:
            return lerp(1.0, self.sustain_level, t2 / max(self.decay, 1e-6))
        return self.sustain_level


@dataclass
class HapticCueInstance:
    """A live, playing cue. `haptics.mixer.HapticMixer` owns a list of
    these and sums their `current_value()` per channel/band each tick."""

    name: str
    channels: Tuple[HapticChannel, ...]
    band_weights: Dict[MotorBand, float]
    envelope: ADSR = field(default_factory=ADSR)
    peak_intensity: float = 1.0
    triggered_at: float = 0.0
    released_at: Optional[float] = None
    one_shot_duration: Optional[float] = None
    priority: int = 0  # higher priority cues duck the continuous layer (haptics.continuous)
    ducks_continuous: bool = False

    def update_auto_release(self, sim_time: float) -> None:
        if self.one_shot_duration is not None and self.released_at is None:
            if sim_time - self.triggered_at >= self.one_shot_duration:
                self.released_at = self.triggered_at + self.one_shot_duration

    def release(self, sim_time: float) -> None:
        if self.released_at is None:
            self.released_at = sim_time

    def is_finished(self, sim_time: float) -> bool:
        if self.released_at is None:
            return False
        return (sim_time - self.released_at) > self.envelope.release + 1e-6

    def current_value(self, sim_time: float) -> float:
        t_trig = sim_time - self.triggered_at
        t_rel = (sim_time - self.released_at) if self.released_at is not None else None
        return self.envelope.value(t_trig, t_rel) * self.peak_intensity

    def band_value(self, sim_time: float, band: MotorBand) -> float:
        return self.current_value(sim_time) * self.band_weights.get(band, 0.0)


def _cue(
    name: str,
    channels: Tuple[HapticChannel, ...],
    low: float,
    high: float,
    peak: float,
    sim_time: float,
    duration: float,
    envelope: Optional[ADSR] = None,
    priority: int = 1,
    ducks_continuous: bool = False,
) -> HapticCueInstance:
    return HapticCueInstance(
        name=name,
        channels=channels,
        band_weights={MotorBand.LOW: low, MotorBand.HIGH: high},
        envelope=envelope or ADSR(),
        peak_intensity=clamp(peak, 0.0, 1.0),
        triggered_at=sim_time,
        one_shot_duration=duration,
        priority=priority,
        ducks_continuous=ducks_continuous,
    )


# ---------------------------------------------------------------------------
# Contact-type cue templates. Each function takes (sim_time, event) and
# returns (attacker_cue, defender_cue) — either may be None. Intensity is
# derived from real data already present in the event's `data` payload
# (`combat.duel` publishes `contact_type`; magnitude comes from the
# controllers' own blade speed at the moment the mixer is driven — see
# `haptics.controller.HapticsController`, which re-derives peak from the
# live blade tip speed rather than baking a fixed number in here).
# ---------------------------------------------------------------------------

ContactCueBuilder = Callable[[float, float], Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]]


def _perfect_parry(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue(
        "perfect_parry", (HapticChannel.MAIN_HAND,), low=0.35, high=1.0, peak=0.75 + energy * 0.2,
        sim_time=sim_time, duration=0.09, envelope=ADSR(attack=0.005, decay=0.03, sustain_level=0.2, release=0.08),
        priority=4, ducks_continuous=True,
    )
    attacker = _cue(
        "perfect_parry_deflected", (HapticChannel.MAIN_HAND,), low=0.6, high=0.4, peak=0.5 + energy * 0.15,
        sim_time=sim_time, duration=0.1, priority=3, ducks_continuous=True,
    )
    return attacker, defender


def _parry(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue("parry", (HapticChannel.MAIN_HAND,), low=0.3, high=0.8, peak=0.55 + energy * 0.15, sim_time=sim_time, duration=0.09, priority=3)
    attacker = _cue("parry_deflected", (HapticChannel.MAIN_HAND,), low=0.45, high=0.3, peak=0.4 + energy * 0.1, sim_time=sim_time, duration=0.09, priority=2)
    return attacker, defender


def _block(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue("block", (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND), low=0.6, high=0.35, peak=0.5 + energy * 0.15, sim_time=sim_time, duration=0.1, priority=2)
    attacker = _cue("block_absorbed", (HapticChannel.MAIN_HAND,), low=0.3, high=0.2, peak=0.3, sim_time=sim_time, duration=0.08, priority=1)
    return attacker, defender


def _failed_parry(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue(
        "failed_parry_shock", (HapticChannel.MAIN_HAND, HapticChannel.CHEST), low=0.95, high=0.6, peak=0.8 + energy * 0.2,
        sim_time=sim_time, duration=0.22, envelope=ADSR(attack=0.01, decay=0.08, sustain_level=0.45, release=0.2),
        priority=5, ducks_continuous=True,
    )
    attacker = _cue("failed_parry_landed", (HapticChannel.MAIN_HAND,), low=0.5, high=0.5, peak=0.55, sim_time=sim_time, duration=0.12, priority=3)
    return attacker, defender


def _direct_hit(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue(
        "direct_hit", (HapticChannel.CHEST, HapticChannel.MAIN_HAND), low=1.0, high=0.5, peak=0.9 + energy * 0.1,
        sim_time=sim_time, duration=0.28, envelope=ADSR(attack=0.008, decay=0.1, sustain_level=0.5, release=0.22),
        priority=6, ducks_continuous=True,
    )
    attacker = _cue("direct_hit_landed", (HapticChannel.MAIN_HAND,), low=0.55, high=0.55, peak=0.6, sim_time=sim_time, duration=0.14, priority=3)
    return attacker, defender


def _glancing_or_edge(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    defender = _cue("glancing_contact", (HapticChannel.MAIN_HAND,), low=0.5, high=0.4, peak=0.4 + energy * 0.1, sim_time=sim_time, duration=0.09, priority=2)
    attacker = _cue("glancing_contact_felt", (HapticChannel.MAIN_HAND,), low=0.3, high=0.3, peak=0.3, sim_time=sim_time, duration=0.08, priority=1)
    return attacker, defender


def _blade_lock(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    cue_a = _cue(
        "blade_lock_grind", (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND), low=0.5, high=0.85, peak=0.5,
        sim_time=sim_time, duration=0.35, envelope=ADSR(attack=0.05, decay=0.1, sustain_level=0.6, release=0.15),
        priority=3, ducks_continuous=True,
    )
    cue_b = _cue(
        "blade_lock_grind", (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND), low=0.5, high=0.85, peak=0.5,
        sim_time=sim_time, duration=0.35, envelope=ADSR(attack=0.05, decay=0.1, sustain_level=0.6, release=0.15),
        priority=3, ducks_continuous=True,
    )
    return cue_a, cue_b  # symmetric: both fighters feel the grinding bind equally


def _mutual_clash(sim_time: float, energy: float) -> Tuple[Optional[HapticCueInstance], Optional[HapticCueInstance]]:
    cue = _cue("mutual_clash", (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND), low=0.55, high=0.6, peak=0.5 + energy * 0.15, sim_time=sim_time, duration=0.12, priority=3)
    # Both fighters feel an equivalent clash — return two independent
    # instances so releasing one never affects the other's mixer.
    other = _cue("mutual_clash", (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND), low=0.55, high=0.6, peak=0.5 + energy * 0.15, sim_time=sim_time, duration=0.12, priority=3)
    return cue, other


CONTACT_CUE_BUILDERS: Dict[str, ContactCueBuilder] = {
    "PERFECT_PARRY": _perfect_parry,
    "PARRY": _parry,
    "CLEAN_BLOCK": _block,
    "GLANCING_BLOCK": _glancing_or_edge,
    "EDGE_CONTACT": _glancing_or_edge,
    "FAILED_PARRY": _failed_parry,
    "DIRECT_CONTACT": _direct_hit,
    "BLADE_LOCK": _blade_lock,
    "MUTUAL_CLASH": _mutual_clash,
}


def stagger_cue(sim_time: float, magnitude: float) -> HapticCueInstance:
    """design doc §29-30 — a stagger/loss-of-balance is felt as a
    shuddering low-frequency pulse scaled by how hard it hit, not a fixed
    "you got hit" buzz (that's already covered by the contact cue above;
    this one specifically represents the *aftermath*)."""
    peak = clamp(0.3 + magnitude * 0.06, 0.2, 1.0)
    return _cue(
        "stagger", (HapticChannel.WHOLE_BODY,), low=0.9, high=0.2, peak=peak, sim_time=sim_time,
        duration=0.25 + magnitude * 0.02, envelope=ADSR(attack=0.02, decay=0.06, sustain_level=0.5, release=0.18),
        priority=3,
    )


def force_ability_cue(sim_time: float, kind: str, magnitude: float) -> HapticCueInstance:
    """design doc §32 — Force abilities swell rather than snap, matching
    their telegraphed, weighty feel."""
    channels = (HapticChannel.WHOLE_BODY, HapticChannel.CHEST) if kind == "FORCE_PUSH" else (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND)
    return _cue(
        f"force_{kind.lower()}", channels, low=0.8, high=0.3, peak=clamp(0.5 + magnitude * 0.1, 0.3, 1.0),
        sim_time=sim_time, duration=0.4, envelope=ADSR(attack=0.08, decay=0.15, sustain_level=0.4, release=0.2), priority=4,
    )


def duel_end_cue(sim_time: float, won: bool) -> HapticCueInstance:
    """design doc §57 — a distinct, non-combat "resolution" cue: a rising
    double-pulse for the winner, a single heavy fall for the loser."""
    if won:
        return _cue(
            "victory", (HapticChannel.WHOLE_BODY,), low=0.4, high=0.7, peak=0.7, sim_time=sim_time,
            duration=0.5, envelope=ADSR(attack=0.02, decay=0.15, sustain_level=0.35, release=0.3), priority=2,
        )
    return _cue(
        "defeat", (HapticChannel.WHOLE_BODY, HapticChannel.CHEST), low=0.9, high=0.15, peak=0.65, sim_time=sim_time,
        duration=0.6, envelope=ADSR(attack=0.05, decay=0.25, sustain_level=0.25, release=0.3), priority=2,
    )


def feint_tell_cue(sim_time: float) -> HapticCueInstance:
    """A very faint tap felt only by the feinting fighter themselves —
    the subtle proprioceptive "hitch" of pulling a strike back, useful as
    an accessibility/practice aid (design doc §82) rather than a tell that
    would leak to the opponent."""
    return _cue("feint_hitch", (HapticChannel.MAIN_HAND,), low=0.1, high=0.35, peak=0.18, sim_time=sim_time, duration=0.05, priority=0)
