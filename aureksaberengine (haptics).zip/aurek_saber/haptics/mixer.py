"""
aurek_saber.haptics.mixer
============================
Combines the continuous base layer (`haptics.continuous`) with any number
of simultaneously-playing discrete cues (`haptics.cues`) into one final
per-channel, per-motor-band intensity each tick — the haptic equivalent of
an audio mix bus. A strong discrete impact "ducks" the continuous blade-hum
layer briefly so it reads clearly instead of blurring into background buzz
(the same reason a game briefly ducks music under an explosion).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from ..character.controller import CombatantController
from ..core.math import clamp
from .channels import HapticChannel, MotorBand
from .continuous import ContinuousState
from .cues import HapticCueInstance

ChannelOutput = Dict[HapticChannel, Dict[MotorBand, float]]

DUCK_STRENGTH = 0.8  # how much a ducking cue suppresses the continuous layer (0..1)
MIN_DUCK_FLOOR = 0.15  # continuous layer is never fully silenced, just attenuated


@dataclass
class HapticMixer:
    """One mixer per fighter/viewer — two fighters in a duel hear (feel)
    two independent mixes, since a perfect parry lands very differently
    in each hand."""

    active: List[HapticCueInstance] = field(default_factory=list)
    continuous_state: ContinuousState = field(default_factory=ContinuousState)
    last_output: ChannelOutput = field(default_factory=dict)

    def trigger(self, cue: HapticCueInstance) -> None:
        self.active.append(cue)

    def trigger_many(self, cues) -> None:
        for c in cues:
            if c is not None:
                self.active.append(c)

    def tick(self, ctrl: CombatantController, sim_time: float, dt: float) -> ChannelOutput:
        for cue in self.active:
            cue.update_auto_release(sim_time)
        self.active = [c for c in self.active if not c.is_finished(sim_time)]

        continuous = self.continuous_state.update(ctrl, sim_time, dt)

        duck_amount = 0.0
        for cue in self.active:
            if cue.ducks_continuous:
                duck_amount = max(duck_amount, cue.current_value(sim_time))
        duck_factor = clamp(1.0 - duck_amount * DUCK_STRENGTH, MIN_DUCK_FLOOR, 1.0)

        output: ChannelOutput = {}
        for channel, bands in continuous.items():
            for band, value in bands.items():
                _add(output, channel, band, value * duck_factor)

        for cue in self.active:
            value = cue.current_value(sim_time)
            if value <= 1e-4:
                continue
            for channel in cue.channels:
                for band, weight in cue.band_weights.items():
                    if weight <= 0:
                        continue
                    _add(output, channel, band, value * weight)

        for channel, bands in output.items():
            for band in bands:
                bands[band] = clamp(bands[band], 0.0, 1.0)

        self.last_output = output
        return output

    def active_cue_names(self) -> List[str]:
        return [c.name for c in self.active]


def _add(output: ChannelOutput, channel: HapticChannel, band: MotorBand, value: float) -> None:
    bands = output.setdefault(channel, {})
    bands[band] = bands.get(band, 0.0) + value
