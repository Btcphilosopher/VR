"""
aurek_saber.haptics.channels
===============================
Haptic output is addressed by *channel*, not by "the controller" — a duel
might be felt through a gamepad's two rumble motors, a VR controller in
each hand, or a haptic vest/suit with chest and back zones. Keeping the
channel vocabulary separate from any one device lets `haptics.mixer`
compute physically-motivated intensities once and have each backend in
`haptics.devices` pick out only the channels it actually has motors for.
"""

from __future__ import annotations

from enum import Enum, auto


class HapticChannel(Enum):
    """Where on the body/controller a cue is felt."""

    MAIN_HAND = auto()    # weapon hand — most contact/blade cues live here
    OFF_HAND = auto()      # off hand — two-handed grips, off-hand parries, dual-wield second blade
    CHEST = auto()         # vest-style body haptics: direct hits, Force impacts
    BACK = auto()          # vest-style: hits/pushes from behind, disarm/knockdown
    WHOLE_BODY = auto()    # broad low-frequency events: knockdown, critical hit, Force shockwave


class MotorBand(Enum):
    """Standard dual-motor rumble convention (matches Xbox/PlayStation/SDL
    gamepad haptics): LOW is the heavier, lower-frequency motor (impacts,
    thuds); HIGH is the lighter, higher-frequency motor (buzz, blade hum,
    sharp taps). A device backend with only one motor should blend the two
    bands itself (see `devices.base.HapticDevice.blend_single_motor`)."""

    LOW = auto()
    HIGH = auto()


# Default per-fighter channel set for a standard single-gamepad setup —
# both hands map onto the one controller's two motors. A VR/vest backend
# instead keeps MAIN_HAND/OFF_HAND/CHEST/BACK physically distinct.
GAMEPAD_CHANNELS = (HapticChannel.MAIN_HAND, HapticChannel.OFF_HAND)
ALL_CHANNELS = tuple(HapticChannel)
