"""
aurek_saber.combat.parry
==========================
design doc §08-11. Turns raw collision geometry + combat state into a
classified contact outcome and its physical response (deflection, recoil,
stagger, counter-window) — never just "play a parry animation".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from ..core.enums import AttackPhase, ContactType
from ..core.math import ZERO, Vec3, clamp, length, normalize
from .collision import ContactGeometry
from .guard import GuardCoverage

# Perfect-parry timing window (design doc §11): the defender's guard must
# have arrived at an aligned pose within this many seconds of blade
# contact for the parry to be classified "perfect" rather than merely
# "clean".
PERFECT_PARRY_WINDOW = 0.12
LATE_BLOCK_WINDOW = 0.30


@dataclass
class ContactResult:
    contact_type: ContactType
    contact_point: Vec3
    contact_normal: Vec3
    attacker_id: str
    defender_id: str

    deflection: Vec3 = field(default_factory=lambda: ZERO.copy())
    attacker_recoil: float = 0.0
    defender_recoil: float = 0.0
    attacker_stagger: float = 0.0
    defender_stagger: float = 0.0
    opening_for_defender: float = 0.0  # 0..1, exploitable window created
    opening_for_attacker: float = 0.0
    counter_window: float = 0.0  # seconds the opening stays live


def classify_contact(
    geometry: ContactGeometry,
    attacker_id: str,
    defender_id: str,
    attacker_blade_speed: float,
    defender_blade_speed: float,
    coverage: GuardCoverage,
    defender_reaction_lag: float,
    defender_guard_intentional: bool,
    defender_stamina_ratio: float,
    defender_balance_ratio: float,
    defender_attack_phase: AttackPhase,
    is_attacker_committed: bool,
) -> ContactResult:
    """The central contact-classification decision tree (design doc §08,
    §10-11). `defender_reaction_lag` is how late (seconds, can be
    negative meaning early) the defender's guard arrived relative to the
    ideal parry moment; `coverage` is the guard-vs-attack-line alignment
    from combat.guard.coverage_against.
    """
    # A defender who is themselves mid-attack (committed) cannot parry —
    # at best this becomes a mutual/edge contact or a bind.
    defender_can_parry = defender_attack_phase in (AttackPhase.NONE, AttackPhase.RECOVERY) or not is_attacker_committed

    closing_speed = attacker_blade_speed + defender_blade_speed

    if not defender_guard_intentional or coverage.exposed:
        ctype = ContactType.DIRECT_CONTACT
    elif not defender_can_parry:
        ctype = ContactType.EDGE_CONTACT
    elif defender_reaction_lag < 0 and abs(defender_reaction_lag) <= PERFECT_PARRY_WINDOW and coverage.alignment > 0.85:
        ctype = ContactType.PERFECT_PARRY
    elif abs(defender_reaction_lag) <= PERFECT_PARRY_WINDOW and coverage.alignment > 0.7:
        ctype = ContactType.PARRY
    elif defender_reaction_lag <= LATE_BLOCK_WINDOW and coverage.alignment > 0.45:
        ctype = ContactType.CLEAN_BLOCK if coverage.alignment > 0.6 else ContactType.GLANCING_BLOCK
    elif defender_reaction_lag > LATE_BLOCK_WINDOW:
        ctype = ContactType.FAILED_PARRY
    else:
        ctype = ContactType.GLANCING_BLOCK

    # Sustained near-zero relative velocity at high mutual force reads as a
    # bind (blade lock) rather than a deflecting parry.
    if closing_speed < 0.6 and coverage.alignment > 0.6 and defender_can_parry:
        ctype = ContactType.BLADE_LOCK

    result = ContactResult(
        contact_type=ctype,
        contact_point=geometry.contact_point,
        contact_normal=geometry.contact_normal,
        attacker_id=attacker_id,
        defender_id=defender_id,
    )

    _apply_physics_response(result, closing_speed, coverage, defender_stamina_ratio, defender_balance_ratio)
    return result


def _apply_physics_response(
    result: ContactResult,
    closing_speed: float,
    coverage: GuardCoverage,
    defender_stamina_ratio: float,
    defender_balance_ratio: float,
) -> None:
    n = normalize(result.contact_normal)
    energy = clamp(closing_speed * 0.35, 0.0, 12.0)
    fatigue_penalty = clamp(1.6 - defender_stamina_ratio, 0.6, 1.6)
    balance_penalty = clamp(1.6 - defender_balance_ratio, 0.6, 1.6)

    ct = result.contact_type
    if ct == ContactType.PERFECT_PARRY:
        result.deflection = n * energy * 1.6
        result.attacker_stagger = energy * 1.1
        result.attacker_recoil = energy * 1.4
        result.defender_recoil = energy * 0.15
        result.opening_for_defender = clamp(0.55 + energy * 0.04, 0.0, 1.0)
        result.counter_window = 0.45
    elif ct == ContactType.PARRY:
        result.deflection = n * energy * 1.1
        result.attacker_stagger = energy * 0.5
        result.attacker_recoil = energy * 0.8
        result.defender_recoil = energy * 0.25
        result.opening_for_defender = clamp(0.3 + energy * 0.03, 0.0, 0.75)
        result.counter_window = 0.28
    elif ct == ContactType.CLEAN_BLOCK:
        result.deflection = n * energy * 0.6
        result.defender_recoil = energy * 0.5 * fatigue_penalty
        result.attacker_recoil = energy * 0.3
        result.opening_for_defender = clamp(0.12 + energy * 0.015, 0.0, 0.4)
        result.counter_window = 0.15
    elif ct == ContactType.GLANCING_BLOCK:
        result.deflection = n * energy * 0.3
        result.defender_recoil = energy * 0.7 * fatigue_penalty
        result.defender_stagger = energy * 0.25 * balance_penalty
        result.opening_for_attacker = clamp(0.15, 0.0, 0.5)
    elif ct == ContactType.EDGE_CONTACT:
        result.deflection = n * energy * 0.2
        result.defender_stagger = energy * 0.4 * balance_penalty
        result.attacker_stagger = energy * 0.2
    elif ct == ContactType.FAILED_PARRY:
        result.defender_stagger = energy * 0.95 * fatigue_penalty * balance_penalty
        result.defender_recoil = energy * 1.1
        result.opening_for_attacker = clamp(0.5 + energy * 0.05, 0.0, 1.0)
        result.counter_window = 0.4
    elif ct == ContactType.DIRECT_CONTACT:
        result.defender_stagger = energy * 1.3 * fatigue_penalty * balance_penalty
        result.opening_for_attacker = clamp(0.7 + energy * 0.05, 0.0, 1.0)
        result.counter_window = 0.5
    elif ct == ContactType.BLADE_LOCK:
        result.deflection = n * 0.0
        result.attacker_recoil = 0.0
        result.defender_recoil = 0.0
        # Blade lock resolution (who wins the press) is handled by
        # combat.duel using relative stamina/stance — this just marks it.
    elif ct == ContactType.DISARM_ATTEMPT:
        result.defender_recoil = energy * 1.6
        result.opening_for_attacker = 0.9


def resolve_blade_lock(attacker_power: float, defender_power: float) -> float:
    """Returns a value in [-1, 1]: positive means the attacker wins the
    bind and pushes through (defender staggers), negative means the
    defender wins it and reverses the attacker (design doc §09)."""
    total = max(attacker_power + defender_power, 1e-6)
    return clamp((attacker_power - defender_power) / total, -1.0, 1.0)
