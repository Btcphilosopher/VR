"""
aurek_saber.combat.duel
=========================
design doc §77, §101, §112. `DuelSimulation` is the authoritative tick
loop that ties every layer together:

    OBSERVE -> intent (AI decision or external/player) -> footwork ->
    blade transform -> continuous collision -> contact classification ->
    physical response -> events -> opponent-model update -> DuelState.

Nothing here is animation-driven: every consequence traces back to real
blade geometry, guard alignment, stamina and balance.
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import Dict, Optional

from ..ai.decision import AIDecision, AIDecisionLoop
from ..ai.personality import DIFFICULTY_TABLE, ARCHETYPE_PRESETS, Archetype, Difficulty, DuelistPersonality
from ..character.controller import CombatantController
from ..character.reaction import generate_reaction
from ..core.enums import (
    AttackPhase,
    CombatantDuelState,
    CombatIntent,
    ConsequenceType,
    ContactType,
    DistanceZone,
    DuelOutcome,
    GuardZone,
    Stance,
)
from ..core.events import CombatEvent, EventBus, EventType
from ..core.math import Vec3, length, normalize, vec3
from .balance import CombatBalance
from .blade import SaberBlade, SaberHandle
from .collision import sweep_blade_blade, sweep_blade_capsule
from .distance import CombatDistanceController, DistancePreferences, classify_distance
from .guard import coverage_against, guard_pose_offset
from .parry import ContactResult, classify_contact
from .stamina import StaminaModel

HITS_TO_DEFEAT = 3
CRITICAL_POWER_THRESHOLD = 0.85
BODY_CAPSULE_RADIUS = 0.20


@dataclass
class FighterSpec:
    combatant_id: str
    position: Vec3
    forward: Vec3
    archetype: Optional[Archetype] = None
    personality: Optional[DuelistPersonality] = None
    difficulty: Difficulty = Difficulty.NORMAL
    stance: Stance = Stance.NEUTRAL
    distance_prefs: DistancePreferences = field(default_factory=DistancePreferences)
    is_ai: bool = True

    def resolve_personality(self) -> DuelistPersonality:
        if self.personality is not None:
            return self.personality
        if self.archetype is not None:
            return ARCHETYPE_PRESETS[self.archetype]
        return ARCHETYPE_PRESETS[Archetype.DUELIST]


def _build_controller(spec: FighterSpec) -> CombatantController:
    ctrl = CombatantController(
        combatant_id=spec.combatant_id,
        position=spec.position.copy(),
        body_forward=normalize(spec.forward),
        stance=spec.stance,
        stamina=StaminaModel(),
        balance=CombatBalance(),
        distance_ctrl=CombatDistanceController(spec.distance_prefs),
        blade=SaberBlade(owner_id=spec.combatant_id),
        handle=SaberHandle(),
    )
    return ctrl


@dataclass
class DuelSimulation:
    duel_id: str
    fighter_a_spec: FighterSpec
    fighter_b_spec: FighterSpec
    seed: int = 0

    def __post_init__(self) -> None:
        self.rng = random.Random(self.seed)
        self.events = EventBus()
        self.tick_index = 0
        self.sim_time = 0.0
        self.outcome = DuelOutcome.ONGOING
        self.intensity = 0.0

        self.controllers: Dict[str, CombatantController] = {
            self.fighter_a_spec.combatant_id: _build_controller(self.fighter_a_spec),
            self.fighter_b_spec.combatant_id: _build_controller(self.fighter_b_spec),
        }
        self.ai: Dict[str, Optional[AIDecisionLoop]] = {}
        for spec in (self.fighter_a_spec, self.fighter_b_spec):
            if spec.is_ai:
                personality = spec.resolve_personality()
                difficulty_mods = DIFFICULTY_TABLE[spec.difficulty]
                self.ai[spec.combatant_id] = AIDecisionLoop(personality, difficulty_mods, seed=self.rng.randint(0, 1 << 30))
            else:
                self.ai[spec.combatant_id] = None

        self.external_intents: Dict[str, CombatIntent] = {cid: CombatIntent.WAIT for cid in self.controllers}
        self.external_attack: Dict[str, tuple] = {}  # cid -> (AttackType, GuardZone, is_feint)
        self.hit_counts: Dict[str, int] = {cid: 0 for cid in self.controllers}
        self.last_decisions: Dict[str, AIDecision] = {}

        self.events.publish(CombatEvent(EventType.DUEL_STARTED, 0, 0.0, source=self.duel_id))

    # ---------------------------------------------------------- public API
    def ids(self):
        return list(self.controllers.keys())

    def other_id(self, cid: str) -> str:
        return next(k for k in self.controllers if k != cid)

    def set_external_intent(self, cid: str, intent: CombatIntent, attack_type=None, target_zone: Optional[GuardZone] = None, is_feint: bool = False) -> None:
        """Used by a player-driven or scripted fighter (design doc §79)."""
        self.external_intents[cid] = intent
        if attack_type is not None:
            self.external_attack[cid] = (attack_type, target_zone, is_feint)

    def is_over(self) -> bool:
        return self.outcome != DuelOutcome.ONGOING

    # --------------------------------------------------------------- tick
    def tick(self, dt: float) -> None:
        if self.is_over():
            return
        self.tick_index += 1
        self.sim_time += dt

        a_id, b_id = self.ids()
        a, b = self.controllers[a_id], self.controllers[b_id]
        distance = length(a.position - b.position)
        zone = classify_distance(distance)

        decisions: Dict[str, AIDecision] = {}
        for cid, ctrl in self.controllers.items():
            opp = self.controllers[self.other_id(cid)]
            ai = self.ai[cid]
            if ai is not None:
                ai.observe(self.sim_time, opp, ctrl.position)
                decision = ai.decide(self.sim_time, ctrl, opp, distance, zone)
            else:
                intent = self.external_intents.get(cid, CombatIntent.WAIT)
                atk = self.external_attack.pop(cid, None)
                decision = AIDecision(intent=intent)
                if atk is not None:
                    decision.attack_type, decision.target_zone, decision.is_feint = atk
            decisions[cid] = decision
            self.last_decisions[cid] = decision

        for cid, ctrl in self.controllers.items():
            self._apply_decision(cid, ctrl, decisions[cid])

        for cid, ctrl in self.controllers.items():
            opp = self.controllers[self.other_id(cid)]
            ctrl.update_footwork(dt, decisions[cid].intent, opp.position, distance)

        for ctrl in self.controllers.values():
            ctrl.update_blade(dt)

        self._resolve_contacts(dt, a, b)

        for ctrl in self.controllers.values():
            ctrl.tick(dt)

        self._update_duel_states(a, b, distance)
        self._update_intensity(dt)
        self._check_outcome(a_id, b_id)

    # -------------------------------------------------------- intent apply
    def _apply_decision(self, cid: str, ctrl: CombatantController, decision: AIDecision) -> None:
        intent = decision.intent
        if intent in (CombatIntent.ATTACK, CombatIntent.FEINT, CombatIntent.COUNTER):
            if ctrl.can_start_action() and not ctrl.is_attacking() and decision.attack_type is not None:
                zone = decision.target_zone or GuardZone.CENTER
                offset = guard_pose_offset(zone)
                started = ctrl.try_begin_attack(decision.attack_type, offset, as_feint=decision.is_feint, target_zone=zone)
                if started:
                    self.events.publish(CombatEvent(
                        EventType.ATTACK_STARTED, self.tick_index, self.sim_time,
                        source=cid, data={"target_zone": zone, "attack_type": decision.attack_type, "feint": decision.is_feint},
                    ))
        elif intent == CombatIntent.PARRY:
            if not ctrl.is_attacking():
                ai = self.ai[cid]
                predicted_zone = ai.last_prediction.predicted_zone if ai and ai.last_prediction else None
                if predicted_zone is not None:
                    ctrl.guard = predicted_zone
                ctrl.duel_state = CombatantDuelState.DEFENDING
        elif intent == CombatIntent.RETREAT:
            if ctrl.duel_state not in (CombatantDuelState.STAGGERED,):
                ctrl.duel_state = CombatantDuelState.RETREATING
                self.events.publish(CombatEvent(EventType.RETREAT, self.tick_index, self.sim_time, source=cid))

        # Feint payoff: once committed and past the abortable window, turn
        # it into a real attack aimed at the opposite zone (design doc §17).
        if ctrl.current_attack is not None and ctrl.current_attack.is_feint and ctrl.current_attack.can_abort() is False:
            new_zone = _opposite_zone(ctrl.current_attack.target_zone or GuardZone.CENTER)
            redirected = ctrl.try_feint_redirect(_attack_type_for_zone(new_zone), guard_pose_offset(new_zone))
            if redirected:
                ctrl.current_attack.target_zone = new_zone
                self.events.publish(CombatEvent(EventType.FEINT, self.tick_index, self.sim_time, source=cid, data={"redirect_zone": new_zone}))

    # ------------------------------------------------------------ contact
    def _resolve_contacts(self, dt: float, a: CombatantController, b: CombatantController) -> None:
        a_active = a.is_attacking() and a.current_attack.is_in_contact_window() and not a.current_attack.contact_resolved
        b_active = b.is_attacking() and b.current_attack.is_in_contact_window() and not b.current_attack.contact_resolved

        if not a_active and not b_active:
            return

        blade_geom = sweep_blade_blade(a.blade, b.blade) if (a.blade.is_ignited() and b.blade.is_ignited()) else None

        if a_active and b_active:
            self._resolve_mutual_clash(a, b, blade_geom)
            return

        attacker, defender = (a, b) if a_active else (b, a)
        attacker_id, defender_id = attacker.combatant_id, defender.combatant_id

        if blade_geom is not None:
            self._resolve_blade_contact(attacker, defender, blade_geom)
            return

        # No blade-to-blade contact: check whether the attack instead
        # lands on the defender's body (guard genuinely missed it).
        capsule_a = defender.position + vec3(0, 1.55, 0)
        capsule_b = defender.position + vec3(0, 0.9, 0)
        body_geom = sweep_blade_capsule(attacker.blade, capsule_a, capsule_b, BODY_CAPSULE_RADIUS)
        if body_geom is not None:
            self._resolve_body_hit(attacker, defender, body_geom)
        elif attacker.current_attack.phase == AttackPhase.RECOVERY:
            self.events.publish(CombatEvent(EventType.ATTACK_MISSED, self.tick_index, self.sim_time, source=attacker_id, target=defender_id))
            attacker.current_attack.contact_resolved = True

    def _resolve_blade_contact(self, attacker: CombatantController, defender: CombatantController, geom) -> None:
        target_zone = attacker.current_attack.target_zone or GuardZone.CENTER
        coverage = coverage_against(defender.guard, target_zone)
        defender_intentional = defender.duel_state != CombatantDuelState.STAGGERED and not defender.is_attacking()
        reaction_lag = self._estimate_reaction_lag(defender, coverage)

        result = classify_contact(
            geom, attacker.combatant_id, defender.combatant_id,
            attacker.blade.tip_speed, defender.blade.tip_speed,
            coverage, reaction_lag, defender_intentional,
            defender.stamina.ratio, defender.balance.stability_factor(),
            defender.current_attack.phase if defender.current_attack else AttackPhase.NONE,
            is_attacker_committed=True,
        )
        attacker.current_attack.contact_resolved = True
        self._apply_contact_result(attacker, defender, result)

    def _resolve_mutual_clash(self, a: CombatantController, b: CombatantController, geom) -> None:
        if geom is None:
            return
        energy = (a.blade.tip_speed + b.blade.tip_speed) * 0.3
        for who in (a, b):
            reaction = generate_reaction(ContactType.EDGE_CONTACT, geom.contact_normal, energy, who.balance.value, who.balance.stance_width, False)
            who.apply_reaction(reaction.kind, reaction.duration, reaction.impulse_direction, reaction.impulse_magnitude, reaction.torque)
            who.stamina.spend(4.0)
            who.current_attack.contact_resolved = True
        self.events.publish(CombatEvent(EventType.BLADE_CONTACT, self.tick_index, self.sim_time, source=a.combatant_id, target=b.combatant_id, data={"contact_type": "MUTUAL_CLASH"}))

    def _resolve_body_hit(self, attacker: CombatantController, defender: CombatantController, geom) -> None:
        attacker.current_attack.contact_resolved = True
        power = attacker.current_attack.power
        consequence = ConsequenceType.CRITICAL_CONTACT if power >= CRITICAL_POWER_THRESHOLD else ConsequenceType.CLEAN_CONTACT
        result = ContactResult(
            contact_type=ContactType.DIRECT_CONTACT,
            contact_point=geom.contact_point,
            contact_normal=geom.contact_normal,
            attacker_id=attacker.combatant_id,
            defender_id=defender.combatant_id,
        )
        result.defender_stagger = 6.0 + power * 8.0
        result.opening_for_attacker = 0.8
        self._apply_contact_result(attacker, defender, result, consequence=consequence)

    def _apply_contact_result(self, attacker: CombatantController, defender: CombatantController, result: ContactResult, consequence: ConsequenceType = ConsequenceType.NONE) -> None:
        impact_dir = normalize(defender.position - attacker.position, defender.body_forward)
        defender_moving_forward = float(defender.velocity @ defender.body_forward) > 0.1

        reaction = generate_reaction(
            result.contact_type, impact_dir, attacker.blade.tip_speed,
            defender.balance.value, defender.balance.stance_width, defender_moving_forward,
        )
        defender.apply_reaction(reaction.kind, reaction.duration, reaction.impulse_direction, reaction.impulse_magnitude, reaction.torque, reaction.turn_toward_attacker)
        defender.spend_defense_cost(was_parry=result.contact_type in (ContactType.PARRY, ContactType.PERFECT_PARRY))

        attacker.balance.apply_impulse(-impact_dir, result.attacker_recoil * 0.3, result.attacker_stagger * 0.2)

        if result.contact_type in (ContactType.PERFECT_PARRY, ContactType.PARRY, ContactType.CLEAN_BLOCK, ContactType.GLANCING_BLOCK, ContactType.EDGE_CONTACT):
            attacker.abort_attack()

        event_type = {
            ContactType.PERFECT_PARRY: EventType.PERFECT_PARRY,
            ContactType.PARRY: EventType.PARRY,
            ContactType.CLEAN_BLOCK: EventType.BLOCK,
            ContactType.GLANCING_BLOCK: EventType.BLOCK,
            ContactType.FAILED_PARRY: EventType.FAILED_PARRY,
            ContactType.DIRECT_CONTACT: EventType.HIT,
            ContactType.EDGE_CONTACT: EventType.BLADE_CONTACT,
            ContactType.BLADE_LOCK: EventType.BLADE_LOCK,
        }.get(result.contact_type, EventType.BLADE_CONTACT)

        self.events.publish(CombatEvent(
            event_type, self.tick_index, self.sim_time,
            source=attacker.combatant_id, target=defender.combatant_id,
            data={"contact_type": result.contact_type.name, "consequence": consequence.name},
        ))

        if result.contact_type in (ContactType.DIRECT_CONTACT, ContactType.FAILED_PARRY):
            self.hit_counts[defender.combatant_id] += 1

        # Feed openings back into whichever AI should feel them.
        if result.opening_for_defender > 0.25:
            ai = self.ai.get(defender.combatant_id)
            if ai:
                ai.notify_opening(result.opening_for_defender)
        if result.opening_for_attacker > 0.25:
            ai = self.ai.get(attacker.combatant_id)
            if ai:
                ai.notify_opening(result.opening_for_attacker)

        # Update opponent models: each AI updates its model of the *other* fighter.
        for cid, ai in self.ai.items():
            if ai is None:
                continue
            other = self.other_id(cid)
            stamina_ratio = self.controllers[other].stamina.ratio
            ai.model.observe_event(self.events.log[-1], other, stamina_ratio)

    def _estimate_reaction_lag(self, defender: CombatantController, coverage) -> float:
        """Approximates parry timing quality from guard alignment and the
        defender's precision — a genuine (if simplified) stand-in for
        "was the blade there at the right instant" (design doc §10-11)."""
        base = 0.22 - coverage.alignment * 0.3
        ai = self.ai.get(defender.combatant_id)
        precision = ai.personality.precision if ai else 0.6
        base -= precision * 0.15
        base += self.rng.gauss(0, 0.04)
        return base

    # ------------------------------------------------------------- upkeep
    def _update_duel_states(self, a: CombatantController, b: CombatantController, distance: float) -> None:
        for ctrl in (a, b):
            if ctrl.duel_state == CombatantDuelState.STAGGERED:
                continue
            if ctrl.is_attacking():
                ctrl.duel_state = CombatantDuelState.ATTACKING
            elif distance > ctrl.distance_ctrl.prefs.attack * 1.8:
                ctrl.duel_state = CombatantDuelState.AWARE
            else:
                ctrl.duel_state = CombatantDuelState.ENGAGED

    def _update_intensity(self, dt: float) -> None:
        recent_window = self.sim_time - 2.0
        recent_events = sum(1 for e in self.events.log if e.time >= recent_window and e.type in (
            EventType.BLADE_CONTACT, EventType.PARRY, EventType.PERFECT_PARRY, EventType.HIT, EventType.FAILED_PARRY,
        ))
        target = min(1.0, recent_events / 6.0)
        self.intensity += (target - self.intensity) * min(1.0, dt * 2.0)

    def _check_outcome(self, a_id: str, b_id: str) -> None:
        for loser_id, winner_id in ((a_id, b_id), (b_id, a_id)):
            if self.hit_counts[loser_id] >= HITS_TO_DEFEAT:
                self.controllers[loser_id].duel_state = CombatantDuelState.DEFEATED
                self.outcome = DuelOutcome.DEFEATED
                self.events.publish(CombatEvent(EventType.DUEL_ENDED, self.tick_index, self.sim_time, source=winner_id, target=loser_id, data={"outcome": "DEFEATED"}))
                return


def _opposite_zone(zone: GuardZone) -> GuardZone:
    table = {
        GuardZone.HIGH_LEFT: GuardZone.LOW_RIGHT,
        GuardZone.HIGH_RIGHT: GuardZone.LOW_LEFT,
        GuardZone.LOW_LEFT: GuardZone.HIGH_RIGHT,
        GuardZone.LOW_RIGHT: GuardZone.HIGH_LEFT,
        GuardZone.CENTER: GuardZone.HIGH_LEFT,
        GuardZone.OPEN: GuardZone.CENTER,
    }
    return table.get(zone, GuardZone.CENTER)


def _attack_type_for_zone(zone: GuardZone):
    from ..core.enums import AttackType
    table = {
        GuardZone.HIGH_LEFT: AttackType.DIAGONAL,
        GuardZone.HIGH_RIGHT: AttackType.DIAGONAL,
        GuardZone.LOW_LEFT: AttackType.RISING,
        GuardZone.LOW_RIGHT: AttackType.RISING,
        GuardZone.CENTER: AttackType.THRUST,
    }
    return table.get(zone, AttackType.HORIZONTAL)
