"""
aurek_saber.combat.balance
=============================
design doc §30. A crude but genuine physical balance model: centre-of-mass
offset from a support polygon, plus angular momentum injected by
impacts/pushes, decaying back toward a stable stance every tick unless it's
pushed past a recovery threshold, in which case the fighter staggers.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..core.math import ZERO, Vec3, clamp, length


STAGGER_THRESHOLD = 45.0  # balance below this triggers a stagger reaction
FALL_THRESHOLD = 10.0  # balance below this risks a knockdown


@dataclass
class CombatBalance:
    value: float = 100.0  # 100 = perfect, 0 = fallen
    com_offset: Vec3 = field(default_factory=lambda: ZERO.copy())  # centre-of-mass offset from support polygon centre
    angular_momentum: float = 0.0  # residual spin/lean, rad/s equivalent
    stance_width: float = 0.42  # metres; wider stance = larger support polygon = more stable

    def apply_impulse(self, direction: Vec3, magnitude: float, torque: float = 0.0) -> None:
        """An external shove — a blade impact, a failed parry recoil, a
        Force push — displaces the centre of mass and/or adds angular
        momentum. Support-polygon size (stance width) resists it."""
        resistance = clamp(self.stance_width / 0.42, 0.6, 1.8)
        self.com_offset = self.com_offset + direction * (magnitude / resistance) * 0.01
        self.angular_momentum += torque / resistance
        offset_mag = length(self.com_offset)
        self.value = clamp(self.value - magnitude * (1.0 / resistance) - abs(torque) * 0.5, 0.0, 100.0)

    def tick(self, dt: float, recovery_multiplier: float = 1.0) -> None:
        """Balance recovers toward 100 unless actively being disrupted;
        recovery_multiplier > 1 (from fatigue/stamina.py) slows this."""
        recover_rate = 55.0 / recovery_multiplier
        self.value = clamp(self.value + recover_rate * dt, 0.0, 100.0)

        # centre-of-mass and spin bleed off exponentially
        decay = clamp(1.0 - 3.0 * dt, 0.0, 1.0)
        self.com_offset = self.com_offset * decay
        self.angular_momentum *= decay

    def is_staggered(self) -> bool:
        return self.value < STAGGER_THRESHOLD

    def is_falling(self) -> bool:
        return self.value < FALL_THRESHOLD

    def stability_factor(self) -> float:
        """0..1, used to scale guard alignment / attack accuracy — an
        unbalanced fighter fights and defends worse (design doc §30)."""
        return clamp(self.value / 100.0, 0.0, 1.0)
