"""
aurek_saber.animation.procedural
===================================
design doc §16, §28. This engine has no skeletal renderer or motion-
matching database — those are genuinely engine/asset features (Unreal,
Unity, a custom C++/Rust runtime) outside what a pure-Python simulation
core can deliver. What *is* deliverable, and genuinely useful to a
downstream renderer, is the procedural layer described in §16: a small
pose-blending utility keyed by named joint targets, driven by the same
simulation signals (attack phase progress, balance, stamina) that already
drive everything else — so a rig integration gets numeric pose data that
already reflects real physical state instead of re-deriving it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

Pose = Dict[str, float]  # joint name -> scalar (angle/blend weight), a minimal placeholder for a full transform track


def blend_poses(a: Pose, b: Pose, t: float) -> Pose:
    keys = set(a) | set(b)
    out: Pose = {}
    for k in keys:
        va, vb = a.get(k, 0.0), b.get(k, 0.0)
        out[k] = va + (vb - va) * max(0.0, min(1.0, t))
    return out


@dataclass
class LayeredPose:
    """design doc §28 animation layers. Each layer contributes a pose and
    a blend weight; layers combine additively over locomotion so e.g. a
    reaction layer can perturb the arms without discarding leg motion."""

    locomotion: Pose = field(default_factory=dict)
    body: Pose = field(default_factory=dict)
    arms: Pose = field(default_factory=dict)
    weapon: Pose = field(default_factory=dict)
    reaction: Pose = field(default_factory=dict)
    reaction_weight: float = 0.0

    def composite(self) -> Pose:
        base = blend_poses(self.locomotion, self.body, 1.0)
        base = blend_poses(base, self.arms, 1.0)
        base = blend_poses(base, self.weapon, 1.0)
        if self.reaction_weight > 0:
            base = blend_poses(base, self.reaction, self.reaction_weight)
        return base


def attack_pose_from_progress(phase_name: str, progress: float) -> Pose:
    """A minimal, honestly-labelled stand-in for the "same attack looks
    different by distance/angle/body orientation" requirement (§16):
    a real rig would drive this from IK targets (character.ik) rather
    than fixed joint curves. Exposed mainly so tests/replay tooling have
    *something* numeric to sample per tick."""
    import math

    swing = math.sin(progress * math.pi)
    return {
        "shoulder_flex": swing * 0.8,
        "elbow_flex": swing * 0.5,
        "wrist_roll": progress,
        "torso_twist": swing * 0.3,
        "phase": {"WINDUP": 0.0, "ACCELERATION": 0.25, "CONTACT": 0.5, "FOLLOW_THROUGH": 0.75, "RECOVERY": 1.0}.get(phase_name, 0.0),
    }
