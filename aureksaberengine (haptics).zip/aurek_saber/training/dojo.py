"""
aurek_saber.training.dojo
============================
design doc §62-63. DUELING_DOJO: run scripted/AI training scenarios on top
of the same DuelSimulation used for real duels, and collect analytics from
the real event stream — there is no separate "training-only" simulation
path, matching the "simulation is authoritative" rule (design doc §90).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from ..ai.personality import Archetype, Difficulty
from ..combat.distance import DistancePreferences
from ..combat.duel import DuelSimulation, FighterSpec
from ..core.enums import CombatIntent
from ..core.events import EventType
from ..core.math import vec3


@dataclass
class TrainingAnalytics:
    """design doc §63."""

    reaction_times: List[float] = field(default_factory=list)
    parries_attempted: int = 0
    parries_succeeded: int = 0
    attacks_attempted: int = 0
    attacks_landed: int = 0
    guard_failures: int = 0
    successful_counters: int = 0
    distance_samples: List[float] = field(default_factory=list)
    stamina_samples: List[float] = field(default_factory=list)

    def parry_rate(self) -> float:
        return self.parries_succeeded / self.parries_attempted if self.parries_attempted else 0.0

    def attack_accuracy(self) -> float:
        return self.attacks_landed / self.attacks_attempted if self.attacks_attempted else 0.0

    def average_distance_error(self, preferred: float) -> float:
        if not self.distance_samples:
            return 0.0
        return sum(abs(d - preferred) for d in self.distance_samples) / len(self.distance_samples)

    def average_stamina_usage(self) -> float:
        if not self.stamina_samples:
            return 0.0
        return 1.0 - (sum(self.stamina_samples) / len(self.stamina_samples))

    def summary(self) -> Dict[str, float]:
        return {
            "parry_rate": self.parry_rate(),
            "attack_accuracy": self.attack_accuracy(),
            "guard_failures": self.guard_failures,
            "successful_counters": self.successful_counters,
            "avg_stamina_usage": self.average_stamina_usage(),
        }


class DuelingDojo:
    """Wraps a DuelSimulation with a chosen scenario and wires analytics
    off the real event bus (design doc §62-63)."""

    def __init__(self, player_id: str = "player", opponent_id: str = "opponent"):
        self.player_id = player_id
        self.opponent_id = opponent_id
        self.analytics = TrainingAnalytics()
        self.sim: DuelSimulation = None  # type: ignore[assignment]

    def start_static_target(self) -> DuelSimulation:
        """A stationary, non-attacking target — pure attack-accuracy and
        distance-control practice."""
        return self._start(opponent_archetype=Archetype.DEFENDER, opponent_difficulty=Difficulty.EASY, opponent_is_ai=False)

    def start_training_droid(self, difficulty: Difficulty = Difficulty.EASY) -> DuelSimulation:
        """A simple scripted-feeling opponent (DEFENDER archetype at low
        difficulty): attacks rarely, parries predictably."""
        return self._start(opponent_archetype=Archetype.DEFENDER, opponent_difficulty=difficulty, opponent_is_ai=True)

    def start_apprentice(self) -> DuelSimulation:
        return self._start(opponent_archetype=Archetype.DUELIST, opponent_difficulty=Difficulty.NORMAL, opponent_is_ai=True)

    def start_master(self) -> DuelSimulation:
        return self._start(opponent_archetype=Archetype.MASTER, opponent_difficulty=Difficulty.MASTER, opponent_is_ai=True)

    def _start(self, opponent_archetype: Archetype, opponent_difficulty: Difficulty, opponent_is_ai: bool) -> DuelSimulation:
        player_spec = FighterSpec(
            combatant_id=self.player_id, position=vec3(0, 0, -1.0), forward=vec3(0, 0, 1),
            is_ai=True, archetype=Archetype.DUELIST, difficulty=Difficulty.NORMAL,
        )
        opponent_spec = FighterSpec(
            combatant_id=self.opponent_id, position=vec3(0, 0, 1.0), forward=vec3(0, 0, -1),
            is_ai=opponent_is_ai, archetype=opponent_archetype, difficulty=opponent_difficulty,
        )
        self.sim = DuelSimulation(duel_id="dojo", fighter_a_spec=player_spec, fighter_b_spec=opponent_spec)
        self.sim.events.subscribe_all(self._on_event)
        return self.sim

    def _on_event(self, event) -> None:
        a = self.analytics
        if event.type == EventType.ATTACK_STARTED:
            if event.source == self.player_id:
                a.attacks_attempted += 1
        elif event.type == EventType.HIT:
            if event.source == self.player_id:
                a.attacks_landed += 1
            elif event.target == self.player_id:
                a.guard_failures += 1
        elif event.type in (EventType.PARRY, EventType.PERFECT_PARRY, EventType.BLOCK):
            if event.target == self.player_id:
                a.parries_attempted += 1
                a.parries_succeeded += 1
        elif event.type == EventType.FAILED_PARRY and event.target == self.player_id:
            a.parries_attempted += 1
            a.guard_failures += 1
        elif event.type == EventType.COUNTER and event.source == self.player_id:
            a.successful_counters += 1

    def sample_tick(self) -> None:
        if self.sim is None:
            return
        player = self.sim.controllers[self.player_id]
        opp = self.sim.controllers[self.opponent_id]
        dist = float(((player.position - opp.position) ** 2).sum() ** 0.5)
        self.analytics.distance_samples.append(dist)
        self.analytics.stamina_samples.append(player.stamina.ratio)
