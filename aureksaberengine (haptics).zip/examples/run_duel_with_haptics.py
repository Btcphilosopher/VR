#!/usr/bin/env python3
"""
AUREK SABER ENGINE — haptics integration demo.

Runs one AI-vs-AI duel exactly like `run_duel.py`, but also drives a
`HapticsController` alongside it and logs the resolved dual-motor rumble
values for both fighters whenever they change meaningfully — so you can
see (read: hear-as-text) the haptic feed react to parries, hits, feints,
low stamina and critical balance without any controller hardware
attached.

Usage:
    python examples/run_duel_with_haptics.py
    python examples/run_duel_with_haptics.py --seed 3 --a-archetype BERSERKER --b-archetype DEFENDER

Swap `LoggingHapticDevice` for a real backend once you have hardware:

    from aurek_saber.haptics.devices.sdl2_device import SDL2RumbleDevice
    devices = {"fighter_a": SDL2RumbleDevice(joystick_index=0)}
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.combat.duel import DuelSimulation, FighterSpec
from aurek_saber.core.clock import SIMULATION_DT
from aurek_saber.core.math import vec3
from aurek_saber.haptics.controller import HapticsController
from aurek_saber.haptics.devices.null_device import LoggingHapticDevice

MAX_TICKS = 120 * 45


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a duel with haptic feedback logging.")
    parser.add_argument("--seed", type=int, default=3)
    parser.add_argument("--a-archetype", default="AGGRESSOR")
    parser.add_argument("--b-archetype", default="DEFENDER")
    args = parser.parse_args()

    spec_a = FighterSpec(combatant_id="fighter_a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype[args.a_archetype], difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="fighter_b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype[args.b_archetype], difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id="haptics_demo", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=args.seed)

    haptics = HapticsController(sim, devices={
        "fighter_a": LoggingHapticDevice("A"),
        "fighter_b": LoggingHapticDevice("B"),
    })

    printed = 0
    for _ in range(MAX_TICKS):
        sim.tick(SIMULATION_DT)
        haptics.tick(SIMULATION_DT)

        while printed < len(sim.events.log):
            event = sim.events.log[printed]
            if event.data.get("contact_type") or event.type.name in ("FEINT", "DUEL_ENDED"):
                print(event)
            printed += 1

        if sim.is_over():
            break

    haptics.shutdown()
    print(f"\nDuel finished after {sim.tick_index} ticks ({sim.sim_time:.2f}s). Outcome: {sim.outcome.name}")


if __name__ == "__main__":
    main()
