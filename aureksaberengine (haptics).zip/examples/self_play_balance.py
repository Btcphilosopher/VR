#!/usr/bin/env python3
"""
AUREK SABER ENGINE — AI self-play & balancing harness (design doc §98-100).

Runs many simulated duels across personality-archetype matchups and
reports aggregate metrics: win rates, average duel length, parry rate,
attack success rate, average stamina remaining at duel end — the raw
material for deciding "is X too strong" (design doc §100).

Usage:
    python examples/self_play_balance.py --n 30
    python examples/self_play_balance.py --n 20 --matchups AGGRESSOR:DEFENDER MASTER:BERSERKER
"""

from __future__ import annotations

import argparse
import os
import statistics
import sys
from collections import Counter, defaultdict

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from aurek_saber.ai.personality import Archetype, Difficulty
from aurek_saber.combat.duel import DuelSimulation, FighterSpec
from aurek_saber.core.clock import SIMULATION_DT
from aurek_saber.core.events import EventType
from aurek_saber.core.math import vec3

MAX_TICKS = 120 * 40


def run_one(a_archetype: str, b_archetype: str, seed: int):
    spec_a = FighterSpec(combatant_id="a", position=vec3(0, 0, -1.1), forward=vec3(0, 0, 1), archetype=Archetype[a_archetype], difficulty=Difficulty.NORMAL)
    spec_b = FighterSpec(combatant_id="b", position=vec3(0, 0, 1.1), forward=vec3(0, 0, -1), archetype=Archetype[b_archetype], difficulty=Difficulty.NORMAL)
    sim = DuelSimulation(duel_id=f"self_play_{seed}", fighter_a_spec=spec_a, fighter_b_spec=spec_b, seed=seed)

    for _ in range(MAX_TICKS):
        sim.tick(SIMULATION_DT)
        if sim.is_over():
            break

    parries = sum(1 for e in sim.events.log if e.type in (EventType.PARRY, EventType.PERFECT_PARRY))
    parry_attempts = sum(1 for e in sim.events.log if e.type in (EventType.PARRY, EventType.PERFECT_PARRY, EventType.FAILED_PARRY, EventType.BLOCK))
    attacks = sum(1 for e in sim.events.log if e.type == EventType.ATTACK_STARTED)
    hits = sum(1 for e in sim.events.log if e.type == EventType.HIT)

    winner = None
    if sim.outcome.name == "DEFEATED":
        winner = "a" if sim.hit_counts["b"] > sim.hit_counts["a"] else "b"

    return {
        "ticks": sim.tick_index,
        "duration_s": sim.sim_time,
        "winner": winner,
        "attacks": attacks,
        "hits": hits,
        "parries": parries,
        "parry_attempts": parry_attempts,
        "stamina_a": sim.controllers["a"].stamina.ratio,
        "stamina_b": sim.controllers["b"].stamina.ratio,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=20, help="duels per matchup")
    parser.add_argument("--matchups", nargs="*", default=["AGGRESSOR:DEFENDER", "DUELIST:COUNTER_FIGHTER", "MASTER:BERSERKER", "TACTICIAN:ASSASSIN"])
    args = parser.parse_args()

    for matchup in args.matchups:
        a_name, b_name = matchup.split(":")
        results = [run_one(a_name, b_name, seed=1000 + i) for i in range(args.n)]

        win_counts = Counter(r["winner"] for r in results if r["winner"])
        durations = [r["duration_s"] for r in results]
        parry_rates = [r["parries"] / r["parry_attempts"] for r in results if r["parry_attempts"] > 0]
        attack_success = [r["hits"] / r["attacks"] for r in results if r["attacks"] > 0]

        print(f"\n=== {a_name} vs {b_name}  (n={args.n}) ===")
        print(f"  win rate:        a={win_counts.get('a', 0)}  b={win_counts.get('b', 0)}  undecided={args.n - sum(win_counts.values())}")
        print(f"  avg duel length: {statistics.mean(durations):.2f}s  (min {min(durations):.1f}s, max {max(durations):.1f}s)")
        if parry_rates:
            print(f"  avg parry rate:  {statistics.mean(parry_rates):.2%}")
        if attack_success:
            print(f"  avg atk success: {statistics.mean(attack_success):.2%}")
        print(f"  avg stamina left (winner side a): {statistics.mean(r['stamina_a'] for r in results):.2%}")


if __name__ == "__main__":
    main()
