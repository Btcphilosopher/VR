"""Passthrough camera abstraction (OpenCV experiments). Never assumes a camera exists."""

from __future__ import annotations

from typing import Protocol

import numpy as np


class PassthroughSource(Protocol):
    name: str

    def read(self) -> np.ndarray | None: ...

    def close(self) -> None: ...


class SyntheticPassthrough:
    """Procedural 'camera feed' of a dim room - deterministic; used when no camera is available."""

    name = "synthetic"

    def __init__(self, width: int = 640, height: int = 360, seed: int = 1) -> None:
        self.w, self.h = width, height
        self._rng = np.random.default_rng(seed)
        self._frame = 0

    def read(self) -> np.ndarray:
        self._frame += 1
        img = np.zeros((self.h, self.w, 3), dtype=np.uint8)
        y = np.linspace(0, 1, self.h)[:, None]
        img[..., 0] = (38 + 30 * y).astype(np.uint8)
        img[..., 1] = (40 + 28 * y).astype(np.uint8)
        img[..., 2] = (44 + 26 * y).astype(np.uint8)
        horizon = int(self.h * 0.62)
        img[horizon:, :, :] = (img[horizon:, :, :] * 0.8).astype(np.uint8)
        noise = self._rng.integers(-4, 5, size=img.shape, dtype=np.int16)
        return np.clip(img.astype(np.int16) + noise, 0, 255).astype(np.uint8)

    def close(self) -> None:
        return None


class OpenCVPassthrough:
    """Webcam via OpenCV. `open()` returns None if OpenCV or a camera is unavailable."""

    name = "opencv"

    def __init__(self, cap: object) -> None:
        self._cap = cap

    @staticmethod
    def open(index: int = 0) -> OpenCVPassthrough | None:
        try:
            import cv2

            cap = cv2.VideoCapture(index)
            if not cap.isOpened():
                cap.release()
                return None
            return OpenCVPassthrough(cap)
        except Exception:
            return None

    def read(self) -> np.ndarray | None:  # pragma: no cover - hardware dependent
        ok, frame = self._cap.read()  # type: ignore[attr-defined]
        return frame if ok else None

    def close(self) -> None:  # pragma: no cover
        self._cap.release()  # type: ignore[attr-defined]


def open_passthrough(prefer_camera: bool = False) -> PassthroughSource:
    if prefer_camera:
        cam = OpenCVPassthrough.open()
        if cam is not None:
            return cam
    return SyntheticPassthrough()
