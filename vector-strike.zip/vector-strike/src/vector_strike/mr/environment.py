"""MixedRealityEnvironment: the single object gameplay consumes to build MR content around a real room."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from ..physics.shapes import AABB
from ..physics.vec import Vec3
from .anchors import (
    Anchor,
    BreachPoint,
    CoverPointMR,
    Furniture,
    Plane,
    PlayArea,
    Portal,
    PortalKind,
    SafeZone,
    ScanMeta,
    SpatialObject,
    SpawnPoint,
    Surface,
    ValidationIssue,
)

MIN_FLOOR_AREA = 6.0
MIN_PLAY_AREA = (1.6, 1.6)  # metres (full width, depth)
MIN_CEILING = 2.0


@dataclass
class MixedRealityEnvironment:
    meta: ScanMeta
    width: float
    depth: float
    ceiling_height: float
    floor: Plane
    ceiling: Plane
    walls: list[Plane]
    portals: list[Portal] = field(default_factory=list)
    objects: list[SpatialObject] = field(default_factory=list)
    surfaces: list[Surface] = field(default_factory=list)
    anchors: list[Anchor] = field(default_factory=list)
    play_area: PlayArea = field(default_factory=lambda: PlayArea(Vec3(), 1.0, 1.0))
    safe_zones: list[SafeZone] = field(default_factory=list)

    # ---- queries ------------------------------------------------------------------------------
    @property
    def floor_area(self) -> float:
        return self.width * self.depth

    def wall(self, wall_id: str) -> Plane:
        return next(w for w in self.walls if w.id == wall_id)

    def portal_world(self, p: Portal) -> tuple[Vec3, Vec3]:
        """(position on wall plane, inward normal)."""
        w = self.wall(p.wall_id)
        d = (w.b - w.a).normalized()
        return w.a + d * p.along, w.normal

    def in_room(self, pos: Vec3, margin: float = 0.0) -> bool:
        return margin <= pos.x <= self.width - margin and margin <= pos.z <= self.depth - margin

    def blocked(self, pos: Vec3, radius: float) -> bool:
        probe = AABB(Vec3(pos.x - radius, 0.05, pos.z - radius), Vec3(pos.x + radius, 1.7, pos.z + radius))
        return any(o.box.intersects(probe) for o in self.objects)

    # ---- validation ----------------------------------------------------------------------------
    def validate(self) -> list[ValidationIssue]:
        issues: list[ValidationIssue] = []
        err = lambda c, m: issues.append(ValidationIssue("error", c, m))  # noqa: E731
        warn = lambda c, m: issues.append(ValidationIssue("warning", c, m))  # noqa: E731
        if self.floor_area < MIN_FLOOR_AREA:
            err("FLOOR_TOO_SMALL", f"floor area {self.floor_area:.1f} m2 < {MIN_FLOOR_AREA} m2")
        if self.ceiling_height < MIN_CEILING:
            err("CEILING_LOW", f"ceiling {self.ceiling_height:.2f} m < {MIN_CEILING} m")
        pa = self.play_area
        if pa.half_x * 2 < MIN_PLAY_AREA[0] or pa.half_z * 2 < MIN_PLAY_AREA[1]:
            err("PLAY_AREA_SMALL", "play area smaller than 1.6 x 1.6 m")
        if not (
            self.in_room(Vec3(pa.center.x - pa.half_x, 0, pa.center.z - pa.half_z), 0.2)
            and self.in_room(Vec3(pa.center.x + pa.half_x, 0, pa.center.z + pa.half_z), 0.2)
        ):
            err("PLAY_AREA_OUTSIDE", "play area is not inside the room with 0.2 m margin")
        for o in self.objects:
            b = o.box
            if b.min.x < -0.05 or b.min.z < -0.05 or b.max.x > self.width + 0.05 or b.max.z > self.depth + 0.05:
                err("OBJECT_OUTSIDE", f"{o.id} extends outside the room")
            if o.box.intersects(
                AABB(
                    Vec3(pa.center.x - pa.half_x, 0.05, pa.center.z - pa.half_z),
                    Vec3(pa.center.x + pa.half_x, 1.7, pa.center.z + pa.half_z),
                )
            ):
                warn("OBJECT_IN_PLAY_AREA", f"{o.id} intrudes into the play area")
            if o.confidence < 0.6:
                warn("LOW_CONFIDENCE", f"{o.id} confidence {o.confidence:.2f}")
        for i, first in enumerate(self.objects):
            for second in self.objects[i + 1 :]:
                if first.box.intersects(second.box):
                    warn("OBJECT_OVERLAP", f"{first.id} overlaps {second.id}")
        walls = {w.id: w for w in self.walls}
        for p in self.portals:
            w = walls.get(p.wall_id)
            if w is None:
                err("PORTAL_NO_WALL", f"{p.id} references missing wall {p.wall_id}")
                continue
            length = (w.b - w.a).length()
            if p.along - p.width / 2 < 0 or p.along + p.width / 2 > length:
                err("PORTAL_OFF_WALL", f"{p.id} does not fit on {p.wall_id}")
        if not any(p.kind is PortalKind.DOOR for p in self.portals):
            warn("NO_DOOR", "no door detected: room invasion falls back to breach points")
        if not self.derive_spawn_points():
            err("NO_SPAWN", "no valid floor spawn points")
        if not self.derive_breach_points() and not any(p.kind is PortalKind.DOOR for p in self.portals):
            err("NO_ENTRY", "no breach point or door available for hostiles")
        return issues

    def is_valid(self) -> bool:
        return not any(i.severity == "error" for i in self.validate())

    # ---- derived gameplay data ----------------------------------------------------------------
    def derive_spawn_points(
        self, count: int = 4, min_player_dist: float = 1.8, clearance: float = 0.45, step: float = 0.4
    ) -> list[SpawnPoint]:
        """Deterministic farthest-point sampling of valid floor positions."""
        cands: list[Vec3] = []
        x = clearance
        while x <= self.width - clearance:
            z = clearance
            while z <= self.depth - clearance:
                p = Vec3(x, 0, z)
                if not self.blocked(p, clearance) and p.dist_xz(self.play_area.center) >= min_player_dist:
                    cands.append(p)
                z += step
            x += step
        if not cands:
            return []
        chosen = [max(cands, key=lambda p: p.dist_xz(self.play_area.center))]
        while len(chosen) < count:
            nxt = max(cands, key=lambda p: min(p.dist_xz(c) for c in chosen))
            if min(nxt.dist_xz(c) for c in chosen) < 0.8:
                break
            chosen.append(nxt)
        return [SpawnPoint(f"floor_{i}", p, "floor") for i, p in enumerate(chosen)]

    def derive_breach_points(self, width: float = 1.4, max_points: int = 3) -> list[BreachPoint]:
        """Wall stretches wide enough, free of portals and tall furniture, where a virtual opening can appear."""
        out: list[BreachPoint] = []
        for w in self.walls:
            length = (w.b - w.a).length()
            d = (w.b - w.a).normalized()
            occupied = [
                (p.along - p.width / 2 - 1.0, p.along + p.width / 2 + 1.0) for p in self.portals if p.wall_id == w.id
            ]
            for o in self.objects:
                if o.height > 0.5:
                    bb = o.box
                    # project the object's footprint onto this wall if it is near it
                    c = bb.center
                    dist = abs((c - w.a).dot(w.normal))
                    if dist < 1.0:
                        t = (c - w.a).dot(d)
                        ext = (bb.size.x if abs(d.x) > 0.5 else bb.size.z) / 2
                        occupied.append((t - ext - 0.2, t + ext + 0.2))
            occupied.sort()
            cursor = 0.4
            best: tuple[float, float] | None = None
            for lo, hi in occupied + [(length - 0.4, length)]:
                if lo - cursor >= width and (best is None or lo - cursor > best[1] - best[0]):
                    best = (cursor, lo)
                cursor = max(cursor, hi)
            if best:
                mid = (best[0] + best[1]) / 2
                out.append(BreachPoint(f"breach_{w.id}", w.id, w.a + d * mid, w.normal, width))
        out.sort(key=lambda b: -b.pos.dist_xz(self.play_area.center))
        return out[:max_points]

    def furniture_cover(self) -> list[SpatialObject]:
        return [o for o in self.objects if 0.6 <= o.height <= 1.6]

    def derive_cover_points(self, offset: float = 0.6) -> list[CoverPointMR]:
        pts: list[CoverPointMR] = []
        for o in self.furniture_cover():
            c = o.box.center
            for n in (Vec3(1, 0, 0), Vec3(-1, 0, 0), Vec3(0, 0, 1), Vec3(0, 0, -1)):
                half = (o.box.size.x if n.x else o.box.size.z) / 2
                p = Vec3(c.x, 0, c.z) + n * (half + offset)
                if self.in_room(p, 0.25) and not self.blocked(p, 0.3):
                    pts.append(CoverPointMR(f"{o.id}_{len(pts)}", p, -n, o.id))
        return pts

    def find_surface(self, label: str | None = None) -> Surface | None:
        cands = [s for s in self.surfaces if label is None or s.label == label]
        return max(cands, key=lambda s: s.size_x * s.size_z, default=None)

    def extraction_zone(self) -> SafeZone:
        if self.safe_zones:
            return self.safe_zones[0]
        return SafeZone("extract", self.play_area.center, min(self.play_area.half_x, self.play_area.half_z))

    # ---- serialisation ------------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        v = lambda p: [round(p.x, 4), round(p.y, 4), round(p.z, 4)]  # noqa: E731
        return {
            "meta": {"room_id": self.meta.room_id, "scanner": self.meta.scanner, "seed": self.meta.seed},
            "size": [self.width, self.depth, self.ceiling_height],
            "walls": [
                {"id": w.id, "a": v(w.a), "b": v(w.b), "normal": v(w.normal), "height": w.height} for w in self.walls
            ],
            "portals": [
                {
                    "id": p.id,
                    "kind": p.kind.value,
                    "wall": p.wall_id,
                    "along": p.along,
                    "width": p.width,
                    "height": p.height,
                    "sill": p.sill,
                }
                for p in self.portals
            ],
            "objects": [
                {
                    "id": o.id,
                    "label": o.label.value,
                    "min": v(o.box.min),
                    "max": v(o.box.max),
                    "confidence": o.confidence,
                }
                for o in self.objects
            ],
            "play_area": {
                "center": v(self.play_area.center),
                "half": [self.play_area.half_x, self.play_area.half_z],
            },
            "safe_zones": [{"id": z.id, "center": v(z.center), "radius": z.radius} for z in self.safe_zones],
            "anchors": [{"id": a.id, "pos": v(a.pos), "yaw": a.yaw, "label": a.label} for a in self.anchors],
        }

    @staticmethod
    def from_dict(d: dict[str, Any]) -> MixedRealityEnvironment:
        from .scanner import build_environment

        vec = lambda a: Vec3(*a)  # noqa: E731
        w, dep, h = d["size"]
        walls = [(x["id"], vec(x["a"]), vec(x["b"]), vec(x["normal"])) for x in d["walls"]]
        env = build_environment(
            ScanMeta(d["meta"]["room_id"], d["meta"].get("scanner", "loaded"), d["meta"].get("seed", 0)),
            w,
            dep,
            h,
            portals=[
                Portal(
                    p["id"],
                    PortalKind(p["kind"]),
                    p["wall"],
                    p["along"],
                    p["width"],
                    p["height"],
                    p.get("sill", 0.0),
                )
                for p in d["portals"]
            ],
            objects=[
                SpatialObject(
                    o["id"],
                    Furniture(o["label"]),
                    AABB(vec(o["min"]), vec(o["max"])),
                    o.get("confidence", 1.0),
                )
                for o in d["objects"]
            ],
            play_area=PlayArea(vec(d["play_area"]["center"]), *d["play_area"]["half"]),
            safe_zones=[SafeZone(z["id"], vec(z["center"]), z["radius"]) for z in d["safe_zones"]],
            wall_override=walls,
        )
        env.anchors = [
            Anchor(a["id"], vec(a["pos"]), a.get("yaw", 0.0), a.get("label", "")) for a in d.get("anchors", [])
        ]
        return env


def environment_to_level(env: MixedRealityEnvironment, seed: int = 1):  # -> Level
    """Convert a scanned room into a playable Level: real geometry + virtual alcoves behind doors/breach points."""
    from ..enemies.cover import generate_cover_points
    from ..missions.level import Level, Light, Zone
    from ..missions.level import SpawnPoint as LvlSpawn
    from ..physics.world import ColliderKind, Material, World

    M = 4.0  # margin around the room that hosts virtual alcoves
    bounds = (-M, -M, env.width + M, env.depth + M)
    lvl = Level("mr_room", f"MR - {env.meta.room_id}", bounds, world=World(), kind="mr", indoor=True)
    world = lvl.world
    T = 0.12
    H = env.ceiling_height
    breaches = env.derive_breach_points() if True else []
    alcoves: list[tuple[str, Vec3, Vec3, float, str]] = []  # (id, wall pos, inward, width, mode)

    def wall_box(
        a: Vec3,
        b: Vec3,
        n: Vec3,
        t0: float,
        t1: float,
        y0: float,
        y1: float,
        material,
        kind,
        tag="",
        key="wall",
        blocks_los=True,
    ):
        d = (b - a).normalized()
        p0, p1 = a + d * t0, a + d * t1
        out = n * -1  # outward
        lo = Vec3(min(p0.x, p1.x), y0, min(p0.z, p1.z))
        hi = Vec3(max(p0.x, p1.x), y1, max(p0.z, p1.z))
        # thicken outward (so interior dimensions remain exactly the scanned room)
        ext = out * T
        lo2 = Vec3(min(lo.x, lo.x + ext.x), y0, min(lo.z, lo.z + ext.z))
        hi2 = Vec3(max(hi.x, hi.x + ext.x), y1, max(hi.z, hi.z + ext.z))
        # ensure non-zero thickness along the wall axis
        if hi2.x - lo2.x < 1e-6:
            lo2, hi2 = Vec3(lo2.x - T / 2, y0, lo2.z), Vec3(hi2.x + T / 2, y1, hi2.z)
        if hi2.z - lo2.z < 1e-6:
            lo2, hi2 = Vec3(lo2.x, y0, lo2.z - T / 2), Vec3(hi2.x, y1, hi2.z + T / 2)
        c = world.add(AABB(lo2, hi2), material, kind, tag=tag, color_key=key, blocks_los=blocks_los)
        return c

    breach_gap: dict[str, tuple[float, float, str]] = {}
    for i, bp in enumerate(breaches):
        breach_gap[bp.wall_id] = (((bp.pos - env.wall(bp.wall_id).a).length()), bp.width, f"breach_{i}")
        alcoves.append((f"breach_{i}", bp.pos, bp.inward, bp.width, "breach"))
    door_i = 0
    for w in env.walls:
        length = (w.b - w.a).length()
        cuts: list[tuple[float, float, str, str, float, float]] = []  # (centre, width, kind, tag, y0, y1)
        for p in env.portals:
            if p.wall_id != w.id:
                continue
            if p.kind is PortalKind.DOOR:
                cuts.append((p.along, p.width, "door", f"portal_{door_i}", 0.0, p.height))
                pos, inward = env.portal_world(p)
                alcoves.append((f"portal_{door_i}", pos, inward, p.width, "portal"))
                door_i += 1
            else:
                cuts.append((p.along, p.width, "window", f"window_{p.id}", p.sill, p.sill + p.height))
        if w.id in breach_gap:
            c, wd, tag = breach_gap[w.id]
            cuts.append((c, wd, "breach", tag, 0.0, H))
        cuts.sort()
        cursor = 0.0
        for centre, width, kind, tag, y0, y1 in cuts:
            lo, hi = centre - width / 2, centre + width / 2
            if lo > cursor:
                wall_box(w.a, w.b, w.normal, cursor, lo, 0.0, H, Material.PLASTER, ColliderKind.MR_REAL)
            if kind == "door":
                wall_box(w.a, w.b, w.normal, lo, hi, y1, H, Material.PLASTER, ColliderKind.MR_REAL)
            elif kind == "window":
                wall_box(w.a, w.b, w.normal, lo, hi, 0.0, y0, Material.PLASTER, ColliderKind.MR_REAL)
                wall_box(w.a, w.b, w.normal, lo, hi, y1, H, Material.PLASTER, ColliderKind.MR_REAL)
                wall_box(
                    w.a,
                    w.b,
                    w.normal,
                    lo,
                    hi,
                    y0,
                    y1,
                    Material.GLASS,
                    ColliderKind.MR_REAL,
                    tag=tag,
                    key="glass",
                    blocks_los=False,
                )
            elif kind == "breach":
                wall_box(
                    w.a,
                    w.b,
                    w.normal,
                    lo,
                    hi,
                    0.0,
                    H,
                    Material.PLASTER,
                    ColliderKind.PROP,
                    tag=tag,
                    key="breach_panel",
                )
            cursor = max(cursor, hi)
        if cursor < length:
            wall_box(w.a, w.b, w.normal, cursor, length, 0.0, H, Material.PLASTER, ColliderKind.MR_REAL)

    # virtual alcoves behind each portal / breach panel
    for aid, pos, inward, width, _mode in alcoves:
        out = inward * -1
        side = Vec3(-out.z, 0, out.x)
        depth = 2.6
        hw = width / 2 + 0.25
        for sgn in (-1, 1):
            c0 = pos + side * (hw * sgn)
            c1 = c0 + out * depth
            world.add(
                AABB(
                    Vec3(min(c0.x, c1.x) - 0.06, 0, min(c0.z, c1.z) - 0.06),
                    Vec3(max(c0.x, c1.x) + 0.06, H, max(c0.z, c1.z) + 0.06),
                ),
                Material.CONCRETE,
                ColliderKind.WALL,
                color_key="virtual_wall",
            )
        e0 = pos + out * depth - side * hw
        e1 = pos + out * depth + side * hw
        world.add(
            AABB(
                Vec3(min(e0.x, e1.x) - 0.06, 0, min(e0.z, e1.z) - 0.06),
                Vec3(max(e0.x, e1.x) + 0.06, H, max(e0.z, e1.z) + 0.06),
            ),
            Material.CONCRETE,
            ColliderKind.WALL,
            color_key="virtual_wall",
        )
        sp = pos + out * (depth - 0.6)
        lvl.spawn_points[aid] = LvlSpawn(aid, sp, math.atan2(inward.x, inward.z))

    # furniture = real-world cover
    for o in env.objects:
        solid_cover = 0.6 <= o.height <= 1.6
        world.add(
            o.box,
            Material.FURNITURE,
            ColliderKind.COVER if solid_cover else ColliderKind.PROP,
            visible=True,
            tag=o.label.value,
            color_key=f"mr_{o.label.value}",
        )
    for i, fsp in enumerate(env.derive_spawn_points()):
        lvl.spawn_points[f"floor_{i}"] = LvlSpawn(f"floor_{i}", fsp.pos, 0.0)
    ez = env.extraction_zone()
    lvl.player_start = (env.play_area.center, 0.0)
    lvl.zones["play_area"] = Zone("play_area", env.play_area.center, 0.8)
    lvl.ambient = 0.6
    for lx, lz in ((env.width * 0.3, env.depth * 0.3), (env.width * 0.7, env.depth * 0.7)):
        lvl.lights.append(Light(Vec3(lx, H - 0.1, lz), (255, 236, 205), 7.0, 1.0))
    lvl.lights.append(Light(Vec3(env.width / 2, H - 0.2, env.depth / 2), (220, 70, 55), 6.0, 0.9, True, False))
    lvl.zones["mr_safe"] = Zone("mr_safe", ez.center, ez.radius)
    generate_cover_points(lvl, min_h=0.6, max_h=1.6)
    return lvl
