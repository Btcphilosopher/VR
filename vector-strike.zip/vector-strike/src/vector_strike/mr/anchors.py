"""Spatial primitives for the mixed-reality abstraction. Hardware layers (OpenXR / vendor scene APIs)
translate their native results into these types; gameplay only ever sees these."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from ..physics.shapes import AABB
from ..physics.vec import Vec3


class AnchorKind(str, Enum):
    ANCHOR = "anchor"
    SPATIAL_MESH = "spatial_mesh"
    PLANE = "plane"
    SURFACE = "surface"
    PORTAL = "portal"
    SPAWN_POINT = "spawn_point"
    COVER_POINT = "cover_point"


class PlaneRole(str, Enum):
    FLOOR = "floor"
    CEILING = "ceiling"
    WALL = "wall"


class PortalKind(str, Enum):
    DOOR = "door"
    WINDOW = "window"


class Furniture(str, Enum):
    TABLE = "table"
    CHAIR = "chair"
    SOFA = "sofa"
    SHELF = "shelf"
    CABINET = "cabinet"
    DESK = "desk"
    BED = "bed"
    OBSTACLE = "obstacle"


@dataclass(slots=True)
class Anchor:
    """A persistent world-locked pose (OpenXR spatial anchor equivalent)."""

    id: str
    pos: Vec3
    yaw: float = 0.0
    label: str = ""
    persistent: bool = True
    confidence: float = 1.0
    kind: AnchorKind = AnchorKind.ANCHOR


@dataclass(slots=True)
class Plane:
    id: str
    role: PlaneRole
    center: Vec3
    normal: Vec3
    width: float
    height: float
    a: Vec3 = Vec3()  # wall ground endpoints (axis-aligned rooms)
    b: Vec3 = Vec3()
    confidence: float = 1.0
    kind: AnchorKind = AnchorKind.PLANE


@dataclass(slots=True)
class Portal:
    id: str
    kind: PortalKind
    wall_id: str
    along: float  # distance from the wall's `a` endpoint to the portal centre
    width: float
    height: float
    sill: float = 0.0
    confidence: float = 1.0
    anchor_kind: AnchorKind = AnchorKind.PORTAL


@dataclass(slots=True)
class SpatialObject:
    """A classified object volume (simplified spatial mesh)."""

    id: str
    label: Furniture
    box: AABB
    confidence: float = 1.0
    kind: AnchorKind = AnchorKind.SPATIAL_MESH

    @property
    def height(self) -> float:
        return self.box.max.y

    @property
    def top_center(self) -> Vec3:
        c = self.box.center
        return Vec3(c.x, self.box.max.y, c.z)


@dataclass(slots=True)
class Surface:
    """A horizontal placement surface (table top, desk, counter)."""

    id: str
    label: str
    center: Vec3
    size_x: float
    size_z: float
    source_id: str
    kind: AnchorKind = AnchorKind.SURFACE


@dataclass(slots=True)
class SpawnPoint:
    id: str
    pos: Vec3
    mode: str = "floor"  # floor | portal | breach
    kind: AnchorKind = AnchorKind.SPAWN_POINT


@dataclass(slots=True)
class BreachPoint:
    id: str
    wall_id: str
    pos: Vec3  # point on the wall plane
    inward: Vec3  # unit normal pointing into the room
    width: float


@dataclass(slots=True)
class CoverPointMR:
    id: str
    pos: Vec3
    facing: Vec3
    source_id: str
    kind: AnchorKind = AnchorKind.COVER_POINT


@dataclass(slots=True)
class SafeZone:
    id: str
    center: Vec3
    radius: float


@dataclass(slots=True)
class PlayArea:
    center: Vec3
    half_x: float
    half_z: float

    def contains(self, p: Vec3, margin: float = 0.0) -> bool:
        return abs(p.x - self.center.x) <= self.half_x + margin and abs(p.z - self.center.z) <= self.half_z + margin


@dataclass(slots=True)
class ValidationIssue:
    severity: str  # error | warning
    code: str
    message: str


@dataclass
class ScanMeta:
    room_id: str = "MR-DEMO-ROOM-001"
    scanner: str = "simulated"
    seed: int = 1
    notes: list[str] = field(default_factory=list)
