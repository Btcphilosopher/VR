"""Room scanning: provider interface, deterministic simulator (MR-DEMO-ROOM-001) and hardware stubs."""

from __future__ import annotations

import random
from typing import Protocol

from ..physics.shapes import AABB
from ..physics.vec import Vec3
from .anchors import (
    Anchor,
    AnchorKind,
    Furniture,
    Plane,
    PlaneRole,
    PlayArea,
    Portal,
    PortalKind,
    SafeZone,
    ScanMeta,
    SpatialObject,
    Surface,
)
from .environment import MixedRealityEnvironment


class HardwareUnavailable(RuntimeError):
    """Raised by hardware-backed providers when no device / runtime is present."""


class SpatialProvider(Protocol):
    name: str

    def scan(self, room_id: str | None = None) -> MixedRealityEnvironment: ...


def build_environment(
    meta: ScanMeta,
    width: float,
    depth: float,
    height: float,
    *,
    portals: list[Portal],
    objects: list[SpatialObject],
    play_area: PlayArea,
    safe_zones: list[SafeZone],
    wall_override: list[tuple[str, Vec3, Vec3, Vec3]] | None = None,
) -> MixedRealityEnvironment:
    """Assemble planes, surfaces and anchors from raw scan results (axis-aligned rooms)."""
    c = Vec3(width / 2, 0, depth / 2)
    floor = Plane("floor", PlaneRole.FLOOR, c, Vec3(0, 1, 0), width, depth)
    ceiling = Plane("ceiling", PlaneRole.CEILING, c.with_y(height), Vec3(0, -1, 0), width, depth)
    if wall_override is not None:
        wall_specs = wall_override
    else:
        wall_specs = [
            ("wall_s", Vec3(0, 0, 0), Vec3(width, 0, 0), Vec3(0, 0, 1)),
            ("wall_e", Vec3(width, 0, 0), Vec3(width, 0, depth), Vec3(-1, 0, 0)),
            ("wall_n", Vec3(width, 0, depth), Vec3(0, 0, depth), Vec3(0, 0, -1)),
            ("wall_w", Vec3(0, 0, depth), Vec3(0, 0, 0), Vec3(1, 0, 0)),
        ]
    walls = [
        Plane(wid, PlaneRole.WALL, (a + b) * 0.5 + Vec3(0, height / 2, 0), n, (b - a).length(), height, a, b)
        for wid, a, b, n in wall_specs
    ]
    surfaces = [
        Surface(f"surface_{o.id}", o.label.value, o.top_center, o.box.size.x, o.box.size.z, o.id)
        for o in objects
        if o.label in (Furniture.TABLE, Furniture.DESK, Furniture.CABINET) and 0.5 <= o.height <= 1.1
    ]
    anchors = [Anchor("anchor_origin", Vec3(0, 0, 0), 0.0, "room_origin")]
    anchors += [
        Anchor(f"anchor_{o.id}", o.box.center.with_y(0), 0.0, o.label.value)
        for o in objects
        if o.label in (Furniture.TABLE, Furniture.SOFA)
    ]
    anchors += [Anchor(f"anchor_{p.id}", Vec3(0, 0, 0), 0.0, p.kind.value, kind=AnchorKind.PORTAL) for p in portals]
    return MixedRealityEnvironment(
        meta=meta,
        width=width,
        depth=depth,
        ceiling_height=height,
        floor=floor,
        ceiling=ceiling,
        walls=walls,
        portals=portals,
        objects=objects,
        surfaces=surfaces,
        anchors=anchors,
        play_area=play_area,
        safe_zones=safe_zones,
    )


def _obj(
    oid: str, label: Furniture, cx: float, cz: float, sx: float, sy: float, sz: float, conf: float = 1.0
) -> SpatialObject:
    return SpatialObject(oid, label, AABB(Vec3(cx - sx / 2, 0, cz - sz / 2), Vec3(cx + sx / 2, sy, cz + sz / 2)), conf)


class SimulatedRoomScanner:
    """Synthetic room scanner. Deterministic per (seed, room_id); needs no hardware or camera."""

    name = "simulated"

    def __init__(self, seed: int = 1, noise: float = 0.01) -> None:
        self.seed = seed
        self.noise = noise

    def scan(self, room_id: str | None = None) -> MixedRealityEnvironment:
        room_id = room_id or "MR-DEMO-ROOM-001"
        if room_id == "MR-DEMO-ROOM-001":
            env = self._demo_room()
        else:
            env = self._random_room(room_id)
        return env

    def _jitter(self, rng: random.Random) -> float:
        return rng.uniform(-self.noise, self.noise)

    def _demo_room(self) -> MixedRealityEnvironment:
        rng = random.Random(self.seed)
        w, d, h = 5.2, 4.2, 2.6
        objects = [
            _obj(
                "sofa_0",
                Furniture.SOFA,
                0.55 + self._jitter(rng),
                2.2 + self._jitter(rng),
                0.9,
                0.85,
                2.0,
                0.97,
            ),
            _obj(
                "table_0",
                Furniture.TABLE,
                3.4 + self._jitter(rng),
                2.4 + self._jitter(rng),
                1.4,
                0.75,
                0.8,
                0.98,
            ),
            _obj("chair_0", Furniture.CHAIR, 2.3, 2.4, 0.5, 0.9, 0.5, 0.93),
            _obj("chair_1", Furniture.CHAIR, 4.5, 2.4, 0.5, 0.9, 0.5, 0.91),
            _obj("shelf_0", Furniture.SHELF, 1.6, 4.0, 1.2, 1.9, 0.4, 0.95),
            _obj("cabinet_0", Furniture.CABINET, 4.75, 0.45, 0.8, 0.9, 0.5, 0.94),
        ]
        portals = [
            Portal("door_south", PortalKind.DOOR, "wall_s", 1.2, 0.9, 2.0),
            Portal("door_east", PortalKind.DOOR, "wall_e", 1.0, 0.9, 2.0),  # `along` measured from wall_e.a (z=0)
            Portal("window_north", PortalKind.WINDOW, "wall_n", 2.2, 1.4, 1.1, 0.9),
        ]
        pa = PlayArea(Vec3(1.9, 0, 1.1), 0.9, 0.8)
        zones = [SafeZone("extract", Vec3(1.9, 0, 1.1), 0.8)]
        meta = ScanMeta("MR-DEMO-ROOM-001", self.name, self.seed, ["synthetic demo room"])
        return build_environment(meta, w, d, h, portals=portals, objects=objects, play_area=pa, safe_zones=zones)

    def _random_room(self, room_id: str) -> MixedRealityEnvironment:
        rng = random.Random(f"{self.seed}:{room_id}")
        w, d = round(rng.uniform(4.0, 6.2), 2), round(rng.uniform(3.6, 5.2), 2)
        h = round(rng.uniform(2.4, 2.8), 2)
        pa = PlayArea(Vec3(w * 0.4, 0, d * 0.3), 0.9, 0.8)
        objects: list[SpatialObject] = []
        kinds = [
            (Furniture.TABLE, 1.3, 0.75, 0.8),
            (Furniture.SOFA, 1.9, 0.85, 0.9),
            (Furniture.SHELF, 1.1, 1.9, 0.4),
            (Furniture.CABINET, 0.8, 0.9, 0.5),
            (Furniture.CHAIR, 0.5, 0.9, 0.5),
            (Furniture.DESK, 1.5, 0.75, 0.7),
        ]
        for i in range(rng.randint(3, 5)):
            label, sx, sy, sz = rng.choice(kinds)
            for _ in range(30):
                cx, cz = (
                    rng.uniform(sx / 2 + 0.1, w - sx / 2 - 0.1),
                    rng.uniform(sz / 2 + 0.1, d - sz / 2 - 0.1),
                )
                o = _obj(
                    f"{label.value}_{i}",
                    label,
                    cx + self._jitter(rng),
                    cz + self._jitter(rng),
                    sx,
                    sy,
                    sz,
                    round(rng.uniform(0.8, 1.0), 2),
                )
                play = AABB(
                    Vec3(pa.center.x - pa.half_x - 0.2, 0, pa.center.z - pa.half_z - 0.2),
                    Vec3(pa.center.x + pa.half_x + 0.2, 2, pa.center.z + pa.half_z + 0.2),
                )
                if not o.box.intersects(play) and not any(o.box.expanded(0.15).intersects(q.box) for q in objects):
                    objects.append(o)
                    break
        portals = [Portal("door_south", PortalKind.DOOR, "wall_s", round(rng.uniform(0.9, w - 0.9), 2), 0.9, 2.0)]
        if rng.random() > 0.4:
            portals.append(
                Portal(
                    "window_north",
                    PortalKind.WINDOW,
                    "wall_n",
                    round(rng.uniform(1.0, w - 1.0), 2),
                    1.2,
                    1.0,
                    0.9,
                )
            )
        meta = ScanMeta(room_id, self.name, self.seed)
        return build_environment(
            meta,
            w,
            d,
            h,
            portals=portals,
            objects=objects,
            play_area=pa,
            safe_zones=[SafeZone("extract", pa.center, 0.8)],
        )


class OpenXRSpatialProvider:
    """Integration point for hardware scene understanding (OpenXR scene/plane/anchor extensions or a vendor
    SDK). It is intentionally a stub: it only reports unavailability so the game falls back to the simulator.
    Implementors translate native planes/meshes/anchors into `mr.anchors` types and return a
    `MixedRealityEnvironment` via `build_environment`."""

    name = "openxr"

    def scan(self, room_id: str | None = None) -> MixedRealityEnvironment:
        raise HardwareUnavailable("OpenXR spatial scene provider not available on this system")


def get_spatial_provider(prefer_hardware: bool = False, seed: int = 1) -> SpatialProvider:
    if prefer_hardware:
        try:
            OpenXRSpatialProvider().scan()
        except HardwareUnavailable:
            pass
    return SimulatedRoomScanner(seed)
