"""MRDirector: turns mixed-reality abstractions into gameplay events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..game import events as ev
from ..game.state import InteractableState
from ..missions.level import DecorBox, InteractableDef, Zone
from ..physics.shapes import AABB
from ..physics.vec import Vec3
from .environment import MixedRealityEnvironment

if TYPE_CHECKING:
    from ..game.session import GameSession


class MRDirector:
    """Events: wall_breach | floor_spawn | room_invasion | objective_object | extraction_zone."""

    def __init__(self, session: GameSession, env: MixedRealityEnvironment) -> None:
        self.s = session
        self.env = env
        self._breach_used = 0
        self._floor_used = 0
        self.log: list[str] = []

    # ---- helpers ------------------------------------------------------------------------------
    def _spawn(self, spawn_name: str, enemy: str, group: str, count: int = 1) -> None:
        from ..missions.models import SpawnEntry

        self.s.spawn_entry(SpawnEntry(enemy=enemy, at=spawn_name, count=count), group, hunt=True)
        self.s._groups_spawned.add(group)

    def trigger(self, kind: str, count: int, enemy: str) -> None:
        self.log.append(kind)
        getattr(self, f"_{kind}")(count, enemy)
        self.s.bus.emit(ev.MR_EVENT, kind=kind, count=count)

    # ---- events -------------------------------------------------------------------------------
    def _wall_breach(self, count: int, enemy: str) -> None:
        """A virtual opening appears on a real wall; hostiles pour through it."""
        lvl = self.s.level
        names = sorted(n for n in lvl.spawn_points if n.startswith("breach_"))
        group = "mr_wall_breach"
        self.s._groups_spawned.add(group)
        if not names:
            self._floor_spawn(count, enemy, group)
            return
        name = names[self._breach_used % len(names)]
        self._breach_used += 1
        for c in lvl.world.by_tag(name):
            lvl.world.set_open(c.id, True)
        self._spawn(name, enemy, group, count)

    def _floor_spawn(self, count: int, enemy: str, group: str = "mr_floor_spawn") -> None:
        """Hostiles rise from spatially valid floor locations (clear of furniture, away from the player)."""
        lvl = self.s.level
        names = sorted(n for n in lvl.spawn_points if n.startswith("floor_"))
        self.s._groups_spawned.add(group)
        for i in range(count):
            self._spawn(names[(self._floor_used + i) % len(names)], enemy, group)
        self._floor_used += count

    def _room_invasion(self, count: int, enemy: str) -> None:
        """Hostiles enter through the real doors and sweep across the mapped room."""
        lvl = self.s.level
        names = sorted(n for n in lvl.spawn_points if n.startswith("portal_"))
        group = "mr_room_invasion"
        self.s._groups_spawned.add(group)
        if not names:
            self._wall_breach(count, enemy)
            return
        for i in range(count):
            self._spawn(names[i % len(names)], enemy, group)

    def _objective_object(self, count: int, enemy: str) -> None:
        """A virtual terminal appears on a real table."""
        surf = self.env.find_surface("table") or self.env.find_surface()
        lvl = self.s.level
        if surf is None:
            pos = self.env.play_area.center
            top = 0.0
        else:
            pos, top = surf.center.with_y(0.0), surf.center.y
        lvl.decor.append(
            DecorBox(
                AABB(Vec3(pos.x - 0.25, top, pos.z - 0.15), Vec3(pos.x + 0.25, top + 0.22, pos.z + 0.15)),
                "steel_dark",
            )
        )
        lvl.decor.append(
            DecorBox(
                AABB(Vec3(pos.x - 0.2, top + 0.22, pos.z - 0.03), Vec3(pos.x + 0.2, top + 0.5, pos.z + 0.03)),
                "screen_amber",
                True,
            )
        )
        d = InteractableDef("mr_objective", pos, "terminal", "HOLD  Secure virtual terminal", 3.0, radius=2.4)
        lvl.interactables["mr_objective"] = d
        self.s.interactables["mr_objective"] = InteractableState(
            d.id, d.pos, d.kind, d.title, d.hold_time, d.radius, True
        )

    def _extraction_zone(self, count: int, enemy: str) -> None:
        """The player's physical space becomes the extraction area."""
        z = self.env.extraction_zone()
        self.s.level.zones["mr_extract"] = Zone("mr_extract", z.center, z.radius)

    def update(self, dt: float) -> None:
        return None
