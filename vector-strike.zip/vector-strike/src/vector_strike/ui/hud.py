"""Minimal tactical HUD (desktop) + wrist interface model (VR).

Design rules: nothing glued permanently to the face. Information lives on the weapon (ammo), in world space
(objective markers), at the screen edge only when relevant (damage direction), and on the wrist (VR)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import pygame

from ..game.session import GameSession
from ..physics.vec import wrap_angle
from ..rendering import palette as pal


@dataclass
class HudModel:
    health: float = 1.0
    health_raw: float = 100.0
    ammo: int = 0
    magazine: int = 0
    reserve: int = 0
    weapon_name: str = ""
    weapon_state: str = ""
    grenades: int = 0
    objective: str = ""
    hint: str = ""
    phase: str = ""
    prompt: str = ""
    prompt_progress: float = 0.0
    timer_label: str = ""
    timer_value: float = 0.0
    compass_deg: float = 0.0
    goal_bearing: float | None = None  # radians relative to view (+ right)
    goal_distance: float = 0.0
    hit_marker: float = 0.0  # 0..1 fade
    kill_marker: float = 0.0
    damage_dirs: list[tuple[float, float]] = field(default_factory=list)  # (angle rel, strength)
    messages: list[str] = field(default_factory=list)
    in_cover: bool = False
    elapsed: float = 0.0
    low_ammo: bool = False


def build_hud(s: GameSession) -> HudModel:
    p = s.player.state
    m = HudModel(
        health=p.health / p.max_health,
        health_raw=p.health,
        grenades=s.inventory.grenades,
        elapsed=s.runner.elapsed,
        phase=s.runner.phase.value,
    )
    w = s.inventory.weapon
    if w is not None:
        m.ammo, m.magazine, m.reserve = (
            w.ammo,
            w.spec.magazine_capacity,
            (-1 if w.spec.infinite_reserve else w.reserve),
        )
        m.weapon_name, m.weapon_state = w.spec.name, w.state.value
        m.low_ammo = w.ammo <= max(3, w.spec.magazine_capacity // 5)
    m.objective, m.hint = s.runner.objective_text()
    tt = s.runner.timer_text()
    if tt:
        m.timer_label, m.timer_value = tt
    m.compass_deg = math.degrees(p.yaw) % 360
    goals = s.runner.goal_positions()
    if goals:
        g = goals[0]
        m.goal_bearing = wrap_angle(math.atan2(g.x - p.pos.x, g.z - p.pos.z) - p.yaw)
        m.goal_distance = g.dist_xz(p.pos)
    if s.interact_target:
        it = s.interactables[s.interact_target]
        m.prompt = it.title
        hold = it.hold_time * (0.4 if s.settings.comfort.simplified_interaction else 1.0)
        m.prompt_progress = min(1.0, it.progress / hold) if hold > 0 else 0.0
    m.hit_marker = max(0.0, 1.0 - (s.t - s.last_hit_marker) / 0.18) if s.last_hit_marker >= 0 else 0.0
    m.kill_marker = max(0.0, 1.0 - (s.t - s.last_kill_marker) / 0.35) if s.last_kill_marker >= 0 else 0.0
    m.messages = [t for ts, t in s.runner.messages if s.t - ts < 6.0][-3:]
    m.in_cover = s.in_cover() if s.tick % 10 == 0 or True else False
    return m


def make_fonts() -> dict[str, pygame.font.Font]:
    pygame.font.init()
    names = "dejavusansmono,liberationmono,consolas,couriernew,monospace"

    def f(size: int, bold: bool = False) -> pygame.font.Font:
        return pygame.font.SysFont(names, size, bold=bold)

    return {"small": f(13), "body": f(16), "title": f(22, True), "huge": f(54, True), "mid": f(30, True)}


def _txt(
    surface: pygame.Surface,
    font: pygame.font.Font,
    text: str,
    pos: tuple[float, float],
    col: tuple[int, int, int],
    anchor: str = "tl",
) -> pygame.Rect:
    img = font.render(text, True, col)
    r = img.get_rect()
    setattr(
        r,
        {
            "tl": "topleft",
            "tr": "topright",
            "tc": "midtop",
            "mc": "center",
            "bl": "bottomleft",
            "br": "bottomright",
            "bc": "midbottom",
        }[anchor],
        (int(pos[0]), int(pos[1])),
    )
    surface.blit(img, r)
    return r


class HudRenderer:
    def __init__(self, fonts: dict[str, pygame.font.Font]) -> None:
        self.f = fonts
        self._health_fade = 0.0
        self._last_health = 1.0

    def draw(
        self,
        surface: pygame.Surface,
        m: HudModel,
        dt: float,
        *,
        reticle: bool = True,
        ads: float = 0.0,
        damage_dirs: list[tuple[float, float]] | None = None,
    ) -> None:
        w, h = surface.get_size()
        cx, cy = w // 2, h // 2
        amber, dim, text, red = pal.AMBER, pal.UI_DIM, pal.UI_TEXT, pal.RED

        # reticle: subtle dot + ticks, fades when aiming down sights
        if reticle:
            col = (220, 220, 210)
            pygame.draw.circle(surface, col, (cx, cy), 2)
            gap = 9
            for dx, dy in ((gap, 0), (-gap, 0), (0, gap), (0, -gap)):
                pygame.draw.line(
                    surface,
                    (col[0], col[1], col[2]),
                    (cx + dx, cy + dy),
                    (cx + int(dx * 1.6), cy + int(dy * 1.6)),
                    1,
                )
        if m.hit_marker > 0:
            c = (255, 255, 255) if m.kill_marker <= 0 else (230, 70, 55)
            r = 10 + int(6 * (1 - m.hit_marker))
            for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                pygame.draw.line(surface, c, (cx + sx * 6, cy + sy * 6), (cx + sx * r, cy + sy * r), 2)
        if m.kill_marker > 0:
            pygame.draw.circle(surface, (230, 70, 55), (cx, cy), 16, 1)

        # health: thin bar at bottom-left, only visible when hurt (fades back out)
        if m.health < self._last_health - 1e-3:
            self._health_fade = 1.0
        self._last_health = m.health
        self._health_fade = max(self._health_fade - dt * 0.35, 0.0)
        vis = 1.0 if m.health < 0.99 else self._health_fade
        if vis > 0.02:
            bw = 170
            col = red if m.health < 0.3 else amber
            ov = pygame.Surface((bw + 4, 8), pygame.SRCALPHA)
            ov.fill((0, 0, 0, int(120 * vis)))
            pygame.draw.rect(ov, (*col, int(230 * vis)), (2, 2, int(bw * max(0.0, m.health)), 4))
            surface.blit(ov, (24, h - 36))
        if m.health < 0.3:
            vig = pygame.Surface((w, h), pygame.SRCALPHA)
            for i in range(6):
                pygame.draw.rect(
                    vig,
                    (160, 20, 20, 10 + int((0.3 - m.health) * 80)),
                    (i * 5, i * 5, w - i * 10, h - i * 10),
                    8,
                )
            surface.blit(vig, (0, 0))

        # damage direction wedges
        for wedge_angle, _strength in damage_dirs or []:
            wa = wedge_angle - math.pi / 2
            r0, r1 = min(w, h) * 0.34, min(w, h) * 0.38
            p0 = (cx + math.cos(wa - 0.18) * r0, cy + math.sin(wa - 0.18) * r0)
            p1 = (cx + math.cos(wa + 0.18) * r0, cy + math.sin(wa + 0.18) * r0)
            p2 = (cx + math.cos(wa) * r1, cy + math.sin(wa) * r1)
            pygame.draw.polygon(surface, (*red,), [p0, p1, p2])

        # top: objective (small) + compass tick
        if m.objective:
            _txt(surface, self.f["body"], m.objective.upper(), (cx, 18), text, "tc")
            if m.hint:
                _txt(surface, self.f["small"], m.hint, (cx, 40), dim, "tc")
        if m.goal_bearing is not None:
            bx = cx + max(-w * 0.38, min(w * 0.38, m.goal_bearing * 260))
            pygame.draw.polygon(surface, amber, [(bx, 66), (bx - 6, 76), (bx + 6, 76)])
            _txt(surface, self.f["small"], f"{m.goal_distance:.0f}m", (bx, 80), amber, "tc")
        _txt(surface, self.f["small"], f"{m.phase}", (24, 18), dim, "tl")
        if m.timer_label:
            col = red if m.timer_value < 30 else amber
            mm, ss = divmod(int(m.timer_value), 60)
            _txt(surface, self.f["mid"], f"{mm}:{ss:02d}", (w - 24, 14), col, "tr")
            _txt(surface, self.f["small"], m.timer_label, (w - 24, 48), dim, "tr")
        else:
            mm, ss = divmod(int(m.elapsed), 60)
            _txt(surface, self.f["small"], f"{mm:02d}:{ss:02d}", (w - 24, 18), dim, "tr")

        # interaction prompt
        if m.prompt:
            _txt(surface, self.f["body"], m.prompt, (cx, cy + 90), amber, "tc")
            if m.prompt_progress > 0:
                pygame.draw.rect(surface, (40, 40, 40), (cx - 80, cy + 118, 160, 6))
                pygame.draw.rect(surface, amber, (cx - 80, cy + 118, int(160 * m.prompt_progress), 6))
        # messages
        y = h - 120
        for line in m.messages:
            _txt(surface, self.f["small"], line, (24, y), text, "tl")
            y += 18
        if m.in_cover:
            _txt(surface, self.f["small"], "[ COVER ]", (cx, h - 34), pal.BLUE, "bc")

    def draw_weapon_ui(self, surface: pygame.Surface, m: HudModel, pos: tuple[int, int]) -> None:
        """Weapon-mounted readout: ammo lives on the weapon, not on the face."""
        col = pal.RED if m.low_ammo else pal.AMBER
        res = "INF" if m.reserve < 0 else str(m.reserve)
        _txt(surface, self.f["mid"], f"{m.ammo:02d}", pos, col, "tl")
        _txt(surface, self.f["small"], f"/ {res}", (pos[0] + 56, pos[1] + 14), pal.UI_DIM, "tl")
        if m.weapon_state in ("reloading", "mag_out", "chamber", "switching"):
            _txt(
                surface,
                self.f["small"],
                {"mag_out": "INSERT MAG", "chamber": "CHARGE", "reloading": "RELOADING", "switching": ""}[
                    m.weapon_state
                ],
                (pos[0], pos[1] + 36),
                pal.AMBER,
                "tl",
            )
        _txt(surface, self.f["small"], f"GRN x{m.grenades}", (pos[0], pos[1] + 52), pal.UI_DIM, "tl")
