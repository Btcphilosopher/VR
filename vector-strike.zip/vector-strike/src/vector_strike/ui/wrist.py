"""Wrist interface model: what the VR wrist panel shows. Renderer-agnostic data + a desktop preview painter."""

from __future__ import annotations

from dataclasses import dataclass

import pygame

from ..rendering import palette as pal
from .hud import HudModel


@dataclass
class WristPanel:
    health_pct: int
    objective: str
    ammo_text: str
    grenades: int
    heading_deg: int
    timer: str
    page: str = "status"  # status | menu

    @staticmethod
    def from_hud(m: HudModel, page: str = "status") -> WristPanel:
        mm, ss = divmod(int(m.timer_value if m.timer_label else m.elapsed), 60)
        return WristPanel(
            int(m.health * 100),
            m.objective,
            f"{m.ammo}/{m.reserve if m.reserve >= 0 else 'INF'}",
            m.grenades,
            int(m.compass_deg),
            f"{mm}:{ss:02d}",
            page,
        )


def draw_wrist_preview(
    surface: pygame.Surface, panel: WristPanel, fonts: dict[str, pygame.font.Font], topleft: tuple[int, int]
) -> None:
    """Desktop preview of the wrist panel (the real thing is world-space geometry on the left forearm)."""
    x, y = topleft
    w, h = 250, 112
    bg = pygame.Surface((w, h), pygame.SRCALPHA)
    bg.fill((14, 16, 18, 210))
    pygame.draw.rect(bg, pal.STEEL, (0, 0, w, h), 1)
    surface.blit(bg, (x, y))
    f = fonts["small"]
    surface.blit(
        f.render(f"HP {panel.health_pct:3d}%   HDG {panel.heading_deg:03d}", True, pal.UI_TEXT),
        (x + 10, y + 8),
    )
    surface.blit(f.render(panel.objective[:30].upper(), True, pal.AMBER), (x + 10, y + 30))
    surface.blit(f.render(f"AMMO {panel.ammo_text}   GRN {panel.grenades}", True, pal.UI_TEXT), (x + 10, y + 52))
    surface.blit(f.render(f"T {panel.timer}", True, pal.UI_DIM), (x + 10, y + 74))
    surface.blit(f.render("[MENU] to open", True, pal.UI_DIM), (x + 10, y + 92))
