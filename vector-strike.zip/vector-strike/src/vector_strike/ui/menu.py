"""Menu widgets and screens: main menu, mission select, loadout, settings, accessibility, results, pause.

Screens are small state objects with `handle(event)`, `update(dt)` and `draw(surface)`. They return
`ScreenAction`s to the app, never mutating global state. Layout is spatially comfortable: a central panel
with generous margins (the VR floating-menu layout is the same model rendered on a world-space quad)."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum

import pygame

from ..core.config import Difficulty, Handedness, LocomotionMode, Settings, TurnMode
from ..game.save import SaveData
from ..game.state import MissionResult
from ..missions.models import MissionDef, MissionMode
from ..rendering import palette as pal
from ..weapons.spec import CATALOGUE, Slot


class Act(str, Enum):
    NONE = "none"
    GOTO = "goto"
    START = "start"
    QUIT = "quit"
    BACK = "back"
    RESUME = "resume"
    RESTART = "restart"
    MENU = "menu"
    SAVE = "save"


@dataclass
class ScreenAction:
    kind: Act = Act.NONE
    target: str = ""


@dataclass
class Item:
    label: str
    action: Callable[[], ScreenAction | None] | None = None
    value: Callable[[], str] | None = None
    adjust: Callable[[int], None] | None = None
    enabled: bool = True
    note: str = ""


def _txt(
    surface: pygame.Surface,
    font: pygame.font.Font,
    text: str,
    pos: tuple[int, int],
    col: tuple[int, int, int],
    anchor: str = "tl",
) -> pygame.Rect:
    img = font.render(text, True, col)
    r = img.get_rect()
    setattr(
        r,
        {
            "tl": "topleft",
            "tc": "midtop",
            "tr": "topright",
            "mc": "center",
            "ml": "midleft",
            "mr": "midright",
        }[anchor],
        pos,
    )
    surface.blit(img, r)
    return r


def _start_action(mission_id: str) -> Callable[[], ScreenAction | None]:
    def go() -> ScreenAction | None:
        return ScreenAction(Act.START, mission_id)

    return go


class MenuList:
    """Vertical list with keyboard + mouse navigation and left/right value adjustment."""

    def __init__(self, items: list[Item], on_sound: Callable[[str], None] | None = None) -> None:
        self.items = items
        self.index = 0
        self.rects: list[pygame.Rect] = []
        self.on_sound = on_sound or (lambda s: None)

    def move(self, d: int) -> None:
        n = len(self.items)
        for _ in range(n):
            self.index = (self.index + d) % n
            if self.items[self.index].enabled:
                break
        self.on_sound("hover")

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_UP, pygame.K_w):
                self.move(-1)
            elif e.key in (pygame.K_DOWN, pygame.K_s):
                self.move(1)
            elif e.key in (pygame.K_LEFT, pygame.K_a):
                it = self.items[self.index]
                if it.adjust:
                    it.adjust(-1)
                    self.on_sound("hover")
            elif e.key in (pygame.K_RIGHT, pygame.K_d):
                it = self.items[self.index]
                if it.adjust:
                    it.adjust(1)
                    self.on_sound("hover")
            elif e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_KP_ENTER):
                return self._activate()
        elif e.type == pygame.MOUSEMOTION:
            for i, r in enumerate(self.rects):
                if r.collidepoint(e.pos) and self.items[i].enabled and i != self.index:
                    self.index = i
                    self.on_sound("hover")
        elif e.type == pygame.MOUSEBUTTONDOWN and e.button in (1, 3):
            for i, r in enumerate(self.rects):
                if r.collidepoint(e.pos) and self.items[i].enabled:
                    self.index = i
                    it = self.items[i]
                    if it.adjust and it.value is not None:
                        it.adjust(1 if e.button == 1 else -1)
                        self.on_sound("hover")
                        return None
                    return self._activate()
        return None

    def _activate(self) -> ScreenAction | None:
        it = self.items[self.index]
        if not it.enabled:
            return None
        self.on_sound("select")
        if it.action:
            return it.action()
        if it.adjust:
            it.adjust(1)
        return None

    def draw(
        self,
        surface: pygame.Surface,
        fonts: dict[str, pygame.font.Font],
        x: int,
        y: int,
        w: int,
        row: int = 40,
        font: str = "mid",
    ) -> None:
        self.rects = []
        for i, it in enumerate(self.items):
            r = pygame.Rect(x, y + i * row, w, row - 6)
            self.rects.append(r)
            sel = i == self.index
            if sel:
                bg = pygame.Surface(r.size, pygame.SRCALPHA)
                bg.fill((224, 160, 48, 38))
                surface.blit(bg, r)
                pygame.draw.rect(surface, pal.AMBER, (r.x, r.y, 3, r.h))
            col = pal.UI_TEXT if it.enabled else (80, 82, 80)
            if sel and it.enabled:
                col = pal.AMBER
            _txt(surface, fonts[font], it.label, (r.x + 14, r.centery), col, "ml")
            if it.value is not None:
                v = it.value()
                _txt(
                    surface,
                    fonts["body"],
                    (f"<  {v}  >" if it.adjust else v),
                    (r.right - 10, r.centery),
                    pal.UI_TEXT if sel else pal.UI_DIM,
                    "mr",
                )
            elif it.note:
                _txt(surface, fonts["small"], it.note, (r.right - 10, r.centery), pal.UI_DIM, "mr")


def panel(surface: pygame.Surface, rect: pygame.Rect, alpha: int = 200) -> None:
    bg = pygame.Surface(rect.size, pygame.SRCALPHA)
    bg.fill((14, 16, 18, alpha))
    surface.blit(bg, rect)
    pygame.draw.rect(surface, (70, 74, 78), rect, 1)
    pygame.draw.line(surface, pal.AMBER, (rect.x, rect.y), (rect.x + 60, rect.y), 2)


class Screen:
    name = "screen"
    wants_background = True

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:  # pragma: no cover - interface
        return None

    def update(self, dt: float) -> None:
        return None

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:  # pragma: no cover
        return None


@dataclass
class MenuContext:
    settings: Settings
    save: SaveData
    missions: list[MissionDef]
    sound: Callable[[str], None] = lambda s: None
    apply_settings: Callable[[], None] = lambda: None
    dev: bool = False


class MainMenu(Screen):
    name = "main"

    def __init__(self, ctx: MenuContext) -> None:
        self.ctx = ctx
        self.menu = MenuList(
            [
                Item("CAMPAIGN", lambda: ScreenAction(Act.GOTO, "campaign")),
                Item("SURVIVAL", lambda: ScreenAction(Act.START, "survival_breach")),
                Item("TRAINING", lambda: ScreenAction(Act.START, "training")),
                Item("MR INVASION", lambda: ScreenAction(Act.GOTO, "mr")),
                Item("LOADOUT", lambda: ScreenAction(Act.GOTO, "loadout")),
                Item("SETTINGS", lambda: ScreenAction(Act.GOTO, "settings")),
                Item("EXIT", lambda: ScreenAction(Act.QUIT)),
            ],
            ctx.sound,
        )

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        return self.menu.handle(e)

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 150))
        surface.blit(shade, (0, 0))
        left = int(w * 0.08)
        _txt(surface, fonts["huge"], "VECTOR STRIKE", (left, int(h * 0.14)), pal.UI_TEXT)
        pygame.draw.line(surface, pal.AMBER, (left, int(h * 0.14) + 66), (left + 120, int(h * 0.14) + 66), 3)
        _txt(
            surface,
            fonts["small"],
            "VECTOR RESPONSE GROUP  //  VR / MR ACTION VERTICAL SLICE",
            (left, int(h * 0.14) + 76),
            pal.UI_DIM,
        )
        self.menu.draw(surface, fonts, left, int(h * 0.38), 320, 46)
        prof = self.ctx.save
        _txt(
            surface,
            fonts["small"],
            f"{prof.player_progress.callsign}   LVL {prof.player_progress.level}   "
            f"MISSIONS {prof.statistics.missions_completed}",
            (left, h - 40),
            pal.UI_DIM,
        )
        _txt(
            surface,
            fonts["small"],
            "W/S or mouse: navigate   Enter: select   Esc: back",
            (w - 24, h - 40),
            pal.UI_DIM,
            "tr",
        )


class MissionSelect(Screen):
    name = "campaign"

    def __init__(self, ctx: MenuContext, modes: tuple[MissionMode, ...], title: str) -> None:
        self.ctx, self.title = ctx, title
        self.items_def = [m for m in ctx.missions if m.mode in modes]
        items = []
        for m in self.items_def:
            rec = ctx.save.missions.get(m.id)
            tag = "COMPLETE" if rec and rec.completed else ""
            items.append(Item(f"{m.title}", _start_action(m.id), note=tag))
        items.append(Item("BACK", lambda: ScreenAction(Act.BACK)))
        self.menu = MenuList(items, ctx.sound)

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            return ScreenAction(Act.BACK)
        return self.menu.handle(e)

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 170))
        surface.blit(shade, (0, 0))
        _txt(surface, fonts["title"], self.title, (int(w * 0.08), 40), pal.UI_TEXT)
        self.menu.draw(surface, fonts, int(w * 0.08), 100, 360, 46)
        idx = self.menu.index
        if idx < len(self.items_def):
            m = self.items_def[idx]
            r = pygame.Rect(int(w * 0.5), 100, int(w * 0.42), int(h * 0.62))
            panel(surface, r)
            x, y = r.x + 24, r.y + 20
            _txt(surface, fonts["mid"], f"MISSION  {m.title}", (x, y), pal.AMBER)
            rows = [
                ("LOCATION", m.location),
                ("DIFFICULTY", m.difficulty_label),
                ("DURATION", f"~{m.estimated_minutes:.0f} min"),
            ]
            y += 44
            for k, v in rows:
                _txt(surface, fonts["small"], k, (x, y), pal.UI_DIM)
                _txt(surface, fonts["body"], v, (x + 120, y - 2), pal.UI_TEXT)
                y += 26
            y += 8
            _txt(surface, fonts["small"], "OBJECTIVES", (x, y), pal.UI_DIM)
            y += 22
            rec = self.ctx.save.missions.get(m.id)
            objs = m.objectives if m.mode is not MissionMode.SURVIVAL else []
            if m.mode is MissionMode.SURVIVAL:
                objs_text = [f"{wv.name}" for wv in m.waves]
            else:
                objs_text = [("(optional) " if o.optional else "") + o.title for o in objs]
            for t in objs_text[:9]:
                _txt(surface, fonts["small"], "- " + t, (x + 6, y), pal.UI_TEXT)
                y += 20
            y = r.bottom - 54
            status = "COMPLETE" if rec and rec.completed else "NOT COMPLETED"
            col = pal.BLUE if rec and rec.completed else pal.UI_DIM
            _txt(surface, fonts["small"], f"STATUS  {status}", (x, y), col)
            if rec and rec.completed:
                _txt(
                    surface,
                    fonts["small"],
                    f"BEST  {rec.best_score}  RANK {rec.best_rank}  {rec.best_time:.0f}s",
                    (x, y + 20),
                    pal.UI_DIM,
                )


class Loadout(Screen):
    name = "loadout"

    def __init__(self, ctx: MenuContext) -> None:
        self.ctx = ctx
        sv = ctx.save

        def cycle(slot: Slot, field_name: str) -> Callable[[int], None]:
            def fn(d: int) -> None:
                opts = [w for w in sv.weapons_unlocked if CATALOGUE[w].slot is slot]
                if slot is Slot.SPECIAL:
                    opts = [""] + opts
                if not opts:
                    return
                cur = getattr(sv.loadout, field_name)
                i = opts.index(cur) if cur in opts else 0
                setattr(sv.loadout, field_name, opts[(i + d) % len(opts)])

            return fn

        def name(field_name: str) -> Callable[[], str]:
            return lambda: (
                CATALOGUE[getattr(sv.loadout, field_name)].name if getattr(sv.loadout, field_name) else "NONE"
            )

        self.menu = MenuList(
            [
                Item("PRIMARY", None, name("primary"), cycle(Slot.PRIMARY, "primary")),
                Item("SIDEARM", None, name("secondary"), cycle(Slot.SECONDARY, "secondary")),
                Item("SPECIAL", None, name("special"), cycle(Slot.SPECIAL, "special")),
                Item("BACK", lambda: ScreenAction(Act.SAVE)),
            ],
            ctx.sound,
        )

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            return ScreenAction(Act.SAVE)
        return self.menu.handle(e)

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 170))
        surface.blit(shade, (0, 0))
        _txt(surface, fonts["title"], "LOADOUT", (int(w * 0.08), 40), pal.UI_TEXT)
        self.menu.draw(surface, fonts, int(w * 0.08), 100, 560, 46)
        idx = self.menu.index
        wid = (
            [self.ctx.save.loadout.primary, self.ctx.save.loadout.secondary, self.ctx.save.loadout.special][idx]
            if idx < 3
            else ""
        )
        if wid:
            sp = CATALOGUE[wid]
            r = pygame.Rect(int(w * 0.08), 320, 560, 250)
            panel(surface, r)
            x, y = r.x + 20, r.y + 16
            _txt(surface, fonts["mid"], sp.name, (x, y), pal.AMBER)
            stats = [
                ("DAMAGE", f"{sp.damage:g}" + (f" x{sp.pellets}" if sp.pellets > 1 else "")),
                ("RATE OF FIRE", f"{sp.rate_of_fire:.0f} rpm"),
                ("MAGAZINE", str(sp.magazine_capacity)),
                ("RELOAD", f"{sp.reload_time:.1f}s"),
                ("SPREAD", f"{sp.spread:.1f} deg"),
                ("RECOIL", f"{sp.recoil:.2f}"),
                ("RANGE", f"{sp.range:.0f} m"),
                ("WEIGHT", f"{sp.weight:.1f} kg"),
                ("FIRE MODEL", sp.fire_mode.value),
            ]
            y += 42
            for i, (k, v) in enumerate(stats):
                cx = x + (i % 2) * 270
                cy = y + (i // 2) * 26
                _txt(surface, fonts["small"], k, (cx, cy), pal.UI_DIM)
                _txt(surface, fonts["body"], v, (cx + 130, cy - 2), pal.UI_TEXT)


class Settings_(Screen):
    name = "settings"

    def __init__(self, ctx: MenuContext, section: str = "main") -> None:
        self.ctx, self.section = ctx, section
        s = ctx.settings

        def bool_item(label: str, obj: object, attr: str) -> Item:
            def adj(d: int) -> None:
                setattr(obj, attr, not getattr(obj, attr))
                ctx.apply_settings()

            return Item(label, None, lambda: "ON" if getattr(obj, attr) else "OFF", adj)

        def enum_item(label: str, obj: object, attr: str, enum_cls) -> Item:
            def adj(d: int) -> None:
                opts = list(enum_cls)
                cur = getattr(obj, attr)
                setattr(obj, attr, opts[(opts.index(cur) + d) % len(opts)])
                ctx.apply_settings()

            return Item(label, None, lambda: getattr(obj, attr).value.upper(), adj)

        def num_item(
            label: str, obj: object, attr: str, lo: float, hi: float, step: float, fmt: str = "{:.2f}"
        ) -> Item:
            def adj(d: int) -> None:
                v = round(min(hi, max(lo, getattr(obj, attr) + d * step)), 4)
                setattr(obj, attr, type(getattr(obj, attr))(v))
                ctx.apply_settings()

            return Item(label, None, lambda: fmt.format(getattr(obj, attr)), adj)

        back = Item("BACK", lambda: ScreenAction(Act.SAVE))
        c = s.comfort
        if section == "main":
            items = [
                enum_item("DIFFICULTY", s.game, "difficulty", Difficulty),
                num_item("FIELD OF VIEW", s.player, "fov_degrees", 60, 120, 5, "{:.0f}"),
                num_item("MOUSE SENSITIVITY", s.player, "mouse_sensitivity", 0.0005, 0.006, 0.0002, "{:.4f}"),
                num_item("MASTER VOLUME", s.audio, "master", 0.0, 1.0, 0.1),
                bool_item("SPATIAL AUDIO", s.audio, "spatial"),
                enum_item("LOCOMOTION (VR)", c, "locomotion", LocomotionMode),
                enum_item("TURNING (VR)", c, "turn_mode", TurnMode),
                num_item("SNAP TURN DEGREES", s.player, "snap_turn_degrees", 10, 90, 5, "{:.0f}"),
                num_item("MOVE SPEED", s.player, "movement_speed", 1.0, 6.0, 0.25),
                enum_item("DOMINANT HAND", c, "handedness", Handedness),
                Item("HAPTICS ...", lambda: ScreenAction(Act.GOTO, "settings:haptics")),
                Item("ACCESSIBILITY ...", lambda: ScreenAction(Act.GOTO, "settings:access")),
                back,
            ]
        elif section == "haptics":
            h = s.haptics
            items = [
                bool_item("HAPTICS", h, "enabled"),
                num_item("INTENSITY", h, "intensity", 0.0, 1.0, 0.1),
                bool_item("REDUCED HAPTICS", h, "reduced"),
                bool_item("WEAPON RECOIL", h, "weapons"),
                bool_item("IMPACTS / DAMAGE", h, "impacts"),
                bool_item("UI FEEDBACK", h, "ui"),
                bool_item("AMBIENT (HEARTBEAT)", h, "ambient"),
                bool_item("LEFT CONTROLLER", h, "left_hand"),
                bool_item("RIGHT CONTROLLER", h, "right_hand"),
                back,
            ]
        else:
            items = [
                bool_item("SEATED MODE", c, "seated_mode"),
                bool_item("REDUCED MOTION", c, "reduced_motion"),
                bool_item("REDUCED CAMERA SHAKE", c, "reduced_camera_shake"),
                bool_item("SIMPLIFIED RELOAD", c, "simplified_reload"),
                bool_item("SIMPLIFIED INTERACTION", c, "simplified_interaction"),
                bool_item("DASH ENABLED", c, "dash_enabled"),
                bool_item("TELEPORT FADE", c, "teleport_fade"),
                num_item("COMFORT VIGNETTE", c, "vignette", 0.0, 1.0, 0.1),
                back,
            ]
        self.menu = MenuList(items, ctx.sound)

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            return ScreenAction(Act.SAVE)
        return self.menu.handle(e)

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 190))
        surface.blit(shade, (0, 0))
        title = {
            "main": "SETTINGS",
            "haptics": "SETTINGS  /  HAPTICS",
            "access": "SETTINGS  /  ACCESSIBILITY",
        }[self.section]
        _txt(surface, fonts["title"], title, (int(w * 0.08), 30), pal.UI_TEXT)
        self.menu.draw(surface, fonts, int(w * 0.08), 80, int(w * 0.6), 40, "body")
        _txt(
            surface,
            fonts["small"],
            "Left/Right adjust   Esc back (saves)",
            (int(w * 0.08), h - 36),
            pal.UI_DIM,
        )


class Results(Screen):
    name = "results"

    def __init__(self, ctx: MenuContext, r: MissionResult, new_unlocks: list[str]) -> None:
        self.ctx, self.r, self.unlocks = ctx, r, new_unlocks
        self.t = 0.0
        self.menu = MenuList(
            [
                Item("CONTINUE", lambda: ScreenAction(Act.MENU)),
                Item("REPLAY", lambda: ScreenAction(Act.START, r.mission_id)),
                Item("LOADOUT", lambda: ScreenAction(Act.GOTO, "loadout")),
            ],
            ctx.sound,
        )

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        return self.menu.handle(e)

    def update(self, dt: float) -> None:
        self.t += dt

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        r = self.r
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 205))
        surface.blit(shade, (0, 0))
        title = "MISSION COMPLETE" if r.success else "MISSION FAILED"
        _txt(surface, fonts["huge"], title, (int(w * 0.08), 36), pal.UI_TEXT if r.success else pal.RED)
        _txt(
            surface,
            fonts["body"],
            f"{r.title}" + ("" if r.success else f"  -  {r.reason}"),
            (int(w * 0.08), 100),
            pal.UI_DIM,
        )
        panel_r = pygame.Rect(int(w * 0.08), 140, int(w * 0.52), 330)
        panel(surface, panel_r)
        x, y = panel_r.x + 24, panel_r.y + 18
        mm, ss = divmod(int(r.elapsed), 60)
        rows = [
            ("COMPLETION TIME", f"{mm}:{ss:02d}"),
            ("ACCURACY", f"{r.accuracy * 100:.0f}%  ({r.hits}/{r.shots})"),
            ("OBJECTIVES", f"{r.primary_done}/{r.primary_total}"),
            ("DAMAGE TAKEN", f"{r.damage_taken:.0f}"),
            ("ENEMIES DEFEATED", str(r.kills)),
            ("OPTIONAL OBJECTIVES", f"{r.optional_done}/{r.optional_total}"),
        ]
        if r.waves_cleared:
            rows.append(("WAVES CLEARED", str(r.waves_cleared)))
        for k, v in rows:
            _txt(surface, fonts["small"], k, (x, y), pal.UI_DIM)
            _txt(surface, fonts["body"], v, (x + 230, y - 2), pal.UI_TEXT)
            y += 30
        # transparent score breakdown
        bx = int(w * 0.64)
        sr = pygame.Rect(bx, 140, int(w * 0.28), 330)
        panel(surface, sr)
        sx, sy = sr.x + 20, sr.y + 18
        _txt(surface, fonts["small"], "SCORE BREAKDOWN", (sx, sy), pal.AMBER)
        sy += 28
        for line in r.score.lines:
            _txt(surface, fonts["small"], line.label, (sx, sy), pal.UI_DIM)
            _txt(
                surface,
                fonts["small"],
                f"{line.points}/{line.maximum}",
                (sr.right - 20, sy),
                pal.UI_TEXT,
                "tr",
            )
            _txt(surface, fonts["small"], line.detail, (sx + 8, sy + 15), (90, 92, 90))
            sy += 40
        _txt(surface, fonts["mid"], f"{r.score.total}", (sx, sr.bottom - 50), pal.AMBER)
        _txt(surface, fonts["mid"], f"RANK {r.score.rank}", (sr.right - 20, sr.bottom - 50), pal.UI_TEXT, "tr")
        if self.unlocks:
            _txt(
                surface,
                fonts["body"],
                "UNLOCKED: " + ", ".join(CATALOGUE[u].name for u in self.unlocks),
                (int(w * 0.08), 484),
                pal.BLUE,
            )
        self.menu.draw(surface, fonts, int(w * 0.08), 530, 320, 42, "body")


class Pause(Screen):
    name = "pause"

    def __init__(self, ctx: MenuContext) -> None:
        self.menu = MenuList(
            [
                Item("RESUME", lambda: ScreenAction(Act.RESUME)),
                Item("SETTINGS", lambda: ScreenAction(Act.GOTO, "settings")),
                Item("RESTART MISSION", lambda: ScreenAction(Act.RESTART)),
                Item("QUIT TO MENU", lambda: ScreenAction(Act.MENU)),
            ],
            ctx.sound,
        )

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            return ScreenAction(Act.RESUME)
        return self.menu.handle(e)

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        shade = pygame.Surface((w, h), pygame.SRCALPHA)
        shade.fill((6, 8, 10, 170))
        surface.blit(shade, (0, 0))
        r = pygame.Rect(w // 2 - 190, h // 2 - 150, 380, 300)
        panel(surface, r, 225)
        _txt(surface, fonts["title"], "PAUSED", (r.centerx, r.y + 20), pal.UI_TEXT, "tc")
        self.menu.draw(surface, fonts, r.x + 20, r.y + 74, r.w - 40, 46, "body")


class Briefing(Screen):
    name = "briefing"

    def __init__(self, ctx: MenuContext, m: MissionDef) -> None:
        self.m, self.t = m, 0.0

    def handle(self, e: pygame.event.Event) -> ScreenAction | None:
        if e.type == pygame.KEYDOWN and e.key in (pygame.K_RETURN, pygame.K_SPACE):
            return ScreenAction(Act.RESUME)
        if e.type == pygame.MOUSEBUTTONDOWN:
            return ScreenAction(Act.RESUME)
        if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
            return ScreenAction(Act.MENU)
        return None

    def update(self, dt: float) -> None:
        self.t += dt

    def draw(self, surface: pygame.Surface, fonts: dict[str, pygame.font.Font]) -> None:
        w, h = surface.get_size()
        surface.fill((10, 12, 14))
        for i in range(0, h, 4):
            pygame.draw.line(surface, (13, 15, 18), (0, i), (w, i))
        x = int(w * 0.1)
        _txt(surface, fonts["small"], "MISSION BRIEFING", (x, 60), pal.AMBER)
        _txt(surface, fonts["huge"], f"{self.m.title}", (x, 84), pal.UI_TEXT)
        _txt(surface, fonts["body"], self.m.location.upper(), (x, 150), pal.UI_DIM)
        pygame.draw.line(surface, pal.AMBER, (x, 182), (x + 100, 182), 3)
        y = 210
        shown = int(self.t * 40)
        for line in self.m.briefing:
            take = max(0, min(len(line), shown))
            shown -= len(line)
            _txt(surface, fonts["body"], line[:take], (x, y), pal.UI_TEXT)
            y += 30
        _txt(surface, fonts["small"], "ENTER  -  begin mission", (x, h - 70), pal.AMBER)
