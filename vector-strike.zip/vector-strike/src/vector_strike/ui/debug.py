"""F3 developer overlay: FPS, frame time, player, entities, physics, VR/MR state, mission state, haptics."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import pygame

from ..core.types import Hand
from ..game.session import GameSession
from ..rendering import palette as pal


@dataclass
class FrameTimer:
    samples: deque[float] = field(default_factory=lambda: deque(maxlen=120))

    def add(self, dt: float) -> None:
        self.samples.append(dt)

    @property
    def fps(self) -> float:
        return len(self.samples) / sum(self.samples) if self.samples and sum(self.samples) > 0 else 0.0

    @property
    def frame_ms(self) -> float:
        return 1000.0 * sum(self.samples) / len(self.samples) if self.samples else 0.0

    @property
    def worst_ms(self) -> float:
        return 1000.0 * max(self.samples) if self.samples else 0.0


def overlay_lines(s: GameSession, timer: FrameTimer, *, vr_state: str, render_stats: dict[str, int]) -> list[str]:
    p = s.player.state
    alive = len(s.alive_enemies())
    mr = "off"
    if s.mr_env is not None:
        env = s.mr_env
        mr = f"{env.meta.room_id} {env.width:.1f}x{env.depth:.1f}m valid={env.is_valid()} anchors={len(env.anchors)}"
    hap = s.haptics
    hl = hr = 0.0
    if hap is not None:
        hl, hr = hap.engine.last_samples[Hand.LEFT].amp, hap.engine.last_samples[Hand.RIGHT].amp
    r = s.runner
    obj = r.active_primary()
    return [
        f"FPS {timer.fps:5.1f}   FRAME {timer.frame_ms:5.2f} ms   WORST {timer.worst_ms:5.2f} ms",
        f"PLAYER ({p.pos.x:6.2f}, {p.pos.y:4.2f}, {p.pos.z:6.2f})  yaw {p.yaw:5.2f}  hp {p.health:5.1f}  {p.stance.value}",
        f"ENEMIES {alive} alive / {len(s.enemies)} total   PROJECTILES {s.projectiles.active_count}   GRENADES {len(s.grenades)}",
        f"PHYSICS OBJECTS {len(s.level.world.colliders)} colliders   NAV paths {s.nav.paths_computed}   NOISES {len(s.noises)}",
        f"RENDER polys {render_stats.get('polys', 0)}  boxes {render_stats.get('boxes', 0)}   GPU MEM n/a (software renderer)",
        f"VR {vr_state}   HAPTICS L {hl:.2f}  R {hr:.2f}   voices {sum(len(v) for v in hap.engine.voices.values()) if hap else 0}",
        f"MR {mr}",
        f"MISSION {s.mission.id}  phase {r.phase.value}  obj {obj.defn.id if obj else '-'}  t {r.elapsed:6.1f}s  tick {s.tick}",
        f"HASH {s.state_hash()}   SEED {s.seed}",
    ]


def draw_overlay(
    surface: pygame.Surface,
    fonts: dict[str, pygame.font.Font],
    lines: list[str],
    haptic_bars: tuple[float, float] | None = None,
) -> None:
    f = fonts["small"]
    h = 16 * len(lines) + 12
    bg = pygame.Surface((760, h), pygame.SRCALPHA)
    bg.fill((8, 10, 12, 190))
    surface.blit(bg, (8, 8))
    for i, line in enumerate(lines):
        surface.blit(f.render(line, True, pal.UI_TEXT), (16, 14 + i * 16))
    if haptic_bars is not None:
        x, y = 780, 14
        for j, (lbl, v) in enumerate((("L", haptic_bars[0]), ("R", haptic_bars[1]))):
            pygame.draw.rect(surface, (30, 32, 34), (x, y + j * 18, 90, 10))
            pygame.draw.rect(surface, pal.AMBER, (x, y + j * 18, int(90 * min(1.0, v)), 10))
            surface.blit(f.render(lbl, True, pal.UI_DIM), (x - 14, y + j * 18 - 3))
