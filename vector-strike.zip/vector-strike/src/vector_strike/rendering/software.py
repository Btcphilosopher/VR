"""Software renderer (pygame) for the desktop development mode.

A deliberately simple painter's-algorithm box renderer: it keeps the full game playable and screenshot-able
without a GPU backend. The `Renderer` protocol lets a ModernGL / OpenXR stereo renderer replace it later.
Performance features: distance + frustum culling, back-face culling, near-plane clipping, cached static
lighting, bounded effect count."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Protocol

import pygame

from ..enemies.enemy import AIState, Enemy
from ..enemies.spec import Role
from ..game.session import GameSession
from ..missions.level import Level
from ..physics.shapes import AABB
from ..physics.vec import Vec3
from ..physics.world import ColliderKind
from . import palette as pal
from .palette import Color

NEAR = 0.08
LIGHT_DIR = (0.35, 0.8, 0.45)
FACE_SHADE = {"+y": 1.0, "+z": 0.86, "-z": 0.74, "+x": 0.7, "-x": 0.62, "-y": 0.45}

_FACES = (
    ("-x", (0, 1, 3, 2)),
    ("+x", (4, 6, 7, 5)),
    ("-y", (0, 4, 5, 1)),
    ("+y", (2, 3, 7, 6)),
    ("-z", (0, 2, 6, 4)),
    ("+z", (1, 5, 7, 3)),
)


class Renderer(Protocol):
    def render(self, session: GameSession, surface: pygame.Surface, flags: DebugFlags, view: ViewState) -> None: ...


@dataclass
class DebugFlags:
    show_fps: bool = False
    show_hitboxes: bool = False
    show_ai: bool = False
    show_mr_mesh: bool = False
    overlay: bool = False


@dataclass
class ViewState:
    """Per-frame presentation inputs that are not simulation state."""

    fov_deg: float = 90.0
    draw_distance: float = 70.0
    reduced_motion: bool = False
    bob_phase: float = 0.0
    ads: float = 0.0
    camera_override: tuple[Vec3, float, float] | None = None  # (eye, yaw, pitch) for menu fly-through


def _shade(c: Color, k: float) -> Color:
    return (max(0, min(255, int(c[0] * k))), max(0, min(255, int(c[1] * k))), max(0, min(255, int(c[2] * k))))


@dataclass
class _Cam:
    ex: float
    ey: float
    ez: float
    fx: float
    fy: float
    fz: float
    rx: float
    rz: float
    ux: float
    uy: float
    uz: float
    f: float
    cx: float
    cy: float

    def to_cam(self, x: float, y: float, z: float) -> tuple[float, float, float]:
        dx, dy, dz = x - self.ex, y - self.ey, z - self.ez
        return (
            dx * self.rx + dz * self.rz,
            dx * self.ux + dy * self.uy + dz * self.uz,
            dx * self.fx + dy * self.fy + dz * self.fz,
        )

    def project(self, c: tuple[float, float, float]) -> tuple[float, float]:
        return (self.cx + c[0] / c[2] * self.f, self.cy - c[1] / c[2] * self.f)


def make_cam(eye: Vec3, yaw: float, pitch: float, fov_deg: float, w: int, h: int) -> _Cam:
    cp, sp = math.cos(pitch), math.sin(pitch)
    fx, fy, fz = math.sin(yaw) * cp, sp, math.cos(yaw) * cp
    rx, rz = math.cos(yaw), -math.sin(yaw)
    # up = forward x right
    ux, uy, uz = fy * rz - fz * 0.0, fz * rx - fx * rz, fx * 0.0 - fy * rx
    f = (w / 2) / math.tan(math.radians(fov_deg) / 2)
    return _Cam(eye.x, eye.y, eye.z, fx, fy, fz, rx, rz, ux, uy, uz, f, w / 2, h / 2)


def _clip_near(poly: list[tuple[float, float, float]]) -> list[tuple[float, float, float]]:
    out: list[tuple[float, float, float]] = []
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        ain, bin_ = a[2] >= NEAR, b[2] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[2]) / (b[2] - a[2])
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR))
    return out


@dataclass
class _Poly:
    depth: float
    color: Color
    pts: list[tuple[float, float]]
    outline: Color | None = None


class SoftwareRenderer:
    def __init__(self, level: Level, fonts: dict[str, pygame.font.Font] | None = None) -> None:
        self.level = level
        self.fonts = fonts or {}
        self._light_cache: dict[tuple[int, bool], tuple[float, float, float]] = {}
        self._door_of: dict[int, str] = {}
        for did, info in level.doors.items():
            for cid in info.collider_ids:
                self._door_of[cid] = did
        self.stats = {"polys": 0, "boxes": 0}
        self._flash = 0.0

    # ---- lighting ---------------------------------------------------------------------------------------
    def _light_at(self, pos: Vec3, powered: bool, key: int | None = None) -> tuple[float, float, float]:
        if key is not None:
            hit = self._light_cache.get((key, powered))
            if hit is not None:
                return hit
        amb = self.level.ambient if powered else 0.14
        r = g = b = amb
        for L in self.level.lights:
            active = (L.mains and powered) or (L.emergency and not powered)
            if not active:
                continue
            d = math.sqrt((pos.x - L.pos.x) ** 2 + (pos.y - L.pos.y) ** 2 + (pos.z - L.pos.z) ** 2)
            if d >= L.radius:
                continue
            k = (1.0 - d / L.radius) ** 2 * L.intensity * (0.55 if powered else 0.9)
            r += k * L.color[0] / 255.0
            g += k * L.color[1] / 255.0
            b += k * L.color[2] / 255.0
        res = (min(r, 1.25), min(g, 1.25), min(b, 1.25))
        if key is not None:
            self._light_cache[(key, powered)] = res
        return res

    # ---- geometry --------------------------------------------------------------------------------------
    def _box_polys(
        self,
        cam: _Cam,
        box: AABB,
        base: Color,
        light: tuple[float, float, float],
        fog_dist: float,
        emissive: bool,
        polys: list[_Poly],
        draw_dist: float,
        yaw: float = 0.0,
        pivot: Vec3 | None = None,
    ) -> None:
        mn, mx = box.min, box.max
        cs = [
            (mn.x if (i & 4) == 0 else mx.x, mn.y if (i & 2) == 0 else mx.y, mn.z if (i & 1) == 0 else mx.z)
            for i in range(8)
        ]
        if yaw != 0.0 and pivot is not None:
            c, s = math.cos(yaw), math.sin(yaw)
            cs = [
                (
                    pivot.x + (x - pivot.x) * c + (z - pivot.z) * s,
                    y,
                    pivot.z - (x - pivot.x) * s + (z - pivot.z) * c,
                )
                for x, y, z in cs
            ]
        cc = [cam.to_cam(*p) for p in cs]
        ex, ey, ez = cam.ex, cam.ey, cam.ez
        fogk = max(0.0, min(1.0, fog_dist / draw_dist))
        fog = pal.FOG
        for name, idx in _FACES:
            if yaw == 0.0:
                if name == "+x" and ex <= mx.x:
                    continue
                if name == "-x" and ex >= mn.x:
                    continue
                if name == "+y" and ey <= mx.y:
                    continue
                if name == "-y" and ey >= mn.y:
                    continue
                if name == "+z" and ez <= mx.z:
                    continue
                if name == "-z" and ez >= mn.z:
                    continue
            else:
                # general back-face test via screen-space winding
                p = [cc[i] for i in idx]
                if all(q[2] < NEAR for q in p):
                    continue
            poly3 = _clip_near([cc[i] for i in idx])
            if len(poly3) < 3:
                continue
            pts = [cam.project(q) for q in poly3]
            if yaw != 0.0:
                area = sum(
                    pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1]
                    for i in range(len(pts))
                )
                if area > 0:
                    continue
            if emissive:
                col = base
            else:
                k = FACE_SHADE[name]
                col = (int(base[0] * k * light[0]), int(base[1] * k * light[1]), int(base[2] * k * light[2]))
            if fogk > 0.0:
                t = fogk**1.4 * 0.85
                col = (
                    int(col[0] + (fog[0] - col[0]) * t),
                    int(col[1] + (fog[1] - col[1]) * t),
                    int(col[2] + (fog[2] - col[2]) * t),
                )
            col = (max(0, min(255, col[0])), max(0, min(255, col[1])), max(0, min(255, col[2])))
            depth = sum(q[2] for q in poly3) / len(poly3)
            polys.append(_Poly(depth, col, pts))

    # ---- main entry --------------------------------------------------------------------------------------
    def render(self, session: GameSession, surface: pygame.Surface, flags: DebugFlags, view: ViewState) -> None:
        w, h = surface.get_size()
        pl = session.player
        if view.camera_override is not None:
            eye, yaw, pitch = view.camera_override
        else:
            bob = 0.0
            if not view.reduced_motion and pl.state.grounded:
                bob = math.sin(view.bob_phase) * 0.018 * min(1.0, pl.state.speed_xz / 3.0)
            eye, yaw, pitch = pl.eye + Vec3(0, bob, 0), pl.state.yaw, pl.state.pitch
        fov = view.fov_deg * (1.0 - 0.22 * view.ads)
        cam = make_cam(eye, yaw, pitch, fov, w, h)
        self._draw_background(surface, cam, w, h)
        self._draw_floor(surface, cam, session, view)
        polys: list[_Poly] = []
        powered = session.powered
        lvl = self.level
        dd = view.draw_distance
        half_fov = math.radians(fov) / 2 + 0.55

        def visible(b: AABB) -> bool:
            c = b.center
            dx, dz = c.x - cam.ex, c.z - cam.ez
            dist = math.hypot(dx, dz)
            rad = max(b.size.x, b.size.z) * 0.71 + 0.5
            if dist - rad > dd:
                return False
            if dist < rad + 0.5:
                return True
            fwd_h = math.hypot(cam.fx, cam.fz)
            dotv = (dx * cam.fx + dz * cam.fz) / (dist * max(fwd_h, 1e-6))
            ang = math.acos(max(-1.0, min(1.0, dotv)))
            return ang - math.asin(min(1.0, rad / dist)) <= half_fov

        n_boxes = 0
        for c in lvl.world.colliders.values():
            if c.open or not c.visible:
                continue
            b = c.aabb
            if not visible(b):
                continue
            key = c.color_key or ("wall" if c.kind is ColliderKind.WALL else "concrete")
            if c.kind is ColliderKind.DOOR:
                did = self._door_of.get(c.id)
                locked = lvl.doors[did].locked if did else True
                key = "door_locked" if locked else "door"
            base = pal.color(key)
            light = self._light_at(b.center, powered, c.id)
            dist = math.hypot(b.center.x - cam.ex, b.center.z - cam.ez)
            self._box_polys(cam, b, base, light, dist, False, polys, dd)
            n_boxes += 1
        for i, d in enumerate(lvl.decor):
            b = d.aabb
            if not visible(b):
                continue
            key = d.color_key
            emissive = d.emissive and (powered or key != "light_white")
            if key == "light_white" and not powered:
                base, emissive = (36, 38, 40), True
            else:
                base = pal.color(key)
            light = self._light_at(b.center, powered, -(i + 1))
            dist = math.hypot(b.center.x - cam.ex, b.center.z - cam.ez)
            self._box_polys(cam, b, base, light, dist, emissive, polys, dd)
            n_boxes += 1
        self._enemy_polys(cam, session, polys, dd, flags)
        self._pickup_polys(cam, session, polys, dd)
        for g in session.grenades:
            bx = AABB(g.pos - Vec3(0.09, 0.09, 0.09), g.pos + Vec3(0.09, 0.09, 0.09))
            self._box_polys(cam, bx, (46, 50, 46), (1, 1, 1), 5.0, False, polys, dd)
        polys.sort(key=lambda p: -p.depth)
        for p in polys:
            if len(p.pts) >= 3:
                pygame.draw.polygon(surface, p.color, p.pts)
        self.stats = {"polys": len(polys), "boxes": n_boxes}
        self._draw_effects(surface, cam, session, w, h)
        self._draw_markers(surface, cam, session)
        if flags.show_hitboxes:
            self._draw_hitboxes(surface, cam, session)
        if flags.show_ai:
            self._draw_ai(surface, cam, session)
        if flags.show_mr_mesh and session.mr_env is not None:
            self._draw_mr_mesh(surface, cam, session)

    # ---- background / floor -----------------------------------------------------------------------------
    def _draw_background(self, surface: pygame.Surface, cam: _Cam, w: int, h: int) -> None:
        horizon = int(cam.cy + cam.fy / max(math.sqrt(max(1e-6, 1 - cam.fy**2)), 1e-6) * cam.f)
        horizon = max(0, min(h, horizon))
        surface.fill(pal.FOG)
        top, hor = pal.SKY_TOP, pal.SKY_HORIZON
        steps = 12
        for i in range(steps):
            y0 = int(horizon * i / steps)
            y1 = int(horizon * (i + 1) / steps)
            t = i / (steps - 1)
            col = (
                int(top[0] + (hor[0] - top[0]) * t),
                int(top[1] + (hor[1] - top[1]) * t),
                int(top[2] + (hor[2] - top[2]) * t),
            )
            pygame.draw.rect(surface, col, (0, y0, w, y1 - y0 + 1))

    def _draw_floor(self, surface: pygame.Surface, cam: _Cam, session: GameSession, view: ViewState) -> None:
        mnx, mnz, mxx, mxz = self.level.bounds
        corners = [(mnx, 0.0, mnz), (mxx, 0.0, mnz), (mxx, 0.0, mxz), (mnx, 0.0, mxz)]
        poly3 = _clip_near([cam.to_cam(*c) for c in corners])
        if len(poly3) >= 3:
            amb = self._light_at(Vec3(cam.ex, 0.5, cam.ez), session.powered)
            col = (
                int(pal.FLOOR[0] * min(1.2, amb[0] + 0.25)),
                int(pal.FLOOR[1] * min(1.2, amb[1] + 0.25)),
                int(pal.FLOOR[2] * min(1.2, amb[2] + 0.25)),
            )
            pygame.draw.polygon(surface, col, [cam.project(q) for q in poly3])
        # grid lines near the camera
        span = 22.0
        sp = 2.0
        x = math.floor((cam.ex - span) / sp) * sp
        lines: list[tuple[tuple[float, float, float], tuple[float, float, float]]] = []
        while x <= cam.ex + span:
            if mnx <= x <= mxx:
                lines.append(((x, 0.0, max(mnz, cam.ez - span)), (x, 0.0, min(mxz, cam.ez + span))))
            x += sp
        z = math.floor((cam.ez - span) / sp) * sp
        while z <= cam.ez + span:
            if mnz <= z <= mxz:
                lines.append(((max(mnx, cam.ex - span), 0.0, z), (min(mxx, cam.ex + span), 0.0, z)))
            z += sp
        lc = _shade(pal.FLOOR_LINE, 0.6 if session.powered else 0.35)
        for a, b in lines:
            ca, cb = cam.to_cam(*a), cam.to_cam(*b)
            if ca[2] < NEAR and cb[2] < NEAR:
                continue
            if ca[2] < NEAR:
                t = (NEAR - ca[2]) / (cb[2] - ca[2])
                ca = (ca[0] + (cb[0] - ca[0]) * t, ca[1] + (cb[1] - ca[1]) * t, NEAR)
            elif cb[2] < NEAR:
                t = (NEAR - cb[2]) / (ca[2] - cb[2])
                cb = (cb[0] + (ca[0] - cb[0]) * t, cb[1] + (ca[1] - cb[1]) * t, NEAR)
            pygame.draw.line(surface, lc, cam.project(ca), cam.project(cb), 1)

    # ---- entities -----------------------------------------------------------------------------------------
    def _enemy_polys(self, cam: _Cam, session: GameSession, polys: list[_Poly], dd: float, flags: DebugFlags) -> None:
        powered = session.powered
        for e in session.enemies:
            d = e.pos.dist_xz(Vec3(cam.ex, 0, cam.ez))
            if d > dd:
                continue
            light = self._light_at(e.pos + Vec3(0, 1.2, 0), powered)
            light = (max(light[0], 0.35), max(light[1], 0.35), max(light[2], 0.35))
            if e.spec.role is Role.TARGET:
                self._target_polys(cam, e, polys, d, dd, light)
                continue
            if not e.alive:
                self._corpse_polys(cam, e, polys, d, dd, light)
                continue
            s = e.stance_scale
            p = e.pos
            yaw = e.yaw
            flash = e.flash_t > 0
            boost = 1.9 if flash else 1.0
            marker = e.spec.marker
            big = 1.18 if e.spec.role is Role.BOSS else 1.08 if e.spec.role is Role.ELITE else 1.0
            parts: list[tuple[AABB, str, bool]] = [
                (
                    AABB(Vec3(p.x - 0.2 * big, p.y, p.z - 0.12), Vec3(p.x - 0.02, p.y + 0.85 * s, p.z + 0.12)),
                    "helix_uniform",
                    False,
                ),
                (
                    AABB(Vec3(p.x + 0.02, p.y, p.z - 0.12), Vec3(p.x + 0.2 * big, p.y + 0.85 * s, p.z + 0.12)),
                    "helix_uniform",
                    False,
                ),
                (
                    AABB(
                        Vec3(p.x - 0.27 * big, p.y + 0.85 * s, p.z - 0.18),
                        Vec3(p.x + 0.27 * big, p.y + 1.5 * s, p.z + 0.18),
                    ),
                    "helix_vest",
                    False,
                ),
                (
                    AABB(
                        Vec3(p.x - 0.15, p.y + 1.5 * s, p.z - 0.15),
                        Vec3(p.x + 0.15, p.y + 1.78 * s, p.z + 0.15),
                    ),
                    "helix_helmet",
                    False,
                ),
                (
                    AABB(
                        Vec3(p.x - 0.15, p.y + 1.63 * s, p.z + 0.11),
                        Vec3(p.x + 0.15, p.y + 1.69 * s, p.z + 0.16),
                    ),
                    marker,
                    True,
                ),
                (
                    AABB(
                        Vec3(p.x - 0.4 * big, p.y + 1.0 * s, p.z - 0.1),
                        Vec3(p.x - 0.27 * big, p.y + 1.45 * s, p.z + 0.12),
                    ),
                    "helix_uniform",
                    False,
                ),
                (
                    AABB(
                        Vec3(p.x + 0.27 * big, p.y + 1.1 * s, p.z - 0.05),
                        Vec3(p.x + 0.4 * big, p.y + 1.4 * s, p.z + 0.6),
                    ),
                    "helix_uniform",
                    False,
                ),
                (
                    AABB(
                        Vec3(p.x + 0.3 * big, p.y + 1.22 * s, p.z + 0.1),
                        Vec3(p.x + 0.38 * big, p.y + 1.36 * s, p.z + 0.85),
                    ),
                    "helix_gun",
                    False,
                ),
                (
                    AABB(Vec3(p.x - 0.2, p.y + 1.0 * s, p.z - 0.26), Vec3(p.x + 0.2, p.y + 1.4 * s, p.z - 0.18)),
                    "helix_vest",
                    False,
                ),
            ]
            if e.spec.role is Role.ELITE or e.spec.role is Role.BOSS:
                parts.append(
                    (
                        AABB(
                            Vec3(p.x - 0.28, p.y + 1.3 * s, p.z + 0.17),
                            Vec3(p.x + 0.28, p.y + 1.48 * s, p.z + 0.22),
                        ),
                        "helix_amber",
                        True,
                    )
                )
            for box, key, em in parts:
                base = pal.color(key)
                if flash:
                    base = (
                        min(255, int(base[0] * boost + 60)),
                        min(255, int(base[1] * boost + 60)),
                        min(255, int(base[2] * boost + 60)),
                    )
                self._box_polys(cam, box, base, light, d, em, polys, dd, yaw=yaw, pivot=p)

    def _target_polys(
        self, cam: _Cam, e: Enemy, polys: list[_Poly], d: float, dd: float, light: tuple[float, float, float]
    ) -> None:
        p = e.pos
        if not e.alive:
            return
        body = AABB(Vec3(p.x - 0.28, p.y + 0.2, p.z - 0.04), Vec3(p.x + 0.28, p.y + 1.5, p.z + 0.04))
        head = AABB(Vec3(p.x - 0.15, p.y + 1.55, p.z - 0.04), Vec3(p.x + 0.15, p.y + 1.85, p.z + 0.04))
        post = AABB(Vec3(p.x - 0.04, p.y, p.z - 0.04), Vec3(p.x + 0.04, p.y + 0.2, p.z + 0.04))
        self._box_polys(cam, body, pal.color("target"), light, d, False, polys, dd, yaw=0.0001, pivot=p)
        self._box_polys(cam, head, pal.color("target_head"), light, d, False, polys, dd, yaw=0.0001, pivot=p)
        self._box_polys(cam, post, pal.color("steel_dark"), light, d, False, polys, dd)

    def _corpse_polys(
        self, cam: _Cam, e: Enemy, polys: list[_Poly], d: float, dd: float, light: tuple[float, float, float]
    ) -> None:
        if e.dead_t > 5.0:
            return
        p = e.pos
        box = AABB(Vec3(p.x - 0.5, 0.0, p.z - 0.25), Vec3(p.x + 0.5, 0.22, p.z + 0.25))
        self._box_polys(cam, box, pal.color("helix_vest"), light, d, False, polys, dd, yaw=e.yaw + 1.2, pivot=p)

    def _pickup_polys(self, cam: _Cam, session: GameSession, polys: list[_Poly], dd: float) -> None:
        for it in session.interactables.values():
            if not it.enabled or it.used:
                continue
            if it.kind in ("pickup", "ammo"):
                p = it.pos
                bob = 0.05 * math.sin(session.t * 2.5)
                col = "warning_amber" if it.kind == "ammo" else "led_blue"
                box = AABB(Vec3(p.x - 0.28, 0.95 + bob, p.z - 0.12), Vec3(p.x + 0.28, 1.07 + bob, p.z + 0.12))
                if it.kind == "ammo":
                    box = AABB(Vec3(p.x - 0.25, 0.0, p.z - 0.2), Vec3(p.x + 0.25, 0.4, p.z + 0.2))
                self._box_polys(
                    cam, box, pal.color(col), (1, 1, 1), p.dist_xz(Vec3(cam.ex, 0, cam.ez)), True, polys, dd
                )

    # ---- overlays ----------------------------------------------------------------------------------------------
    def _draw_effects(self, surface: pygame.Surface, cam: _Cam, session: GameSession, w: int, h: int) -> None:
        for fx in session.effects:
            a = max(0.0, fx.ttl / max(fx.max_ttl, 1e-6))
            if fx.kind == "tracer" and fx.end is not None:
                ca, cb = cam.to_cam(fx.pos.x, fx.pos.y, fx.pos.z), cam.to_cam(fx.end.x, fx.end.y, fx.end.z)
                if ca[2] < NEAR and cb[2] < NEAR:
                    continue
                if ca[2] < NEAR:
                    t = (NEAR - ca[2]) / (cb[2] - ca[2])
                    ca = (ca[0] + (cb[0] - ca[0]) * t, ca[1] + (cb[1] - ca[1]) * t, NEAR)
                elif cb[2] < NEAR:
                    t = (NEAR - cb[2]) / (ca[2] - cb[2])
                    cb = (cb[0] + (ca[0] - cb[0]) * t, cb[1] + (ca[1] - cb[1]) * t, NEAR)
                col = _shade(pal.TRACER.get(fx.color, pal.TRACER["amber"]), 0.4 + 0.6 * a)
                pygame.draw.line(surface, col, cam.project(ca), cam.project(cb), 2)
            elif fx.kind == "impact":
                c = cam.to_cam(fx.pos.x, fx.pos.y, fx.pos.z)
                if c[2] > NEAR:
                    x, y = cam.project(c)
                    r = max(2, int(cam.f * 0.07 / c[2] * (1.2 - a * 0.5)))
                    col = _shade(pal.TRACER["spark"], a)
                    pygame.draw.line(surface, col, (x - r, y), (x + r, y), 1)
                    pygame.draw.line(surface, col, (x, y - r), (x, y + r), 1)
                    pygame.draw.line(surface, col, (x - r * 0.7, y - r * 0.7), (x + r * 0.7, y + r * 0.7), 1)
            elif fx.kind == "explosion":
                self._ring(surface, cam, fx.pos, fx.size * (1.0 - a) * 0.8 + 0.5, _shade(pal.AMBER, 0.3 + 0.7 * a), 3)
            elif fx.kind == "grenade_warning":
                pulse = 0.55 + 0.45 * math.sin(session.t * 10)
                self._ring(surface, cam, fx.pos.with_y(0.05), fx.size, _shade(pal.RED, pulse), 2)
            elif fx.kind == "flash" and a > 0.2:
                self._flash = a

    def _draw_markers(self, surface: pygame.Surface, cam: _Cam, session: GameSession) -> None:
        """World-space objective markers (no flat HUD glue): floor ring + beam + diamond for the active goal."""
        r = session.runner
        obj = r.active_primary()
        if obj is None or obj.defn.type not in ("reach_zone", "interact", "pickup"):
            return
        d = obj.defn
        if d.type == "reach_zone" and d.zone:
            z = session.level.zones.get(d.zone)
            if z is None:
                return
            center, radius = z.center, z.radius
            self._ring(surface, cam, center.with_y(0.04), radius, pal.AMBER, 2)
        else:
            it = session.level.interactables.get(d.target or "")
            if it is None:
                return
            center = it.pos
        top = cam.to_cam(center.x, 2.6, center.z)
        base = cam.to_cam(center.x, 0.0, center.z)
        if top[2] > NEAR and base[2] > NEAR:
            pygame.draw.line(surface, _shade(pal.AMBER, 0.55), cam.project(base), cam.project(top), 1)
        if top[2] > NEAR:
            x, y = cam.project(top)
            pulse = 0.8 + 0.2 * math.sin(session.t * 4.0)
            sz = max(5.0, min(14.0, 70.0 / top[2])) * pulse
            pts = [(x, y - sz), (x + sz * 0.7, y), (x, y + sz), (x - sz * 0.7, y)]
            pygame.draw.polygon(surface, pal.AMBER, pts, 2)
            font = self.fonts.get("small")
            if font:
                dist = math.hypot(center.x - cam.ex, center.z - cam.ez)
                img = font.render(f"{dist:.0f}m", True, pal.AMBER)
                surface.blit(img, (x - img.get_width() / 2, y + sz + 4))

    def _ring(self, surface: pygame.Surface, cam: _Cam, center: Vec3, radius: float, col: Color, width: int) -> None:
        pts = []
        for i in range(24):
            ang = i / 24 * math.tau
            c = cam.to_cam(center.x + math.cos(ang) * radius, center.y, center.z + math.sin(ang) * radius)
            if c[2] < NEAR:
                continue
            pts.append(cam.project(c))
        if len(pts) >= 3:
            pygame.draw.lines(surface, col, True, pts, width)

    def _draw_hitboxes(self, surface: pygame.Surface, cam: _Cam, session: GameSession) -> None:
        for e in session.enemies:
            if not e.alive:
                continue
            for hb in e.hitboxes():
                self._wire_box(surface, cam, hb.box, (255, 80, 60) if hb.name == "head" else (255, 200, 60))

    def _wire_box(self, surface: pygame.Surface, cam: _Cam, b: AABB, col: Color) -> None:
        mn, mx = b.min, b.max
        cs = [
            cam.to_cam(mn.x if not (i & 4) else mx.x, mn.y if not (i & 2) else mx.y, mn.z if not (i & 1) else mx.z)
            for i in range(8)
        ]
        for a, c in (
            (0, 1),
            (2, 3),
            (4, 5),
            (6, 7),
            (0, 2),
            (1, 3),
            (4, 6),
            (5, 7),
            (0, 4),
            (1, 5),
            (2, 6),
            (3, 7),
        ):
            ca, cb = cs[a], cs[c]
            if ca[2] < NEAR or cb[2] < NEAR:
                continue
            pygame.draw.line(surface, col, cam.project(ca), cam.project(cb), 1)

    def _draw_ai(self, surface: pygame.Surface, cam: _Cam, session: GameSession) -> None:
        font = self.fonts.get("small")
        for e in session.enemies:
            if not e.alive or e.inert:
                continue
            c = cam.to_cam(e.pos.x, 2.1, e.pos.z)
            if c[2] < NEAR:
                continue
            x, y = cam.project(c)
            col = {
                AIState.ENGAGE: (255, 90, 70),
                AIState.FLANK: (255, 170, 60),
                AIState.TAKE_COVER: (110, 170, 230),
                AIState.RETREAT: (200, 120, 200),
                AIState.SEARCH: (230, 210, 90),
                AIState.ALERT: (255, 230, 120),
            }.get(e.state, (150, 150, 150))
            if font:
                surface.blit(font.render(f"{e.spec.role.value}:{e.state.value}", True, col), (x - 30, y))
            for a, b in zip([e.pos] + e.path[:-1], e.path, strict=False):
                ca, cb = cam.to_cam(a.x, 0.1, a.z), cam.to_cam(b.x, 0.1, b.z)
                if ca[2] > NEAR and cb[2] > NEAR:
                    pygame.draw.line(surface, col, cam.project(ca), cam.project(cb), 1)

    def _draw_mr_mesh(self, surface: pygame.Surface, cam: _Cam, session: GameSession) -> None:
        env = session.mr_env
        if env is None:
            return
        for o in env.objects:
            self._wire_box(surface, cam, o.box, (110, 200, 150))
        for sp in session.level.spawn_points.values():
            c = cam.to_cam(sp.pos.x, 0.05, sp.pos.z)
            if c[2] > NEAR:
                x, y = cam.project(c)
                pygame.draw.circle(surface, (230, 160, 50), (int(x), int(y)), 4, 1)
