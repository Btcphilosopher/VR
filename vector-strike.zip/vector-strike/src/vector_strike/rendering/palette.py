"""Art-direction palette: dark graphite, concrete, steel, muted military colours, amber, restrained blue,
red warning indicators. No neon, no purple, no cartoon colour."""

from __future__ import annotations

Color = tuple[int, int, int]

GRAPHITE: Color = (28, 30, 33)
CONCRETE: Color = (92, 94, 96)
STEEL: Color = (112, 119, 126)
OLIVE: Color = (74, 79, 60)
AMBER: Color = (224, 160, 48)
BLUE: Color = (61, 108, 143)
RED: Color = (192, 57, 43)

FOG: Color = (13, 15, 18)
SKY_TOP: Color = (9, 11, 14)
SKY_HORIZON: Color = (27, 30, 35)
FLOOR: Color = (46, 48, 50)
FLOOR_LINE: Color = (60, 63, 66)
UI_TEXT: Color = (214, 214, 206)
UI_DIM: Color = (130, 132, 128)

COLORS: dict[str, Color] = {
    "wall_a": (96, 98, 99),
    "wall_b": (88, 90, 92),
    "wall": (92, 94, 96),
    "door": (84, 92, 98),
    "door_locked": (96, 70, 66),
    "concrete": (98, 100, 101),
    "concrete_dark": (74, 76, 78),
    "crate": (88, 80, 62),
    "crate_trim": (60, 56, 46),
    "steel": (112, 119, 126),
    "steel_dark": (58, 62, 66),
    "pipe": (88, 92, 90),
    "container_a": (74, 84, 70),
    "container_b": (96, 76, 56),
    "container_c": (64, 74, 88),
    "rack": (42, 46, 50),
    "locker": (82, 90, 86),
    "wood": (112, 94, 72),
    "wood_dark": (78, 66, 52),
    "fabric": (66, 72, 78),
    "train_body": (118, 124, 128),
    "window_dark": (24, 28, 34),
    "target": (206, 198, 176),
    "target_head": (190, 70, 50),
    "floor_panel": (52, 54, 56),
    "virtual_wall": (44, 52, 62),
    "glass": (70, 96, 110),
    "breach_panel": (80, 74, 70),
    "mr_sofa": (86, 76, 70),
    "mr_table": (112, 94, 72),
    "mr_chair": (70, 76, 82),
    "mr_shelf": (84, 70, 56),
    "mr_cabinet": (96, 86, 72),
    "mr_desk": (104, 88, 68),
    "mr_bed": (86, 90, 98),
    "mr_obstacle": (90, 90, 90),
    # emissive
    "warning_amber": (230, 164, 40),
    "led_blue": (90, 150, 210),
    "screen_blue": (80, 130, 180),
    "screen_amber": (226, 160, 52),
    "light_white": (240, 238, 226),
    # characters
    "helix_vest": (40, 44, 40),
    "helix_uniform": (34, 37, 38),
    "helix_helmet": (28, 30, 33),
    "helix_red": (200, 56, 44),
    "helix_amber": (230, 164, 40),
    "helix_skin": (96, 78, 66),
    "helix_gun": (24, 26, 28),
}

EMISSIVE = {
    "warning_amber",
    "led_blue",
    "screen_blue",
    "screen_amber",
    "light_white",
    "helix_red",
    "helix_amber",
}

TRACER: dict[str, Color] = {
    "amber": (255, 214, 120),
    "blue": (140, 196, 255),
    "red": (255, 110, 90),
    "spark": (255, 226, 170),
}


def color(key: str) -> Color:
    return COLORS.get(key, CONCRETE)
