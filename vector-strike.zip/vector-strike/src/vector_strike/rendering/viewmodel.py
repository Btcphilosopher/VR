"""Procedural first-person weapon silhouettes (screen space) with bob, sway, recoil and ADS."""

from __future__ import annotations

import math

import pygame

from ..weapons.spec import WeaponKind
from ..weapons.weapon import Weapon, WeaponState

# (x, y, w, h) boxes in a 0..100 design space, muzzle to the left-up, grip lower-right
_SHAPES: dict[WeaponKind, list[tuple[float, float, float, float, tuple[int, int, int]]]] = {
    WeaponKind.RIFLE: [
        (10, 38, 60, 12, (36, 38, 40)),
        (62, 40, 28, 18, (44, 47, 44)),
        (34, 48, 10, 22, (30, 32, 34)),
        (70, 52, 10, 26, (34, 36, 38)),
        (2, 40, 14, 6, (24, 26, 28)),
        (30, 33, 24, 5, (52, 56, 58)),
    ],
    WeaponKind.CARBINE: [
        (18, 38, 50, 12, (38, 40, 42)),
        (60, 40, 26, 18, (46, 50, 46)),
        (38, 48, 9, 20, (30, 32, 34)),
        (68, 52, 10, 26, (34, 36, 38)),
        (10, 40, 10, 6, (24, 26, 28)),
    ],
    WeaponKind.SMG: [
        (26, 40, 40, 14, (40, 42, 44)),
        (58, 42, 22, 16, (46, 48, 46)),
        (44, 52, 9, 24, (30, 32, 34)),
        (66, 54, 10, 24, (34, 36, 38)),
        (20, 42, 8, 6, (24, 26, 28)),
    ],
    WeaponKind.SHOTGUN: [
        (4, 40, 66, 9, (36, 38, 40)),
        (6, 49, 54, 7, (50, 54, 52)),
        (60, 38, 30, 20, (74, 62, 48)),
        (68, 52, 10, 24, (34, 36, 38)),
    ],
    WeaponKind.SIDEARM: [
        (34, 40, 30, 12, (40, 42, 44)),
        (58, 44, 12, 12, (46, 50, 46)),
        (60, 54, 10, 26, (34, 36, 38)),
    ],
    WeaponKind.ENERGY: [
        (10, 38, 58, 14, (40, 46, 54)),
        (62, 40, 28, 18, (50, 56, 62)),
        (30, 36, 14, 4, (90, 150, 210)),
        (70, 52, 10, 24, (34, 36, 38)),
        (2, 41, 14, 8, (60, 90, 120)),
    ],
    WeaponKind.TRAINING: [
        (14, 40, 52, 12, (84, 84, 80)),
        (60, 42, 26, 16, (70, 70, 66)),
        (66, 52, 10, 24, (60, 60, 56)),
    ],
}


def weapon_anchor(w: int, h: int, ads: float) -> tuple[int, int, float]:
    """(x, y, scale) of the viewmodel for the current ADS blend."""
    hip = (w * 0.50, h * 0.50, w * 0.0036)
    ads_pos = (w * 0.30, h * 0.43, w * 0.0046)
    return (
        int(hip[0] + (ads_pos[0] - hip[0]) * ads),
        int(hip[1] + (ads_pos[1] - hip[1]) * ads),
        hip[2] + (ads_pos[2] - hip[2]) * ads,
    )


def draw_viewmodel(
    surface: pygame.Surface,
    weapon: Weapon,
    *,
    ads: float,
    bob_phase: float,
    speed: float,
    reduced_motion: bool,
    flash: float,
    t: float,
) -> tuple[int, int]:
    """Draws the weapon; returns the screen position where the weapon-mounted ammo readout should go."""
    w, h = surface.get_size()
    ax, ay, sc = weapon_anchor(w, h, ads)
    if not reduced_motion:
        k = 1.0 - ads * 0.8
        ax += int(math.cos(bob_phase * 0.5) * 7 * min(1.0, speed / 3) * k)
        ay += int(abs(math.sin(bob_phase)) * 8 * min(1.0, speed / 3) * k)
    ay += int(weapon.recoil_pitch * 6)
    ax += int(weapon.recoil_pitch * 2)
    if weapon.state is WeaponState.SWITCHING:
        ay += int(weapon.state_timer / max(weapon.spec.switch_time, 1e-3) * 160)
    elif weapon.state in (WeaponState.RELOADING_TIMED, WeaponState.MAG_OUT, WeaponState.CHAMBER_PENDING):
        ay += 70 if weapon.state is not WeaponState.CHAMBER_PENDING else 20
        ax -= 10
    for bx, by, bw, bh, col in _SHAPES[weapon.spec.kind]:
        r = pygame.Rect(int(ax + bx * sc), int(ay + by * sc), max(2, int(bw * sc)), max(2, int(bh * sc)))
        lit = (min(255, col[0] + 30), min(255, col[1] + 30), min(255, col[2] + 30))
        pygame.draw.rect(surface, lit, r)
        pygame.draw.rect(surface, (120, 124, 126), r, 1)
    if flash > 0.2:
        mx, my = int(ax + 2 * sc), int(ay + 43 * sc)
        for ang, ln in ((0, 40), (0.5, 26), (-0.5, 26), (1.0, 14), (-1.0, 14)):
            ex, ey = mx - math.cos(ang) * ln * sc * 0.5, my - math.sin(ang) * ln * sc * 0.5
            pygame.draw.line(surface, (255, 218, 130), (mx, my), (ex, ey), 3)
    return int(ax + 40 * sc), int(ay + 24 * sc)
