"""Data-driven mission schema (pydantic) and YAML loading."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from ..core.paths import configs_dir


class MissionPhase(str, Enum):
    BRIEFING = "BRIEFING"
    INFILTRATION = "INFILTRATION"
    OBJECTIVE = "OBJECTIVE"
    ESCALATION = "ESCALATION"
    EXTRACTION = "EXTRACTION"
    RESULTS = "RESULTS"


class MissionMode(str, Enum):
    MISSION = "mission"
    SURVIVAL = "survival"
    TRAINING = "training"
    MR = "mr"


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SpawnEntry(_M):
    enemy: str
    at: str
    count: int = 1
    route: str | None = None
    state: str = "idle"  # idle | patrol | alert | hunt


class ObjectiveDef(_M):
    id: str
    title: str
    type: str  # reach_zone | interact | clear_group | survive | pickup | kills | reload |
    # switch_weapon | throw_grenade | defend_waves
    hint: str = ""
    optional: bool = False
    after: str | None = None  # optional objectives unlock after this objective completes
    phase: MissionPhase | None = None
    zone: str | None = None
    target: str | None = None
    group: str | None = None
    hold: float | None = None
    count: int = 1
    duration: float = 0.0
    require_crouch: bool = False
    score: int = 0
    on_activate: list[dict[str, Any]] = Field(default_factory=list)
    on_complete: list[dict[str, Any]] = Field(default_factory=list)


class WaveDef(_M):
    name: str
    tag: str = "wave"  # wave | elite | boss
    spawns: list[SpawnEntry]
    delay: float = 2.0


class MissionDef(_M):
    id: str
    title: str
    level: str
    mode: MissionMode = MissionMode.MISSION
    location: str = ""
    difficulty_label: str = "Standard"
    estimated_minutes: float = 10.0
    par_time: float = 600.0
    summary: str = ""
    briefing: list[str] = Field(default_factory=list)
    loadout: list[str] = Field(default_factory=list)  # forced starting weapons (training etc.)
    grenades: int = 2
    start_groups: list[str] = Field(default_factory=list)
    groups: dict[str, list[SpawnEntry]] = Field(default_factory=dict)
    objectives: list[ObjectiveDef] = Field(default_factory=list)
    waves: list[WaveDef] = Field(default_factory=list)
    intermission: float = 10.0
    fail_timer: str | None = None


def missions_dir() -> Path:
    return configs_dir() / "missions"


def load_mission_file(path: Path) -> MissionDef:
    raw = yaml.safe_load(path.read_text())
    return MissionDef.model_validate(raw["mission"])


def list_missions() -> list[MissionDef]:
    out = [load_mission_file(p) for p in sorted(missions_dir().glob("*.yaml"))]
    order = {"training": 0, "vector_01": 1, "vector_02": 2, "survival_breach": 3, "mr_invasion": 4}
    out.sort(key=lambda m: order.get(m.id, 99))
    return out


def load_mission(mission_id: str) -> MissionDef:
    for m in list_missions():
        if m.id == mission_id:
            return m
    raise KeyError(f"unknown mission '{mission_id}'")
