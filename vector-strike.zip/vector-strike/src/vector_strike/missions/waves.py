"""Survival / BREACH wave director: readable escalation through enemy *roles*, not just health."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..enemies.enemy import AIState, Enemy
from ..game import events as ev
from .models import MissionDef

if TYPE_CHECKING:
    from ..game.session import GameSession


@dataclass
class WaveDirector:
    s: GameSession
    mission: MissionDef
    index: int = -1
    state: str = "idle"  # idle | countdown | active | intermission | done
    timer: float = 0.0
    finished: bool = False
    wave_enemies: list[Enemy] = field(default_factory=list)
    boss: Enemy | None = None
    boss_phase: int = 0
    waves_cleared: int = 0

    def start(self) -> None:
        if self.state == "idle":
            self.state = "countdown"
            self.timer = 3.0
            self.s.runner.say("BREACH IMMINENT - hold the post")

    @property
    def total(self) -> int:
        return len(self.mission.waves)

    def status_text(self) -> str:
        if self.state == "intermission":
            return f"intermission {max(0, int(self.timer))}s"
        name = self.mission.waves[self.index].name if 0 <= self.index < self.total else ""
        alive = sum(1 for e in self.wave_enemies if e.alive)
        return f"{name}  ({alive} hostile)" if self.state == "active" else name

    def _spawn_wave(self) -> None:
        w = self.mission.waves[self.index]
        self.wave_enemies = []
        opened: set[str] = set()
        for entry in w.spawns:
            door = {"out_n": "breach_n", "out_s": "breach_s", "out_w": "breach_w", "out_e": "breach_e"}.get(entry.at)
            if door and door not in opened and door in self.s.level.doors:
                opened.add(door)
                self.s.unlock_door(door)
            es = self.s.spawn_entry(entry, group=f"wave{self.index + 1}", hunt=True)
            self.wave_enemies.extend(es)
            if entry.enemy == "commander" and es:
                self.boss, self.boss_phase = es[0], 0
        self.state = "active"
        self.s.bus.emit(ev.WAVE_START, index=self.index + 1, wave_name=w.name, tag=w.tag, count=len(self.wave_enemies))
        self.s.runner.say(f"WAVE {self.index + 1}: {w.name}")

    def update(self, dt: float) -> None:
        if self.finished or self.state == "idle":
            return
        self.timer -= dt
        if self.state == "countdown" and self.timer <= 0:
            self.index = 0
            self._spawn_wave()
        elif self.state == "active":
            self._boss_phases()
            if all(not e.alive for e in self.wave_enemies):
                self.waves_cleared += 1
                for door in ("breach_n", "breach_s", "breach_w", "breach_e"):
                    if door in self.s.level.doors:
                        self.s.lock_door(door)
                if self.index + 1 >= self.total:
                    self.state, self.finished = "done", True
                    return
                self.state, self.timer = "intermission", self.mission.intermission
                self.s.set_interactable_enabled("ammo_crate", True, reset=True)
                self.s.player.state.health = min(self.s.player.state.max_health, self.s.player.state.health + 30)
                self.s.runner.say("Wave cleared - resupply at the cache")
        elif self.state == "intermission" and self.timer <= 0:
            self.index += 1
            self._spawn_wave()

    def _boss_phases(self) -> None:
        b = self.boss
        if b is None or not b.alive:
            return
        frac = b.health / b.spec.health
        if self.boss_phase == 0 and frac < 0.66:
            self.boss_phase = 1
            self._reinforce("rifleman", 2, "BOSS: reinforcements inbound")
        elif self.boss_phase == 1 and frac < 0.33:
            self.boss_phase = 2
            self._reinforce("flanker", 2, "BOSS: enraged - flankers inbound")
            b.state_t = 0.0

    def _reinforce(self, enemy: str, count: int, msg: str) -> None:
        from .models import SpawnEntry

        self.s.runner.say(msg)
        for at in ("out_w", "out_e"):
            door = {"out_w": "breach_w", "out_e": "breach_e"}[at]
            self.s.unlock_door(door)
            self.wave_enemies.extend(
                self.s.spawn_entry(SpawnEntry(enemy=enemy, at=at, count=count // 2 or 1), group="boss_adds", hunt=True)
            )

    @staticmethod
    def aggressive(e: Enemy) -> bool:
        return e.state in (AIState.ENGAGE, AIState.FLANK)
