"""Transparent scoring. Kill counts are shown on the results screen but never scored directly."""

from __future__ import annotations

from dataclasses import dataclass, field

PRIMARY_MAX = 4000
OPTIONAL_EACH = 500
ACCURACY_MAX = 1500
TIME_MAX = 1500
DAMAGE_MAX = 1000
ACCURACY_TARGET = 0.55  # accuracy at which the accuracy bonus is maxed
DAMAGE_BUDGET = 300.0  # damage taken at which the damage bonus is zero


@dataclass(slots=True)
class ScoreLine:
    label: str
    points: int
    maximum: int
    detail: str = ""


@dataclass(slots=True)
class ScoreBreakdown:
    lines: list[ScoreLine] = field(default_factory=list)
    multiplier: float = 1.0
    total: int = 0
    maximum: int = 0
    rank: str = "D"


def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


def compute_score(
    *,
    primary_done: int,
    primary_total: int,
    optional_done: int,
    optional_total: int,
    shots: int,
    hits: int,
    elapsed: float,
    par_time: float,
    damage_taken: float,
    completed: bool,
    difficulty_multiplier: float = 1.0,
) -> ScoreBreakdown:
    sb = ScoreBreakdown(multiplier=difficulty_multiplier)
    frac = primary_done / primary_total if primary_total else 1.0
    sb.lines.append(ScoreLine("OBJECTIVES", int(PRIMARY_MAX * frac), PRIMARY_MAX, f"{primary_done}/{primary_total}"))
    sb.lines.append(
        ScoreLine(
            "OPTIONAL OBJECTIVES",
            optional_done * OPTIONAL_EACH,
            optional_total * OPTIONAL_EACH,
            f"{optional_done}/{optional_total}",
        )
    )
    acc = hits / shots if shots else 0.0
    acc_pts = int(ACCURACY_MAX * _clamp(acc / ACCURACY_TARGET)) if completed else 0
    sb.lines.append(ScoreLine("ACCURACY", acc_pts, ACCURACY_MAX, f"{acc * 100:.0f}%"))
    time_pts = int(TIME_MAX * _clamp(2.0 - elapsed / max(par_time, 1.0))) if completed else 0
    sb.lines.append(ScoreLine("TIME", time_pts, TIME_MAX, f"{elapsed:.0f}s / par {par_time:.0f}s"))
    dmg_pts = int(DAMAGE_MAX * (1.0 - _clamp(damage_taken / DAMAGE_BUDGET))) if completed else 0
    sb.lines.append(ScoreLine("DAMAGE TAKEN", dmg_pts, DAMAGE_MAX, f"{damage_taken:.0f} dmg"))
    raw = sum(line.points for line in sb.lines)
    sb.maximum = sum(line.maximum for line in sb.lines)
    sb.total = int(raw * difficulty_multiplier)
    ratio = raw / sb.maximum if sb.maximum else 0.0
    sb.rank = "S" if ratio >= 0.9 else "A" if ratio >= 0.75 else "B" if ratio >= 0.6 else "C" if ratio >= 0.4 else "D"
    return sb
