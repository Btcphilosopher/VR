"""Procedural level definitions. Everything is deterministic given the seed."""

from __future__ import annotations

from collections.abc import Callable

from ..assets.procedural import barrier, crate, low_wall, pillar
from ..physics.vec import Vec3
from .level import Level, LevelBuilder, Light

AMBER = (255, 190, 90)
RED = (220, 60, 50)
BLUE = (120, 170, 220)
COLD = (225, 235, 255)


def _light_grid(
    b: LevelBuilder,
    x0: float,
    z0: float,
    x1: float,
    z1: float,
    step: float = 8.0,
    color: tuple[int, int, int] = (255, 244, 224),
    radius: float = 11.0,
) -> None:
    x = x0 + step / 2
    while x < x1:
        z = z0 + step / 2
        while z < z1:
            b.light(x, z, radius=radius, color=color)
            z += step
        x += step


def blackout(seed: int = 1) -> Level:
    b = LevelBuilder("blackout", "Helix Research Complex - Halden Works", (0, 0, 64, 50), seed)
    # service area (entry)
    b.wall(20, 0, 40, 0)
    b.wall(20, 0, 20, 10)
    b.wall(40, 0, 40, 10)
    # loading hall
    b.wall(8, 10, 52, 10, gaps=[(30, 2.8, None)])
    b.wall(8, 10, 8, 26)
    b.wall(52, 10, 52, 26, gaps=[(18, 3.0, "dock_door")])
    b.wall(8, 26, 52, 26, gaps=[(14, 2.4, None), (30, 3.2, "blast_door"), (46, 2.4, None)])
    # security room, corridor, offices, server room
    b.wall(8, 26, 8, 36)
    b.wall(22, 26, 22, 36)
    b.wall(38, 26, 38, 36)
    b.wall(52, 26, 52, 36)
    b.wall(8, 36, 52, 36, gaps=[(30, 3.0, None)])
    b.wall(14, 36, 14, 48)
    b.wall(46, 36, 46, 48)
    b.wall(14, 48, 46, 48)
    # dock (extraction) enclosure
    b.wall(52, 10, 62, 10)
    b.wall(52, 26, 62, 26)
    b.wall(62, 10, 62, 26)

    # --- service area dressing
    b.place(crate(3), 23, 3, seed=3)
    b.place(crate(4), 24.2, 3.2, seed=4)
    b.place(barrier(), 36, 4.5)
    b.place("locker", 38.5, 1.0, rot90=True)
    # --- loading hall dressing / cover
    b.place("container", 15, 13.5, seed=1)
    b.place("container", 45, 22.5, seed=2)
    b.place(barrier(), 26, 15)
    b.place(barrier(), 34, 15)
    b.place(low_wall(3.0), 22, 21)
    b.place(low_wall(3.0), 38, 21)
    b.place(pillar(), 20, 18)
    b.place(pillar(), 40, 18)
    b.scatter(
        "crate",
        8,
        10,
        12,
        50,
        25,
        keep_clear=[(30, 11, 3), (30, 25, 4), (52, 18, 4), (14, 25, 3), (46, 25, 3)],
    )
    b.place("pipe_run", 30, 24.5)
    # --- security room
    b.place("desk", 15, 29, seed=1)
    b.place("desk", 19, 33, seed=2)
    b.place("locker", 9, 28, rot90=True)
    b.place("locker", 9, 30, rot90=True)
    b.place("terminal", 10.6, 34.4, rot90=True)
    # --- corridor
    b.place(barrier(), 27, 31, rot90=True)
    b.place(barrier(), 33, 29, rot90=True)
    b.place(crate(7), 25, 34.5, seed=7)
    # --- offices
    for i, (x, z) in enumerate([(42, 29), (47, 29), (42, 33), (47, 33)]):
        b.place("desk", x, z, seed=i)
        b.place("chair", x, z + 0.9)
    b.place("terminal", 50.6, 34.4, rot90=True)
    b.place("shelf", 45, 35.6)
    # --- server room
    for i, x in enumerate([19, 23, 37, 41]):
        b.place("server_rack", x, 40.5, seed=10 + i)
        b.place("server_rack", x, 45, seed=20 + i)
    b.place(low_wall(2.4), 30, 41.5)
    b.place(crate(9), 26, 43, seed=9)
    b.place(crate(10), 34, 39, seed=10)
    b.place("terminal", 30, 47.0)

    # --- lights
    _light_grid(b, 20, 0, 40, 10, 10)
    _light_grid(b, 8, 10, 52, 26, 8)
    _light_grid(b, 8, 26, 22, 36, 7, COLD)
    _light_grid(b, 22, 26, 38, 36, 8)
    _light_grid(b, 38, 26, 52, 36, 7)
    _light_grid(b, 14, 36, 46, 48, 8, BLUE, 10)
    for x, z in [(30, 2), (30, 12), (14, 27), (46, 27), (30, 27), (30, 37), (52, 18), (30, 46), (10, 32)]:
        b.light(x, z, y=2.8, radius=9, intensity=1.0, color=RED, emergency=True, mains=False)
    b.level.lights.append(Light(Vec3(58, 5, 18), AMBER, 14, 0.8, True, False))

    # --- zones / interactables
    b.zone("entry_point", 30, 10.8, 2.6)
    b.zone("security_room", 15, 31, 6)
    b.zone("server_room", 30, 42, 9)
    b.zone("download_point", 30, 46, 3)
    b.zone("extract", 58, 18, 3.5)
    b.interactable("security_console", 10.6, 33.2, "terminal", "HOLD  Disable security grid", 3.0, enabled=False)
    b.interactable("data_terminal", 30, 45.8, "terminal", "HOLD  Download data device", 8.0, enabled=False)
    b.interactable("intel_laptop", 50.6, 33.2, "terminal", "HOLD  Copy personnel files", 2.0, enabled=False)
    b.interactable("ammo_blackout", 30, 6, "ammo", "Resupply cache", 0.0)

    # --- spawns / routes
    spawn_table: list[tuple[str, float, float, float]] = [
        ("h1", 12, 14, 0),
        ("h2", 16, 22, 3.14),
        ("h3", 36, 14, 1.5),
        ("h4", 44, 20, 3.14),
        ("h5", 24, 23.5, 3.14),
        ("h6", 47, 13.5, 3.14),
        ("s1", 11, 31, 0),
        ("s2", 18, 33.5, 3.14),
        ("o1", 42, 31, 3.14),
        ("o2", 49, 31, 3.14),
        ("c1", 27, 33, 0),
        ("c2", 34, 31, 0),
        ("v1", 18, 44, 3.14),
        ("v2", 27, 40, 0),
        ("v3", 34, 43.5, 3.14),
        ("v4", 42, 43, 3.14),
        ("esc_door", 30, 34.5, 0),
        ("esc_vent", 42, 38.5, 3.14),
        ("esc_hall_a", 30, 12, 0),
        ("esc_hall_b", 25, 12, 0),
        ("esc_dock", 54, 12, 0),
    ]
    for sname, sx, sz, syaw in spawn_table:
        b.spawn(sname, sx, sz, syaw)
    b.route("hall_w", [(12, 14), (12, 22), (22, 23.5), (22, 14)])
    b.route("hall_e", [(36, 14), (47, 13.5), (47, 22), (36, 23)])
    b.route("office", [(42, 31), (49, 31), (49, 34), (42, 34)])
    lvl = b.level
    lvl.player_start = (Vec3(30, 0, 2.5), 0.0)
    lvl.ambient = 0.62
    return b.finish()


def transit(seed: int = 2) -> Level:
    b = LevelBuilder("transit", "Kessler Interchange - High-Speed Terminal", (-2, 0, 58, 66), seed, kind="transit")
    # entry plaza
    b.wall(18, 0, 34, 0)
    b.wall(18, 0, 18, 8)
    b.wall(34, 0, 34, 8)
    # concourse
    b.wall(4, 8, 48, 8, gaps=[(26, 3.0, None)])
    b.wall(4, 8, 4, 28)
    b.wall(48, 8, 48, 28)
    b.wall(4, 28, 48, 28, gaps=[(12, 2.6, None), (38, 2.6, None)])
    # service tunnel (concourse -> platform)
    b.wall(8, 28, 8, 40)
    b.wall(16, 28, 16, 40)
    # control room
    b.wall(30, 28, 30, 40)
    b.wall(46, 28, 46, 40)
    # platform hall
    b.wall(4, 40, 52, 40, gaps=[(12, 2.6, None), (38, 2.6, None)])
    b.wall(4, 40, 4, 62)
    b.wall(52, 40, 52, 62, gaps=[(57, 3.2, "lockdown_shutter")])
    b.wall(4, 62, 52, 62)
    # exit apron
    b.wall(52, 52, 58, 52)
    b.wall(52, 62, 58, 62)
    b.wall(58, 52, 58, 62)

    # concourse dressing
    for x in (12, 20, 32, 40):
        b.place(pillar(), x, 14)
        b.place(pillar(), x, 22)
    for x in (16, 36):
        b.place("bench", x, 18)
    b.place(low_wall(4.0), 24, 12)
    b.place(low_wall(4.0), 28, 12)  # ticket barrier line
    b.place(low_wall(3.0), 10, 24)
    b.place(low_wall(3.0), 42, 24)
    b.scatter("crate", 4, 6, 10, 46, 26, keep_clear=[(26, 9, 3), (12, 27, 3), (38, 27, 3)])
    # tunnel dressing
    b.place(crate(12), 10, 33, seed=12)
    b.place(barrier(), 14, 36, rot90=True)
    b.place("pipe_run", 12, 31)
    # control room
    b.place("desk", 34, 32, seed=3)
    b.place("desk", 40, 32, seed=4)
    b.place("desk", 34, 36, seed=5)
    b.place("terminal", 44.2, 38.4, rot90=True)
    b.place("locker", 31, 34, rot90=True)
    # platform
    b.place("train_car", 21, 47)
    b.place("train_car", 31, 54)
    b.place("bench", 8, 44)
    b.place("bench", 46, 44)
    b.place("bench", 46, 58)
    b.place(pillar(), 44, 50)
    b.place(pillar(), 8, 56)
    b.place(low_wall(3.0), 14, 59.5)
    b.place(crate(14), 40, 59, seed=14)
    b.place(crate(15), 7, 50, seed=15)

    _light_grid(b, 18, 0, 34, 8, 8, COLD)
    _light_grid(b, 4, 8, 48, 28, 8, COLD, 12)
    _light_grid(b, 8, 28, 16, 40, 6, (255, 220, 170), 8)
    _light_grid(b, 30, 28, 46, 40, 8, BLUE, 10)
    _light_grid(b, 4, 40, 52, 62, 8, (235, 240, 255), 12)
    for x, z in [(26, 9), (12, 29), (38, 29), (12, 41), (38, 41), (50, 57), (26, 3), (40, 36)]:
        b.light(x, z, y=2.8, radius=9, color=RED, emergency=True, mains=False)

    b.zone("terminal_entry", 38, 26.2, 3.0)
    b.zone("control_room", 38, 34, 6)
    b.zone("platform", 28, 50, 12)
    b.zone("extract", 49, 57, 3.5)
    b.interactable("transfer_node", 44.2, 37.3, "terminal", "HOLD  Intercept data transfer", 10.0, enabled=False)
    b.interactable("ammo_transit", 26, 5, "ammo", "Resupply cache", 0.0)
    spawn_table: list[tuple[str, float, float, float]] = [
        ("k1", 12, 12, 0),
        ("k2", 22, 20, 0),
        ("k3", 36, 14, 3.14),
        ("k4", 42, 20, 3.14),
        ("k5", 8, 20, 0),
        ("g1", 34, 34, 3.14),
        ("g2", 42, 36, 3.14),
        ("p1", 12, 44, 0),
        ("p2", 24, 43, 0),
        ("p3", 40, 47, 3.14),
        ("p4", 36, 58, 3.14),
        ("p5", 14, 52, 0),
        ("esc_plat_w", 8, 60, 0),
        ("esc_plat_e", 44, 60, 3.14),
        ("esc_tunnel", 12, 38.5, 0),
        ("esc_conc", 26, 10, 0),
        ("esc_conc2", 6, 12, 0),
    ]
    for sname, sx, sz, syaw in spawn_table:
        b.spawn(sname, sx, sz, syaw)
    b.route("conc_w", [(12, 12), (20, 20), (8, 20), (12, 10)])
    b.route("conc_e", [(36, 14), (42, 22), (40, 12), (30, 18)])
    b.route("plat", [(12, 44), (24, 43), (40, 44), (24, 44)])
    b.level.player_start = (Vec3(26, 0, 2.5), 0.0)
    b.level.ambient = 0.6
    return b.finish()


def breach(seed: int = 3) -> Level:
    b = LevelBuilder("breach", "Vector Forward Post - Operations Bay", (-10, -10, 42, 36), seed)
    b.wall(2, 2, 30, 2, gaps=[(16, 3.0, "breach_s")])
    b.wall(2, 24, 30, 24, gaps=[(16, 3.0, "breach_n")])
    b.wall(2, 2, 2, 24, gaps=[(13, 3.0, "breach_w")])
    b.wall(30, 2, 30, 24, gaps=[(13, 3.0, "breach_e")])
    # approach corridors (spawn pockets)
    b.wall(14.5, -8, 14.5, 2)
    b.wall(17.5, -8, 17.5, 2)
    b.wall(14.5, -8, 17.5, -8)
    b.wall(14.5, 24, 14.5, 32)
    b.wall(17.5, 24, 17.5, 32)
    b.wall(14.5, 32, 17.5, 32)
    b.wall(-6, 11.5, 2, 11.5)
    b.wall(-6, 14.5, 2, 14.5)
    b.wall(-6, 11.5, -6, 14.5)
    b.wall(30, 11.5, 38, 11.5)
    b.wall(30, 14.5, 38, 14.5)
    b.wall(38, 11.5, 38, 14.5)
    # barricades around the defensible centre
    for x, z, ln in [(11, 8, 3.0), (21, 8, 3.0), (11, 18, 3.0), (21, 18, 3.0)]:
        b.place(low_wall(ln), x, z)
    b.place(barrier(), 16, 5.5)
    b.place(barrier(), 16, 20.5)
    b.place(barrier(), 6, 13, rot90=True)
    b.place(barrier(), 26, 13, rot90=True)
    b.place(crate(21), 8, 4.5, seed=21)
    b.place(crate(22), 24, 21.5, seed=22)
    b.place(pillar(), 6, 6)
    b.place(pillar(), 26, 6)
    b.place(pillar(), 6, 20)
    b.place(pillar(), 26, 20)
    _light_grid(b, 2, 2, 30, 24, 7, (230, 235, 245), 11)
    for x, z in [(16, 3), (16, 23), (3, 13), (29, 13)]:
        b.light(x, z, y=2.8, radius=8, color=RED, emergency=True, mains=False)
    b.zone("centre", 16, 13, 4)
    b.interactable("ammo_crate", 16, 12, "ammo", "Resupply cache", 0.0)
    spawn_table: list[tuple[str, float, float, float]] = [
        ("out_s", 16, -6.5, 0),
        ("out_n", 16, 30.5, 3.14),
        ("out_w", -4.5, 13, 1.57),
        ("out_e", 36.5, 13, -1.57),
    ]
    for sname, sx, sz, syaw in spawn_table:
        b.spawn(sname, sx, sz, syaw)
    b.level.player_start = (Vec3(16, 0, 13), 0.0)
    b.level.ambient = 0.55
    return b.finish()


def training_range(seed: int = 4) -> Level:
    b = LevelBuilder("range", "Vector Training Hall", (0, 0, 40, 30), seed, kind="training")
    b.room(2, 2, 38, 28)
    b.place(low_wall(3.0), 28, 12)
    b.place(low_wall(3.0), 32, 12)
    b.place("table", 12, 4.2)
    b.place("table", 36, 4.2)
    for x in (16, 20, 24, 28, 32):
        b.place(barrier(), x, 18.0)
    b.place(crate(31), 5, 12, seed=31)
    b.place(pillar(), 4, 24)
    _light_grid(b, 2, 2, 38, 28, 8, (235, 240, 250), 12)
    b.zone("move_a", 8, 12, 1.4)
    b.zone("move_b", 8, 22, 1.4)
    b.zone("cover_zone", 30, 10.4, 1.3)
    b.interactable("rack_trainer", 12, 5.0, "pickup", "E  Take TR-0 Trainer", 0.0, weapon="tr0_trainer")
    b.interactable("rack_pilot", 36, 5.0, "pickup", "E  Take P-11 Pilot", 0.0, weapon="p11_pilot")
    b.interactable("mr_demo_terminal", 6, 26, "terminal", "HOLD  Spatial link (MR interaction)", 3.0, enabled=False)
    b.interactable("ammo_range", 20, 4.2, "ammo", "Ammo cache", 0.0)
    for i, x in enumerate((17, 21, 25, 29, 33)):
        b.spawn(f"t{i + 1}", x, 23.5, 3.14)
    b.level.player_start = (Vec3(8, 0, 5), 0.0)
    b.level.ambient = 0.75
    return b.finish()


LEVELS: dict[str, Callable[[int], Level]] = {
    "blackout": blackout,
    "transit": transit,
    "breach": breach,
    "range": training_range,
}


def build_level(level_id: str, seed: int = 1) -> Level:
    return LEVELS[level_id](seed)
