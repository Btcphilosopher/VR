"""Mission state machine: phases, sequential primary objectives, optional objectives and actions."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, Any

from ..game import events as ev
from ..game.events import Event
from ..physics.vec import Vec3
from ..player.player import Stance
from .models import MissionDef, MissionPhase, ObjectiveDef

if TYPE_CHECKING:
    from ..game.session import GameSession


class ObjStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    DONE = "done"


@dataclass(slots=True)
class ObjectiveState:
    defn: ObjectiveDef
    status: ObjStatus = ObjStatus.PENDING
    counter: int = 0
    elapsed: float = 0.0


@dataclass(slots=True)
class MissionTimer:
    id: str
    remaining: float
    fail: bool = True
    label: str = ""


class MissionRunner:
    def __init__(self, session: GameSession, mission: MissionDef) -> None:
        self.s = session
        self.mission = mission
        self.states: dict[str, ObjectiveState] = {o.id: ObjectiveState(o) for o in mission.objectives}
        self.order: list[str] = [o.id for o in mission.objectives if not o.optional]
        self.phase = MissionPhase.BRIEFING
        self.started = False
        self.finished = False
        self.success = False
        self.fail_reason = ""
        self.messages: deque[tuple[float, str]] = deque(maxlen=6)
        self.timers: dict[str, MissionTimer] = {}
        self.elapsed = 0.0
        b = session.bus
        b.subscribe(ev.INTERACTION_COMPLETE, self._on_interaction)
        b.subscribe(ev.ENEMY_DEFEATED, self._on_defeated)
        b.subscribe(ev.WEAPON_RELOAD_COMPLETE, lambda e: self._count("reload"))
        b.subscribe(ev.WEAPON_SWITCH, lambda e: self._count("switch_weapon"))
        b.subscribe(
            ev.GRENADE_THROWN,
            lambda e: self._count("throw_grenade") if e.data.get("team") == "vector" else None,
        )
        b.subscribe(ev.PLAYER_DOWN, lambda e: self.fail("Operative down"))

    # ---- lifecycle ------------------------------------------------------------------
    def start(self) -> None:
        if self.started:
            return
        self.started = True
        self._set_phase(MissionPhase.INFILTRATION)
        self.s.bus.emit(ev.MISSION_START, mission=self.mission.id)
        for g in self.mission.start_groups:
            self.s.spawn_group(g)
        for oid in self.order[:1]:
            self._activate(self.states[oid])
        for st in self.states.values():
            if st.defn.optional and st.defn.after is None:
                self._activate(st)

    def _set_phase(self, p: MissionPhase) -> None:
        if p is not self.phase:
            self.phase = p
            self.s.bus.emit(ev.MISSION_PHASE, phase=p.value)

    def say(self, text: str) -> None:
        self.messages.append((self.s.bus.time, text))

    def fail(self, reason: str) -> None:
        if self.finished:
            return
        self.finished, self.success, self.fail_reason = True, False, reason
        self._set_phase(MissionPhase.RESULTS)
        self.s.bus.emit(ev.MISSION_FAILED, reason=reason)

    def _finish_success(self) -> None:
        if self.finished:
            return
        self.finished, self.success = True, True
        self._set_phase(MissionPhase.RESULTS)
        self.s.bus.emit(ev.MISSION_COMPLETE, mission=self.mission.id)

    # ---- objective plumbing -----------------------------------------------------------
    def active_primary(self) -> ObjectiveState | None:
        for oid in self.order:
            st = self.states[oid]
            if st.status is not ObjStatus.DONE:
                return st if st.status is ObjStatus.ACTIVE else None
        return None

    def active_objectives(self) -> list[ObjectiveState]:
        return [s for s in self.states.values() if s.status is ObjStatus.ACTIVE]

    def _activate(self, st: ObjectiveState) -> None:
        if st.status is not ObjStatus.PENDING:
            return
        st.status = ObjStatus.ACTIVE
        st.elapsed = 0.0
        d = st.defn
        if d.phase is not None:
            self._set_phase(d.phase)
        if d.type in ("interact", "pickup") and d.target:
            self.s.set_interactable_enabled(d.target, True)
        if d.hint:
            self.say(d.hint)
        self.s.bus.emit(ev.OBJECTIVE_ACTIVE, objective=d.id, title=d.title)
        self._run_actions(d.on_activate)

    def _complete(self, st: ObjectiveState) -> None:
        if st.status is ObjStatus.DONE:
            return
        st.status = ObjStatus.DONE
        d = st.defn
        self.s.bus.emit(ev.OBJECTIVE_COMPLETE, objective=d.id, title=d.title, optional=d.optional)
        self.say(("OPTIONAL COMPLETE: " if d.optional else "OBJECTIVE COMPLETE: ") + d.title)
        self._run_actions(d.on_complete)
        for other in self.states.values():
            if other.defn.optional and other.defn.after == d.id:
                self._activate(other)
        if not d.optional:
            idx = self.order.index(d.id)
            if idx + 1 < len(self.order):
                self._activate(self.states[self.order[idx + 1]])
            else:
                self._finish_success()

    # ---- actions ------------------------------------------------------------------
    def _run_actions(self, actions: list[dict[str, Any]]) -> None:
        for a in actions:
            kind = a.get("action")
            s = self.s
            if kind == "unlock_door":
                s.unlock_door(a["id"])
            elif kind == "lock_door":
                s.lock_door(a["id"])
            elif kind == "spawn_group":
                s.spawn_group(a["group"], hunt=bool(a.get("hunt", False)))
            elif kind == "power_fail":
                s.power_fail()
            elif kind == "message":
                self.say(a["text"])
            elif kind == "start_timer":
                self.timers[a["id"]] = MissionTimer(
                    a["id"], float(a["seconds"]), bool(a.get("fail", True)), a.get("label", "")
                )
            elif kind == "stop_timer":
                self.timers.pop(a["id"], None)
            elif kind == "enable_interactable":
                s.set_interactable_enabled(a["id"], bool(a.get("enabled", True)))
            elif kind == "set_hotspot":
                s.hotspot = s.level.zone(a["zone"]).center if a.get("zone") else None
            elif kind == "mr_event":
                s.mr_event(a["kind"], int(a.get("count", 1)), a.get("enemy", "rifleman"))
            elif kind == "give_grenades":
                s.inventory.grenades = min(s.inventory.max_grenades, s.inventory.grenades + int(a.get("count", 1)))
            elif kind == "start_waves":
                s.start_waves()
            else:
                raise ValueError(f"unknown mission action '{kind}'")

    # ---- events -------------------------------------------------------------------
    def _on_interaction(self, e: Event) -> None:
        iid = e.data.get("id")
        for st in self.active_objectives():
            d = st.defn
            if d.type in ("interact", "pickup") and d.target == iid:
                self._complete(st)

    def _on_defeated(self, e: Event) -> None:
        for st in self.active_objectives():
            d = st.defn
            if d.type == "kills" and (d.group is None or d.group == e.data.get("group")):
                st.counter += 1
                if st.counter >= d.count:
                    self._complete(st)

    def _count(self, kind: str) -> None:
        for st in self.active_objectives():
            d = st.defn
            if d.type == kind:
                st.counter += 1
                if st.counter >= d.count:
                    self._complete(st)

    # ---- per tick -----------------------------------------------------------------
    def update(self, dt: float) -> None:
        if not self.started or self.finished:
            return
        self.elapsed += dt
        for tid in list(self.timers):
            t = self.timers[tid]
            t.remaining -= dt
            if t.remaining <= 0:
                del self.timers[tid]
                if t.fail:
                    self.fail(t.label or "Time expired")
                    return
        p = self.s.player
        for st in list(self.active_objectives()):
            d = st.defn
            st.elapsed += dt
            if d.type == "reach_zone" and d.zone:
                z = self.s.level.zone(d.zone)
                if p.state.pos.dist_xz(z.center) <= z.radius and (
                    not d.require_crouch or p.state.stance is Stance.CROUCH
                ):
                    self._complete(st)
            elif d.type == "clear_group" and d.group:
                if self.s.group_spawned(d.group) and self.s.group_alive(d.group) == 0:
                    self._complete(st)
            elif d.type == "survive":
                if st.elapsed >= d.duration:
                    self._complete(st)
            elif d.type == "defend_waves":
                if self.s.waves is not None and self.s.waves.finished:
                    self._complete(st)

    # ---- HUD / bot helpers ------------------------------------------------------------
    def goal_positions(self) -> list[Vec3]:
        st = self.active_primary()
        if st is None:
            return []
        d = st.defn
        lvl = self.s.level
        if d.type == "reach_zone" and d.zone:
            return [lvl.zone(d.zone).center]
        if d.type in ("interact", "pickup") and d.target:
            return [lvl.interactables[d.target].pos]
        if d.type in ("clear_group", "kills"):
            pos = self.s.player.state.pos
            es = [e for e in self.s.enemies if e.alive and (d.group is None or e.group == d.group)]
            es.sort(key=lambda e: e.pos.dist_xz(pos))
            return [e.pos for e in es]
        return []

    def objective_text(self) -> tuple[str, str]:
        st = self.active_primary()
        if st is None:
            return ("", "")
        d = st.defn
        extra = ""
        if d.type in ("kills", "reload", "switch_weapon", "throw_grenade") and d.count > 1:
            extra = f"  {st.counter}/{d.count}"
        if d.type == "clear_group" and d.group:
            extra = f"  {self.s.group_alive(d.group)} remaining"
        if d.type == "defend_waves" and self.s.waves is not None:
            extra = f"  {self.s.waves.status_text()}"
        return (d.title + extra, d.hint)

    @property
    def primary_done(self) -> int:
        return sum(1 for oid in self.order if self.states[oid].status is ObjStatus.DONE)

    @property
    def optional_done(self) -> int:
        return sum(1 for st in self.states.values() if st.defn.optional and st.status is ObjStatus.DONE)

    @property
    def optional_total(self) -> int:
        return sum(1 for st in self.states.values() if st.defn.optional)

    def timer_text(self) -> tuple[str, float] | None:
        if not self.timers:
            return None
        t = min(self.timers.values(), key=lambda x: x.remaining)
        return (t.label or t.id, t.remaining)
