"""Level data model and a builder that turns rooms/props into colliders, decor, nav and cover data."""

from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..assets.procedural import PropDef, build_prop
from ..physics.shapes import AABB
from ..physics.vec import Vec3
from ..physics.world import Collider, ColliderKind, Material, World

WALL_H = 3.2
WALL_T = 0.3


@dataclass(slots=True)
class Zone:
    name: str
    center: Vec3
    radius: float


@dataclass(slots=True)
class InteractableDef:
    id: str
    pos: Vec3
    kind: str  # terminal | pickup | ammo | console
    title: str
    hold_time: float = 0.0
    radius: float = 1.8
    enabled: bool = True
    data: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class SpawnPoint:
    name: str
    pos: Vec3
    yaw: float = 0.0


@dataclass(slots=True)
class Light:
    pos: Vec3
    color: tuple[int, int, int] = (255, 244, 224)
    radius: float = 10.0
    intensity: float = 1.0
    emergency: bool = False  # only lit after power failure
    mains: bool = True  # goes dark after power failure


@dataclass(slots=True)
class DecorBox:
    aabb: AABB
    color_key: str
    emissive: bool = False


@dataclass(slots=True)
class DoorInfo:
    collider_ids: list[int]
    locked: bool = True


@dataclass(slots=True)
class CoverPoint:
    pos: Vec3
    facing: Vec3  # unit vector from the point *through* the cover toward the side it protects against
    collider_id: int
    height: float


@dataclass
class Level:
    id: str
    name: str
    bounds: tuple[float, float, float, float]  # min_x, min_z, max_x, max_z
    world: World = field(default_factory=World)
    decor: list[DecorBox] = field(default_factory=list)
    zones: dict[str, Zone] = field(default_factory=dict)
    interactables: dict[str, InteractableDef] = field(default_factory=dict)
    spawn_points: dict[str, SpawnPoint] = field(default_factory=dict)
    patrol_routes: dict[str, list[Vec3]] = field(default_factory=dict)
    lights: list[Light] = field(default_factory=list)
    doors: dict[str, DoorInfo] = field(default_factory=dict)
    cover_points: list[CoverPoint] = field(default_factory=list)
    player_start: tuple[Vec3, float] = (Vec3(0, 0, 0), 0.0)
    ambient: float = 0.55
    indoor: bool = True
    kind: str = "industrial"

    def zone(self, name: str) -> Zone:
        return self.zones[name]


Gap = tuple[float, float, str | None]  # centre, width, door id (None = open doorway)


class LevelBuilder:
    def __init__(
        self,
        level_id: str,
        name: str,
        bounds: tuple[float, float, float, float],
        seed: int = 1,
        kind: str = "industrial",
    ) -> None:
        self.level = Level(level_id, name, bounds, kind=kind)
        self.rng = random.Random(seed)
        self._seg = 0

    # ---- walls ----------------------------------------------------------
    def _wall_box(
        self,
        x0: float,
        z0: float,
        x1: float,
        z1: float,
        h: float = WALL_H,
        y0: float = 0.0,
        material: Material = Material.CONCRETE,
        tag: str = "",
        key: str = "wall",
        kind: ColliderKind = ColliderKind.WALL,
    ) -> Collider:
        box = AABB(Vec3(min(x0, x1), y0, min(z0, z1)), Vec3(max(x0, x1), y0 + h, max(z0, z1)))
        self._seg += 1
        ck = key + ("_a" if self._seg % 2 == 0 else "_b") if key == "wall" else key
        return self.level.world.add(box, material, kind, tag=tag, color_key=ck)

    def wall(
        self,
        x0: float,
        z0: float,
        x1: float,
        z1: float,
        gaps: list[Gap] | None = None,
        thickness: float = WALL_T,
        material: Material = Material.CONCRETE,
        h: float = WALL_H,
    ) -> None:
        """Axis-aligned wall from (x0,z0) to (x1,z1) with doorway gaps; long runs are split for rendering."""
        horizontal = abs(z1 - z0) < abs(x1 - x0)  # runs along x
        a0, a1 = (x0, x1) if horizontal else (z0, z1)
        if a0 > a1:
            a0, a1 = a1, a0
        fixed = z0 if horizontal else x0
        spans = [(a0, a1)]
        for centre, width, door_id in sorted(gaps or [], key=lambda g: g[0]):
            g0, g1 = centre - width / 2, centre + width / 2
            new: list[tuple[float, float]] = []
            for s0, s1 in spans:
                if g1 <= s0 or g0 >= s1:
                    new.append((s0, s1))
                    continue
                if g0 > s0:
                    new.append((s0, g0))
                if g1 < s1:
                    new.append((g1, s1))
            spans = new
            # lintel above the doorway and the door itself
            if horizontal:
                self._wall_box(g0, fixed - thickness / 2, g1, fixed + thickness / 2, h - 2.6, 2.6, material)
            else:
                self._wall_box(fixed - thickness / 2, g0, fixed + thickness / 2, g1, h - 2.6, 2.6, material)
            if door_id:
                if horizontal:
                    c = self._wall_box(
                        g0,
                        fixed - 0.12,
                        g1,
                        fixed + 0.12,
                        2.6,
                        0.0,
                        Material.STEEL,
                        tag=door_id,
                        key="door",
                        kind=ColliderKind.DOOR,
                    )
                else:
                    c = self._wall_box(
                        fixed - 0.12,
                        g0,
                        fixed + 0.12,
                        g1,
                        2.6,
                        0.0,
                        Material.STEEL,
                        tag=door_id,
                        key="door",
                        kind=ColliderKind.DOOR,
                    )
                info = self.level.doors.setdefault(door_id, DoorInfo([], True))
                info.collider_ids.append(c.id)
        for s0, s1 in spans:
            n = max(1, int((s1 - s0) / 4.0 + 0.999))
            step = (s1 - s0) / n
            for i in range(n):
                p0, p1 = s0 + i * step, s0 + (i + 1) * step
                if horizontal:
                    self._wall_box(p0, fixed - thickness / 2, p1, fixed + thickness / 2, h, 0.0, material)
                else:
                    self._wall_box(fixed - thickness / 2, p0, fixed + thickness / 2, p1, h, 0.0, material)

    def room(
        self,
        x0: float,
        z0: float,
        x1: float,
        z1: float,
        *,
        south: list[Gap] | None = None,
        north: list[Gap] | None = None,
        west: list[Gap] | None = None,
        east: list[Gap] | None = None,
    ) -> None:
        self.wall(x0, z0, x1, z0, south)
        self.wall(x0, z1, x1, z1, north)
        self.wall(x0, z0, x0, z1, west)
        self.wall(x1, z0, x1, z1, east)

    # ---- props ----------------------------------------------------------
    def place(
        self, prop: PropDef | str, x: float, z: float, *, rot90: bool = False, seed: int = 0, tag: str = ""
    ) -> Collider | None:
        p = build_prop(prop, seed) if isinstance(prop, str) else prop
        sx, sz = (p.size.z, p.size.x) if rot90 else (p.size.x, p.size.z)
        lvl = self.level
        col: Collider | None = None
        if p.solid:
            kind = ColliderKind.COVER if p.cover else ColliderKind.PROP
            col = lvl.world.add(
                AABB(Vec3(x - sx / 2, 0, z - sz / 2), Vec3(x + sx / 2, p.size.y, z + sz / 2)),
                p.material,
                kind,
                visible=False,
                tag=tag or p.kind,
            )
        for part in p.parts:
            o, s = part.offset, part.size
            if rot90:
                o, s = Vec3(o.z, o.y, o.x), Vec3(s.z, s.y, s.x)
            lvl.decor.append(
                DecorBox(
                    AABB(
                        Vec3(x + o.x - s.x / 2, o.y - s.y / 2, z + o.z - s.z / 2),
                        Vec3(x + o.x + s.x / 2, o.y + s.y / 2, z + o.z + s.z / 2),
                    ),
                    part.color_key,
                    part.emissive,
                )
            )
        return col

    def scatter(
        self,
        kind: str,
        count: int,
        x0: float,
        z0: float,
        x1: float,
        z1: float,
        keep_clear: list[tuple[float, float, float]] | None = None,
    ) -> None:
        placed = 0
        tries = 0
        while placed < count and tries < count * 40:
            tries += 1
            x, z = self.rng.uniform(x0, x1), self.rng.uniform(z0, z1)
            if any((x - cx) ** 2 + (z - cz) ** 2 < r * r for cx, cz, r in (keep_clear or [])):
                continue
            p = build_prop(kind, self.rng.randrange(10_000))
            box = AABB(
                Vec3(x - p.size.x / 2 - 0.6, 0, z - p.size.z / 2 - 0.6),
                Vec3(x + p.size.x / 2 + 0.6, 2, z + p.size.z / 2 + 0.6),
            )
            if self.level.world.query_aabb(box):
                continue
            self.place(p, x, z, seed=p.seed)
            placed += 1

    # ---- metadata -------------------------------------------------------
    def zone(self, name: str, x: float, z: float, r: float) -> None:
        self.level.zones[name] = Zone(name, Vec3(x, 0, z), r)

    def spawn(self, name: str, x: float, z: float, yaw: float = 0.0) -> None:
        self.level.spawn_points[name] = SpawnPoint(name, Vec3(x, 0, z), yaw)

    def route(self, name: str, pts: list[tuple[float, float]]) -> None:
        self.level.patrol_routes[name] = [Vec3(x, 0, z) for x, z in pts]

    def interactable(
        self,
        id_: str,
        x: float,
        z: float,
        kind: str,
        title: str,
        hold: float = 0.0,
        enabled: bool = True,
        **data: str,
    ) -> None:
        self.level.interactables[id_] = InteractableDef(
            id_, Vec3(x, 0, z), kind, title, hold, enabled=enabled, data=dict(data)
        )

    def light(
        self,
        x: float,
        z: float,
        *,
        y: float = 3.0,
        radius: float = 10.0,
        intensity: float = 1.0,
        color: tuple[int, int, int] = (255, 244, 224),
        emergency: bool = False,
        mains: bool = True,
    ) -> None:
        self.level.lights.append(Light(Vec3(x, y, z), color, radius, intensity, emergency, mains))
        if not emergency:
            self.place("light", x, z, tag="light_fixture")
            # lift fixture decor to ceiling height
            d = self.level.decor[-1]
            self.level.decor[-1] = DecorBox(d.aabb.translated(Vec3(0, y - 0.01, 0)), d.color_key, True)

    def finish(self) -> Level:
        from ..enemies.cover import generate_cover_points

        generate_cover_points(self.level)
        return self.level
