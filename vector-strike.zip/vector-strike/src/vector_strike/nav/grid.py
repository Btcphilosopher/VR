"""Grid navigation: obstacle rasterisation, A* with corner-safe diagonals, and path smoothing."""

from __future__ import annotations

import heapq
import math

import numpy as np

from ..physics.vec import Vec3
from ..physics.world import World

SQRT2 = math.sqrt(2.0)
_NEIGH = [
    (1, 0, 1.0),
    (-1, 0, 1.0),
    (0, 1, 1.0),
    (0, -1, 1.0),
    (1, 1, SQRT2),
    (1, -1, SQRT2),
    (-1, 1, SQRT2),
    (-1, -1, SQRT2),
]


class NavGrid:
    def __init__(
        self,
        min_x: float,
        min_z: float,
        max_x: float,
        max_z: float,
        cell: float = 0.5,
        agent_radius: float = 0.4,
    ) -> None:
        self.cell = cell
        self.agent_radius = agent_radius
        self.min_x, self.min_z = min_x, min_z
        self.w = int(math.ceil((max_x - min_x) / cell))
        self.h = int(math.ceil((max_z - min_z) / cell))
        self.blocked = np.zeros((self.w, self.h), dtype=bool)
        self._world_version = -1
        self._world: World | None = None
        self.paths_computed = 0

    # ---- build ----------------------------------------------------------
    def rebuild(self, world: World, radius: float | None = None) -> None:
        radius = self.agent_radius if radius is None else radius
        self.blocked[:, :] = False
        for c in world.colliders.values():
            if not c.blocks_move or c.open:
                continue
            b = c.aabb
            if b.max.y < 0.4 or b.min.y > 1.8:
                continue
            x0, z0 = self.to_cell(b.min.x - radius, b.min.z - radius)
            x1, z1 = self.to_cell(b.max.x + radius, b.max.z + radius)
            x0, z0 = max(x0, 0), max(z0, 0)
            x1, z1 = min(x1, self.w - 1), min(z1, self.h - 1)
            if x0 <= x1 and z0 <= z1:
                self.blocked[x0 : x1 + 1, z0 : z1 + 1] = True
        self._world_version = world.version
        self._world = world

    def ensure_current(self, world: World) -> None:
        if self._world_version != world.version:
            self.rebuild(world)

    # ---- conversions ----------------------------------------------------
    def to_cell(self, x: float, z: float) -> tuple[int, int]:
        return int((x - self.min_x) / self.cell), int((z - self.min_z) / self.cell)

    def to_world(self, cx: int, cz: int) -> Vec3:
        return Vec3(self.min_x + (cx + 0.5) * self.cell, 0.0, self.min_z + (cz + 0.5) * self.cell)

    def in_bounds(self, cx: int, cz: int) -> bool:
        return 0 <= cx < self.w and 0 <= cz < self.h

    def walkable(self, cx: int, cz: int) -> bool:
        return self.in_bounds(cx, cz) and not self.blocked[cx, cz]

    def is_walkable_pos(self, p: Vec3) -> bool:
        cx, cz = self.to_cell(p.x, p.z)
        return self.walkable(cx, cz)

    def _reachable(self, a: Vec3, b: Vec3) -> bool:
        """True if a small body can move straight from a to b without touching solid geometry.
        Stops snapped nav cells from jumping across a wall when an agent hugs it."""
        w = self._world
        if w is None:
            return True
        dist = a.dist_xz(b)
        steps = max(1, int(dist / 0.2))
        from ..physics.shapes import AABB

        for i in range(steps + 1):
            t = i / steps
            x, z = a.x + (b.x - a.x) * t, a.z + (b.z - a.z) * t
            if w._blocked(AABB(Vec3(x - 0.15, 0.1, z - 0.15), Vec3(x + 0.15, 1.6, z + 0.15))):
                return False
        return True

    def nearest_walkable(self, p: Vec3, max_r: int = 12) -> tuple[int, int] | None:
        cx, cz = self.to_cell(p.x, p.z)
        if self.walkable(cx, cz):
            return cx, cz
        for r in range(1, max_r + 1):
            cands: list[tuple[float, int, int]] = []
            for dx in range(-r, r + 1):
                for dz in range(-r, r + 1):
                    if max(abs(dx), abs(dz)) != r:
                        continue
                    if self.walkable(cx + dx, cz + dz):
                        cands.append((dx * dx + dz * dz, cx + dx, cz + dz))
            cands.sort()
            for _, nx, nz in cands:
                if self._reachable(p, self.to_world(nx, nz)):
                    return nx, nz
        return None

    # ---- queries --------------------------------------------------------
    def line_walkable(self, a: Vec3, b: Vec3) -> bool:
        dist = a.dist_xz(b)
        steps = max(1, int(dist / (self.cell * 0.5)))
        for i in range(steps + 1):
            t = i / steps
            x = a.x + (b.x - a.x) * t
            z = a.z + (b.z - a.z) * t
            cx, cz = self.to_cell(x, z)
            if not self.walkable(cx, cz):
                return False
        return True

    def find_path(self, start: Vec3, goal: Vec3, max_nodes: int = 20000) -> list[Vec3] | None:
        s = self.nearest_walkable(start)
        g = self.nearest_walkable(goal)
        if s is None or g is None:
            return None
        self.paths_computed += 1
        if s == g:
            return [goal]
        open_heap: list[tuple[float, int, tuple[int, int]]] = []
        counter = 0
        heapq.heappush(open_heap, (0.0, counter, s))
        came: dict[tuple[int, int], tuple[int, int]] = {}
        cost: dict[tuple[int, int], float] = {s: 0.0}
        expanded = 0
        while open_heap and expanded < max_nodes:
            _, _, cur = heapq.heappop(open_heap)
            expanded += 1
            if cur == g:
                break
            cx, cz = cur
            for dx, dz, c in _NEIGH:
                nx, nz = cx + dx, cz + dz
                if not self.walkable(nx, nz):
                    continue
                if dx != 0 and dz != 0 and not (self.walkable(cx + dx, cz) and self.walkable(cx, cz + dz)):
                    continue
                nc = cost[cur] + c
                if nc < cost.get((nx, nz), 1e18):
                    cost[(nx, nz)] = nc
                    came[(nx, nz)] = cur
                    ddx, ddz = abs(g[0] - nx), abs(g[1] - nz)
                    h = (ddx + ddz) + (SQRT2 - 2.0) * min(ddx, ddz)
                    counter += 1
                    heapq.heappush(open_heap, (nc + h, counter, (nx, nz)))
        if g not in came and g != s:
            return None
        cells = [g]
        while cells[-1] != s:
            cells.append(came[cells[-1]])
        cells.reverse()
        pts = [self.to_world(cx, cz) for cx, cz in cells]
        pts = self._smooth(pts)
        if self.walkable(*self.to_cell(goal.x, goal.z)):
            pts[-1] = Vec3(goal.x, 0.0, goal.z)
        return pts[1:] if len(pts) > 1 else pts

    def _smooth(self, pts: list[Vec3]) -> list[Vec3]:
        if len(pts) <= 2:
            return pts
        out = [pts[0]]
        i = 0
        while i < len(pts) - 1:
            j = len(pts) - 1
            while j > i + 1 and not self.line_walkable(pts[i], pts[j]):
                j -= 1
            out.append(pts[j])
            i = j
        return out
