"""Typed configuration (pydantic) loaded from YAML. No global mutable settings objects."""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator

from .paths import configs_dir


class Difficulty(str, Enum):
    RECRUIT = "recruit"
    NORMAL = "normal"
    VETERAN = "veteran"


class Handedness(str, Enum):
    RIGHT = "right"
    LEFT = "left"


class LocomotionMode(str, Enum):
    TELEPORT = "teleport"
    SMOOTH = "smooth"
    ROOM_SCALE = "room_scale"


class TurnMode(str, Enum):
    SNAP = "snap"
    SMOOTH = "smooth"


class _Model(BaseModel):
    model_config = ConfigDict(extra="ignore", validate_assignment=True)


class GameCfg(_Model):
    difficulty: Difficulty = Difficulty.NORMAL
    vr_enabled: bool = False
    mr_enabled: bool = False
    seed: int = 1337
    developer_mode: bool = False


class PlayerCfg(_Model):
    movement_speed: float = Field(3.0, ge=0.5, le=8.0)
    sprint_multiplier: float = Field(1.6, ge=1.0, le=3.0)
    snap_turn_degrees: float = Field(30.0, ge=10.0, le=90.0)
    smooth_turn_speed: float = Field(110.0, ge=30.0, le=300.0)
    mouse_sensitivity: float = Field(0.0022, gt=0.0)
    invert_y: bool = False
    fov_degrees: float = Field(90.0, ge=60.0, le=120.0)


class ComfortCfg(_Model):
    locomotion: LocomotionMode = LocomotionMode.SMOOTH
    turn_mode: TurnMode = TurnMode.SNAP
    vignette: float = Field(0.5, ge=0.0, le=1.0)
    seated_mode: bool = False
    handedness: Handedness = Handedness.RIGHT
    reduced_motion: bool = False
    reduced_camera_shake: bool = False
    simplified_reload: bool = False
    simplified_interaction: bool = False
    dash_enabled: bool = True
    teleport_fade: bool = True


class HapticsCfg(_Model):
    enabled: bool = True
    intensity: float = Field(0.8, ge=0.0, le=1.0)
    reduced: bool = False  # caps amplitude and drops ambient/low-priority layers
    weapons: bool = True
    impacts: bool = True
    ui: bool = True
    ambient: bool = True
    left_hand: bool = True
    right_hand: bool = True


class AudioCfg(_Model):
    master: float = Field(0.8, ge=0.0, le=1.0)
    effects: float = Field(0.9, ge=0.0, le=1.0)
    spatial: bool = True
    enabled: bool = True


class GraphicsCfg(_Model):
    resolution: str = "1280x720"
    quality: str = "high"
    fps_cap: int = Field(60, ge=15, le=240)
    draw_distance: float = Field(70.0, ge=20.0, le=200.0)
    fullscreen: bool = False

    @field_validator("resolution")
    @classmethod
    def _res(cls, v: str) -> str:
        w, _, h = v.lower().partition("x")
        if not (w.isdigit() and h.isdigit()):
            raise ValueError("resolution must look like 1920x1080")
        return v.lower()

    @property
    def size(self) -> tuple[int, int]:
        w, _, h = self.resolution.partition("x")
        return int(w), int(h)


class MRCfg(_Model):
    room_preset: str = "MR-DEMO-ROOM-001"
    enemy_scale: float = 1.0
    breach_events: bool = True
    furniture_cover: bool = True


class Settings(_Model):
    game: GameCfg = Field(default_factory=GameCfg)
    player: PlayerCfg = Field(default_factory=PlayerCfg)
    comfort: ComfortCfg = Field(default_factory=ComfortCfg)
    haptics: HapticsCfg = Field(default_factory=HapticsCfg)
    audio: AudioCfg = Field(default_factory=AudioCfg)
    graphics: GraphicsCfg = Field(default_factory=GraphicsCfg)
    mr: MRCfg = Field(default_factory=MRCfg)


def load_settings(path: Path | None = None) -> Settings:
    p = path or (configs_dir() / "default.yaml")
    if not p.exists():
        return Settings()
    raw: dict[str, Any] = yaml.safe_load(p.read_text()) or {}
    return Settings.model_validate(raw)


def dump_settings(settings: Settings, path: Path) -> None:
    path.write_text(yaml.safe_dump(settings.model_dump(mode="json"), sort_keys=False))
