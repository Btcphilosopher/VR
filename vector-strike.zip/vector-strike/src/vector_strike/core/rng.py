"""Deterministic random streams. All gameplay randomness flows through GameRng."""

from __future__ import annotations

import hashlib
import math
import random


class GameRng:
    """Named, independently seeded sub-streams so systems do not perturb each other."""

    def __init__(self, seed: int = 1) -> None:
        self.seed = seed
        self._streams: dict[str, random.Random] = {}

    def stream(self, name: str) -> random.Random:
        s = self._streams.get(name)
        if s is None:
            digest = hashlib.sha256(f"{self.seed}:{name}".encode()).digest()
            s = random.Random(int.from_bytes(digest[:8], "little"))
            self._streams[name] = s
        return s

    def state_digest(self) -> str:
        h = hashlib.sha256()
        for k in sorted(self._streams):
            h.update(k.encode())
            h.update(repr(self._streams[k].getstate()[1][:4]).encode())
        return h.hexdigest()[:16]


def gauss_unit_disc(rng: random.Random) -> tuple[float, float]:
    """Point in the unit disc, biased toward the centre (for weapon spread)."""
    r = min(1.0, abs(rng.gauss(0.0, 0.45)))
    a = rng.uniform(0.0, 2 * math.pi)
    return r * math.cos(a), r * math.sin(a)
