"""Small shared enums used across subsystems."""

from __future__ import annotations

from enum import Enum


class Hand(str, Enum):
    LEFT = "left"
    RIGHT = "right"

    @property
    def other(self) -> Hand:
        return Hand.LEFT if self is Hand.RIGHT else Hand.RIGHT


class Team(str, Enum):
    VECTOR = "vector"
    HELIX = "helix"
    NEUTRAL = "neutral"
