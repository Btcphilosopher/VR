"""Locate repository resources (configs, assets) in dev checkouts and installed layouts."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def repo_root() -> Path:
    env = os.environ.get("VECTOR_STRIKE_ROOT")
    if env:
        return Path(env)
    here = Path(__file__).resolve()
    for parent in here.parents:
        if (parent / "configs" / "default.yaml").exists():
            return parent
    return Path.cwd()


def configs_dir() -> Path:
    return repo_root() / "configs"


def assets_dir() -> Path:
    return repo_root() / "assets"


def user_data_dir() -> Path:
    env = os.environ.get("VECTOR_STRIKE_HOME")
    if env:
        p = Path(env)
    else:
        p = Path.home() / ".vector_strike"
    p.mkdir(parents=True, exist_ok=True)
    return p
