"""Deterministic procedural props: pure data (box parts + collider) usable by the renderer,
the level builder, the OBJ exporter and the asset-metadata generator."""

from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import dataclass, field

from ..physics.vec import Vec3
from ..physics.world import Material


@dataclass(frozen=True, slots=True)
class Part:
    offset: Vec3  # centre of the part relative to the prop base-centre (y = height above floor)
    size: Vec3
    color_key: str
    emissive: bool = False


@dataclass(frozen=True)
class PropDef:
    kind: str
    size: Vec3  # collider size (x, y, z); base sits on the floor
    material: Material
    parts: tuple[Part, ...] = ()
    solid: bool = True
    cover: bool = False
    seed: int = 0
    tags: tuple[str, ...] = field(default_factory=tuple)

    @property
    def height(self) -> float:
        return self.size.y


def _p(ox: float, oy: float, oz: float, sx: float, sy: float, sz: float, key: str, em: bool = False) -> Part:
    return Part(Vec3(ox, oy, oz), Vec3(sx, sy, sz), key, em)


def crate(seed: int = 0, size: float | None = None) -> PropDef:
    r = random.Random(seed)
    s = size or r.choice([0.9, 1.0, 1.2, 1.4])
    return PropDef(
        "crate",
        Vec3(s, s, s),
        Material.CRATE,
        (
            _p(0, s * 0.5, 0, s, s, s, "crate"),
            _p(0, s - 0.03, 0, s + 0.04, 0.06, s + 0.04, "crate_trim"),
            _p(0, 0.03, 0, s + 0.04, 0.06, s + 0.04, "crate_trim"),
        ),
        cover=s >= 0.9,
        seed=seed,
        tags=("cover", "industrial"),
    )


def container(seed: int = 0) -> PropDef:
    key = random.Random(seed).choice(["container_a", "container_b", "container_c"])
    return PropDef(
        "container",
        Vec3(6.0, 2.6, 2.4),
        Material.STEEL,
        (_p(0, 1.3, 0, 6.0, 2.6, 2.4, key), _p(0, 2.62, 0, 6.05, 0.05, 2.45, "steel_dark")),
        seed=seed,
        tags=("industrial", "large"),
    )


def barrier(seed: int = 0, length: float = 2.4) -> PropDef:
    return PropDef(
        "barrier",
        Vec3(length, 1.0, 0.5),
        Material.CONCRETE,
        (
            _p(0, 0.35, 0, length, 0.7, 0.5, "concrete_dark"),
            _p(0, 0.85, 0, length, 0.3, 0.28, "concrete_dark"),
            _p(0, 0.5, 0.26, length * 0.9, 0.06, 0.02, "warning_amber", True),
        ),
        cover=True,
        seed=seed,
        tags=("cover",),
    )


def low_wall(length: float = 3.0, height: float = 1.15) -> PropDef:
    return PropDef(
        "low_wall",
        Vec3(length, height, 0.35),
        Material.CONCRETE,
        (_p(0, height / 2, 0, length, height, 0.35, "concrete"),),
        cover=True,
        tags=("cover",),
    )


def pillar(width: float = 0.7, height: float = 3.2) -> PropDef:
    return PropDef(
        "pillar",
        Vec3(width, height, width),
        Material.CONCRETE,
        (_p(0, height / 2, 0, width, height, width, "concrete"),),
        tags=("structure",),
    )


def server_rack(seed: int = 0) -> PropDef:
    r = random.Random(seed)
    parts = [_p(0, 1.1, 0, 0.8, 2.2, 0.9, "rack")]
    for i in range(6):
        on = r.random() > 0.25
        parts.append(_p(0, 0.35 + i * 0.3, 0.46, 0.6, 0.04, 0.02, "led_blue" if on else "steel_dark", on))
    return PropDef(
        "server_rack",
        Vec3(0.8, 2.2, 0.9),
        Material.STEEL,
        tuple(parts),
        cover=False,
        seed=seed,
        tags=("server", "tall"),
    )


def desk(seed: int = 0) -> PropDef:
    return PropDef(
        "desk",
        Vec3(1.6, 0.85, 0.8),
        Material.FURNITURE,
        (
            _p(0, 0.78, 0, 1.6, 0.07, 0.8, "wood_dark"),
            _p(-0.7, 0.38, 0, 0.06, 0.76, 0.7, "steel_dark"),
            _p(0.7, 0.38, 0, 0.06, 0.76, 0.7, "steel_dark"),
            _p(0.0, 1.1, -0.2, 0.5, 0.3, 0.05, "screen_blue", True),
        ),
        cover=True,
        seed=seed,
        tags=("furniture", "cover"),
    )


def table(w: float = 1.4, d: float = 0.8, h: float = 0.75) -> PropDef:
    return PropDef(
        "table",
        Vec3(w, h, d),
        Material.FURNITURE,
        (
            _p(0, h - 0.03, 0, w, 0.06, d, "wood"),
            _p(-w / 2 + 0.06, h / 2, 0, 0.06, h, d - 0.1, "steel_dark"),
            _p(w / 2 - 0.06, h / 2, 0, 0.06, h, d - 0.1, "steel_dark"),
        ),
        cover=h >= 0.7,
        tags=("furniture", "surface"),
    )


def chair() -> PropDef:
    return PropDef(
        "chair",
        Vec3(0.5, 0.9, 0.5),
        Material.FURNITURE,
        (_p(0, 0.45, 0, 0.45, 0.06, 0.45, "fabric"), _p(0, 0.7, -0.2, 0.45, 0.45, 0.06, "fabric")),
        solid=True,
        tags=("furniture",),
    )


def sofa() -> PropDef:
    return PropDef(
        "sofa",
        Vec3(2.0, 0.85, 0.9),
        Material.FURNITURE,
        (_p(0, 0.25, 0, 2.0, 0.5, 0.9, "fabric"), _p(0, 0.65, -0.35, 2.0, 0.45, 0.22, "fabric")),
        cover=True,
        tags=("furniture", "cover"),
    )


def shelf() -> PropDef:
    return PropDef(
        "shelf",
        Vec3(1.2, 1.9, 0.4),
        Material.FURNITURE,
        (_p(0, 0.95, 0, 1.2, 1.9, 0.4, "wood_dark"),),
        tags=("furniture", "tall"),
    )


def bench() -> PropDef:
    return PropDef(
        "bench",
        Vec3(2.0, 0.5, 0.5),
        Material.STEEL,
        (
            _p(0, 0.45, 0, 2.0, 0.06, 0.5, "steel"),
            _p(-0.8, 0.22, 0, 0.06, 0.44, 0.4, "steel_dark"),
            _p(0.8, 0.22, 0, 0.06, 0.44, 0.4, "steel_dark"),
        ),
        tags=("transit",),
    )


def train_car(length: float = 18.0) -> PropDef:
    return PropDef(
        "train_car",
        Vec3(length, 3.3, 3.0),
        Material.STEEL,
        (
            _p(0, 1.65, 0, length, 3.3, 3.0, "train_body"),
            _p(0, 2.1, 1.52, length * 0.9, 0.7, 0.03, "window_dark"),
            _p(0, 0.9, 1.52, length, 0.12, 0.04, "warning_amber", True),
        ),
        tags=("transit", "large"),
    )


def locker() -> PropDef:
    return PropDef(
        "locker",
        Vec3(0.6, 1.9, 0.5),
        Material.STEEL,
        (_p(0, 0.95, 0, 0.6, 1.9, 0.5, "locker"),),
        tags=("industrial",),
    )


def target_dummy() -> PropDef:
    return PropDef(
        "target_dummy",
        Vec3(0.6, 1.8, 0.4),
        Material.WOOD,
        (_p(0, 0.9, 0, 0.5, 1.5, 0.1, "target"), _p(0, 1.6, 0, 0.3, 0.3, 0.1, "target_head")),
        solid=False,
        tags=("training",),
    )


def terminal(kind: str = "terminal") -> PropDef:
    return PropDef(
        kind,
        Vec3(1.0, 1.1, 0.6),
        Material.STEEL,
        (_p(0, 0.45, 0, 1.0, 0.9, 0.6, "steel_dark"), _p(0, 1.0, -0.1, 0.8, 0.4, 0.06, "screen_amber", True)),
        tags=("interactive",),
    )


def light_fixture() -> PropDef:
    return PropDef(
        "light",
        Vec3(1.2, 0.1, 0.2),
        Material.STEEL,
        (_p(0, 0, 0, 1.2, 0.08, 0.2, "light_white", True),),
        solid=False,
        tags=("light",),
    )


def pipe_run(length: float = 6.0) -> PropDef:
    return PropDef(
        "pipe_run",
        Vec3(length, 0.3, 0.3),
        Material.STEEL,
        (_p(0, 0, 0, length, 0.25, 0.25, "pipe"),),
        solid=False,
        tags=("industrial",),
    )


def floor_panel(w: float = 2.0, d: float = 2.0) -> PropDef:
    return PropDef(
        "floor_panel",
        Vec3(w, 0.02, d),
        Material.CONCRETE,
        (_p(0, 0.01, 0, w, 0.02, d, "floor_panel"),),
        solid=False,
        tags=("floor",),
    )


def door_panel(width: float = 2.0) -> PropDef:
    return PropDef(
        "door",
        Vec3(width, 2.6, 0.25),
        Material.STEEL,
        (_p(0, 1.3, 0, width, 2.6, 0.25, "door"),),
        tags=("door",),
    )


PROP_FACTORIES: dict[str, Callable[..., PropDef]] = {
    "crate": crate,
    "container": container,
    "barrier": barrier,
    "low_wall": low_wall,
    "pillar": pillar,
    "server_rack": server_rack,
    "desk": desk,
    "table": table,
    "chair": chair,
    "sofa": sofa,
    "shelf": shelf,
    "bench": bench,
    "train_car": train_car,
    "locker": locker,
    "target_dummy": target_dummy,
    "terminal": terminal,
    "light": light_fixture,
    "pipe_run": pipe_run,
    "floor_panel": floor_panel,
    "door": door_panel,
}


def build_prop(kind: str, seed: int = 0) -> PropDef:
    """Instantiate a prop by kind. `seed` is only forwarded to factories that declare a `seed` parameter."""
    import inspect

    f = PROP_FACTORIES[kind]
    if "seed" in inspect.signature(f).parameters:
        return f(seed=seed)
    return f()


def to_obj(prop: PropDef) -> str:
    """Wavefront OBJ of the prop's box parts (placeholder geometry for DCC import)."""
    lines = [f"# {prop.kind} seed={prop.seed}", f"o {prop.kind}"]
    vi = 1
    for part in prop.parts:
        c, s = part.offset, part.size
        for dx in (-0.5, 0.5):
            for dy in (-0.5, 0.5):
                for dz in (-0.5, 0.5):
                    lines.append(f"v {c.x + dx * s.x:.4f} {c.y + dy * s.y:.4f} {c.z + dz * s.z:.4f}")
        faces = [(1, 3, 4, 2), (5, 6, 8, 7), (1, 2, 6, 5), (3, 7, 8, 4), (1, 5, 7, 3), (2, 4, 8, 6)]
        for f in faces:
            lines.append("f " + " ".join(str(vi + i - 1) for i in f))
        vi += 8
    return "\n".join(lines) + "\n"
