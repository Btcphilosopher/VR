"""Command line entry: `python -m vector_strike` (desktop) | --headless-sim | --screenshots | --generate-assets."""

from __future__ import annotations

import argparse
import os
import sys


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="vector-strike", description="VECTOR STRIKE - VR/MR action shooter vertical slice"
    )
    ap.add_argument("--dev", action="store_true", help="enable developer console (`) and tools")
    ap.add_argument(
        "--vr",
        choices=["off", "sim", "hardware"],
        default="off",
        help="sim = drive the game through the VR input stack with a desktop-emulated headset; "
        "hardware = try OpenXR, fall back to sim",
    )
    ap.add_argument(
        "--mission",
        help="launch a mission directly (training, vector_01, vector_02, survival_breach, mr_invasion)",
    )
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--headless-sim", metavar="MISSION", help="play a mission with the scripted bot, print the result")
    ap.add_argument("--difficulty", choices=["recruit", "normal", "veteran"])
    ap.add_argument("--screenshots", metavar="DIR", help="render the menu/mission screens to PNG files (headless)")
    ap.add_argument("--generate-assets", action="store_true", help="regenerate procedural assets + art package")
    ap.add_argument("--selftest", action="store_true", help="run the 18-step acceptance walkthrough headlessly")
    args = ap.parse_args(argv)

    if args.headless_sim or args.screenshots or args.selftest or args.generate_assets:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

    if args.generate_assets:
        from .tools.artgen import generate_all

        generate_all()
        return 0
    if args.selftest:
        from .tools.acceptance import run_acceptance

        return 0 if run_acceptance(verbose=True) else 1
    if args.headless_sim:
        from .core.config import Difficulty, load_settings
        from .game.session import GameSession
        from .tools.bot import run_bot

        st = load_settings()
        if args.difficulty:
            st.game.difficulty = Difficulty(args.difficulty)
        s = GameSession.create(st, args.headless_sim, seed=args.seed)
        ok = run_bot(s, 1500.0)
        r = s.result
        print(
            f"{args.headless_sim}: {'SUCCESS' if ok else 'FAILED'}"
            + (f" ({r.reason})" if r and not ok else "")
            + (
                f"  time={r.elapsed:.0f}s acc={r.accuracy:.0%} dmg={r.damage_taken:.0f} score={r.score.total} rank={r.score.rank}"
                if r
                else ""
            )
        )
        return 0 if ok else 1
    if args.screenshots:
        from .tools.screenshots import render_screens

        render_screens(args.screenshots)
        return 0

    from .game.app import make_app

    app = make_app(dev=args.dev, vr_mode=args.vr, seed=args.seed)
    if args.difficulty:
        from .core.config import Difficulty

        app.settings.game.difficulty = Difficulty(args.difficulty)
    if args.mission:
        app.start_mission(args.mission)
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
