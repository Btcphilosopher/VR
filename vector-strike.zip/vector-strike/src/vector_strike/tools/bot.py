"""AutoPilot: a deterministic scripted player used for simulation tests, demos and balance checks.

It plays through the same PlayerIntent interface as a human, so it exercises the real game rules."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..enemies.enemy import Enemy
from ..game.intent import PlayerIntent
from ..game.session import GameSession
from ..physics.vec import Vec3, clamp, wrap_angle
from ..weapons.spec import Slot
from ..weapons.weapon import WeaponState

MAX_TURN = 7.5  # rad/s


@dataclass
class AutoPilot:
    session: GameSession
    skill: float = 0.85  # 0..1 aim quality
    path: list[Vec3] = field(default_factory=list)
    path_goal: Vec3 | None = None
    path_t: float = 0.0
    stuck_t: float = 0.0
    last_pos: Vec3 = Vec3()
    unstick: float = 0.0
    _phase_flags: dict[str, bool] = field(default_factory=dict)
    _reload_done: bool = False

    # ---- helpers -----------------------------------------------------------------------------
    def _visible_enemies(self, include_inert: bool = False) -> list[tuple[float, Enemy]]:
        s = self.session
        eye = s.player.eye
        out = []
        for e in s.enemies:
            if not e.alive or (e.inert and not include_inert):
                continue
            d = e.pos.dist_xz(s.player.state.pos)
            if d > 45:
                continue
            chest = e.pos + Vec3(0, 1.2 * e.stance_scale, 0)
            if s.level.world.line_of_sight(eye, chest):
                out.append((d, e))
        out.sort(key=lambda x: x[0])
        return out

    def _turn(self, desired_yaw: float, desired_pitch: float, dt: float, intent: PlayerIntent) -> float:
        p = self.session.player.state
        dy = wrap_angle(desired_yaw - p.yaw)
        dp = desired_pitch - p.pitch
        step = MAX_TURN * dt
        intent.look_yaw = clamp(dy, -step, step)
        intent.look_pitch = clamp(dp, -step, step)
        return abs(dy) + abs(dp)

    def _navigate(self, goal: Vec3, dt: float) -> Vec3 | None:
        s = self.session
        pos = s.player.state.pos
        self.path_t -= dt
        if self.path_goal is None or self.path_goal.dist_xz(goal) > 1.0 or self.path_t <= 0:
            self.path_goal = goal
            self.path_t = 1.5
            p = s.nav.find_path(pos, goal)
            self.path = p or []
        while self.path and pos.dist_xz(self.path[0]) < 0.6:
            self.path.pop(0)
        return self.path[0] if self.path else None

    # ---- main --------------------------------------------------------------------------------------
    def decide(self, dt: float) -> PlayerIntent:
        s = self.session
        intent = PlayerIntent()
        p = s.player
        st = p.state
        w = s.inventory.weapon
        r = s.runner
        obj = r.active_primary()
        otype = obj.defn.type if obj else ""
        visible = self._visible_enemies(include_inert=otype == "kills")

        # stuck handling
        if st.pos.dist_xz(self.last_pos) < 0.15 * dt * 10:
            self.stuck_t += dt
        else:
            self.stuck_t = 0.0
            self.last_pos = st.pos
        if self.stuck_t > 2.0:
            self.unstick = 0.6
            self.stuck_t = 0.0
            self.path = []
        if self.unstick > 0:
            self.unstick -= dt
            intent.move_x = 1.0
            intent.jump = int(s.t * 4) % 2 == 0
        # training one-shots
        if otype == "reload" and w is not None and w.ammo >= w.spec.magazine_capacity:
            intent.fire = int(s.t * 10) % 2 == 0  # burn a couple of rounds so a reload is legal
        if otype == "reload" and w is not None and w.ammo < w.spec.magazine_capacity:
            intent.reload = True
        if otype == "switch_weapon":
            slot = Slot.SECONDARY if s.inventory.active is Slot.PRIMARY else Slot.PRIMARY
            intent.switch_slot = slot
        if otype == "throw_grenade":
            intent.grenade = int(s.t * 2) % 2 == 0
        if otype == "kills" and not visible and obj is not None:
            tg = [e for e in s.enemies if e.alive and e.group == (obj.defn.group or "")]
            if tg:
                tgt = min(tg, key=lambda e: e.pos.dist_xz(st.pos))
                if tgt.pos.dist_xz(st.pos) > 14:
                    visible = []
        # reload logic
        if w is not None and w.state is WeaponState.READY and otype not in ("reload",):
            if w.ammo == 0 and w.reserve_available:
                intent.reload = True
            elif w.ammo <= 4 and (not visible or visible[0][0] > 10) and w.reserve_available:
                intent.reload = True
            elif w.ammo == 0 and not w.reserve_available:
                intent.switch_slot = Slot.SECONDARY if s.inventory.active is Slot.PRIMARY else Slot.PRIMARY

        engaged = bool(visible) and w is not None
        if engaged and w is not None:
            d, tgt = visible[0]
            aim_pt = tgt.pos + Vec3(0, (1.45 if self.skill > 0.8 else 1.15) * tgt.stance_scale, 0)
            to = aim_pt - p.eye
            yaw = math.atan2(to.x, to.z)
            pitch = math.asin(clamp(to.y / max(to.length(), 1e-6), -1, 1))
            err = self._turn(yaw, pitch, dt, intent)
            intent.aim = True
            intent.crouch = d > 6 and st.health > 25
            intent.fire = err < (0.05 + (1 - self.skill) * 0.1) and d < w.spec.range * 0.7
            # keep closing distance only if we need to reach a goal behind them; otherwise hold & fight
            goals = r.goal_positions()
            if d > 28 and goals:
                intent.crouch = False
                intent.move_z = 1.0
        else:
            goal = self._goal(otype, obj)
            if goal is not None:
                wp = self._navigate(goal, dt)
                target = wp if wp is not None else goal
                to = target - p.eye
                yaw = math.atan2(to.x, to.z)
                if st.pos.dist_xz(goal) > self._arrive_radius(otype):
                    err = self._turn(yaw, 0.0, dt, intent)
                    if wp is None and otype in ("clear_group", "kills"):
                        intent.crouch = True  # no route to the target (e.g. behind a virtual wall): hold and wait
                    else:
                        intent.move_z = 1.0 if err < 0.8 else 0.0
                        intent.sprint = True
                else:
                    self._turn(math.atan2(goal.x - st.pos.x, goal.z - st.pos.z), 0.0, dt, intent)
                    if otype in ("interact", "pickup"):
                        intent.interact = True
                    if obj is not None and obj.defn.require_crouch:
                        intent.crouch = True
            else:
                # hold: face the nearest enemy or look around
                near = [e for e in s.enemies if e.alive and not e.inert]
                if near:
                    tgt = min(near, key=lambda e: e.pos.dist_xz(st.pos))
                    to = tgt.pos - st.pos
                    self._turn(math.atan2(to.x, to.z), 0.0, dt, intent)
                    if tgt.pos.dist_xz(st.pos) > 6 and s.waves is not None:
                        wp = self._navigate(tgt.pos, dt)
                        if wp is not None and tgt.pos.dist_xz(st.pos) > 14:
                            ty = math.atan2(wp.x - st.pos.x, wp.z - st.pos.z)
                            self._turn(ty, 0.0, dt, intent)
                            intent.move_z = 1.0
        # always interact when an interactable prompt is in range and we need it (ammo)
        if (
            s.interact_target
            and s.interactables[s.interact_target].kind == "ammo"
            and w
            and w.reserve < w.spec.magazine_capacity
        ):
            intent.interact = True
        return intent

    def _arrive_radius(self, otype: str) -> float:
        if otype in ("interact", "pickup"):
            return 1.3
        if otype == "reach_zone":
            return 0.6
        return 3.0

    def _goal(self, otype: str, obj) -> Vec3 | None:
        s = self.session
        if obj is None:
            return None
        d = obj.defn
        if otype == "reach_zone":
            z = s.level.zone(d.zone or "")
            return z.center
        if otype in ("interact", "pickup"):
            it = s.level.interactables[d.target or ""]
            return it.pos
        if otype in ("clear_group", "kills"):
            gs = [e for e in s.enemies if e.alive and (d.group is None or e.group == d.group)]
            if not gs:
                return None
            tgt = min(gs, key=lambda e: e.pos.dist_xz(s.player.state.pos))
            if otype == "kills":
                # step towards a firing position ~10 m from the nearest target
                dirv = (s.player.state.pos - tgt.pos).flat().normalized()
                return tgt.pos + dirv * 10.0
            return tgt.pos
        return None


def run_bot(
    session: GameSession, max_seconds: float = 1200.0, dt: float = 1 / 60, skill: float = 0.85, on_tick=None
) -> bool:
    """Play a session to completion. Returns True on mission success."""
    bot = AutoPilot(session, skill=skill)
    limit = int(max_seconds / dt)
    for _ in range(limit):
        if session.done:
            break
        session.step(dt, bot.decide(dt))
        if on_tick is not None:
            on_tick(session)
    return bool(session.result and session.result.success)
