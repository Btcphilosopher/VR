"""Art pipeline: procedural asset export (OBJ + metadata), concept-art prompt library, UI/HUD specs and
procedural placeholder images. No image-generation model is available in this environment, so concept art is
delivered as production-ready prompts + deterministic placeholder boards (clearly labelled as placeholders)."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from ..assets.procedural import PROP_FACTORIES, build_prop, to_obj
from ..core.paths import repo_root
from ..enemies.spec import ENEMIES
from ..haptics.patterns import pattern_names
from ..weapons.spec import CATALOGUE

STYLE = (
    "late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, "
    "raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning "
    "indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple "
    "gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos"
)

# (id, title, prompt, aspect)
CONCEPT_PROMPTS: list[tuple[str, str, str, str]] = [
    (
        "01_main_menu",
        "Main menu key art",
        "Slow-moving industrial interior at night seen through a low-angle camera, wet concrete floor reflecting amber work lights, "
        "steel gantries and stacked shipping containers receding into haze, a lone operative silhouette in practical plate carrier far "
        "off-centre, large negative space on the left for the title VECTOR STRIKE in a restrained grotesque sans (white, wide tracking), "
        "thin amber rule under the title",
        "16:9",
    ),
    (
        "02_first_person_environment",
        "First-person environment frame",
        "First-person VR view down a concrete loading hall, lowered rifle with weapon-mounted ammo counter in amber, low barrier cover "
        "mid-ground, overhead strip lights half-failed, volumetric dust, subtle red warning beacon at far end, depth-of-field tuned for headset "
        "comfort, no flat HUD on the face",
        "16:9",
    ),
    (
        "03_industrial_facility",
        "Industrial facility - Halden Works",
        "Exterior establishing shot of a fictional research and logistics complex at night: brutalist concrete blocks, rooftop plant, steel "
        "service stairs, sodium-amber floodlights, one lit server wing with cold blue glow, rain-slick asphalt service yard, security cameras "
        "with red status LEDs",
        "21:9",
    ),
    (
        "04_transport_terminal",
        "Transport terminal - Kessler Interchange",
        "High-speed rail terminal concourse at night, long platform with parked train cars in matte steel, concrete pillars, wayfinding in "
        "plain white-on-graphite signage, amber emergency lighting after a blackout, service tunnel entrance with hazard stripes, "
        "no real station branding",
        "21:9",
    ),
    (
        "05_weapon_renders",
        "Weapon hero renders (all seven)",
        "Professional military-industrial product photography on a graphite sweep, three-quarter studio lighting, matte polymer and "
        "hard-anodised aluminium, no manufacturer branding, small engraved model numbers (KS-4, WR-2, SP-9, HM-12, P-11, ARC-9, TR-0) "
        "only",
        "16:9",
    ),
    (
        "06_enemy_character",
        "HELIX Operative",
        "Full-body design sheet of a paramilitary technology contractor: dark graphite uniform, low-reflectance plate carrier, "
        "ballistic helmet with a small red identification band, practical comms headset, gloves, boots, modular pouches; elite variant "
        "with amber trim; front/side/back views, material callouts; avoid excessive sci-fi armour",
        "3:2",
    ),
    (
        "07_player_equipment",
        "Vector Operative equipment",
        "Equipment layout: muted olive plate carrier with MOLLE-style webbing, wrist computer on the left forearm (amber-on-graphite readout), "
        "magazine pouch left hip, sidearm holster right hip, helmet with restrained blue marker light, field radio, gloves with "
        "controller-tracking rings",
        "3:2",
    ),
    (
        "08_vr_wrist_ui",
        "VR wrist interface",
        "Concept of a world-space forearm display: matte graphite bezel, amber monospaced data (health %, ammo, heading, timer), thin "
        "blue accent for objective bearing, red only for warnings; physical buttons on the bezel; shown from the player's first-person view",
        "16:9",
    ),
    (
        "09_mr_room",
        "Mixed-reality room",
        "Passthrough living room with virtual overlays: translucent amber breach outline on a real wall, a virtual terminal standing on the "
        "real table, floor spawn markers as thin circular glyphs, furniture edges tinted green to show cover; restrained, no hologram "
        "excess",
        "16:9",
    ),
    (
        "10_mission_briefing",
        "Mission briefing screen",
        "Dark briefing table scene: top-down satellite-style plan of the complex drawn as thin amber line-work on graphite, objective pins, "
        "typed mission text block, paper dossier edge, subtle scan-line",
        "16:9",
    ),
    (
        "11_loading_screen",
        "Loading screen",
        "Minimal loading frame: single industrial detail (steel door seam with amber light spill) with a thin progress rule and a one-line "
        "tip, huge negative space",
        "16:9",
    ),
    (
        "12_results_screen",
        "Results screen",
        "After-action report layout: left column of stats in amber/white monospace, right column transparent score breakdown table, rank "
        "letter large in steel white, background a desaturated freeze-frame of the extraction vehicle",
        "16:9",
    ),
    (
        "13_inventory",
        "Inventory / loadout",
        "Loadout bay: weapon on a graphite rack under a single overhead lamp, stat bars as thin amber lines, attachment ghost outlines, "
        "equipment hanging on pegboard, no sci-fi hologram",
        "16:9",
    ),
    (
        "14_mission_select",
        "Mission selection",
        "Operations room wall: a row of mission folders (BLACKOUT, TRANSIT, BREACH, INVASION) pinned on corkboard-free steel panels, each "
        "with a location photo, difficulty pips and a completion stamp in red/blue",
        "16:9",
    ),
    (
        "15_environment_key_art",
        "Environment key art",
        "Wide cinematic key art: Vector operatives breach a dark server hall as the facility power fails, emergency amber/red lighting cutting "
        "through haze, silhouettes of HELIX contractors behind server racks, strong depth layers, anamorphic flare restrained",
        "21:9",
    ),
]

HUD_SPEC = """# HUD & UI Specification

## Principles
- Nothing permanently glued to the face. Information lives on the **weapon**, in the **world**, on the **wrist**, or at the screen
  edge *only when relevant*.
- Colour roles: **amber** = player-relevant information, **cold blue** = objective bearing / cover state, **red** = danger only.
- One typeface family: monospaced for data (DejaVu Sans Mono fallback), grotesque sans for titles. Sizes tuned for >= 1.5 deg legibility in VR.

## Elements
| Element | Desktop | VR / MR | Behaviour |
|---|---|---|---|
| Reticle | 4 ticks + dot, centre | none (physical sights; soft aim dot optional) | fades 70% while aiming |
| Ammo | weapon-mounted readout | on the weapon body, rotates with the weapon | turns red <= 20% mag; shows INSERT MAG / CHARGE in physical reload |
| Health | thin bar bottom-left, hidden at full health | wrist panel + haptic heartbeat | red vignette below 30% |
| Damage direction | red wedge on a ring | wedge ring at 1.2 m + left/right haptic bias | 0.8 s |
| Objective | small text top-centre | wrist panel + world-space marker | marker = floor ring, vertical beam, diamond, distance |
| Interaction prompt | below reticle, progress bar | above the interactable, world-locked | hold-to-confirm; simplified-interaction shortens holds |
| Mission timer | top-right (only when a fail timer runs) | wrist panel | red below 30 s |
| Hit / kill marker | white X / red ring | haptic tick (+ small X) | 0.18 s / 0.35 s |

## Wrist interface
Left forearm, 14 x 8 cm, tilt-to-wake. Page *status* (HP, objective, ammo, heading, timer). Page *menu* opens the floating menu
(MISSION, LOADOUT, TRAINING, SETTINGS, ACCESSIBILITY, EXIT).

## Floating menu (VR)
World-space panel 1.6 m wide at 1.2 m distance, 12 degrees below eye line, never follows head roll. Laser-pointer or thumbstick
navigation; grip to go back. Same item model as the desktop menu (`ui.menu.MenuList`).

## Menus
`MAIN`: CAMPAIGN / SURVIVAL / TRAINING / MR INVASION / LOADOUT / SETTINGS / EXIT over a slowly dollying industrial background.
`MISSION SELECT`: location, difficulty, estimated duration, objectives, completion status. `RESULTS`: time, accuracy, objectives,
damage taken, enemies defeated, optional objectives, transparent score lines, then CONTINUE / REPLAY / LOADOUT.
"""


def _weapon_art_spec(w) -> dict:
    return {
        "id": w.id,
        "name": w.name,
        "kind": w.kind.value,
        "views": ["side_profile", "first_person_view", "reload_view", "magazine", "attachment_configuration"],
        "materials": {
            "receiver": "hard-anodised aluminium, matte graphite",
            "furniture": "glass-filled polymer, muted olive/black",
            "barrel": "nitrided steel, dark gunmetal",
            "markings": "engraved model number only, no maker brand",
        },
        "prompts": {
            "side_profile": f"{w.name}, fictional {w.kind.value}, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. {STYLE}",
            "first_person_view": f"First-person VR view of the {w.name} held {'two-handed' if w.two_handed else 'one-handed'}, weapon-mounted amber ammo counter, hands in tracked gloves",
            "reload_view": f"{w.name} reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull",
            "magazine": f"{w.name} magazine, cut-away showing {w.magazine_capacity}-round capacity, polymer body with steel feed lips, amber round-count window",
            "attachments": f"{w.name} attachment configuration sheet: optic, grip, muzzle device ({'energy emitter' if w.fire_mode.value == 'projectile' else 'brake/suppressor'}), light",
        },
    }


def generate_all(root: Path | None = None) -> dict[str, int]:
    root = root or repo_root()
    assets = root / "assets"
    counts: dict[str, int] = {}
    (assets / "props").mkdir(parents=True, exist_ok=True)
    # --- procedural props: OBJ + metadata -----------------------------------------------------------------------
    n = 0
    for kind in sorted(PROP_FACTORIES):
        for seed in (0, 1, 2) if kind in ("crate", "server_rack", "desk", "barrier") else (0,):
            p = build_prop(kind, seed)
            stem = f"{kind}_s{seed}"
            (assets / "props" / f"{stem}.obj").write_text(to_obj(p))
            meta = {
                "id": stem,
                "kind": kind,
                "seed": seed,
                "size_m": list(p.size.as_tuple()),
                "material": p.material.value,
                "solid": p.solid,
                "cover": p.cover,
                "tags": list(p.tags),
                "parts": len(p.parts),
                "generator": "vector_strike.assets.procedural",
                "deterministic": True,
            }
            (assets / "props" / f"{stem}.json").write_text(json.dumps(meta, indent=2))
            n += 1
    counts["props"] = n
    # --- weapon + character specs ----------------------------------------------------------------------------------
    (assets / "weapons").mkdir(parents=True, exist_ok=True)
    for w in CATALOGUE.values():
        spec = _weapon_art_spec(w)
        spec["gameplay"] = {k: v for k, v in asdict(w).items() if k not in ("haptic",)} | {"haptic": asdict(w.haptic)}
        (assets / "weapons" / f"{w.id}.json").write_text(json.dumps(spec, indent=2, default=str))
    counts["weapons"] = len(CATALOGUE)
    (assets / "characters").mkdir(parents=True, exist_ok=True)
    chars = {
        "vector_operative": "Player. Muted olive plate carrier, blue marker light, wrist computer, tracked gloves.",
        **{
            e.id: f"{e.name}. Role {e.role.value}; marker colour {e.marker}; HP {e.health:g}." for e in ENEMIES.values()
        },
    }
    for cid, desc in chars.items():
        meta = {
            "id": cid,
            "description": desc,
            "style": STYLE,
            "prompt": f"{desc} Practical equipment, realistic materials, helmet, body armour, comms, gloves, boots. {STYLE}",
        }
        (assets / "characters" / f"{cid}.json").write_text(json.dumps(meta, indent=2))
    counts["characters"] = len(chars)
    # --- concept art prompts ----------------------------------------------------------------------------------------------
    (assets / "concept_art").mkdir(parents=True, exist_ok=True)
    docs = root / "docs" / "art"
    docs.mkdir(parents=True, exist_ok=True)
    md = [
        "# Concept Art Prompt Library",
        "",
        "Global style block (append to every prompt):",
        "",
        f"> {STYLE}",
        "",
    ]
    for cid, title, prompt, ar in CONCEPT_PROMPTS:
        md += [f"## {cid} - {title}", f"*Aspect {ar}*", "", prompt, ""]
        (assets / "concept_art" / f"{cid}.json").write_text(
            json.dumps(
                {
                    "id": cid,
                    "title": title,
                    "aspect": ar,
                    "prompt": prompt + " " + STYLE,
                    "status": "prompt_only",
                    "placeholder": f"assets/generated/{cid}.png",
                },
                indent=2,
            )
        )
    (docs / "CONCEPT_PROMPTS.md").write_text("\n".join(md))
    wmd = [
        "# Weapon Art Specification",
        "",
        "All designs are original and fictional. Product-photography style, no manufacturer branding.",
        "",
    ]
    for w in CATALOGUE.values():
        s = _weapon_art_spec(w)
        wmd += [
            f"## {w.name} (`{w.id}`) - {w.kind.value}",
            "",
            f"Damage {w.damage:g}{f' x{w.pellets}' if w.pellets > 1 else ''} | {w.rate_of_fire:.0f} rpm | mag {w.magazine_capacity} | "
            f"reload {w.reload_time:.1f}s | haptic kick {w.haptic.kick:.2f}",
            "",
        ]
        for k, v in s["prompts"].items():
            wmd.append(f"- **{k}**: {v}")
        wmd += ["", "Materials: " + "; ".join(f"{k}: {v}" for k, v in s["materials"].items()), ""]
    (docs / "WEAPONS.md").write_text("\n".join(wmd))
    (docs / "UI_HUD_SPEC.md").write_text(HUD_SPEC)
    counts["concept_prompts"] = len(CONCEPT_PROMPTS)
    # --- haptic pattern catalogue ----------------------------------------------------------------------------------------------
    (root / "docs" / "HAPTICS_PATTERNS.json").write_text(json.dumps(pattern_names(), indent=2))
    return counts
