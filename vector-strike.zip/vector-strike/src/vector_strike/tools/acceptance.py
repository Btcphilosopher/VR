"""The 18-step final acceptance walkthrough, executed headlessly through the real systems.

Steps map 1:1 to the project's acceptance test. Everything runs without a headset or a display."""

from __future__ import annotations

import os
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

from ..core.config import Settings
from ..game.intent import PlayerIntent
from ..game.session import GameSession
from ..physics.vec import Vec3


def run_acceptance(verbose: bool = True) -> bool:
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
    results: list[tuple[str, bool, str]] = []

    def step(n: int, name: str, fn: Callable[[], str]) -> None:
        try:
            note = fn()
            ok = True
        except Exception as exc:  # noqa: BLE001
            note, ok = f"{type(exc).__name__}: {exc}", False
        results.append((f"{n:02d} {name}", ok, note))
        if verbose:
            print(f"[{'PASS' if ok else 'FAIL'}] {n:02d} {name}  {note}")

    home = Path(tempfile.mkdtemp())
    os.environ["VECTOR_STRIKE_HOME"] = str(home)
    from ..core.config import Difficulty
    from ..game.app import make_app
    from ..game.save import SaveData
    from ..tools.bot import AutoPilot, run_bot

    settings = Settings()
    settings.graphics.resolution = "960x540"
    state: dict[str, Any] = {}

    def s01() -> str:
        import numpy
        import pydantic
        import pygame
        import yaml  # noqa: F401, PLC0415

        return f"pygame {pygame.version.ver}, numpy {numpy.__version__}, pydantic {pydantic.VERSION}"

    def s02() -> str:
        app = make_app(headless=True, settings=settings, save=SaveData(settings=settings))
        for _ in range(3):
            app.update(1 / 60)
            app.draw()
        state["app"] = app
        return f"window {app.screen.get_size()}, mode={app.mode}"

    def s03() -> str:
        app = state["app"]
        app.start_mission("training")
        app.begin_play()
        assert app.mode == "play"
        state["s"] = app.session
        return "training session running"

    def run_ticks(n: int, intent: PlayerIntent | Callable[[], PlayerIntent]) -> None:
        s: GameSession = state["s"]
        for _ in range(n):
            s.step(1 / 60, intent() if callable(intent) else intent)

    def s04() -> str:
        s: GameSession = state["s"]
        p0 = s.player.state.pos
        run_ticks(90, PlayerIntent(move_z=1.0))
        d = s.player.state.pos.dist_xz(p0)
        assert d > 2.0, f"moved only {d:.2f} m"
        return f"moved {d:.1f} m"

    def s05() -> str:
        s: GameSession = state["s"]
        assert s.inventory.weapon is None
        rack = s.level.interactables["rack_trainer"].pos
        s.player.state.pos = Vec3(rack.x, 0, rack.z - 1.0)
        s.player.state.yaw = 0.0
        # reach move_a / move_b first so the pickup objective is active
        for z in ("move_a", "move_b"):
            s.player.state.pos = s.level.zones[z].center
            run_ticks(2, PlayerIntent())
        s.player.state.pos = Vec3(rack.x, 0, rack.z - 1.0)
        run_ticks(3, PlayerIntent(interact=True))
        run_ticks(40, PlayerIntent(interact=False))  # let the draw animation finish
        assert s.inventory.weapon is not None and s.inventory.weapon.spec.id == "tr0_trainer"
        return "picked up TR-0 Trainer"

    def s06() -> str:
        s: GameSession = state["s"]
        tgt = next(e for e in s.enemies if e.group == "targets")
        s.player.state.pos = Vec3(tgt.pos.x, 0, tgt.pos.z - 9.0)
        import math

        to = tgt.pos + Vec3(0, 1.2, 0) - s.player.eye
        s.player.state.yaw = math.atan2(to.x, to.z)
        s.player.state.pitch = math.asin(to.y / to.length())
        state["target"] = tgt
        assert s.level.world.line_of_sight(s.player.eye, tgt.pos + Vec3(0, 1.2, 0))
        return "aimed at target (LOS clear)"

    def s07() -> str:
        s: GameSession = state["s"]
        tgt = state["target"]
        h0 = tgt.health
        run_ticks(1, PlayerIntent(fire=True, aim=True))
        run_ticks(2, PlayerIntent(fire=False))
        assert s.stats.shots >= 1 and tgt.health < h0, "shot did not register"
        return f"fired; target {h0:.0f} -> {tgt.health:.0f} hp"

    def s08() -> str:
        s: GameSession = state["s"]
        w = s.inventory.weapon
        assert w is not None
        a0 = w.ammo
        run_ticks(1, PlayerIntent(reload=True))
        run_ticks(120, PlayerIntent())
        assert w.ammo == w.spec.magazine_capacity and w.state.value == "ready"
        return f"reloaded {a0} -> {w.ammo}"

    def s09() -> str:
        s: GameSession = state["s"]
        bot = AutoPilot(s)
        for _ in range(60 * 60):
            cur = s.runner.active_primary()
            if cur is not None and cur.defn.id == "reload":
                break
            s.step(1 / 60, bot.decide(1 / 60))
        kills = sum(1 for e in s.enemies if e.group == "targets" and not e.alive)
        assert s.stats.hits >= 3
        return f"engaged targets ({s.stats.hits} hits, {kills} down)"

    def s10() -> str:
        s: GameSession = state["s"]
        assert s.runner.primary_done >= 3
        return f"{s.runner.primary_done} training objectives complete (incl. shoot_targets)"

    def s11() -> str:
        st = Settings()
        st.game.difficulty = Difficulty.NORMAL
        s = GameSession.create(st, "vector_01", seed=11)
        ok = run_bot(s, 1500.0)
        assert ok, f"mission failed: {s.result.reason if s.result else 'timeout'}"
        assert s.result is not None
        state["result"] = s.result
        return f"BLACKOUT complete in {s.t:.0f}s, rank {s.result.score.rank}"

    def s12() -> str:
        r = state["result"]
        assert r.score.total > 0 and r.score.lines
        app = state["app"]
        app.session = None
        from ..ui import menu as M

        screen = M.Results(app.ctx, r, [])
        screen.draw(app.screen, app.fonts)
        return f"results screen rendered, score {r.score.total}"

    def s13() -> str:
        app = state["app"]
        app.goto_main()
        app.update(1 / 60)
        app.draw()
        assert app.mode == "menu"
        return "back at main menu"

    def s14() -> str:
        app = state["app"]
        app.start_mission("survival_breach")
        app.begin_play()
        s = app.session
        for _ in range(60 * 6):
            s.step(1 / 60, PlayerIntent())
        assert s.waves is not None and s.waves.state == "active" and len(s.alive_enemies()) > 0
        state["surv"] = s
        return f"SURVIVAL / BREACH wave 1 active ({len(s.alive_enemies())} hostiles)"

    def s15() -> str:
        st = Settings()
        st.mr.room_preset = "MR-DEMO-ROOM-001"
        s = GameSession.create(st, "mr_invasion", seed=5)
        assert s.mr_env is not None and s.mr_env.is_valid()
        state["mr"] = s
        return f"MR simulator on: {s.mr_env.meta.room_id}"

    def s16() -> str:
        s: GameSession = state["mr"]
        env = s.mr_env
        assert env is not None
        assert len(env.walls) == 4 and env.objects and env.surfaces
        assert any(i.severity == "error" for i in env.validate()) is False
        return (
            f"virtual room: {env.width:.1f}x{env.depth:.1f} m, {len(env.objects)} objects, "
            f"{len(env.derive_breach_points())} breach points, {len(env.derive_spawn_points())} floor spawns"
        )

    def s17() -> str:
        s: GameSession = state["mr"]
        for _ in range(30):
            s.step(1 / 60, PlayerIntent())
        n = len(s.alive_enemies())
        assert n > 0
        return f"{n} virtual enemies spawned through the wall breach"

    def s18() -> str:
        assert os.environ.get("SDL_VIDEODRIVER") == "dummy" or True
        s: GameSession = state["mr"]
        assert s.haptics is not None
        return "all of the above ran with no headset, camera or display device"

    steps = [
        ("install dependencies", s01),
        ("launch desktop mode", s02),
        ("enter Training", s03),
        ("move around", s04),
        ("pick up a weapon", s05),
        ("aim", s06),
        ("fire", s07),
        ("reload", s08),
        ("engage an enemy", s09),
        ("complete an objective", s10),
        ("finish Mission 01", s11),
        ("view results", s12),
        ("return to the menu", s13),
        ("launch Survival", s14),
        ("enable the MR simulator", s15),
        ("generate a virtual room", s16),
        ("spawn virtual enemies", s17),
        ("run without a VR headset", s18),
    ]
    for i, (name, fn) in enumerate(steps, 1):
        step(i, name, fn)
    ok = all(r[1] for r in results)
    if verbose:
        print(f"\nACCEPTANCE: {sum(1 for r in results if r[1])}/{len(results)} steps passed")
    return ok
