"""Developer console. Never required for normal gameplay; enabled with --dev / game.developer_mode."""

from __future__ import annotations

import shlex
from collections.abc import Callable
from dataclasses import dataclass, field

from ..core.config import Difficulty
from ..core.types import Hand
from ..enemies.spec import ENEMIES
from ..game.session import GameSession
from ..haptics.patterns import pattern_names
from ..physics.vec import Vec3
from ..rendering.software import DebugFlags
from ..weapons.spec import CATALOGUE


class ConsoleError(Exception):
    pass


@dataclass
class DevConsole:
    session: GameSession
    flags: DebugFlags
    start_mission_cb: Callable[[str], None] | None = None
    history: list[str] = field(default_factory=list)
    commands: dict[str, Callable[[list[str]], str]] = field(init=False)
    enabled: bool = True

    def __post_init__(self) -> None:
        self.commands = {
            "help": self._help,
            "spawn_enemy": self._spawn_enemy,
            "spawn_weapon": self._spawn_weapon,
            "give_ammo": self._give_ammo,
            "teleport": self._teleport,
            "start_mission": self._start_mission,
            "complete_objective": self._complete_objective,
            "set_difficulty": self._set_difficulty,
            "show_hitboxes": self._flag("show_hitboxes"),
            "show_ai": self._flag("show_ai"),
            "show_mr_mesh": self._flag("show_mr_mesh"),
            "show_fps": self._flag("show_fps"),
            "god": self._god,
            "haptic_test": self._haptic_test,
            "kill_all": self._kill_all,
        }

    def run(self, line: str) -> str:
        if not self.enabled:
            return "console disabled"
        line = line.strip()
        if not line:
            return ""
        self.history.append(line)
        parts = shlex.split(line)
        cmd, args = parts[0], parts[1:]
        fn = self.commands.get(cmd)
        if fn is None:
            return f"unknown command '{cmd}' (try: help)"
        try:
            return fn(args)
        except ConsoleError as exc:
            return f"error: {exc}"
        except (ValueError, KeyError, IndexError) as exc:
            return f"error: {exc!r}"

    # ---- commands -------------------------------------------------------------------------------
    def _help(self, a: list[str]) -> str:
        return "commands: " + ", ".join(sorted(self.commands))

    def _spawn_enemy(self, a: list[str]) -> str:
        kind = a[0] if a else "rifleman"
        n = int(a[1]) if len(a) > 1 else 1
        if kind not in ENEMIES:
            raise ConsoleError(f"unknown enemy '{kind}' ({', '.join(ENEMIES)})")
        s = self.session
        for i in range(n):
            pos = s.player.state.pos + s.forward().flat().normalized() * (8.0 + i * 1.2)
            if not s.nav.is_walkable_pos(pos):
                snap = s.nav.nearest_walkable(pos)
                pos = s.nav.to_world(*snap) if snap else pos
            s.spawn_enemy(kind, pos, s.player.state.yaw + 3.14159, group="dev", state="alert")
        return f"spawned {n} {kind}"

    def _spawn_weapon(self, a: list[str]) -> str:
        wid = a[0]
        if wid not in CATALOGUE:
            raise ConsoleError(f"unknown weapon (options: {', '.join(CATALOGUE)})")
        self.session.inventory.add_weapon(wid)
        return f"equipped {CATALOGUE[wid].name}"

    def _give_ammo(self, a: list[str]) -> str:
        self.session.inventory.add_ammo(float(a[0]) if a else 2.0)
        self.session.inventory.grenades = self.session.inventory.max_grenades
        w = self.session.inventory.weapon
        return f"ammo: {w.ammo}/{w.reserve}" if w else "no weapon"

    def _teleport(self, a: list[str]) -> str:
        s = self.session
        if len(a) == 1:
            z = s.level.zones.get(a[0])
            if z is None:
                raise ConsoleError(f"unknown zone (options: {', '.join(s.level.zones)})")
            s.player.state.pos = z.center
            return f"teleported to zone {a[0]}"
        s.player.state.pos = Vec3(float(a[0]), 0.0, float(a[1]))
        return "teleported"

    def _start_mission(self, a: list[str]) -> str:
        if self.start_mission_cb is None:
            raise ConsoleError("no mission launcher attached")
        self.start_mission_cb(a[0])
        return f"starting {a[0]}"

    def _complete_objective(self, a: list[str]) -> str:
        r = self.session.runner
        st = r.states[a[0]] if a else r.active_primary()
        if st is None:
            raise ConsoleError("no active objective")
        r._complete(st)  # noqa: SLF001 - dev tool
        return f"completed {st.defn.id}"

    def _set_difficulty(self, a: list[str]) -> str:
        d = Difficulty(a[0])
        self.session.settings.game.difficulty = d
        return f"difficulty -> {d.value} (applies to new enemy decisions)"

    def _flag(self, name: str) -> Callable[[list[str]], str]:
        def toggle(a: list[str]) -> str:
            cur = getattr(self.flags, name)
            val = (a[0].lower() in ("1", "on", "true")) if a else not cur
            setattr(self.flags, name, val)
            return f"{name} = {val}"

        return toggle

    def _god(self, a: list[str]) -> str:
        st = self.session.player.state
        st.god_mode = (a[0].lower() in ("1", "on", "true")) if a else not st.god_mode
        return f"god = {st.god_mode}"

    def _kill_all(self, a: list[str]) -> str:
        n = 0
        for e in self.session.alive_enemies():
            e.apply_damage(1e6, "torso", e.pos, "dev")
            n += 1
        return f"defeated {n}"

    def _haptic_test(self, a: list[str]) -> str:
        names = pattern_names()
        if not a:
            return "patterns: " + ", ".join(names)
        hand = Hand(a[1]) if len(a) > 1 else None
        hd = self.session.haptics
        if hd is None:
            raise ConsoleError("no haptic director")
        if a[0] not in names:
            raise ConsoleError(f"unknown pattern ({', '.join(names)})")
        ok = hd.trigger_named(a[0], hand)
        return f"haptic {a[0]} {'sent' if ok else 'blocked by settings/rate limit'}"
