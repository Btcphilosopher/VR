"""Render the game's own screens to PNG - these double as procedural placeholder art for the design package."""

from __future__ import annotations

import math
import os
from pathlib import Path

import pygame

from ..core.config import Settings
from ..game.save import SaveData
from ..game.session import GameSession
from ..game.state import MissionResult
from ..physics.vec import Vec3
from ..rendering.software import DebugFlags, SoftwareRenderer, ViewState
from ..rendering.viewmodel import draw_viewmodel
from ..tools.bot import AutoPilot
from ..ui import menu as M
from ..ui.hud import HudRenderer, build_hud, make_fonts
from ..ui.wrist import WristPanel, draw_wrist_preview


def _save(surf: pygame.Surface, out: Path, name: str) -> None:
    pygame.image.save(surf, str(out / f"{name}.png"))


def render_screens(out_dir: str, size: tuple[int, int] = (1280, 720)) -> list[str]:
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ["VECTOR_STRIKE_HOME"] = str(Path(out_dir) / ".home")
    pygame.init()
    surf = pygame.display.set_mode(size)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    fonts = make_fonts()
    hud = HudRenderer(fonts)
    settings = Settings()
    save = SaveData(settings=settings)
    from ..missions.models import list_missions

    ctx = M.MenuContext(settings, save, list_missions())
    names: list[str] = []

    # ---- menu (industrial dolly) --------------------------------------------------------------------------------------
    s = GameSession.create(settings, "vector_01", seed=3, autostart=False)
    r = SoftwareRenderer(s.level, fonts)
    view = ViewState(camera_override=(Vec3(22, 1.7, 18.5), 0.75, -0.02), fov_deg=80)
    r.render(s, surf, DebugFlags(), view)
    M.MainMenu(ctx).draw(surf, fonts)
    _save(surf, out, "menu_main")
    names.append("menu_main")
    r.render(s, surf, DebugFlags(), view)
    sel = M.MissionSelect(ctx, ("mission",) and (M.MissionMode.MISSION,), "CAMPAIGN")
    sel.draw(surf, fonts)
    _save(surf, out, "menu_mission_select")
    names.append("menu_mission_select")
    r.render(s, surf, DebugFlags(), view)
    M.Loadout(ctx).draw(surf, fonts)
    _save(surf, out, "menu_loadout")
    names.append("menu_loadout")
    r.render(s, surf, DebugFlags(), view)
    M.Settings_(ctx, "haptics").draw(surf, fonts)
    _save(surf, out, "menu_settings_haptics")
    names.append("menu_settings_haptics")
    r.render(s, surf, DebugFlags(), view)
    M.Settings_(ctx, "access").draw(surf, fonts)
    _save(surf, out, "menu_settings_accessibility")
    names.append("menu_settings_accessibility")
    M.Briefing(ctx, ctx.missions[1]).t = 99.0
    b = M.Briefing(ctx, ctx.missions[1])
    b.t = 99.0
    b.draw(surf, fonts)
    _save(surf, out, "briefing_blackout")
    names.append("briefing_blackout")

    # ---- gameplay frames --------------------------------------------------------------------------------------------------
    def play_frame(
        mission: str, name: str, ticks: int, setup=None, wrist: bool = False, power_fail: bool = False
    ) -> None:
        st = Settings()
        gs = GameSession.create(st, mission, seed=21)
        gr = SoftwareRenderer(gs.level, fonts)
        bot = AutoPilot(gs)
        if setup:
            setup(gs)
        if power_fail:
            gs.power_fail()
        for _ in range(ticks):
            gs.step(1 / 60, bot.decide(1 / 60))
            if gs.done:
                break
        v = ViewState(fov_deg=90, ads=0.0, draw_distance=70)
        gr.render(gs, surf, DebugFlags(), v)
        w = gs.inventory.weapon
        pos = (int(size[0] * 0.7), int(size[1] * 0.8))
        if w is not None:
            flash = max((e.ttl / e.max_ttl for e in gs.effects if e.kind == "flash"), default=0.0)
            pos = draw_viewmodel(
                surf,
                w,
                ads=0.0,
                bob_phase=gs.t * 6,
                speed=gs.player.state.speed_xz,
                reduced_motion=False,
                flash=flash,
                t=gs.t,
            )
        if not gs.powered:
            ov = pygame.Surface(size, pygame.SRCALPHA)
            ov.fill((40, 6, 4, 26))
            surf.blit(ov, (0, 0))
        m = build_hud(gs)
        hud.draw(surf, m, 1 / 60)
        if w is not None:
            hud.draw_weapon_ui(surf, m, pos)
        if wrist:
            draw_wrist_preview(surf, WristPanel.from_hud(m), fonts, (24, size[1] - 150))
        _save(surf, out, name)
        names.append(name)

    play_frame("training", "gameplay_training", 60 * 2)
    play_frame("vector_01", "gameplay_blackout_hall", 60 * 12, wrist=True)
    play_frame("vector_01", "gameplay_blackout_power_fail", 60 * 30, power_fail=True)
    play_frame("vector_02", "gameplay_transit_concourse", 60 * 14)
    play_frame("survival_breach", "gameplay_survival_breach", 60 * 14)

    # ---- MR view ---------------------------------------------------------------------------------------------------------------------
    st = Settings()
    gs = GameSession.create(st, "mr_invasion", seed=5)
    gr = SoftwareRenderer(gs.level, fonts)
    bot = AutoPilot(gs)
    for _ in range(40):
        gs.step(1 / 60, bot.decide(1 / 60))
    gs.player.state.yaw = math.radians(35)
    flags = DebugFlags(show_mr_mesh=True)
    gr.render(gs, surf, flags, ViewState(fov_deg=100, draw_distance=30))
    hud.draw(surf, build_hud(gs), 1 / 60)
    _save(surf, out, "mr_invasion_room")
    names.append("mr_invasion_room")

    # ---- results -----------------------------------------------------------------------------------------------------------------------
    gs = GameSession.create(Settings(), "vector_01", seed=7)
    from ..tools.bot import run_bot

    run_bot(gs, 1500.0)
    res: MissionResult = gs.result  # type: ignore[assignment]
    surf.fill((10, 12, 14))
    gr = SoftwareRenderer(gs.level, fonts)
    gr.render(gs, surf, DebugFlags(), ViewState(camera_override=(Vec3(50, 1.7, 18), 3.9, -0.02)))
    M.Results(ctx, res, ["hm12_hammer"]).draw(surf, fonts)
    _save(surf, out, "results_screen")
    names.append("results_screen")
    pygame.quit()
    return names
