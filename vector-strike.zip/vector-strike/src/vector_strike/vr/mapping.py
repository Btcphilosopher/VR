"""Maps a VR InputFrame to the device-independent PlayerIntent used by the simulation."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core.config import ComfortCfg, Handedness, PlayerCfg
from ..core.types import Hand
from ..game import events as ev
from ..game.intent import PlayerIntent
from ..game.session import GameSession
from ..physics.vec import Vec3, wrap_angle
from ..weapons.handling import HolsterRig, VRReloadController, compute_handling
from .actions import InputFrame
from .locomotion import Locomotion, LocomotionOutput

STAND_HEAD = 1.65


@dataclass
class VRIntentMapper:
    comfort: ComfortCfg
    player: PlayerCfg
    locomotion: Locomotion = field(init=False)
    holsters: HolsterRig = field(init=False)
    reload: VRReloadController = field(init=False)
    rig_yaw: float = 0.0
    last_loco: LocomotionOutput = field(default_factory=LocomotionOutput)
    _prev_head_yaw: float | None = None
    _prev_head_pitch: float = 0.0
    _trigger_down: bool = False
    _b_prev_sup: bool = False
    _stick_click_prev: bool = False
    _crouch_toggle: bool = False
    menu_pressed: bool = False
    _menu_prev: bool = False

    def __post_init__(self) -> None:
        self.locomotion = Locomotion(self.comfort, self.player)
        self.holsters = HolsterRig(self.comfort.handedness, self.comfort.seated_mode)
        self.reload = VRReloadController(simplified=self.comfort.simplified_reload, handedness=self.comfort.handedness)

    def dominant(self) -> Hand:
        return Hand.LEFT if self.comfort.handedness is Handedness.LEFT else Hand.RIGHT

    def map(self, frame: InputFrame, session: GameSession, dt: float) -> PlayerIntent:
        s = session
        dom_hand = self.dominant()
        sup_hand = dom_hand.other
        dom, sup = frame.controller(dom_hand), frame.controller(sup_hand)
        st = s.player.state
        intent = PlayerIntent(hand=dom_hand)

        # ---- locomotion & turning ------------------------------------------------------------------
        loco = self.locomotion.process(frame, self.rig_yaw, st.pos, s.nav, dt)
        self.last_loco = loco
        self.rig_yaw = wrap_angle(self.rig_yaw + loco.turn)
        intent.move_x, intent.move_z = loco.move_x, loco.move_z
        intent.teleport_to = loco.teleport_to
        extra = Vec3(0, 0, 0)
        if loco.room_delta is not None:
            extra = extra + loco.room_delta
        if loco.dash_delta is not None:
            extra = extra + loco.dash_delta
            intent.dash_dir = loco.dash_delta.normalized()
        if extra.length() > 0:
            intent.room_delta = extra

        # head look -> player yaw/pitch (view follows the HMD)
        target_yaw = wrap_angle(self.rig_yaw + frame.head.yaw)
        intent.look_yaw = wrap_angle(target_yaw - st.yaw)
        intent.look_pitch = frame.head.pitch - st.pitch

        # ---- posture -------------------------------------------------------------------------------
        sc = sup.stick_click
        if sc and not self._stick_click_prev:
            self._crouch_toggle = not self._crouch_toggle
        self._stick_click_prev = sc
        physical_crouch = frame.head.position.y < STAND_HEAD * 0.72 and not self.comfort.seated_mode
        intent.crouch = self._crouch_toggle or physical_crouch
        intent.sprint = dom.stick_click

        # ---- weapon handling ---------------------------------------------------------------------------
        w = s.inventory.weapon
        head_ref = frame.head.position
        if w is not None:
            res = compute_handling(frame.head, dom, sup, w.spec)
            # tracking space -> world space (stand under the head, rotate by rig yaw)
            cy, sy = math.cos(self.rig_yaw), math.sin(self.rig_yaw)

            def to_world(p: Vec3) -> Vec3:
                d = p - Vec3(head_ref.x, 0.0, head_ref.z)
                return st.pos + Vec3(d.x * cy + d.z * sy, d.y, -d.x * sy + d.z * cy)

            def rot(v: Vec3) -> Vec3:
                return Vec3(v.x * cy + v.z * sy, v.y, -v.x * sy + v.z * cy)

            intent.aim_override = (to_world(res.origin), rot(res.direction).normalized())
            intent.stability = res.stability
            intent.aim = res.aim_mode.value == "shoulder"
            intent.support_hand = sup_hand if res.grip.value == "two_handed" else None
            flags = self.reload.process(frame, dom_hand, w, dt)
            intent.reload = flags["reload"]
            intent.drop_mag, intent.insert_mag, intent.charge = (
                flags["drop_mag"],
                flags["insert_mag"],
                flags["charge"],
            )
            if self.comfort.simplified_interaction and dom.b and w.state.value == "chamber":
                intent.charge = True
            # trigger with hysteresis
            if dom.trigger > 0.65:
                self._trigger_down = True
            elif dom.trigger < 0.35:
                self._trigger_down = False
            intent.fire = self._trigger_down
        # holsters (draw weapons from body zones)
        act = self.holsters.process(frame, s.inventory.active, dom_hand)
        if act is not None and s.inventory.slots[act.slot] is not None:
            s.inventory.switch_to(act.slot)
            s.bus.emit(ev.WEAPON_DRAW, hand=act.hand, slot=act.slot.value)

        # ---- buttons -----------------------------------------------------------------------------------------
        intent.interact = dom.b
        b_sup = sup.b
        intent.grenade = b_sup and not self._b_prev_sup
        self._b_prev_sup = b_sup
        menu = frame.left.menu or frame.right.menu
        self.menu_pressed = menu and not self._menu_prev
        self._menu_prev = menu
        return intent

    def vignette(self) -> float:
        return self.last_loco.vignette
