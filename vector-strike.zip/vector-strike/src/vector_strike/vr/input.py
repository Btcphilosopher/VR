"""VRInput abstraction + backends (scripted for tests, desktop-emulated, OpenXR stub)."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass

from ..core.types import Hand
from ..haptics.devices import HapticDevice, NullHapticDevice
from ..haptics.engine import HapticSample
from ..physics.vec import Vec3, forward_from_angles, right_from_yaw
from .actions import ControllerState, InputAction, InputFrame, Pose

log = logging.getLogger(__name__)


class VRUnavailable(RuntimeError):
    """No headset / OpenXR runtime present."""


class VRInput(ABC):
    """Abstract headset input. Concrete backends fill an `InputFrame` each poll."""

    name = "abstract"

    def __init__(self) -> None:
        self.frame: InputFrame | None = None
        self.haptic_device: HapticDevice = NullHapticDevice()

    @abstractmethod
    def poll(self, t: float) -> InputFrame: ...

    # ---- convenience accessors in the spec's vocabulary ------------------------------------
    def head_pose(self) -> Pose:
        assert self.frame is not None
        return self.frame.head

    def controller_pose(self, hand: Hand) -> Pose:
        assert self.frame is not None
        return self.frame.controller(hand).pose

    def value(self, action: InputAction, hand: Hand) -> float | bool | tuple[float, float]:
        assert self.frame is not None
        c = self.frame.controller(hand)
        table: dict[InputAction, float | bool | tuple[float, float]] = {
            InputAction.TRIGGER: c.trigger,
            InputAction.GRIP: c.grip,
            InputAction.THUMBSTICK: c.stick,
            InputAction.THUMBPAD: c.pad,
            InputAction.A_BUTTON: c.a,
            InputAction.B_BUTTON: c.b,
            InputAction.MENU: c.menu,
        }
        return table[action]

    def haptic(self, hand: Hand, sample: HapticSample, dt: float) -> None:
        self.haptic_device.apply(hand, sample, dt)

    def shutdown(self) -> None:
        return None


class ScriptedVRInput(VRInput):
    """Deterministic input driven by a callable or a list of frames - for tests and replays."""

    name = "scripted"

    def __init__(self, source: Callable[[float], InputFrame] | list[InputFrame]) -> None:
        super().__init__()
        self._src = source
        self._i = 0

    def poll(self, t: float) -> InputFrame:
        if callable(self._src):
            self.frame = self._src(t)
        else:
            self.frame = self._src[min(self._i, len(self._src) - 1)]
            self._i += 1
        return self.frame


@dataclass
class DesktopControls:
    """Raw desktop state the emulator converts to a fake headset (filled by the pygame input layer)."""

    move_x: float = 0.0
    move_z: float = 0.0
    fire: bool = False
    aim: bool = False
    interact: bool = False
    reload: bool = False
    grenade: bool = False
    crouch: bool = False
    sprint: bool = False
    menu: bool = False
    yaw: float = 0.0
    pitch: float = 0.0


class DesktopEmulatedVR(VRInput):
    """Fake headset for development: the desktop camera is the head, the hands float in front of it."""

    name = "desktop-emulated"

    def __init__(self, controls: DesktopControls | None = None) -> None:
        super().__init__()
        self.controls = controls or DesktopControls()
        self.head_height = 1.65

    def poll(self, t: float) -> InputFrame:
        c = self.controls
        head_pos = Vec3(0.0, self.head_height * (0.65 if c.crouch else 1.0), 0.0)
        head = Pose(head_pos, c.yaw, c.pitch, 0.0)
        f, r = forward_from_angles(c.yaw, c.pitch), right_from_yaw(c.yaw)
        lift = 0.0 if c.aim else -0.28
        rpos = head_pos + f * (0.38 if c.aim else 0.30) + r * (0.0 if c.aim else 0.18) + Vec3(0, lift, 0)
        lpos = head_pos + f * (0.70 if c.aim else 0.34) + r * (-0.0 if c.aim else -0.18) + Vec3(0, lift, 0)
        right = ControllerState(
            Pose(rpos, c.yaw, c.pitch),
            trigger=1.0 if c.fire else 0.0,
            grip=1.0 if c.aim else 0.0,
            a=c.reload,
            b=c.interact,
        )
        left = ControllerState(
            Pose(lpos, c.yaw, c.pitch),
            grip=1.0 if c.aim else 0.0,
            stick=(c.move_x, c.move_z),
            stick_click=c.sprint,
            b=c.grenade,
            menu=c.menu,
        )
        self.frame = InputFrame(t, head, left, right)
        return self.frame


class OpenXRInput(VRInput):
    """OpenXR backend skeleton (pyopenxr). It binds the headset-agnostic actions to the
    `/interaction_profiles/khr/simple_controller` + common thumbstick/trigger/squeeze paths.

    HARDWARE-UNTESTED: constructing it without pyopenxr or a runtime raises VRUnavailable so callers fall back
    to `DesktopEmulatedVR`. The frame loop, swapchains and stereo rendering belong to a native/GL renderer
    layer that replaces `rendering.software`."""

    name = "openxr"

    def __init__(self) -> None:
        super().__init__()
        try:
            import xr  # noqa: F401
        except Exception as exc:
            raise VRUnavailable(f"pyopenxr not installed ({exc})") from exc
        raise VRUnavailable("No OpenXR runtime session available (headset not connected)")

    def poll(self, t: float) -> InputFrame:  # pragma: no cover
        raise VRUnavailable("OpenXR session not running")


def create_vr_input(prefer_hardware: bool, controls: DesktopControls | None = None) -> VRInput:
    """Factory with graceful fallback - the game must never require a headset."""
    if prefer_hardware:
        try:
            return OpenXRInput()
        except VRUnavailable as exc:
            log.info("VR hardware unavailable (%s) - using desktop emulation", exc)
    return DesktopEmulatedVR(controls)
