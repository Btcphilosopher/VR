"""VR locomotion: teleport, smooth, room-scale, dash, snap/smooth turn, vignette, scripted movement."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core.config import ComfortCfg, Handedness, LocomotionMode, PlayerCfg, TurnMode
from ..core.types import Hand
from ..nav.grid import NavGrid
from ..physics.vec import Vec3, clamp, right_from_yaw
from .actions import InputFrame

TELEPORT_RANGE = 9.0
DASH_DISTANCE = 3.0
DASH_TIME = 0.18
DASH_COOLDOWN = 1.2


@dataclass(slots=True)
class LocomotionOutput:
    move_x: float = 0.0
    move_z: float = 0.0
    turn: float = 0.0  # radians this tick (snap or smooth)
    teleport_to: Vec3 | None = None
    dash_delta: Vec3 | None = None  # world-space displacement this tick
    room_delta: Vec3 | None = None  # physical movement (world space)
    vignette: float = 0.0  # 0..1 comfort vignette strength
    teleport_arc: list[Vec3] = field(default_factory=list)
    teleport_valid: bool = False
    fade: float = 0.0  # 0..1 blink fade this tick


@dataclass
class Locomotion:
    comfort: ComfortCfg
    player: PlayerCfg
    _snap_armed: bool = True
    _tp_aiming: bool = False
    _tp_target: Vec3 | None = None
    _dash_t: float = 0.0
    _dash_dir: Vec3 = Vec3()
    _dash_cd: float = 0.0
    _a_prev: bool = False
    _last_head: Vec3 | None = None

    # hand roles: dominant hand aims/turns, the other hand moves
    def hands(self) -> tuple[Hand, Hand]:
        dom = Hand.LEFT if self.comfort.handedness is Handedness.LEFT else Hand.RIGHT
        return dom, dom.other

    def process(
        self, frame: InputFrame, rig_yaw: float, player_pos: Vec3, nav: NavGrid | None, dt: float
    ) -> LocomotionOutput:
        out = LocomotionOutput()
        dom, mover = self.hands()
        mc, dc = frame.controller(mover), frame.controller(dom)
        self._dash_cd = max(0.0, self._dash_cd - dt)
        head_yaw = rig_yaw + frame.head.yaw

        # ---- turning -------------------------------------------------------------------------------
        tx = dc.stick[0]
        if self.comfort.turn_mode is TurnMode.SNAP:
            if abs(tx) > 0.7 and self._snap_armed:
                out.turn = math.copysign(math.radians(self.player.snap_turn_degrees), tx)
                self._snap_armed = False
            elif abs(tx) < 0.3:
                self._snap_armed = True
        else:
            rate = self.player.smooth_turn_speed * (0.5 if self.comfort.reduced_motion else 1.0)
            if abs(tx) > 0.15:
                out.turn = math.radians(rate) * tx * dt

        # ---- room-scale ---------------------------------------------------------------------------
        if self._last_head is not None and self.comfort.locomotion is LocomotionMode.ROOM_SCALE:
            d = frame.head.position - self._last_head
            local = Vec3(d.x, 0.0, d.z)
            r = right_from_yaw(rig_yaw)
            f = Vec3(math.sin(rig_yaw), 0, math.cos(rig_yaw))
            out.room_delta = r * local.x + f * local.z
        self._last_head = frame.head.position

        # ---- primary locomotion ---------------------------------------------------------------------
        sx, sy = mc.stick
        mag = math.hypot(sx, sy)
        mode = self.comfort.locomotion
        if mode is LocomotionMode.SMOOTH:
            if mag > 0.12:
                out.move_x, out.move_z = sx, sy
        elif mode is LocomotionMode.TELEPORT:
            self._teleport(frame, mover, rig_yaw, player_pos, nav, out, sy)
        # room-scale mode still allows smooth movement with the stick when pushed (hybrid) - off by default
        elif mode is LocomotionMode.ROOM_SCALE and mag > 0.5:
            out.move_x, out.move_z = sx * 0.6, sy * 0.6

        # ---- dash ---------------------------------------------------------------------------------------
        a_pressed = mc.a and not self._a_prev
        self._a_prev = mc.a
        if self.comfort.dash_enabled and a_pressed and self._dash_t <= 0 and self._dash_cd <= 0:
            if mag > 0.3:
                fwd = Vec3(math.sin(head_yaw), 0, math.cos(head_yaw))
                rgt = right_from_yaw(head_yaw)
                self._dash_dir = (fwd * sy + rgt * sx).normalized()
            else:
                self._dash_dir = Vec3(math.sin(head_yaw), 0, math.cos(head_yaw))
            if self.comfort.reduced_motion:
                out.dash_delta = self._dash_dir * DASH_DISTANCE  # instant blink, no travel
                out.fade = 0.4
                self._dash_cd = DASH_COOLDOWN
            else:
                self._dash_t = DASH_TIME
        if self._dash_t > 0:
            step = min(dt, self._dash_t)
            out.dash_delta = self._dash_dir * (DASH_DISTANCE / DASH_TIME * step)
            self._dash_t -= step
            if self._dash_t <= 1e-6:
                self._dash_t = 0.0
                self._dash_cd = DASH_COOLDOWN

        # ---- comfort vignette ----------------------------------------------------------------------------
        speed = math.hypot(out.move_x, out.move_z) * self.player.movement_speed
        if out.dash_delta is not None and not self.comfort.reduced_motion:
            speed = max(speed, DASH_DISTANCE / DASH_TIME)
        turn_rate = abs(out.turn) / max(dt, 1e-3) if self.comfort.turn_mode is TurnMode.SMOOTH else 0.0
        strength = clamp(speed / 5.0 + turn_rate / 2.5, 0.0, 1.0)
        out.vignette = self.comfort.vignette * strength * (1.25 if self.comfort.reduced_motion else 1.0)
        out.vignette = clamp(out.vignette, 0.0, 1.0)
        return out

    def _teleport(
        self,
        frame: InputFrame,
        hand: Hand,
        rig_yaw: float,
        pos: Vec3,
        nav: NavGrid | None,
        out: LocomotionOutput,
        stick_y: float,
    ) -> None:
        if stick_y > 0.6:
            self._tp_aiming = True
            out.teleport_arc, target = self._arc(frame, hand, rig_yaw, pos)
            valid = target is not None and (
                nav is None or (nav.is_walkable_pos(target) and nav.line_walkable(pos, target))
            )
            self._tp_target = target if valid else None
            out.teleport_valid = valid
        elif self._tp_aiming:
            self._tp_aiming = False
            if self._tp_target is not None:
                out.teleport_to = self._tp_target
                out.fade = 1.0 if self.comfort.teleport_fade else 0.0
            self._tp_target = None

    def _arc(self, frame: InputFrame, hand: Hand, rig_yaw: float, pos: Vec3) -> tuple[list[Vec3], Vec3 | None]:
        """Ballistic arc from the controller, in world space; returns (points, landing point on the floor)."""
        cs = frame.controller(hand)
        fwd_local = cs.pose.forward()
        # rotate controller forward from tracking space into the rig's world orientation
        cy, sy = math.cos(rig_yaw), math.sin(rig_yaw)
        fwd = Vec3(fwd_local.x * cy + fwd_local.z * sy, fwd_local.y, -fwd_local.x * sy + fwd_local.z * cy)
        origin = pos + Vec3(0, cs.pose.position.y, 0)
        v = fwd.normalized() * 7.5 + Vec3(0, 1.5, 0)
        pts: list[Vec3] = []
        p = origin
        for _ in range(40):
            pts.append(p)
            v = Vec3(v.x, v.y - 9.81 * 0.05, v.z)
            p = p + v * 0.05
            if p.y <= 0.0:
                land = Vec3(p.x, 0.0, p.z)
                pts.append(land)
                if land.dist_xz(pos) > TELEPORT_RANGE:
                    return pts, None
                return pts, land
        return pts, None


@dataclass
class ScriptedMovement:
    """Vehicle / cinematic movement along waypoints. With reduced-motion the rig cuts instead of gliding."""

    waypoints: list[Vec3]
    speed: float = 5.0
    reduced_motion: bool = False
    index: int = 0
    done: bool = False

    def step(self, pos: Vec3, dt: float) -> tuple[Vec3, float]:
        """Returns (new_pos, fade) - fade>0 only for reduced-motion cuts."""
        if self.done or self.index >= len(self.waypoints):
            self.done = True
            return pos, 0.0
        tgt = self.waypoints[self.index]
        if self.reduced_motion:
            self.index = len(self.waypoints)
            self.done = True
            return self.waypoints[-1], 1.0
        d = tgt - pos
        dist = d.length_xz()
        if dist <= self.speed * dt:
            self.index += 1
            return tgt, 0.0
        return pos + d.flat().normalized() * (self.speed * dt), 0.0
