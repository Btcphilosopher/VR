"""Headset-agnostic input vocabulary. Gameplay never sees a vendor SDK - only these types."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from ..core.types import Hand
from ..physics.vec import Vec3, forward_from_angles, right_from_yaw

__all__ = ["Hand", "InputAction", "Pose", "ControllerState", "InputFrame"]


class InputAction(str, Enum):
    LEFT_HAND = "left_hand"
    RIGHT_HAND = "right_hand"
    TRIGGER = "trigger"
    GRIP = "grip"
    THUMBSTICK = "thumbstick"
    THUMBPAD = "thumbpad"
    A_BUTTON = "a_button"
    B_BUTTON = "b_button"
    MENU = "menu"
    HEAD_POSE = "head_pose"
    CONTROLLER_POSE = "controller_pose"


@dataclass(frozen=True, slots=True)
class Pose:
    """Position (tracking space, metres) + orientation as yaw/pitch/roll (radians)."""

    position: Vec3 = Vec3()
    yaw: float = 0.0
    pitch: float = 0.0
    roll: float = 0.0

    def forward(self) -> Vec3:
        return forward_from_angles(self.yaw, self.pitch)

    def right(self) -> Vec3:
        r = right_from_yaw(self.yaw)
        return r

    def up(self) -> Vec3:
        f, r = self.forward(), self.right()
        up = f.cross(r).normalized()
        # apply roll about the forward axis
        c, s = math.cos(self.roll), math.sin(self.roll)
        return (up * c + r * s).normalized()


@dataclass(slots=True)
class ControllerState:
    pose: Pose = field(default_factory=Pose)
    trigger: float = 0.0
    grip: float = 0.0
    stick: tuple[float, float] = (0.0, 0.0)  # x right, y forward
    stick_click: bool = False
    pad: tuple[float, float] = (0.0, 0.0)
    pad_click: bool = False
    a: bool = False
    b: bool = False
    menu: bool = False
    tracked: bool = True


@dataclass(slots=True)
class InputFrame:
    t: float
    head: Pose
    left: ControllerState
    right: ControllerState

    def controller(self, hand: Hand) -> ControllerState:
        return self.left if hand is Hand.LEFT else self.right
