"""Maps gameplay events to haptic patterns and drives the mixer + output device.

Event payload conventions (see game.events):
  weapon_fire / dry_fire / magazine_* / chamber : hand, support_hand, profile (fire only)
  hit_confirm / kill_confirm                    : hands (list[Hand]) - the hands holding the weapon
  player_damaged                                : amount, angle (radians relative to view, + = right)
  explosion                                     : pos, distance_to_player
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field

from ..core.config import HapticsCfg
from ..core.types import Hand
from ..game import events as ev
from ..game.events import Event, EventBus
from .devices import HapticDevice, NullHapticDevice
from .engine import HapticEngine, HapticSample
from .patterns import damage_pattern, explosion_pattern, get_pattern, weapon_fire

HEARTBEAT_START = 0.32  # health fraction below which the heartbeat loop runs


@dataclass
class HapticDirector:
    bus: EventBus
    cfg: HapticsCfg
    device: HapticDevice = field(default_factory=NullHapticDevice)
    dominant: Hand = Hand.RIGHT
    engine: HapticEngine = field(init=False)
    _health_fn: Callable[[], float] | None = None

    def __post_init__(self) -> None:
        self.engine = HapticEngine(self.cfg)
        b = self.bus
        b.subscribe(ev.WEAPON_FIRE, self._on_fire)
        b.subscribe(ev.WEAPON_DRY, lambda e: self._hand_pulse("dry_fire", e))
        b.subscribe(ev.MAGAZINE_DROP, lambda e: self._hand_pulse("magazine_drop", e, support_echo=0.0))
        b.subscribe(ev.MAGAZINE_INSERT, self._on_insert)
        b.subscribe(ev.WEAPON_CHAMBER, lambda e: self._hand_pulse("weapon_chamber", e, support_echo=0.5))
        b.subscribe(ev.WEAPON_RELOAD_COMPLETE, lambda e: self._hand_pulse("reload_ready", e))
        b.subscribe(ev.WEAPON_PICKUP, lambda e: self._hand_pulse("grab", e))
        b.subscribe(ev.WEAPON_DRAW, lambda e: self._hand_pulse("grab", e))
        b.subscribe(ev.WEAPON_HOLSTER, lambda e: self._hand_pulse("holster", e))
        b.subscribe(ev.WEAPON_SWITCH, lambda e: self._hand_pulse("grab", e))
        b.subscribe(ev.HIT_CONFIRM, lambda e: self._hands_pulse("hit_confirm", e, 1.0))
        b.subscribe(ev.KILL_CONFIRM, lambda e: self._hands_pulse("kill_confirm", e, 1.0))
        b.subscribe(ev.PLAYER_DAMAGED, self._on_damaged)
        b.subscribe(ev.EXPLOSION, self._on_explosion)
        b.subscribe(ev.OBJECTIVE_COMPLETE, lambda e: self._both("objective_complete", 1.0))
        b.subscribe(ev.POWER_FAIL, lambda e: self._both("power_fail", 1.0))
        b.subscribe(ev.UI_HOVER, lambda e: self._ui_pulse("ui_hover", e))
        b.subscribe(ev.UI_SELECT, lambda e: self._ui_pulse("ui_select", e))
        b.subscribe(ev.DASH, lambda e: self._both("dash", 1.0))
        b.subscribe(ev.TELEPORT, lambda e: self._both("teleport", 1.0))
        b.subscribe(ev.INTERACTION_PROGRESS, self._on_interaction)
        b.subscribe(
            ev.MR_EVENT,
            lambda e: self._both("wall_breach", 1.0) if e.data.get("kind") == "wall_breach" else None,
        )

    # ---- wiring ---------------------------------------------------------
    def attach_health(self, fn: Callable[[], float]) -> None:
        self._health_fn = fn

    def _hands(self, e: Event) -> tuple[Hand, Hand | None]:
        hand = e.data.get("hand") or self.dominant
        sup = e.data.get("support_hand")
        return Hand(hand), (Hand(sup) if sup else None)

    def _ui_hand(self, e: Event) -> Hand:
        return Hand(e.data.get("hand") or self.dominant)

    def _ui_pulse(self, name: str, e: Event) -> None:
        self.engine.trigger(get_pattern(name), self._ui_hand(e))

    def _hand_pulse(self, name: str, e: Event, support_echo: float = 0.0) -> None:
        hand, sup = self._hands(e)
        p = get_pattern(name)
        self.engine.trigger(p, hand)
        if sup is not None and support_echo > 0:
            self.engine.trigger(p, sup, support_echo)

    def _hands_pulse(self, name: str, e: Event, scale: float) -> None:
        p = get_pattern(name)
        hands = e.data.get("hands") or [self.dominant]
        for h in hands:
            self.engine.trigger(p, Hand(h), scale)

    def _both(self, name: str, scale: float) -> None:
        p = get_pattern(name)
        for h in (Hand.LEFT, Hand.RIGHT):
            self.engine.trigger(p, h, scale)

    # ---- handlers -------------------------------------------------------
    def _on_fire(self, e: Event) -> None:
        profile = e.data["profile"]
        hand, sup = self._hands(e)
        pat = weapon_fire(profile)
        scale = 0.6 if self.cfg.reduced else 1.0
        self.engine.trigger(pat, hand, scale)
        if sup is not None:
            self.engine.trigger(pat, sup, profile.support_scale * scale)

    def _on_insert(self, e: Event) -> None:
        hand, sup = self._hands(e)
        p = get_pattern("magazine_insert")
        # the magazine is seated by the support hand when two-handed; weapon hand feels an echo
        self.engine.trigger(p, sup or hand)
        if sup is not None:
            self.engine.trigger(p, hand, 0.5)

    def _on_damaged(self, e: Event) -> None:
        amount = float(e.data.get("amount", 10.0))
        angle = float(e.data.get("angle", 0.0))
        amp = min(1.0, 0.25 + amount / 40.0)
        import math

        right_w = 0.5 + 0.5 * math.sin(angle)
        pat = damage_pattern(amp)
        self.engine.trigger(pat, Hand.RIGHT, 0.35 + 0.65 * right_w)
        self.engine.trigger(pat, Hand.LEFT, 0.35 + 0.65 * (1.0 - right_w))

    def _on_explosion(self, e: Event) -> None:
        d = float(e.data.get("distance_to_player", 99.0))
        if d > 30.0:
            return
        amp = 1.0 / (1.0 + d / 6.0)
        pat = explosion_pattern(amp)
        for h in (Hand.LEFT, Hand.RIGHT):
            self.engine.trigger(pat, h)

    def _on_interaction(self, e: Event) -> None:
        self.engine.trigger(get_pattern("interaction_tick"), self.dominant)

    # ---- per tick -------------------------------------------------------
    def trigger_named(self, name: str, hand: Hand | None = None, scale: float = 1.0) -> bool:
        """Dev-console / test entry: fire a library pattern by name."""
        p = get_pattern(name)
        if hand is None:
            return any([self.engine.trigger(p, h, scale) for h in (Hand.LEFT, Hand.RIGHT)])
        return self.engine.trigger(p, hand, scale)

    def update(self, dt: float) -> dict[Hand, HapticSample]:
        if self._health_fn is not None:
            hf = self._health_fn()
            if 0.0 < hf < HEARTBEAT_START:
                s = 0.25 + 0.55 * (1.0 - hf / HEARTBEAT_START)
                self.engine.start_loop("heartbeat", get_pattern("heartbeat"), Hand.LEFT, s)
            else:
                self.engine.stop_loop("heartbeat")
        samples = self.engine.update(dt)
        for hand, sample in samples.items():
            self.device.apply(hand, sample, dt)
        return samples
