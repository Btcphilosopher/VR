"""Haptic pattern library: amplitude/frequency envelopes authored as keyframes.

Amplitude is normalised 0..1, frequency normalised 0..1 (mapped to 40..320 Hz by `freq_to_hz`).
Patterns are device-agnostic; the engine mixes them and a device backend delivers them.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .profile import HapticProfile

MIN_HZ, MAX_HZ = 40.0, 320.0


def freq_to_hz(f: float) -> float:
    return MIN_HZ + (MAX_HZ - MIN_HZ) * max(0.0, min(1.0, f))


class Group(str, Enum):
    WEAPON = "weapon"
    IMPACT = "impact"
    UI = "ui"
    AMBIENT = "ambient"


@dataclass(frozen=True, slots=True)
class Keyframe:
    t: float
    amp: float
    freq: float


@dataclass(frozen=True, slots=True)
class HapticPattern:
    name: str
    keyframes: tuple[Keyframe, ...]
    group: Group
    priority: int = 5
    loop: bool = False
    min_interval: float = 0.0

    @property
    def duration(self) -> float:
        return self.keyframes[-1].t

    def sample(self, t: float) -> tuple[float, float]:
        """Linear-interpolated (amp, freq) at time t. Returns (0, f) after the end unless looping."""
        kf = self.keyframes
        if self.loop and self.duration > 0:
            t = t % self.duration
        if t < 0 or t >= kf[-1].t:
            return 0.0, kf[-1].freq
        for a, b in zip(kf, kf[1:], strict=False):
            if a.t <= t < b.t:
                span = b.t - a.t
                u = 0.0 if span <= 0 else (t - a.t) / span
                return a.amp + (b.amp - a.amp) * u, a.freq + (b.freq - a.freq) * u
        return 0.0, kf[-1].freq


def _kf(*pts: tuple[float, float, float]) -> tuple[Keyframe, ...]:
    return tuple(Keyframe(*p) for p in pts)


def weapon_fire(profile: HapticProfile, name: str = "weapon_fire") -> HapticPattern:
    k = profile.kick_ms / 1000.0
    tail = profile.tail_ms / 1000.0
    return HapticPattern(
        name,
        _kf(
            (0.0, profile.kick, profile.freq),
            (k, profile.kick * 0.75, profile.freq),
            (k + tail, 0.0, profile.freq * 0.6),
        ),
        Group.WEAPON,
        priority=7,
        min_interval=0.018,
    )


def damage_pattern(amp: float) -> HapticPattern:
    a = max(0.15, min(1.0, amp))
    return HapticPattern(
        "damage_taken",
        _kf((0.0, a, 0.35), (0.12, a * 0.6, 0.3), (0.30, 0.0, 0.25)),
        Group.IMPACT,
        priority=9,
        min_interval=0.08,
    )


def explosion_pattern(amp: float) -> HapticPattern:
    a = max(0.1, min(1.0, amp))
    return HapticPattern(
        "explosion",
        _kf((0.0, a, 0.15), (0.25, a * 0.8, 0.12), (0.9, a * 0.3, 0.1), (1.4, 0.0, 0.1)),
        Group.IMPACT,
        priority=10,
        min_interval=0.2,
    )


# Static library -----------------------------------------------------------------------------
_STATIC: dict[str, HapticPattern] = {}


def _reg(p: HapticPattern) -> None:
    _STATIC[p.name] = p


_reg(HapticPattern("dry_fire", _kf((0.0, 0.28, 0.9), (0.015, 0.0, 0.9)), Group.WEAPON, 4, min_interval=0.1))
_reg(
    HapticPattern(
        "magazine_drop",
        _kf((0.0, 0.55, 0.9), (0.012, 0.0, 0.9), (0.03, 0.35, 0.8), (0.045, 0.0, 0.8)),
        Group.WEAPON,
        6,
    )
)
_reg(HapticPattern("magazine_insert", _kf((0.0, 0.8, 0.25), (0.05, 0.45, 0.25), (0.10, 0.0, 0.25)), Group.WEAPON, 6))
_reg(
    HapticPattern(
        "weapon_chamber",
        _kf((0.0, 0.7, 0.85), (0.02, 0.0, 0.85), (0.07, 0.95, 0.7), (0.11, 0.0, 0.7)),
        Group.WEAPON,
        6,
    )
)
_reg(HapticPattern("reload_ready", _kf((0.0, 0.3, 0.6), (0.04, 0.0, 0.6)), Group.WEAPON, 5))
_reg(HapticPattern("hit_confirm", _kf((0.0, 0.35, 0.95), (0.025, 0.0, 0.95)), Group.IMPACT, 6, min_interval=0.04))
_reg(
    HapticPattern(
        "kill_confirm",
        _kf((0.0, 0.5, 0.9), (0.03, 0.0, 0.9), (0.06, 0.65, 0.9), (0.095, 0.0, 0.9)),
        Group.IMPACT,
        8,
    )
)
_reg(HapticPattern("grab", _kf((0.0, 0.22, 0.7), (0.03, 0.0, 0.7)), Group.UI, 3, min_interval=0.05))
_reg(HapticPattern("holster", _kf((0.0, 0.4, 0.3), (0.06, 0.0, 0.3)), Group.UI, 3))
_reg(HapticPattern("ui_hover", _kf((0.0, 0.15, 0.9), (0.012, 0.0, 0.9)), Group.UI, 1, min_interval=0.06))
_reg(HapticPattern("ui_select", _kf((0.0, 0.32, 0.8), (0.035, 0.0, 0.8)), Group.UI, 2))
_reg(
    HapticPattern(
        "objective_complete",
        _kf(
            (0.0, 0.3, 0.6),
            (0.04, 0.0, 0.6),
            (0.10, 0.45, 0.7),
            (0.14, 0.0, 0.7),
            (0.20, 0.7, 0.8),
            (0.26, 0.0, 0.8),
        ),
        Group.UI,
        6,
    )
)
_reg(HapticPattern("interaction_tick", _kf((0.0, 0.12, 0.6), (0.02, 0.0, 0.6)), Group.UI, 2, min_interval=0.12))
_reg(HapticPattern("dash", _kf((0.0, 0.45, 0.2), (0.12, 0.2, 0.2), (0.22, 0.0, 0.2)), Group.IMPACT, 5))
_reg(HapticPattern("teleport", _kf((0.0, 0.25, 0.5), (0.05, 0.0, 0.5)), Group.UI, 3))
_reg(
    HapticPattern(
        "wall_breach",
        _kf((0.0, 0.95, 0.12), (0.12, 0.7, 0.1), (0.6, 0.25, 0.1), (0.9, 0.0, 0.1)),
        Group.IMPACT,
        9,
    )
)
_reg(HapticPattern("power_fail", _kf((0.0, 0.65, 0.1), (0.6, 0.35, 0.1), (1.6, 0.0, 0.1)), Group.AMBIENT, 4))
_reg(
    HapticPattern(
        "heartbeat",
        _kf(
            (0.0, 0.0, 0.2),
            (0.02, 0.4, 0.2),
            (0.12, 0.0, 0.2),
            (0.22, 0.32, 0.2),
            (0.32, 0.0, 0.2),
            (0.9, 0.0, 0.2),
        ),
        Group.AMBIENT,
        2,
        loop=True,
    )
)


def get_pattern(name: str) -> HapticPattern:
    return _STATIC[name]


def pattern_names() -> list[str]:
    return sorted(_STATIC)
