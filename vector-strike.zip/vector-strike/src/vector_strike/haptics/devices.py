"""Haptic output backends. The game never talks to hardware directly - only to a HapticDevice."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Protocol

from ..core.types import Hand
from .engine import HapticSample

log = logging.getLogger(__name__)


class HapticDevice(Protocol):
    name: str

    def connect(self) -> bool: ...

    def apply(self, hand: Hand, sample: HapticSample, dt: float) -> None: ...

    def stop_all(self) -> None: ...


@dataclass
class NullHapticDevice:
    name: str = "null"

    def connect(self) -> bool:
        return True

    def apply(self, hand: Hand, sample: HapticSample, dt: float) -> None:
        return None

    def stop_all(self) -> None:
        return None


@dataclass
class RecordingHapticDevice:
    """Captures everything sent to 'the controllers' - used by tests and the desktop debug overlay."""

    name: str = "recording"
    log: list[tuple[float, Hand, float, float]] = field(default_factory=list)
    t: float = 0.0
    max_entries: int = 20000

    def connect(self) -> bool:
        return True

    def apply(self, hand: Hand, sample: HapticSample, dt: float) -> None:
        if hand is Hand.RIGHT:
            self.t += dt
        if sample.amp > 0 and len(self.log) < self.max_entries:
            self.log.append((self.t, hand, sample.amp, sample.hz))

    def stop_all(self) -> None:
        return None

    def peak(self, hand: Hand) -> float:
        return max((a for _, h, a, _ in self.log if h is hand), default=0.0)


class GamepadRumbleDevice:
    """Desktop fallback: maps hands onto a gamepad's two rumble motors (left=low freq, right=high)."""

    name = "gamepad"

    def __init__(self) -> None:
        self._joy: Any = None
        self._amps = {Hand.LEFT: 0.0, Hand.RIGHT: 0.0}

    def connect(self) -> bool:
        try:
            import pygame

            pygame.joystick.init()
            if pygame.joystick.get_count() == 0:
                return False
            self._joy = pygame.joystick.Joystick(0)
            self._joy.init()
            return True
        except Exception as exc:  # pragma: no cover - hardware dependent
            log.info("gamepad rumble unavailable: %s", exc)
            return False

    def apply(self, hand: Hand, sample: HapticSample, dt: float) -> None:
        self._amps[hand] = sample.amp
        if self._joy is None or hand is not Hand.RIGHT:  # pragma: no cover - hardware dependent
            return
        try:  # pragma: no cover
            self._joy.rumble(self._amps[Hand.LEFT], self._amps[Hand.RIGHT], int(max(dt, 0.016) * 1500))
        except Exception:
            self._joy = None

    def stop_all(self) -> None:  # pragma: no cover - hardware dependent
        if self._joy is not None:
            self._joy.stop_rumble()


class OpenXRHapticDevice:
    """OpenXR vibration output via pyopenxr.

    NOTE: this adapter is a thin, *hardware-untested* integration point. The session, action set and
    haptic action handles must be supplied by the OpenXR runtime layer (see vr.openxr_backend).
    `connect()` returns False when pyopenxr or a session is unavailable so callers fall back cleanly.
    """

    name = "openxr"

    def __init__(self, session: object | None = None, haptic_actions: dict[Hand, object] | None = None):
        self._session = session
        self._actions = haptic_actions or {}
        self._xr = None

    def connect(self) -> bool:
        try:
            import xr

            self._xr = xr
        except Exception:
            return False
        return self._session is not None and bool(self._actions)

    def apply(self, hand: Hand, sample: HapticSample, dt: float) -> None:  # pragma: no cover
        xr = self._xr
        action = self._actions.get(hand)
        if xr is None or action is None:
            return
        if sample.amp <= 0.0:
            return
        vib = xr.HapticVibration(
            amplitude=float(sample.amp), frequency=float(sample.hz), duration=int(max(dt, 0.011) * 1.5e9)
        )
        xr.apply_haptic_feedback(
            self._session,
            action,
            xr.HapticActionInfo(action=action),
            vib,
        )

    def stop_all(self) -> None:  # pragma: no cover
        return None
