"""Per-weapon haptic tuning (kept in its own module so weapon specs can import it cheaply)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class HapticProfile:
    """How a weapon feels in the hand.

    kick:        peak normalised amplitude of the recoil impulse (0..1)
    kick_ms:     hold time at peak before decay starts
    tail_ms:     decay time after the kick
    freq:        normalised carrier frequency (0 = deep thump, 1 = sharp buzz)
    support_scale: fraction of the impulse the support hand receives when two-handed
    """

    kick: float = 0.7
    kick_ms: float = 14.0
    tail_ms: float = 60.0
    freq: float = 0.45
    support_scale: float = 0.45
