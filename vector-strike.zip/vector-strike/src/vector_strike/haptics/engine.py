"""Per-hand haptic mixer.

Voices (pattern instances) are mixed per hand with priority ducking and soft clipping, then scaled
by the user's comfort settings. The result is one (amplitude, frequency) sample per hand per tick,
which a `HapticDevice` backend turns into controller vibration.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core.config import HapticsCfg
from ..core.types import Hand
from .patterns import Group, HapticPattern, freq_to_hz

MAX_VOICES_PER_HAND = 8
REDUCED_CAP = 0.5


@dataclass(frozen=True, slots=True)
class HapticSample:
    amp: float = 0.0
    freq: float = 0.0  # normalised 0..1

    @property
    def hz(self) -> float:
        return freq_to_hz(self.freq)


@dataclass(slots=True)
class Voice:
    pattern: HapticPattern
    hand: Hand
    start: float
    scale: float
    key: str | None = None  # looping voices are addressed by key


def _soft_clip(x: float) -> float:
    if x <= 0.8:
        return x
    return 0.8 + 0.2 * math.tanh((x - 0.8) / 0.2)


@dataclass
class HapticEngine:
    cfg: HapticsCfg
    t: float = 0.0
    voices: dict[Hand, list[Voice]] = field(default_factory=lambda: {Hand.LEFT: [], Hand.RIGHT: []})
    last_samples: dict[Hand, HapticSample] = field(
        default_factory=lambda: {Hand.LEFT: HapticSample(), Hand.RIGHT: HapticSample()}
    )
    _last_trigger: dict[tuple[str, Hand], float] = field(default_factory=dict)
    dropped: int = 0

    # ---- gating ---------------------------------------------------------
    def _group_enabled(self, g: Group) -> bool:
        c = self.cfg
        if not c.enabled:
            return False
        if g is Group.WEAPON:
            return c.weapons
        if g is Group.IMPACT:
            return c.impacts
        if g is Group.UI:
            return c.ui
        return c.ambient and not c.reduced

    def _hand_enabled(self, hand: Hand) -> bool:
        return self.cfg.left_hand if hand is Hand.LEFT else self.cfg.right_hand

    # ---- triggering -----------------------------------------------------
    def trigger(self, pattern: HapticPattern, hand: Hand, scale: float = 1.0) -> bool:
        """Start a one-shot voice. Returns False if gated, rate-limited, or out-prioritised."""
        if scale <= 0.0 or not self._group_enabled(pattern.group) or not self._hand_enabled(hand):
            return False
        key = (pattern.name, hand)
        last = self._last_trigger.get(key)
        if last is not None and self.t - last < pattern.min_interval:
            return False
        lst = self.voices[hand]
        if len(lst) >= MAX_VOICES_PER_HAND:
            victim = min(lst, key=lambda v: (v.pattern.priority, -v.start))
            if victim.pattern.priority > pattern.priority:
                self.dropped += 1
                return False
            lst.remove(victim)
            self.dropped += 1
        self._last_trigger[key] = self.t
        lst.append(Voice(pattern, hand, self.t, scale))
        return True

    def start_loop(self, key: str, pattern: HapticPattern, hand: Hand, scale: float) -> None:
        if not self._group_enabled(pattern.group) or not self._hand_enabled(hand):
            return
        for v in self.voices[hand]:
            if v.key == key:
                v.scale = scale
                return
        self.voices[hand].append(Voice(pattern, hand, self.t, scale, key))

    def stop_loop(self, key: str) -> None:
        for hand in self.voices:
            self.voices[hand] = [v for v in self.voices[hand] if v.key != key]

    def clear(self) -> None:
        for hand in self.voices:
            self.voices[hand].clear()

    # ---- mixing ---------------------------------------------------------
    def update(self, dt: float) -> dict[Hand, HapticSample]:
        out: dict[Hand, HapticSample] = {}
        for hand, lst in self.voices.items():
            live: list[Voice] = []
            contribs: list[tuple[float, float, int]] = []
            for v in lst:
                age = self.t - v.start
                if not v.pattern.loop and age >= v.pattern.duration:
                    continue
                live.append(v)
                a, f = v.pattern.sample(age)
                contribs.append((a * v.scale, f, v.pattern.priority))
            self.voices[hand] = live
            out[hand] = self._mix(hand, contribs)
        self.last_samples = out
        self.t += dt  # sample first, then advance: a voice triggered this tick is heard at age 0
        return out

    def _mix(self, hand: Hand, contribs: list[tuple[float, float, int]]) -> HapticSample:
        if not contribs or not self._hand_enabled(hand) or not self.cfg.enabled:
            return HapticSample()
        top = max((p for a, _, p in contribs if a > 0.05), default=0)
        total = 0.0
        fsum = 0.0
        for a, f, p in contribs:
            if p < top - 2:
                a *= 0.5  # priority ducking
            total += a
            fsum += a * f
        if total <= 1e-4:
            return HapticSample()
        amp = _soft_clip(total) * self.cfg.intensity
        if self.cfg.reduced:
            amp = min(amp, REDUCED_CAP)
        return HapticSample(amp=min(1.0, amp), freq=fsum / total)
