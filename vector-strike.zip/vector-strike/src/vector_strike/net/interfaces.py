"""Networking preparation: interfaces only (no multiplayer yet). A future 2-4 player co-op VR mode implements
these over UDP/WebRTC; `LoopbackSession` is a single-process reference implementation used by tests."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class NetRole(str, Enum):
    HOST = "host"
    CLIENT = "client"
    OFFLINE = "offline"


@dataclass(frozen=True, slots=True)
class PlayerSnapshot:
    player_id: int
    tick: int
    head: tuple[float, float, float, float, float, float]  # pos xyz + yaw/pitch/roll
    left_hand: tuple[float, float, float, float, float, float]
    right_hand: tuple[float, float, float, float, float, float]
    health: float
    weapon_id: str


@dataclass(frozen=True, slots=True)
class EntitySnapshot:
    entity_id: int
    kind: str
    tick: int
    pos: tuple[float, float, float]
    yaw: float
    state: str
    health: float


@dataclass(frozen=True, slots=True)
class MissionSnapshot:
    tick: int
    mission_id: str
    phase: str
    objectives: dict[str, str]
    timers: dict[str, float]


class NetworkSession(ABC):
    """Connection lifecycle + message pump."""

    role: NetRole = NetRole.OFFLINE
    max_players: int = 4

    @abstractmethod
    def host(self, mission_id: str, max_players: int = 4) -> None: ...

    @abstractmethod
    def join(self, address: str) -> None: ...

    @abstractmethod
    def leave(self) -> None: ...

    @abstractmethod
    def send(self, channel: str, payload: dict[str, Any]) -> None: ...

    @abstractmethod
    def poll(self) -> list[tuple[str, dict[str, Any]]]: ...

    @property
    @abstractmethod
    def local_player_id(self) -> int: ...


class PlayerReplication(ABC):
    @abstractmethod
    def publish_local(self, snap: PlayerSnapshot) -> None: ...

    @abstractmethod
    def remote_players(self) -> dict[int, PlayerSnapshot]: ...


class EntityReplication(ABC):
    @abstractmethod
    def publish(self, snaps: list[EntitySnapshot]) -> None: ...

    @abstractmethod
    def latest(self) -> dict[int, EntitySnapshot]: ...


class MissionReplication(ABC):
    @abstractmethod
    def publish(self, snap: MissionSnapshot) -> None: ...

    @abstractmethod
    def latest(self) -> MissionSnapshot | None: ...


@dataclass
class LoopbackSession(NetworkSession):
    """In-memory session: everything sent is received by `poll`. Reference for protocol tests."""

    role: NetRole = NetRole.OFFLINE
    _queue: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    _connected: bool = False
    _mission: str = ""

    def host(self, mission_id: str, max_players: int = 4) -> None:
        self.role, self._connected, self._mission, self.max_players = (
            NetRole.HOST,
            True,
            mission_id,
            max_players,
        )

    def join(self, address: str) -> None:
        self.role, self._connected = NetRole.CLIENT, True

    def leave(self) -> None:
        self.role, self._connected = NetRole.OFFLINE, False
        self._queue.clear()

    def send(self, channel: str, payload: dict[str, Any]) -> None:
        if self._connected:
            self._queue.append((channel, dict(payload)))

    def poll(self) -> list[tuple[str, dict[str, Any]]]:
        out, self._queue = self._queue, []
        return out

    @property
    def local_player_id(self) -> int:
        return 0


class LoopbackReplication(PlayerReplication, EntityReplication, MissionReplication):
    def __init__(self) -> None:
        self._players: dict[int, PlayerSnapshot] = {}
        self._entities: dict[int, EntitySnapshot] = {}
        self._mission: MissionSnapshot | None = None

    def publish_local(self, snap: PlayerSnapshot) -> None:
        self._players[snap.player_id] = snap

    def remote_players(self) -> dict[int, PlayerSnapshot]:
        return dict(self._players)

    def publish(self, snaps):
        if isinstance(snaps, MissionSnapshot):
            self._mission = snaps
        else:
            for s in snaps:
                self._entities[s.entity_id] = s

    def latest(self):
        return self._mission if self._mission is not None and not self._entities else dict(self._entities)


Hook = Callable[[Any], None]
