"""Minimal immutable 3-vector math. Axes: +x right, +y up, +z forward (yaw 0)."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Vec3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0

    def __add__(self, o: Vec3) -> Vec3:
        return Vec3(self.x + o.x, self.y + o.y, self.z + o.z)

    def __sub__(self, o: Vec3) -> Vec3:
        return Vec3(self.x - o.x, self.y - o.y, self.z - o.z)

    def __mul__(self, k: float) -> Vec3:
        return Vec3(self.x * k, self.y * k, self.z * k)

    __rmul__ = __mul__

    def __truediv__(self, k: float) -> Vec3:
        return Vec3(self.x / k, self.y / k, self.z / k)

    def __neg__(self) -> Vec3:
        return Vec3(-self.x, -self.y, -self.z)

    def dot(self, o: Vec3) -> float:
        return self.x * o.x + self.y * o.y + self.z * o.z

    def cross(self, o: Vec3) -> Vec3:
        return Vec3(
            self.y * o.z - self.z * o.y,
            self.z * o.x - self.x * o.z,
            self.x * o.y - self.y * o.x,
        )

    def length(self) -> float:
        return math.sqrt(self.x * self.x + self.y * self.y + self.z * self.z)

    def length_xz(self) -> float:
        return math.hypot(self.x, self.z)

    def normalized(self) -> Vec3:
        n = self.length()
        return Vec3(0.0, 0.0, 0.0) if n < 1e-9 else self / n

    def dist(self, o: Vec3) -> float:
        return (self - o).length()

    def dist_xz(self, o: Vec3) -> float:
        return math.hypot(self.x - o.x, self.z - o.z)

    def lerp(self, o: Vec3, t: float) -> Vec3:
        return self + (o - self) * t

    def flat(self) -> Vec3:
        return Vec3(self.x, 0.0, self.z)

    def with_y(self, y: float) -> Vec3:
        return Vec3(self.x, y, self.z)

    def as_tuple(self) -> tuple[float, float, float]:
        return (self.x, self.y, self.z)


ZERO = Vec3(0.0, 0.0, 0.0)
UP = Vec3(0.0, 1.0, 0.0)


def clamp(v: float, lo: float, hi: float) -> float:
    return lo if v < lo else hi if v > hi else v


def wrap_angle(a: float) -> float:
    """Wrap radians to (-pi, pi]."""
    while a > math.pi:
        a -= 2 * math.pi
    while a <= -math.pi:
        a += 2 * math.pi
    return a


def forward_from_angles(yaw: float, pitch: float = 0.0) -> Vec3:
    cp = math.cos(pitch)
    return Vec3(math.sin(yaw) * cp, math.sin(pitch), math.cos(yaw) * cp)


def right_from_yaw(yaw: float) -> Vec3:
    return Vec3(math.cos(yaw), 0.0, -math.sin(yaw))


def yaw_to(src: Vec3, dst: Vec3) -> float:
    return math.atan2(dst.x - src.x, dst.z - src.z)


def angles_from_direction(d: Vec3) -> tuple[float, float]:
    d = d.normalized()
    return math.atan2(d.x, d.z), math.asin(clamp(d.y, -1.0, 1.0))
