"""Static collision world with a uniform spatial hash (broadphase), raycasts and character movement."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from .shapes import AABB, ray_aabb
from .vec import Vec3


class Material(Enum):
    CONCRETE = "concrete"
    STEEL = "steel"
    GLASS = "glass"
    WOOD = "wood"
    PLASTER = "plaster"
    FURNITURE = "furniture"
    CRATE = "crate"


# Penetration "resistance": energy a round must spend to pass through one collider.
RESISTANCE: dict[Material, float] = {
    Material.CONCRETE: 99.0,
    Material.STEEL: 6.0,
    Material.GLASS: 0.6,
    Material.WOOD: 1.5,
    Material.PLASTER: 2.5,
    Material.FURNITURE: 1.0,
    Material.CRATE: 3.0,
}


class ColliderKind(Enum):
    WALL = "wall"
    COVER = "cover"
    PROP = "prop"
    DOOR = "door"
    MR_REAL = "mr_real"


@dataclass(slots=True)
class Collider:
    id: int
    aabb: AABB
    material: Material = Material.CONCRETE
    kind: ColliderKind = ColliderKind.WALL
    blocks_move: bool = True
    blocks_los: bool = True
    visible: bool = True
    open: bool = False
    tag: str = ""
    color_key: str = ""

    @property
    def active(self) -> bool:
        return not self.open

    @property
    def resistance(self) -> float:
        return RESISTANCE[self.material]


@dataclass(slots=True)
class RayHit:
    t: float
    point: Vec3
    collider: Collider


@dataclass(slots=True)
class NoiseEvent:
    pos: Vec3
    radius: float
    t: float
    source: str = ""


CELL = 4.0


@dataclass
class World:
    """Collision world. Keep mutation (door open/close) going through methods so the hash stays valid."""

    colliders: dict[int, Collider] = field(default_factory=dict)
    _grid: dict[tuple[int, int], list[int]] = field(default_factory=dict)
    _next_id: int = 1
    version: int = 0  # bumped when door state changes (nav / lighting caches key off this)

    # ---- construction -------------------------------------------------
    def add(
        self,
        aabb: AABB,
        material: Material = Material.CONCRETE,
        kind: ColliderKind = ColliderKind.WALL,
        *,
        blocks_move: bool = True,
        blocks_los: bool = True,
        visible: bool = True,
        tag: str = "",
        color_key: str = "",
    ) -> Collider:
        c = Collider(self._next_id, aabb, material, kind, blocks_move, blocks_los, visible, False, tag, color_key)
        self._next_id += 1
        self.colliders[c.id] = c
        for key in self._cells_for_box(aabb):
            self._grid.setdefault(key, []).append(c.id)
        self.version += 1
        return c

    def set_open(self, collider_id: int, is_open: bool) -> None:
        c = self.colliders[collider_id]
        if c.open != is_open:
            c.open = is_open
            self.version += 1

    def by_tag(self, tag: str) -> list[Collider]:
        return [c for c in self.colliders.values() if c.tag == tag]

    # ---- spatial hash --------------------------------------------------
    @staticmethod
    def _cell(v: float) -> int:
        return math.floor(v / CELL)

    def _cells_for_box(self, b: AABB) -> list[tuple[int, int]]:
        return [
            (cx, cz)
            for cx in range(self._cell(b.min.x), self._cell(b.max.x) + 1)
            for cz in range(self._cell(b.min.z), self._cell(b.max.z) + 1)
        ]

    def query_aabb(self, box: AABB) -> list[Collider]:
        seen: set[int] = set()
        out: list[Collider] = []
        for key in self._cells_for_box(box):
            for cid in self._grid.get(key, ()):
                if cid not in seen:
                    seen.add(cid)
                    c = self.colliders[cid]
                    if c.aabb.intersects(box):
                        out.append(c)
        return out

    def _cells_along(self, a: Vec3, b: Vec3) -> list[tuple[int, int]]:
        """Amanatides-Woo grid traversal in the XZ plane."""
        cx, cz = self._cell(a.x), self._cell(a.z)
        ex, ez = self._cell(b.x), self._cell(b.z)
        cells = [(cx, cz)]
        dx, dz = b.x - a.x, b.z - a.z
        step_x = 1 if dx > 0 else -1
        step_z = 1 if dz > 0 else -1
        t_dx = abs(CELL / dx) if dx != 0 else math.inf
        t_dz = abs(CELL / dz) if dz != 0 else math.inf
        nx = (cx + (1 if dx > 0 else 0)) * CELL
        nz = (cz + (1 if dz > 0 else 0)) * CELL
        t_mx = (nx - a.x) / dx if dx != 0 else math.inf
        t_mz = (nz - a.z) / dz if dz != 0 else math.inf
        guard = abs(ex - cx) + abs(ez - cz) + 2
        while (cx, cz) != (ex, ez) and guard > 0:
            guard -= 1
            if t_mx < t_mz:
                cx += step_x
                t_mx += t_dx
            else:
                cz += step_z
                t_mz += t_dz
            cells.append((cx, cz))
        return cells

    # ---- raycasts ------------------------------------------------------
    def raycast_all(
        self,
        origin: Vec3,
        direction: Vec3,
        max_dist: float,
        *,
        los_only: bool = False,
        ignore_ids: frozenset[int] = frozenset(),
    ) -> list[RayHit]:
        d = direction.normalized()
        end = origin + d * max_dist
        seen: set[int] = set()
        hits: list[RayHit] = []
        for key in self._cells_along(origin, end):
            for cid in self._grid.get(key, ()):
                if cid in seen or cid in ignore_ids:
                    continue
                seen.add(cid)
                c = self.colliders[cid]
                if c.open or not (c.blocks_los if los_only else True):
                    continue
                if not los_only and not (c.blocks_move or c.blocks_los):
                    continue
                t = ray_aabb(origin, d, c.aabb, max_dist)
                if t is not None:
                    hits.append(RayHit(t, origin + d * t, c))
        hits.sort(key=lambda h: h.t)
        return hits

    def raycast(
        self,
        origin: Vec3,
        direction: Vec3,
        max_dist: float,
        *,
        los_only: bool = False,
        ignore_ids: frozenset[int] = frozenset(),
    ) -> RayHit | None:
        hits = self.raycast_all(origin, direction, max_dist, los_only=los_only, ignore_ids=ignore_ids)
        return hits[0] if hits else None

    def line_of_sight(self, a: Vec3, b: Vec3) -> bool:
        d = b - a
        dist = d.length()
        if dist < 1e-6:
            return True
        return self.raycast(a, d, dist - 1e-3, los_only=True) is None

    # ---- character movement -------------------------------------------
    def _blocked(self, box: AABB) -> bool:
        return any(c.blocks_move and not c.open for c in self.query_aabb(box))

    def move_and_collide(self, pos: Vec3, delta: Vec3, radius: float, height: float) -> tuple[Vec3, bool]:
        """Axis-separated sweep (slides along walls). Floor is y=0. Returns (new_pos, grounded)."""
        p = pos
        for axis in ("x", "z"):
            step = delta.x if axis == "x" else delta.z
            if step == 0.0:
                continue
            cand = Vec3(p.x + step, p.y, p.z) if axis == "x" else Vec3(p.x, p.y, p.z + step)
            box = AABB(
                Vec3(cand.x - radius, cand.y + 0.05, cand.z - radius),
                Vec3(cand.x + radius, cand.y + height, cand.z + radius),
            )
            if not self._blocked(box):
                p = cand
        ny = p.y + delta.y
        grounded = False
        if ny <= 0.0:
            ny, grounded = 0.0, True
        return Vec3(p.x, ny, p.z), grounded
