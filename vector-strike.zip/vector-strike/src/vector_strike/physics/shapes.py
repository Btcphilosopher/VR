"""Axis-aligned collision primitives and ray tests."""

from __future__ import annotations

from dataclasses import dataclass

from .vec import Vec3


@dataclass(frozen=True, slots=True)
class AABB:
    min: Vec3
    max: Vec3

    @staticmethod
    def from_center(center: Vec3, size: Vec3) -> AABB:
        h = size * 0.5
        return AABB(center - h, center + h)

    @staticmethod
    def from_base(base: Vec3, size_xz: tuple[float, float], height: float) -> AABB:
        return AABB(
            Vec3(base.x - size_xz[0] / 2, base.y, base.z - size_xz[1] / 2),
            Vec3(base.x + size_xz[0] / 2, base.y + height, base.z + size_xz[1] / 2),
        )

    @property
    def center(self) -> Vec3:
        return (self.min + self.max) * 0.5

    @property
    def size(self) -> Vec3:
        return self.max - self.min

    def contains(self, p: Vec3) -> bool:
        return self.min.x <= p.x <= self.max.x and self.min.y <= p.y <= self.max.y and self.min.z <= p.z <= self.max.z

    def intersects(self, o: AABB) -> bool:
        return (
            self.min.x < o.max.x
            and self.max.x > o.min.x
            and self.min.y < o.max.y
            and self.max.y > o.min.y
            and self.min.z < o.max.z
            and self.max.z > o.min.z
        )

    def expanded(self, r: float) -> AABB:
        d = Vec3(r, r, r)
        return AABB(self.min - d, self.max + d)

    def translated(self, d: Vec3) -> AABB:
        return AABB(self.min + d, self.max + d)


@dataclass(frozen=True, slots=True)
class Hitbox:
    """Named damage volume with a damage multiplier."""

    name: str
    box: AABB
    multiplier: float = 1.0


def ray_aabb(origin: Vec3, direction: Vec3, box: AABB, max_t: float = 1e9) -> float | None:
    """Slab test. Returns entry distance along `direction` (unit) or None."""
    tmin, tmax = 0.0, max_t
    for o, d, lo, hi in (
        (origin.x, direction.x, box.min.x, box.max.x),
        (origin.y, direction.y, box.min.y, box.max.y),
        (origin.z, direction.z, box.min.z, box.max.z),
    ):
        if abs(d) < 1e-12:
            if o < lo or o > hi:
                return None
            continue
        inv = 1.0 / d
        t1, t2 = (lo - o) * inv, (hi - o) * inv
        if t1 > t2:
            t1, t2 = t2, t1
        if t1 > tmin:
            tmin = t1
        if t2 < tmax:
            tmax = t2
        if tmin > tmax:
            return None
    return tmin
