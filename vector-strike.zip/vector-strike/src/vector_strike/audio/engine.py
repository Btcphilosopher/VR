"""Audio architecture: event -> sound mapping, procedural synthesis, spatial (pan/attenuation) abstraction.

Backends: NullAudio (silent), RecordingAudio (tests), PygameAudio (stereo mixer, pooled channels).
Sounds are synthesised from numpy so the prototype ships no binary audio assets; real assets can replace
the SoundBank entries by id without touching gameplay."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Protocol

import numpy as np

from ..game import events as ev
from ..game.events import Event, EventBus
from ..physics.vec import Vec3, right_from_yaw

SAMPLE_RATE = 22050

# canonical event -> sound id (spec: weapon_fire weapon_reload magazine_insert footstep impact enemy_alert
# objective_complete mission_start mission_complete)
EVENT_SOUNDS: dict[str, str] = {
    ev.WEAPON_FIRE: "weapon_fire",
    ev.ENEMY_FIRE: "enemy_fire",
    ev.WEAPON_DRY: "dry_fire",
    ev.WEAPON_RELOAD_START: "weapon_reload",
    ev.MAGAZINE_DROP: "magazine_drop",
    ev.MAGAZINE_INSERT: "magazine_insert",
    ev.WEAPON_CHAMBER: "chamber",
    ev.FOOTSTEP: "footstep",
    ev.IMPACT: "impact",
    ev.ENEMY_ALERT: "enemy_alert",
    ev.OBJECTIVE_COMPLETE: "objective_complete",
    ev.MISSION_START: "mission_start",
    ev.MISSION_COMPLETE: "mission_complete",
    ev.MISSION_FAILED: "mission_failed",
    ev.EXPLOSION: "explosion",
    ev.HIT_CONFIRM: "hit_tick",
    ev.KILL_CONFIRM: "kill_tick",
    ev.PLAYER_DAMAGED: "damage",
    ev.POWER_FAIL: "power_fail",
    ev.DOOR: "door",
    ev.UI_HOVER: "ui_hover",
    ev.UI_SELECT: "ui_select",
    ev.WAVE_START: "wave_start",
    ev.WEAPON_SWITCH: "switch",
    ev.WEAPON_PICKUP: "pickup",
    ev.MR_EVENT: "mr_event",
}

LISTENER_SOUNDS = {
    "hit_tick",
    "kill_tick",
    "damage",
    "ui_hover",
    "ui_select",
    "objective_complete",
    "mission_start",
    "mission_complete",
    "mission_failed",
    "power_fail",
    "wave_start",
    "weapon_reload",
    "dry_fire",
    "magazine_drop",
    "magazine_insert",
    "chamber",
    "switch",
    "pickup",
    "mr_event",
}


def _env(n: int, attack: float, decay: float) -> np.ndarray:
    t = np.arange(n) / SAMPLE_RATE
    return np.minimum(t / max(attack, 1e-4), 1.0) * np.exp(-t / decay)


def synth(sound_id: str) -> np.ndarray:
    """Deterministic mono float32 waveform in [-1, 1]."""
    rng = np.random.default_rng(sum(map(ord, sound_id)))

    def noise(dur: float) -> np.ndarray:
        return rng.uniform(-1, 1, int(SAMPLE_RATE * dur)).astype(np.float32)

    def tone(freq: float, dur: float, shape: float = 0.0) -> np.ndarray:
        t = np.arange(int(SAMPLE_RATE * dur)) / SAMPLE_RATE
        f = freq * (1.0 - shape * t / dur)
        return np.sin(2 * math.pi * np.cumsum(f) / SAMPLE_RATE).astype(np.float32)

    def lp(x: np.ndarray, k: int) -> np.ndarray:
        return np.convolve(x, np.ones(k) / k, mode="same").astype(np.float32)

    if sound_id in ("weapon_fire", "enemy_fire"):
        n = noise(0.22)
        e = _env(len(n), 0.001, 0.05)
        crack = n * e
        thump = tone(90 if sound_id == "weapon_fire" else 120, 0.22, 0.6) * _env(len(n), 0.002, 0.07)
        out = 0.7 * lp(crack, 3 if sound_id == "weapon_fire" else 6) + 0.6 * thump
    elif sound_id == "explosion":
        n = lp(noise(1.0), 18)
        out = n * _env(len(n), 0.004, 0.28) * 2.2 + tone(48, 1.0, 0.5) * _env(len(n), 0.004, 0.35)
    elif sound_id in ("magazine_drop", "chamber", "dry_fire", "switch", "pickup"):
        base = {"magazine_drop": 900, "chamber": 1400, "dry_fire": 1800, "switch": 600, "pickup": 700}[sound_id]
        n = noise(0.08)
        out = (tone(base, 0.08) * 0.5 + n * 0.5) * _env(len(n), 0.0005, 0.015)
    elif sound_id in ("magazine_insert", "weapon_reload"):
        out = tone(220, 0.12, 0.3) * _env(int(SAMPLE_RATE * 0.12), 0.001, 0.03) + noise(0.12) * 0.3 * _env(
            int(SAMPLE_RATE * 0.12), 0.001, 0.02
        )
    elif sound_id == "footstep":
        n = lp(noise(0.1), 14)
        out = n * _env(len(n), 0.003, 0.025) * 1.6
    elif sound_id == "impact":
        n = noise(0.09)
        out = lp(n, 2) * _env(len(n), 0.0005, 0.02) * 0.8
    elif sound_id == "enemy_alert":
        out = (tone(520, 0.14) + tone(780, 0.14)) * 0.3 * _env(int(SAMPLE_RATE * 0.14), 0.005, 0.07)
    elif sound_id in ("hit_tick", "kill_tick"):
        f = 2400 if sound_id == "hit_tick" else 1500
        out = tone(f, 0.05) * _env(int(SAMPLE_RATE * 0.05), 0.0005, 0.012)
    elif sound_id == "damage":
        out = tone(70, 0.25, 0.4) * _env(int(SAMPLE_RATE * 0.25), 0.002, 0.08) + lp(noise(0.25), 8) * 0.6 * _env(
            int(SAMPLE_RATE * 0.25), 0.001, 0.05
        )
    elif sound_id in ("objective_complete", "mission_complete", "mission_start", "wave_start"):
        notes = {
            "objective_complete": [660, 880],
            "mission_complete": [440, 554, 659, 880],
            "mission_start": [330, 440],
            "wave_start": [196, 196, 147],
        }[sound_id]
        parts = [tone(f, 0.16) * _env(int(SAMPLE_RATE * 0.16), 0.004, 0.09) * 0.45 for f in notes]
        out = np.concatenate(parts)
    elif sound_id == "mission_failed":
        out = np.concatenate(
            [tone(f, 0.25, 0.1) * _env(int(SAMPLE_RATE * 0.25), 0.004, 0.14) * 0.5 for f in (220, 175, 131)]
        )
    elif sound_id == "power_fail":
        out = tone(60, 1.2, 0.8) * _env(int(SAMPLE_RATE * 1.2), 0.01, 0.6) * 0.8
    elif sound_id == "door":
        out = lp(noise(0.5), 10) * _env(int(SAMPLE_RATE * 0.5), 0.02, 0.2)
    elif sound_id in ("ui_hover", "ui_select"):
        f = 1200 if sound_id == "ui_hover" else 900
        out = tone(f, 0.04) * _env(int(SAMPLE_RATE * 0.04), 0.0005, 0.01) * 0.4
    elif sound_id == "mr_event":
        out = lp(noise(0.7), 12) * _env(int(SAMPLE_RATE * 0.7), 0.003, 0.25) * 1.6
    else:
        out = tone(440, 0.05) * 0.2
    out = np.asarray(out, dtype=np.float32)
    peak = float(np.max(np.abs(out))) if out.size else 1.0
    return out / max(peak, 1e-6) * 0.9


@dataclass(frozen=True, slots=True)
class SpatialParams:
    gain: float
    pan: float  # -1 left .. +1 right
    delay_s: float  # speed-of-sound delay (informational; mixers may ignore)
    distance: float


class Listener:
    """Head pose used for spatialisation (VR: tracked head; desktop: camera)."""

    def __init__(self) -> None:
        self.pos = Vec3()
        self.yaw = 0.0

    def set(self, pos: Vec3, yaw: float) -> None:
        self.pos, self.yaw = pos, yaw


def spatialise(listener: Listener, src: Vec3, ref_dist: float = 4.0, max_dist: float = 70.0) -> SpatialParams:
    d = src - listener.pos
    dist = d.length()
    gain = 1.0 if dist <= 0.5 else min(1.0, ref_dist / (ref_dist + (dist - 0.5) * 0.9))
    if dist >= max_dist:
        gain = 0.0
    horiz = d.flat()
    pan = 0.0
    if horiz.length() > 0.3:
        pan = max(-1.0, min(1.0, horiz.normalized().dot(right_from_yaw(listener.yaw)) * 0.95))
    return SpatialParams(gain, pan, dist / 343.0, dist)


class AudioBackend(Protocol):
    def play(self, sound_id: str, left: float, right: float) -> None: ...

    def shutdown(self) -> None: ...


class NullAudio:
    def play(self, sound_id: str, left: float, right: float) -> None:
        return None

    def shutdown(self) -> None:
        return None


@dataclass
class RecordingAudio:
    log: list[tuple[str, float, float]] = field(default_factory=list)

    def play(self, sound_id: str, left: float, right: float) -> None:
        self.log.append((sound_id, left, right))

    def shutdown(self) -> None:
        return None

    def count(self, sound_id: str) -> int:
        return sum(1 for s, _, _ in self.log if s == sound_id)


class PygameAudio:
    """Stereo mixer backend. Falls back to silent if no audio device is available."""

    def __init__(self, channels: int = 24) -> None:
        import pygame

        self.pg = pygame
        self.ok = False
        self.sounds: dict[str, object] = {}
        try:
            pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=2, buffer=512)
            pygame.mixer.set_num_channels(channels)
            self.ok = True
        except Exception:
            self.ok = False

    def _get(self, sound_id: str):
        s = self.sounds.get(sound_id)
        if s is None:
            mono = synth(sound_id)
            pcm = (mono * 32767).astype(np.int16)
            stereo = np.ascontiguousarray(np.stack([pcm, pcm], axis=1))
            s = self.pg.sndarray.make_sound(stereo)
            self.sounds[sound_id] = s
        return s

    def play(self, sound_id: str, left: float, right: float) -> None:
        if not self.ok:
            return
        ch = self.pg.mixer.find_channel()  # None when all busy -> drop (bounded)
        if ch is None:
            return
        ch.set_volume(min(1.0, left), min(1.0, right))
        ch.play(self._get(sound_id))

    def shutdown(self) -> None:
        if self.ok:
            self.pg.mixer.quit()


class AudioEngine:
    """Subscribes to the event bus and plays spatialised sounds."""

    def __init__(
        self,
        bus: EventBus,
        backend: AudioBackend,
        *,
        master: float = 0.8,
        effects: float = 0.9,
        spatial: bool = True,
    ) -> None:
        self.backend = backend
        self.listener = Listener()
        self.master, self.effects, self.spatial = master, effects, spatial
        self._last: dict[str, float] = {}
        self.bus = bus
        for name in EVENT_SOUNDS:
            bus.subscribe(name, self._on_event)

    def _on_event(self, e: Event) -> None:
        sid = EVENT_SOUNDS[e.name]
        # throttle spammy sounds
        min_gap = {"impact": 0.03, "hit_tick": 0.03, "enemy_fire": 0.015}.get(sid, 0.0)
        pos = e.data.get("pos")
        key = (
            sid if not isinstance(pos, Vec3) else f"{sid}@{pos.x:.0f},{pos.z:.0f}"
        )  # distinct sources never mask each other
        if min_gap and e.t - self._last.get(key, -9.0) < min_gap:
            return
        self._last[key] = e.t
        vol = self.master * self.effects
        if sid in LISTENER_SOUNDS or not isinstance(pos, Vec3):
            self.backend.play(sid, vol, vol)
            return
        if not self.spatial:
            self.backend.play(sid, vol, vol)
            return
        sp = spatialise(self.listener, pos)
        if sp.gain <= 0.01:
            return
        left = vol * sp.gain * math.sqrt(0.5 * (1.0 - sp.pan))
        right = vol * sp.gain * math.sqrt(0.5 * (1.0 + sp.pan))
        self.backend.play(sid, left * 1.4, right * 1.4)
