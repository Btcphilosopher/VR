"""Enemy entity and state-machine AI.

States: IDLE, PATROL, ALERT, SEARCH, ENGAGE, TAKE_COVER, FLANK, RETREAT, DEFEATED.
Enemies perceive through vision (cone + LOS), hearing (noise events), damage, ally alerts and
mission hotspots. Decisions run on a staggered interval; movement/shooting run every tick.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

from ..core.types import Team
from ..physics.shapes import AABB, Hitbox
from ..physics.vec import ZERO, Vec3, wrap_angle, yaw_to
from ..physics.world import NoiseEvent
from ..weapons.firemodel import spread_direction
from ..weapons.weapon import Weapon
from .cover import STAND_EYE, CoverSystem
from .spec import EnemySpec, Role

if TYPE_CHECKING:
    from ..nav.grid import NavGrid
    from ..physics.world import World
    from ..player.player import Player


class AIState(str, Enum):
    IDLE = "idle"
    PATROL = "patrol"
    ALERT = "alert"
    SEARCH = "search"
    ENGAGE = "engage"
    TAKE_COVER = "take_cover"
    FLANK = "flank"
    RETREAT = "retreat"
    DEFEATED = "defeated"


class CoverPhase(str, Enum):
    MOVE = "move"
    HIDE = "hide"
    PEEK = "peek"


CROUCH_SCALE = 0.62
RADIUS = 0.3
THINK_INTERVAL = 0.15
ALLY_ALERT_RADIUS = 28.0


@dataclass
class AIContext:
    """Everything an enemy may consult or ask for in one tick. Built once per tick by the session."""

    player: Player
    world: World
    nav: NavGrid
    cover: CoverSystem
    allies: list[Enemy]
    noises: list[NoiseEvent]
    rng: random.Random
    t: float
    dt: float
    accuracy_mult: float = 1.0
    reaction_mult: float = 1.0
    hotspot: Vec3 | None = None
    path_budget: int = 4
    fire: object = None  # callable(enemy, origin, direction, spread_deg) -> None
    throw_grenade: object = None  # callable(enemy, target) -> None
    on_state: object = None  # callable(enemy, old, new) -> None
    on_alert: object = None  # callable(enemy) -> None


@dataclass
class Enemy:
    uid: int
    spec: EnemySpec
    pos: Vec3
    yaw: float = 0.0
    group: str = ""
    team: Team = Team.HELIX
    state: AIState = AIState.IDLE
    health: float = 0.0
    weapon: Weapon = field(init=False)
    state_t: float = 0.0
    think_t: float = 0.0
    crouched: bool = False
    inert: bool = False
    route_name: str = ""
    route: list[Vec3] = field(default_factory=list)
    route_idx: int = 0
    home: Vec3 = ZERO
    path: list[Vec3] = field(default_factory=list)
    goal: Vec3 | None = None
    need_path: bool = False
    last_known: Vec3 | None = None
    last_seen_t: float = -99.0
    sees_player: bool = False
    cover_pos: Vec3 | None = None
    cover_phase: CoverPhase = CoverPhase.MOVE
    phase_t: float = 0.0
    cover_cycles: int = 0
    burst_left: int = 0
    burst_pause: float = 0.0
    strafe_dir: float = 1.0
    strafe_t: float = 0.0
    recent_damage: float = 0.0
    last_damage_dir: Vec3 | None = None
    last_alert_broadcast: float = -99.0
    last_grenade_t: float = -99.0
    search_points: int = 0
    heard_t: float = -99.0
    flash_t: float = 0.0
    dead_t: float = 0.0
    spawn_t: float = 0.0
    retreat_t: float = 0.0
    path_fail_t: float = 0.0

    def __post_init__(self) -> None:
        self.health = self.spec.health
        self.weapon = Weapon.create(self.spec.weapon, None)
        self.weapon.reserve = 999
        self.home = self.pos
        self.inert = self.spec.role is Role.TARGET

    # ---- Damageable -------------------------------------------------------
    @property
    def alive(self) -> bool:
        return self.state is not AIState.DEFEATED

    @property
    def stance_scale(self) -> float:
        return CROUCH_SCALE if self.crouched else 1.0

    @property
    def eye(self) -> Vec3:
        return self.pos + Vec3(0, STAND_EYE * self.stance_scale, 0)

    @property
    def muzzle(self) -> Vec3:
        f = Vec3(math.sin(self.yaw), 0, math.cos(self.yaw))
        return self.pos + Vec3(0, 1.35 * self.stance_scale, 0) + f * 0.55

    def hitboxes(self) -> list[Hitbox]:
        p, s = self.pos, self.stance_scale
        w = 0.28
        return [
            Hitbox(
                "head",
                AABB(Vec3(p.x - 0.16, p.y + 1.55 * s, p.z - 0.16), Vec3(p.x + 0.16, p.y + 1.85 * s, p.z + 0.16)),
                2.0,
            ),
            Hitbox(
                "torso",
                AABB(Vec3(p.x - w, p.y + 0.85 * s, p.z - 0.2), Vec3(p.x + w, p.y + 1.55 * s, p.z + 0.2)),
                1.0,
            ),
            Hitbox(
                "legs",
                AABB(Vec3(p.x - 0.22, p.y, p.z - 0.18), Vec3(p.x + 0.22, p.y + 0.85 * s, p.z + 0.18)),
                0.7,
            ),
        ]

    def apply_damage(self, amount: float, hitbox: str, source_pos: Vec3, source: str) -> bool:
        if not self.alive:
            return False
        self.health -= amount
        self.recent_damage = min(1.0, self.recent_damage + amount / max(self.spec.health, 1.0) + 0.25)
        self.flash_t = 0.12
        d = source_pos - self.pos
        self.last_damage_dir = d.flat().normalized()
        if self.health <= 0.0:
            self._set_state(AIState.DEFEATED, None)
            self.dead_t = 0.0
            return True
        return False

    # ---- state plumbing -----------------------------------------------------
    def _set_state(self, new: AIState, ctx: AIContext | None) -> None:
        if new is self.state:
            return
        old = self.state
        self.state = new
        self.state_t = 0.0
        self.path = []
        self.need_path = False
        self.burst_left = 0
        if new is AIState.TAKE_COVER:
            self.cover_phase = CoverPhase.MOVE
            self.cover_cycles = 0
        if new not in (AIState.TAKE_COVER, AIState.ENGAGE):
            self.crouched = False
        if ctx is not None:
            if new is not AIState.TAKE_COVER:
                ctx.cover.release(self.uid)
            cb = ctx.on_state
            if callable(cb):
                cb(self, old, new)

    def _go(self, goal: Vec3) -> None:
        self.goal = goal
        self.need_path = True
        self.path = []

    # ---- main update --------------------------------------------------------
    def update(self, ctx: AIContext) -> None:
        dt = ctx.dt
        self.state_t += dt
        self.flash_t = max(0.0, self.flash_t - dt)
        self.recent_damage = max(0.0, self.recent_damage - dt * 0.12)
        self.weapon.update(dt)
        if self.state is AIState.DEFEATED:
            self.dead_t += dt
            if self.inert and self.dead_t > 4.0:  # training targets pop back up
                self.health = self.spec.health
                self.state = AIState.IDLE
            return
        if self.inert:
            return
        self.think_t -= dt
        if self.think_t <= 0.0:
            self.think_t = THINK_INTERVAL + (self.uid % 5) * 0.01
            self._think(ctx)
        self._act(ctx)

    # ---- perception -----------------------------------------------------------
    def _perceive(self, ctx: AIContext) -> None:
        pl = ctx.player
        self.sees_player = False
        if not pl.alive:
            return
        to = pl.state.pos - self.pos
        dist = to.length_xz()
        vr = self.spec.vision_range * (0.75 if pl.state.stance.value == "crouch" else 1.0)
        if dist <= vr:
            aware = self.state in (AIState.ENGAGE, AIState.TAKE_COVER, AIState.FLANK, AIState.ALERT)
            half_fov = math.radians(self.spec.fov_deg * (0.5 if not aware else 0.85))
            ang = abs(wrap_angle(math.atan2(to.x, to.z) - self.yaw))
            if ang <= half_fov or dist < 3.0:
                eye = self.eye
                if ctx.world.line_of_sight(eye, pl.eye) or ctx.world.line_of_sight(eye, pl.chest):
                    self.sees_player = True
        if self.sees_player:
            self.last_known = pl.state.pos
            self.last_seen_t = ctx.t
        # hearing
        for n in ctx.noises:
            if n.t <= self.heard_t:
                continue
            d = n.pos.dist_xz(self.pos)
            if d <= n.radius * self.spec.hearing:
                self.heard_t = n.t
                if not self.sees_player and self.state in (AIState.IDLE, AIState.PATROL):
                    self.last_known = n.pos
                    self._set_state(AIState.ALERT, ctx)

    def _broadcast_alert(self, ctx: AIContext) -> None:
        if ctx.t - self.last_alert_broadcast < 3.0 or self.last_known is None:
            return
        self.last_alert_broadcast = ctx.t
        for a in ctx.allies:
            if a is self or not a.alive or a.inert:
                continue
            if a.state in (AIState.IDLE, AIState.PATROL) and a.pos.dist_xz(self.pos) <= ALLY_ALERT_RADIUS:
                a.last_known = self.last_known
                a._set_state(AIState.ALERT, ctx)
        cb = ctx.on_alert
        if callable(cb):
            cb(self)

    # ---- decision ---------------------------------------------------------------
    def _think(self, ctx: AIContext) -> None:
        self._perceive(ctx)
        pl = ctx.player
        if not pl.alive:
            if self.state not in (AIState.IDLE, AIState.PATROL):
                self._set_state(AIState.PATROL if self.route else AIState.IDLE, ctx)
            return
        st = self.state
        sees = self.sees_player
        if sees:
            self._broadcast_alert(ctx)

        # reacting to damage
        if self.recent_damage > 0.0 and st in (AIState.IDLE, AIState.PATROL, AIState.SEARCH):
            if self.last_damage_dir is not None and self.last_known is None:
                self.last_known = self.pos + self.last_damage_dir * 12.0
            self._set_state(AIState.ALERT, ctx)
            st = self.state

        # retreat when badly hurt (not elites/bosses/breachers)
        low = self.health < self.spec.health * 0.28
        if (
            low
            and st in (AIState.ENGAGE, AIState.TAKE_COVER, AIState.FLANK)
            and self.spec.role in (Role.RIFLEMAN, Role.FLANKER, Role.SUPPRESSOR)
            and ctx.t - self.last_seen_t < 6.0
        ):
            self.retreat_t = 0.0
            self._set_state(AIState.RETREAT, ctx)
            return

        if st is AIState.IDLE:
            if sees:
                self._set_state(AIState.ALERT, ctx)
            elif self.route and self.state_t > 2.0:
                self._set_state(AIState.PATROL, ctx)
            elif (
                ctx.hotspot is not None
                and self.state_t > 1.0
                and self.last_known is None
                and self.spec.role is not Role.TARGET
            ):
                self.last_known = ctx.hotspot
                self._set_state(AIState.SEARCH, ctx)
        elif st is AIState.PATROL:
            if sees:
                self._set_state(AIState.ALERT, ctx)
        elif st is AIState.ALERT:
            if self.last_known is not None:
                self.yaw = _turn_toward(self.yaw, yaw_to(self.pos, self.last_known), 6.0 * THINK_INTERVAL)
            if self.state_t >= self.spec.reaction * ctx.reaction_mult:
                if sees:
                    self._set_state(AIState.ENGAGE, ctx)
                else:
                    self._set_state(AIState.SEARCH, ctx)
        elif st is AIState.SEARCH:
            if sees:
                self._set_state(AIState.ALERT, ctx)
            elif self.state_t > 14.0:
                self.last_known = None
                self._set_state(AIState.PATROL if self.route else AIState.IDLE, ctx)
                if not self.route:
                    self._go(self.home)
        elif st is AIState.ENGAGE:
            self._think_engage(ctx, sees)
        elif st is AIState.TAKE_COVER:
            self._think_cover(ctx, sees)
        elif st is AIState.FLANK:
            if sees and self.state_t > 2.5:
                self._set_state(AIState.ENGAGE, ctx)
            elif self.state_t > 14.0:
                self._set_state(AIState.SEARCH, ctx)
        elif st is AIState.RETREAT:
            self.retreat_t += THINK_INTERVAL
            if self.retreat_t > 5.0 and not sees:
                self._set_state(AIState.TAKE_COVER, ctx)
            elif self.retreat_t > 9.0:
                self._set_state(AIState.TAKE_COVER, ctx)

    def _allies_engaged(self, ctx: AIContext) -> int:
        return sum(
            1
            for a in ctx.allies
            if a is not self
            and a.alive
            and a.state in (AIState.ENGAGE, AIState.TAKE_COVER)
            and a.pos.dist_xz(self.pos) < 30
        )

    def _think_engage(self, ctx: AIContext, sees: bool) -> None:
        role = self.spec.role
        if not sees:
            gone = ctx.t - self.last_seen_t
            if role is Role.SUPPRESSOR and gone < 4.0:
                return  # keep pinning the last known position
            if role in (Role.FLANKER, Role.ELITE) and self._allies_engaged(ctx) >= 1 and self._try_flank(ctx):
                return
            if gone > 1.2:
                self._set_state(AIState.SEARCH, ctx)
            return
        # sees player
        if role is Role.BREACHER:
            return  # rush
        if role is Role.FLANKER and self.state_t > 1.5 and self._allies_engaged(ctx) >= 1 and self._try_flank(ctx):
            return
        pressured = self.recent_damage > 0.35 or self.weapon.ammo <= max(2, self.weapon.spec.magazine_capacity // 5)
        bored = self.state_t > 2.0 + 4.0 * self.spec.aggression
        if (pressured or bored) and ctx.rng.random() > self.spec.aggression * 0.6:
            if self._try_cover(ctx):
                return
        if self.spec.throws_grenades:
            pass  # grenades are handled in _act while the player is behind cover

    def _try_cover(self, ctx: AIContext) -> bool:
        threat = self.last_known or ctx.player.state.pos
        res = ctx.cover.find_cover(self.pos, threat, self.uid, ctx.rng)
        if res is None:
            return False
        _, spot = res
        self.cover_pos = spot
        self._set_state(AIState.TAKE_COVER, ctx)
        self._go(spot)
        return True

    def _try_flank(self, ctx: AIContext) -> bool:
        threat = self.last_known or ctx.player.state.pos
        spot = ctx.cover.flank_point(self.pos, threat, self.uid, ctx.rng)
        if spot is None:
            return False
        self._set_state(AIState.FLANK, ctx)
        self._go(spot)
        return True

    def _think_cover(self, ctx: AIContext, sees: bool) -> None:
        if self.cover_pos is None:
            self._set_state(AIState.ENGAGE if sees else AIState.SEARCH, ctx)
            return
        if self.cover_phase is CoverPhase.MOVE:
            if self.pos.dist_xz(self.cover_pos) < 0.7:
                self.cover_phase, self.phase_t = CoverPhase.HIDE, 0.0
                self.crouched = True
            return
        self.phase_t += THINK_INTERVAL
        if self.cover_phase is CoverPhase.HIDE:
            self.crouched = True
            if self.weapon.ammo < self.weapon.spec.magazine_capacity * 0.5 and not self.weapon.reloading:
                self.weapon.start_reload()
            hide_for = 1.0 + 2.2 * (1.0 - self.spec.aggression)
            if self.phase_t >= hide_for and not self.weapon.reloading:
                self.cover_phase, self.phase_t = CoverPhase.PEEK, 0.0
                self.crouched = False
                self.burst_left = 0
        elif self.cover_phase is CoverPhase.PEEK:
            self.crouched = False
            if self.phase_t >= 1.2 + 1.2 * self.spec.aggression:
                self.cover_phase, self.phase_t = CoverPhase.HIDE, 0.0
                self.cover_cycles += 1
                self.crouched = True
        # leave cover to flank / search when the player cannot be found for a while
        if ctx.t - self.last_seen_t > 8.0:
            self._set_state(AIState.SEARCH, ctx)
        elif self.cover_cycles >= 3 and self.spec.role in (Role.FLANKER, Role.ELITE) and self._allies_engaged(ctx) >= 1:
            self._try_flank(ctx)
        elif self.cover_cycles >= 5:
            self._set_state(AIState.ENGAGE if sees else AIState.SEARCH, ctx)

    # ---- action: movement + shooting ----------------------------------------------
    def _act(self, ctx: AIContext) -> None:
        st = self.state
        dt = ctx.dt
        speed = self.spec.speed
        moving_goal = False

        if st is AIState.IDLE:
            if self.goal is not None and self.pos.dist_xz(self.goal) > 0.8 and (self.path or self.need_path):
                moving_goal = True
                speed *= 0.7
        elif st is AIState.PATROL:
            if not self.route:
                self._set_state(AIState.IDLE, ctx)
            else:
                wp = self.route[self.route_idx]
                if self.pos.dist_xz(wp) < 0.8:
                    self.route_idx = (self.route_idx + 1) % len(self.route)
                    self.state_t = 0.0
                elif self.goal is None or self.goal.dist_xz(wp) > 0.1:
                    self._go(wp)
                moving_goal = True
                speed *= 0.55
        elif st is AIState.SEARCH:
            tgt: Vec3 | None = self.last_known or ctx.hotspot
            if tgt is not None and self.pos.dist_xz(tgt) > 1.5 and self.search_points == 0:
                if self.goal is None or self.goal.dist_xz(tgt) > 0.5:
                    self._go(tgt)
                moving_goal = True
                speed *= 0.8
            else:
                # look around, then try a nearby point or two
                self.yaw = wrap_angle(self.yaw + 1.2 * dt)
                if self.state_t % 4.0 < dt and self.search_points < 2:
                    self.search_points += 1
                    ang = ctx.rng.uniform(0, 2 * math.pi)
                    self._go(self.pos + Vec3(math.sin(ang), 0, math.cos(ang)) * 5.0)
                if self.path:
                    moving_goal = True
                    speed *= 0.7
        elif st is AIState.ALERT:
            pass
        elif st is AIState.ENGAGE:
            self._act_engage(ctx)
            if self.spec.role is Role.BREACHER and self.last_known is not None:
                if self.pos.dist_xz(ctx.player.state.pos) > 7.0:
                    if self.goal is None or self.goal.dist_xz(ctx.player.state.pos) > 3.0:
                        self._go(ctx.player.state.pos)
                    moving_goal = True
                    speed *= 1.05
            else:
                self._strafe(ctx)
        elif st is AIState.TAKE_COVER:
            if self.cover_phase is CoverPhase.MOVE and self.cover_pos is not None:
                moving_goal = True
                speed *= 1.15
            elif self.cover_phase is CoverPhase.PEEK:
                self._act_engage(ctx)
        elif st is AIState.FLANK:
            moving_goal = True
            speed *= 1.2
            if self.sees_player and self.state_t > 1.0:
                self._act_engage(ctx)
        elif st is AIState.RETREAT:
            moving_goal = True
            speed *= 1.1
            if self.goal is None or self.state_t < 0.05:
                away = (self.pos - ctx.player.state.pos).flat().normalized()
                self._go(self.pos + away * 14.0)

        if moving_goal and self.goal is not None:
            self._follow(ctx, speed)

    def _act_engage(self, ctx: AIContext) -> None:
        pl = ctx.player
        dt = ctx.dt
        target = pl.state.pos if self.sees_player else self.last_known
        if target is None:
            return
        self.yaw = _turn_toward(self.yaw, yaw_to(self.pos, target), 9.0 * dt)
        w = self.weapon
        if w.ammo <= 0 and not w.reloading and w.state.value == "ready":
            w.start_reload()
        if w.reloading:
            return
        suppress = (not self.sees_player) and self.spec.role is Role.SUPPRESSOR
        # throw a grenade at a player who is camping behind cover
        if (
            self.spec.throws_grenades
            and not self.sees_player
            and ctx.t - self.last_grenade_t > 9.0
            and self.last_known is not None
            and ctx.t - self.last_seen_t < 5.0
            and 6.0 < self.pos.dist_xz(self.last_known) < 24.0
            and callable(ctx.throw_grenade)
        ):
            self.last_grenade_t = ctx.t
            ctx.throw_grenade(self, self.last_known)
            return
        if not self.sees_player and not suppress:
            return
        if self.burst_pause > 0:
            self.burst_pause -= dt
            return
        if self.burst_left <= 0:
            lo, hi = (3, 6) if self.spec.role is not Role.SUPPRESSOR else (8, 14)
            if self.spec.role is Role.BREACHER:
                lo, hi = 1, 1
            self.burst_left = ctx.rng.randint(lo, hi)
        if not w.can_fire:
            return
        aim_at = pl.chest if self.sees_player else Vec3(target.x, 1.0, target.z)
        dist = self.pos.dist(aim_at)
        acc = max(0.05, self.spec.accuracy * ctx.accuracy_mult)
        spread = w.spec.spread * (2.0 - acc) * (1.0 + dist / 55.0)
        if pl.state.speed_xz > 2.0:
            spread *= 1.25
        if suppress:
            spread *= 2.5
        direction = (aim_at - self.muzzle).normalized()
        w.consume_round()
        self.burst_left -= 1
        if self.burst_left <= 0:
            self.burst_pause = ctx.rng.uniform(0.35, 0.9) * (1.3 - self.spec.aggression * 0.5)
        fire = ctx.fire
        if callable(fire):
            fire(self, self.muzzle, direction, spread)

    def _strafe(self, ctx: AIContext) -> None:
        self.strafe_t -= ctx.dt
        if self.strafe_t <= 0:
            self.strafe_t = ctx.rng.uniform(0.8, 2.0)
            self.strafe_dir = ctx.rng.choice([-1.0, 1.0, 0.0])
        if self.strafe_dir != 0.0 and self.sees_player and self.spec.role is not Role.TARGET:
            side = Vec3(math.cos(self.yaw), 0, -math.sin(self.yaw)) * self.strafe_dir
            step = side * self.spec.speed * 0.45 * ctx.dt
            if ctx.nav.is_walkable_pos(self.pos + side * 0.8):
                self.pos, _ = ctx.world.move_and_collide(self.pos, step, RADIUS, 1.7)

    def _follow(self, ctx: AIContext, speed: float) -> None:
        if self.path_fail_t > 0.0:
            self.path_fail_t -= ctx.dt
            return
        if self.need_path and self.goal is not None:
            if ctx.path_budget > 0:
                ctx.path_budget -= 1
                p = ctx.nav.find_path(self.pos, self.goal)
                self.path = p or []
                self.need_path = False
                if p is None:
                    self.goal = None
                    self.path_fail_t = 0.8
                    if self.state is AIState.TAKE_COVER:
                        self._set_state(AIState.ENGAGE, ctx)
                    return
            else:
                return
        if not self.path:
            return
        tgt = self.path[0]
        d = tgt - self.pos
        dist = d.length_xz()
        if dist < 0.35:
            self.path.pop(0)
            return
        step = min(dist, speed * ctx.dt)
        dirv = d.flat().normalized()
        if self.state not in (AIState.ENGAGE,) or not self.sees_player:
            self.yaw = _turn_toward(self.yaw, math.atan2(dirv.x, dirv.z), 10.0 * ctx.dt)
        # light separation from allies so groups do not stack
        push = Vec3(0, 0, 0)
        for a in ctx.allies:
            if a is not self and a.alive:
                dd = self.pos - a.pos
                l = dd.length_xz()
                if 0.01 < l < 0.9:
                    push = push + dd.flat().normalized() * (0.9 - l)
        mv = dirv * step + push * 0.5 * ctx.dt
        self.pos, _ = ctx.world.move_and_collide(self.pos, mv, RADIUS, 1.7)
        if self.state is AIState.TAKE_COVER and self.cover_pos is not None and not self.path:
            self.pos = Vec3(self.pos.x, 0.0, self.pos.z)


def _turn_toward(cur: float, target: float, max_step: float) -> float:
    d = wrap_angle(target - cur)
    if abs(d) <= max_step:
        return target
    return wrap_angle(cur + math.copysign(max_step, d))


def aim_spread(direction: Vec3, spread_deg: float, rng: random.Random) -> Vec3:
    return spread_direction(direction, spread_deg, rng)
