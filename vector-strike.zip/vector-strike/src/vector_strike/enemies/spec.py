"""HELIX operative archetypes (fictional). Roles shape behaviour, not just health pools."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ..weapons.spec import WeaponSpec, enemy_variant


class Role(str, Enum):
    RIFLEMAN = "rifleman"
    FLANKER = "flanker"
    SUPPRESSOR = "suppressor"
    BREACHER = "breacher"
    ELITE = "elite"
    BOSS = "boss"
    TARGET = "target"


@dataclass(frozen=True, slots=True)
class EnemySpec:
    id: str
    name: str
    role: Role
    health: float
    speed: float
    accuracy: float  # 0..1 (higher = tighter spread)
    weapon: WeaponSpec
    vision_range: float = 38.0
    fov_deg: float = 110.0
    reaction: float = 0.55  # seconds in ALERT before committing
    aggression: float = 0.5  # 0 = hugs cover, 1 = holds ground
    hearing: float = 1.0
    throws_grenades: bool = False
    marker: str = "helix_red"  # colour key for the identification stripe


_RIFLE = enemy_variant("ks4_kestrel", damage=7.0, spread=2.4, magazine_capacity=24, rate_of_fire=520)
_SMG = enemy_variant("sp9_sparrow", damage=5.0, spread=3.2, magazine_capacity=28, rate_of_fire=700)
_CARB = enemy_variant("wr2_warden", damage=6.0, spread=3.0, magazine_capacity=40, rate_of_fire=640)
_SHOT = enemy_variant("hm12_hammer", damage=5.5, spread=5.5, magazine_capacity=6, range=22.0)
_ELITE = enemy_variant("ks4_kestrel", damage=9.0, spread=1.6, magazine_capacity=30, rate_of_fire=560)
_BOSS = enemy_variant("ks4_kestrel", damage=10.0, spread=1.8, magazine_capacity=60, rate_of_fire=600)
_TARGET = enemy_variant("tr0_trainer", damage=0.0, spread=0.0)

ENEMIES: dict[str, EnemySpec] = {
    e.id: e
    for e in [
        EnemySpec("rifleman", "Helix Rifleman", Role.RIFLEMAN, 60, 3.2, 0.55, _RIFLE, aggression=0.5),
        EnemySpec("flanker", "Helix Flanker", Role.FLANKER, 45, 4.1, 0.45, _SMG, reaction=0.4, aggression=0.7),
        EnemySpec("suppressor", "Helix Suppressor", Role.SUPPRESSOR, 85, 2.7, 0.4, _CARB, aggression=0.3),
        EnemySpec("breacher", "Helix Breacher", Role.BREACHER, 95, 3.8, 0.5, _SHOT, aggression=1.0, fov_deg=120),
        EnemySpec(
            "elite",
            "Helix Elite",
            Role.ELITE,
            150,
            3.4,
            0.75,
            _ELITE,
            reaction=0.3,
            aggression=0.55,
            throws_grenades=True,
            vision_range=45,
            marker="helix_amber",
        ),
        EnemySpec(
            "commander",
            "Helix Commander",
            Role.BOSS,
            900,
            2.6,
            0.8,
            _BOSS,
            reaction=0.2,
            aggression=0.9,
            throws_grenades=True,
            vision_range=60,
            hearing=1.5,
            marker="helix_amber",
        ),
        EnemySpec("training_target", "Target", Role.TARGET, 40, 0.0, 0.0, _TARGET, vision_range=0.0),
    ]
}


def get_enemy(enemy_id: str) -> EnemySpec:
    return ENEMIES[enemy_id]
