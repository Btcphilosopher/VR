"""Cover point generation and queries (shared by enemy AI, player cover feedback and MR furniture cover)."""

from __future__ import annotations

import math
import random
from typing import TYPE_CHECKING

from ..physics.shapes import AABB
from ..physics.vec import Vec3
from ..physics.world import ColliderKind, World

if TYPE_CHECKING:
    from ..missions.level import CoverPoint, Level

CROUCH_EYE = 0.9
STAND_EYE = 1.6
COVER_OFFSET = 0.75


def generate_cover_points(level: Level, min_h: float = 0.75, max_h: float = 1.6) -> None:
    """Create cover points behind every low-ish solid. `facing` points from the point *through* the
    cover toward the side it protects against."""
    from ..missions.level import CoverPoint

    world = level.world
    pts: list[CoverPoint] = []
    min_x, min_z, max_x, max_z = level.bounds
    for c in world.colliders.values():
        if c.kind not in (ColliderKind.COVER, ColliderKind.MR_REAL) or c.open:
            continue
        b = c.aabb
        h = b.max.y
        if not (min_h <= h <= max_h):
            continue
        cx, cz = b.center.x, b.center.z
        sx, sz = b.size.x, b.size.z
        sides: list[tuple[Vec3, float]] = []  # (outward normal, run length along side)
        sides += [(Vec3(1, 0, 0), sz), (Vec3(-1, 0, 0), sz), (Vec3(0, 0, 1), sx), (Vec3(0, 0, -1), sx)]
        for n, run in sides:
            along = Vec3(-n.z, 0, n.x)
            offs = [0.0] if run < 2.2 else [-run * 0.28, run * 0.28]
            half = (sx if n.x != 0 else sz) / 2
            for o in offs:
                p = Vec3(cx, 0, cz) + n * (half + COVER_OFFSET) + along * o
                if not (min_x + 0.5 < p.x < max_x - 0.5 and min_z + 0.5 < p.z < max_z - 0.5):
                    continue
                probe = AABB(Vec3(p.x - 0.35, 0.1, p.z - 0.35), Vec3(p.x + 0.35, 1.7, p.z + 0.35))
                if any(k.blocks_move and not k.open for k in world.query_aabb(probe)):
                    continue
                pts.append(CoverPoint(p, -n, c.id, h))
    level.cover_points = pts


def is_covered(world: World, threat_eye: Vec3, spot: Vec3, crouched: bool = True) -> bool:
    eye = Vec3(spot.x, CROUCH_EYE if crouched else STAND_EYE, spot.z)
    return not world.line_of_sight(threat_eye, eye)


class CoverSystem:
    """Claims-aware cover queries."""

    def __init__(self, level: Level) -> None:
        self.level = level
        self.claims: dict[int, int] = {}  # cover index -> owner id

    def release(self, owner: int) -> None:
        for k in [k for k, v in self.claims.items() if v == owner]:
            del self.claims[k]

    def find_cover(
        self,
        pos: Vec3,
        threat_pos: Vec3,
        owner: int,
        rng: random.Random,
        max_dist: float = 22.0,
        min_threat_dist: float = 4.0,
    ) -> tuple[int, Vec3] | None:
        world = self.level.world
        threat_eye = Vec3(threat_pos.x, STAND_EYE, threat_pos.z)
        best: tuple[float, int] | None = None
        for i, cp in enumerate(self.level.cover_points):
            if self.claims.get(i, owner) != owner:
                continue
            d = pos.dist_xz(cp.pos)
            if d > max_dist:
                continue
            td = threat_pos.dist_xz(cp.pos)
            if td < min_threat_dist:
                continue
            if not is_covered(world, threat_eye, cp.pos):
                continue
            # prefer near, and cover that does not require running towards the threat
            toward = (cp.pos - pos).flat().normalized().dot((threat_pos - pos).flat().normalized())
            score = -d - max(0.0, toward) * 6.0 + rng.uniform(0.0, 2.0) - (4.0 if td < 8 else 0.0)
            if best is None or score > best[0]:
                best = (score, i)
        if best is None:
            return None
        self.release(owner)
        self.claims[best[1]] = owner
        return best[1], self.level.cover_points[best[1]].pos

    def flank_point(
        self,
        pos: Vec3,
        threat_pos: Vec3,
        owner: int,
        rng: random.Random,
        min_dist: float = 7.0,
        max_dist: float = 18.0,
    ) -> Vec3 | None:
        """Cover point on the lateral side of the threat (50-110 degrees off the current bearing)."""
        cur = math.atan2(pos.x - threat_pos.x, pos.z - threat_pos.z)
        best: tuple[float, Vec3] | None = None
        for cp in self.level.cover_points:
            td = threat_pos.dist_xz(cp.pos)
            if not (min_dist <= td <= max_dist):
                continue
            ang = math.atan2(cp.pos.x - threat_pos.x, cp.pos.z - threat_pos.z)
            diff = abs((ang - cur + math.pi) % (2 * math.pi) - math.pi)
            if not (math.radians(45) <= diff <= math.radians(120)):
                continue
            score = -abs(diff - math.radians(80)) * 4 - pos.dist_xz(cp.pos) * 0.15 + rng.uniform(0, 1.0)
            if best is None or score > best[0]:
                best = (score, cp.pos)
        return best[1] if best else None

    def player_cover_fraction(self, player_pos: Vec3, crouched: bool, threats: list[Vec3]) -> float:
        if not threats:
            return 0.0
        eye = Vec3(player_pos.x, CROUCH_EYE if crouched else STAND_EYE, player_pos.z)
        covered = sum(1 for t in threats if not self.level.world.line_of_sight(Vec3(t.x, STAND_EYE, t.z), eye))
        return covered / len(threats)
