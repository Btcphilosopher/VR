"""Synchronous event bus. Audio, haptics, HUD, mission logic and stats all subscribe here."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

# Canonical event names (strings keep the bus decoupled and loggable).
WEAPON_FIRE = "weapon_fire"
WEAPON_DRY = "weapon_dry_fire"
WEAPON_RELOAD_START = "weapon_reload_start"
MAGAZINE_DROP = "magazine_drop"
MAGAZINE_INSERT = "magazine_insert"
WEAPON_CHAMBER = "weapon_chamber"
WEAPON_RELOAD_COMPLETE = "weapon_reload_complete"
WEAPON_SWITCH = "weapon_switch"
WEAPON_PICKUP = "weapon_pickup"
WEAPON_DRAW = "weapon_draw"
WEAPON_HOLSTER = "weapon_holster"
HIT_CONFIRM = "hit_confirm"
KILL_CONFIRM = "kill_confirm"
IMPACT = "impact"
PLAYER_DAMAGED = "player_damaged"
PLAYER_DOWN = "player_down"
ENEMY_ALERT = "enemy_alert"
ENEMY_DEFEATED = "enemy_defeated"
ENEMY_STATE = "enemy_state"
ENEMY_GRENADE = "enemy_grenade_thrown"
GRENADE_THROWN = "grenade_thrown"
EXPLOSION = "explosion"
FOOTSTEP = "footstep"
INTERACTION_PROGRESS = "interaction_progress"
INTERACTION_COMPLETE = "interaction_complete"
OBJECTIVE_ACTIVE = "objective_active"
OBJECTIVE_COMPLETE = "objective_complete"
MISSION_START = "mission_start"
MISSION_COMPLETE = "mission_complete"
MISSION_FAILED = "mission_failed"
MISSION_PHASE = "mission_phase"
POWER_FAIL = "power_fail"
WAVE_START = "wave_start"
UI_HOVER = "ui_hover"
UI_SELECT = "ui_select"
TELEPORT = "teleport"
DASH = "dash"
MR_EVENT = "mr_event"
DOOR = "door"
NOISE = "noise"
HEARTBEAT = "heartbeat"
ENEMY_FIRE = "enemy_fire"
PICKUP_AMMO = "pickup_ammo"


@dataclass(slots=True)
class Event:
    name: str
    t: float
    data: dict[str, Any] = field(default_factory=dict)


Handler = Callable[[Event], None]


class EventBus:
    """Synchronous pub/sub with a bounded history ring for tests and debugging."""

    def __init__(self, history: int = 512) -> None:
        self._subs: dict[str, list[Handler]] = {}
        self._all: list[Handler] = []
        self.history: deque[Event] = deque(maxlen=history)
        self.time = 0.0

    def subscribe(self, name: str, handler: Handler) -> None:
        self._subs.setdefault(name, []).append(handler)

    def subscribe_all(self, handler: Handler) -> None:
        self._all.append(handler)

    def emit(self, name: str, **data: Any) -> Event:
        ev = Event(name, self.time, data)
        self.history.append(ev)
        for h in self._subs.get(name, ()):
            h(ev)
        for h in self._all:
            h(ev)
        return ev

    def count(self, name: str) -> int:
        return sum(1 for e in self.history if e.name == name)
