"""Plain-data state records and result objects. No global mutable state anywhere in the game."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..core.config import Difficulty
from ..missions.models import MissionPhase
from ..missions.scoring import ScoreBreakdown
from ..physics.vec import Vec3


@dataclass(frozen=True, slots=True)
class DifficultyProfile:
    enemy_accuracy: float
    enemy_damage: float
    reaction: float
    score_multiplier: float
    player_damage: float


DIFFICULTY: dict[Difficulty, DifficultyProfile] = {
    Difficulty.RECRUIT: DifficultyProfile(0.6, 0.6, 1.4, 0.8, 0.8),
    Difficulty.NORMAL: DifficultyProfile(1.0, 1.0, 1.0, 1.0, 1.0),
    Difficulty.VETERAN: DifficultyProfile(1.25, 1.4, 0.75, 1.3, 1.0),
}


@dataclass(slots=True)
class Stats:
    shots: int = 0
    hits: int = 0
    kills: int = 0
    headshots: int = 0
    grenades: int = 0
    reloads: int = 0
    damage_dealt: float = 0.0

    @property
    def accuracy(self) -> float:
        return self.hits / self.shots if self.shots else 0.0


@dataclass(slots=True)
class InteractableState:
    id: str
    pos: Vec3
    kind: str
    title: str
    hold_time: float
    radius: float
    enabled: bool
    data: dict[str, str] = field(default_factory=dict)
    progress: float = 0.0
    used: bool = False


@dataclass(slots=True)
class MissionResult:
    success: bool
    mission_id: str
    title: str
    reason: str
    elapsed: float
    accuracy: float
    shots: int
    hits: int
    kills: int
    headshots: int
    damage_taken: float
    primary_done: int
    primary_total: int
    optional_done: int
    optional_total: int
    score: ScoreBreakdown
    phase: MissionPhase = MissionPhase.RESULTS
    waves_cleared: int = 0


@dataclass(slots=True)
class Effect:
    kind: str  # tracer | impact | explosion | flash | grenade_warning
    pos: Vec3
    end: Vec3 | None = None
    color: str = "amber"
    ttl: float = 0.1
    max_ttl: float = 0.1
    size: float = 1.0
