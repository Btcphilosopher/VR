"""GameSession: the complete headless simulation. Rendering, audio, haptics and UI are consumers.

Deterministic: all randomness comes from GameRng streams; `step(dt, intent)` with a fixed dt and a
fixed intent sequence reproduces the same world (see tests/test_determinism.py).
"""

from __future__ import annotations

import hashlib
import math
from collections import deque
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ..core.config import Settings
from ..core.rng import GameRng
from ..core.types import Hand, Team
from ..enemies.cover import CoverSystem
from ..enemies.enemy import AIContext, AIState, Enemy
from ..enemies.spec import get_enemy
from ..haptics.devices import HapticDevice, NullHapticDevice
from ..haptics.director import HapticDirector
from ..missions.level import Level
from ..missions.levels import build_level
from ..missions.models import MissionDef, MissionMode, SpawnEntry, load_mission
from ..missions.runner import MissionRunner
from ..missions.scoring import compute_score
from ..missions.waves import WaveDirector
from ..nav.grid import NavGrid
from ..physics.vec import Vec3, clamp, forward_from_angles
from ..physics.world import NoiseEvent
from ..player.player import Player, Stance
from ..weapons.firemodel import ProjectileSystem, WeaponFireModel
from ..weapons.grenade import BLAST_RADIUS, GRAVITY, Grenade, blast_damage
from ..weapons.inventory import Inventory
from ..weapons.spec import Slot
from . import events as ev
from .events import EventBus
from .intent import PlayerIntent
from .state import DIFFICULTY, Effect, InteractableState, MissionResult, Stats

if TYPE_CHECKING:
    from ..mr.director import MRDirector
    from ..mr.environment import MixedRealityEnvironment

SIM_DT = 1.0 / 60.0
NOISE_LIFETIME = 0.4
AI_ACTIVE_RADIUS = 70.0
AI_MAX_UPDATES = 64


@dataclass
class GameSession:
    settings: Settings
    mission: MissionDef
    level: Level
    seed: int = 1337
    bus: EventBus = field(default_factory=EventBus)
    rng: GameRng = field(init=False)
    nav: NavGrid = field(init=False)
    cover: CoverSystem = field(init=False)
    player: Player = field(init=False)
    inventory: Inventory = field(init=False)
    enemies: list[Enemy] = field(default_factory=list)
    interactables: dict[str, InteractableState] = field(default_factory=dict)
    projectiles: ProjectileSystem = field(default_factory=ProjectileSystem)
    grenades: list[Grenade] = field(default_factory=list)
    effects: deque[Effect] = field(default_factory=lambda: deque(maxlen=160))
    noises: list[NoiseEvent] = field(default_factory=list)
    stats: Stats = field(default_factory=Stats)
    runner: MissionRunner = field(init=False)
    waves: WaveDirector | None = None
    haptics: HapticDirector | None = None
    t: float = 0.0
    tick: int = 0
    powered: bool = True
    hotspot: Vec3 | None = None
    done: bool = False
    result: MissionResult | None = None
    mr_env: MixedRealityEnvironment | None = None
    mr_director: MRDirector | None = None
    last_hit_marker: float = -1.0
    last_kill_marker: float = -1.0
    hit_dirs: deque[tuple[float, float]] = field(default_factory=lambda: deque(maxlen=6))
    interact_target: str | None = None
    view_kick: tuple[float, float] = (0.0, 0.0)
    _next_uid: int = 1
    _reported: set[int] = field(default_factory=set)
    _hunters: set[int] = field(default_factory=set)
    _groups_spawned: set[str] = field(default_factory=set)
    _interact_prev: bool = False
    _grenade_prev: bool = False
    _ammo_cooldowns: dict[str, float] = field(default_factory=dict)

    # ---- construction ---------------------------------------------------------------
    @staticmethod
    def create(
        settings: Settings,
        mission: MissionDef | str,
        *,
        seed: int | None = None,
        loadout: list[str] | None = None,
        haptic_device: HapticDevice | None = None,
        autostart: bool = True,
    ) -> GameSession:
        m = load_mission(mission) if isinstance(mission, str) else mission
        sd = settings.game.seed if seed is None else seed
        mr_env = None
        if m.mode is MissionMode.MR:
            from ..mr.environment import environment_to_level
            from ..mr.scanner import SimulatedRoomScanner

            mr_env = SimulatedRoomScanner(seed=1).scan(settings.mr.room_preset)
            level = environment_to_level(mr_env, sd)
        else:
            level = build_level(m.level, sd)
        s = GameSession(settings=settings, mission=m, level=level, seed=sd)
        s.mr_env = mr_env
        s._init(loadout, haptic_device)
        if autostart:
            s.start()
        return s

    def _init(self, loadout: list[str] | None, haptic_device: HapticDevice | None) -> None:
        self.rng = GameRng(self.seed)
        lvl = self.level
        self.nav = NavGrid(*lvl.bounds, cell=0.25, agent_radius=0.3) if lvl.kind == "mr" else NavGrid(*lvl.bounds)
        self.nav.rebuild(lvl.world)
        self.cover = CoverSystem(lvl)
        self.player = Player(self.settings.player, self.bus)
        prof = DIFFICULTY[self.settings.game.difficulty]
        self.player.damage_multiplier = prof.player_damage
        pos, yaw = lvl.player_start
        self.player.state.pos, self.player.state.yaw = pos, yaw
        self.player.state.seated = self.settings.comfort.seated_mode
        self.inventory = Inventory(self.bus, grenades=self.mission.grenades)
        weapons = (
            self.mission.loadout
            if self.mission.loadout is not None and self.mission.mode is MissionMode.TRAINING
            else (loadout or ["ks4_kestrel", "p11_pilot"])
        )
        for wid in weapons:
            self.inventory.add_weapon(wid, make_active=False)
        if self.inventory.active is None:
            for slot in (Slot.PRIMARY, Slot.SECONDARY, Slot.SPECIAL):
                if self.inventory.slots[slot] is not None:
                    self.inventory.switch_to(slot, silent=True)
                    break
        for d in lvl.interactables.values():
            self.interactables[d.id] = InteractableState(
                d.id, d.pos, d.kind, d.title, d.hold_time, d.radius, d.enabled, dict(d.data)
            )
        # doors start closed/locked
        for info in lvl.doors.values():
            info.locked = True
        self.haptics = HapticDirector(
            self.bus,
            self.settings.haptics,
            haptic_device or NullHapticDevice(),
            dominant=Hand.LEFT if self.settings.comfort.handedness.value == "left" else Hand.RIGHT,
        )
        self.haptics.attach_health(lambda: self.player.state.health / self.player.state.max_health)
        self.runner = MissionRunner(self, self.mission)
        if self.mission.mode is MissionMode.SURVIVAL:
            self.waves = WaveDirector(self, self.mission)
        self.bus.subscribe(ev.FOOTSTEP, self._on_footstep)
        if self.mission.mode is MissionMode.MR:
            from ..mr.director import MRDirector

            assert self.mr_env is not None
            self.mr_director = MRDirector(self, self.mr_env)

    def start(self) -> None:
        self.runner.start()

    # ---- world manipulation (mission actions / dev console) --------------------------------
    def unlock_door(self, door_id: str) -> None:
        info = self.level.doors.get(door_id)
        if info is None:
            return
        info.locked = False
        for cid in info.collider_ids:
            self.level.world.set_open(cid, True)
        self.bus.emit(ev.DOOR, id=door_id, open=True)

    def lock_door(self, door_id: str) -> None:
        info = self.level.doors.get(door_id)
        if info is None:
            return
        info.locked = True
        for cid in info.collider_ids:
            self.level.world.set_open(cid, False)
        self.bus.emit(ev.DOOR, id=door_id, open=False)

    def power_fail(self) -> None:
        self.powered = False
        self.bus.emit(ev.POWER_FAIL)

    def set_interactable_enabled(self, iid: str, enabled: bool, reset: bool = False) -> None:
        it = self.interactables.get(iid)
        if it is not None:
            it.enabled = enabled
            if reset:
                it.used = False
                it.progress = 0.0

    def start_waves(self) -> None:
        if self.waves is not None:
            self.waves.start()

    def mr_event(self, kind: str, count: int, enemy: str) -> None:
        if self.mr_director is not None:
            self.mr_director.trigger(kind, count, enemy)

    def new_uid(self) -> int:
        u = self._next_uid
        self._next_uid += 1
        return u

    def spawn_enemy(
        self,
        enemy_id: str,
        pos: Vec3,
        yaw: float = 0.0,
        *,
        group: str = "",
        route: str | None = None,
        state: str = "idle",
        hunt: bool = False,
    ) -> Enemy:
        e = Enemy(self.new_uid(), get_enemy(enemy_id), pos.with_y(0.0), yaw, group=group)
        e.weapon.bus = None
        if route and route in self.level.patrol_routes:
            e.route = list(self.level.patrol_routes[route])
            e.route_idx = min(range(len(e.route)), key=lambda i: e.route[i].dist_xz(pos))
        if state == "patrol" and e.route:
            e._set_state(AIState.PATROL, None)
        elif state == "alert" or hunt:
            e.last_known = self.player.state.pos
            e._set_state(AIState.SEARCH if hunt else AIState.ALERT, None)
        if hunt:
            self._hunters.add(e.uid)
        self.enemies.append(e)
        return e

    def spawn_entry(self, entry: SpawnEntry, group: str, hunt: bool = False) -> list[Enemy]:
        sp = self.level.spawn_points[entry.at]
        out = []
        for i in range(entry.count):
            ang = i * 2.399963
            scale = 0.4 if self.level.kind == "mr" else 1.0
            off = Vec3(math.cos(ang), 0, math.sin(ang)) * (0.0 if entry.count == 1 else (0.9 + 0.25 * i) * scale)
            state = "alert" if entry.state == "hunt" else entry.state
            out.append(
                self.spawn_enemy(
                    entry.enemy,
                    sp.pos + off,
                    sp.yaw,
                    group=group,
                    route=entry.route,
                    state=state,
                    hunt=hunt or entry.state == "hunt",
                )
            )
        return out

    def spawn_group(self, name: str, hunt: bool = False) -> None:
        self._groups_spawned.add(name)
        for entry in self.mission.groups.get(name, []):
            self.spawn_entry(entry, name, hunt)
        if hunt:
            self.hotspot = None

    def group_spawned(self, name: str) -> bool:
        return name in self._groups_spawned

    def group_alive(self, name: str) -> int:
        return sum(1 for e in self.enemies if e.group == name and e.alive)

    def alive_enemies(self) -> list[Enemy]:
        return [e for e in self.enemies if e.alive and not e.inert]

    # ---- noise ---------------------------------------------------------------------------
    def add_noise(self, pos: Vec3, radius: float, source: str = "") -> None:
        self.noises.append(NoiseEvent(pos, radius, self.t, source))

    def _on_footstep(self, e: ev.Event) -> None:
        pos: Vec3 = e.data["pos"]
        if e.data.get("crouch"):
            return
        self.add_noise(pos, 11.0 if e.data.get("sprint") else 5.5, "footstep")

    # ---- interaction ------------------------------------------------------------------------
    def _find_interactable(self) -> InteractableState | None:
        p = self.player.state.pos
        fwd = Vec3(math.sin(self.player.state.yaw), 0, math.cos(self.player.state.yaw))
        best: tuple[float, InteractableState] | None = None
        for it in self.interactables.values():
            if not it.enabled or it.used:
                continue
            d = p.dist_xz(it.pos)
            if d > it.radius:
                continue
            to = (it.pos - p).flat().normalized()
            facing = fwd.dot(to)
            if d > 1.0 and facing < 0.35:
                continue
            if best is None or d < best[0]:
                best = (d, it)
        return best[1] if best else None

    def _update_interaction(self, dt: float, intent: PlayerIntent) -> None:
        it = self._find_interactable()
        self.interact_target = it.id if it else None
        fresh = intent.interact and not self._interact_prev
        self._interact_prev = intent.interact
        for other in self.interactables.values():
            if other is not it and other.progress > 0:
                other.progress = max(0.0, other.progress - dt * 2.0)
        if it is None:
            return
        hold = it.hold_time * (0.4 if self.settings.comfort.simplified_interaction else 1.0)
        if hold <= 0:
            if fresh:
                self._complete_interaction(it)
            return
        if intent.interact:
            it.progress += dt
            self.bus.emit(ev.INTERACTION_PROGRESS, id=it.id, fraction=min(1.0, it.progress / hold))
            if it.progress >= hold:
                self._complete_interaction(it)
        else:
            it.progress = max(0.0, it.progress - dt * 1.5)

    def _complete_interaction(self, it: InteractableState) -> None:
        it.progress = 0.0
        if it.kind == "pickup":
            wid = it.data.get("weapon", "")
            if wid:
                self.inventory.add_weapon(wid)
            it.used = True
        elif it.kind == "ammo":
            self.inventory.add_ammo(1.0)
            self.inventory.grenades = min(self.inventory.max_grenades, self.inventory.grenades + 1)
            self.bus.emit(ev.PICKUP_AMMO, id=it.id)
            it.used = True
            self._ammo_cooldowns[it.id] = 25.0
        else:
            it.used = True
        self.bus.emit(ev.INTERACTION_COMPLETE, id=it.id, kind=it.kind)

    # ---- combat -----------------------------------------------------------------------------
    def _enemy_fire(self, enemy: Enemy, origin: Vec3, direction: Vec3, spread: float) -> None:
        prof = DIFFICULTY[self.settings.game.difficulty]
        model = WeaponFireModel(enemy.weapon.spec)
        res = model.fire(
            origin,
            direction,
            Team.HELIX,
            self.level.world,
            [self.player],
            self.rng.stream("enemy_fire"),
            self.projectiles,
            spread_deg=spread,
            damage_scale=prof.enemy_damage,
            source=f"enemy{enemy.uid}",
        )
        for tr in res.traces:
            self.effects.append(Effect("tracer", tr.origin, tr.end, "red", 0.08, 0.08))
            if tr.hit_surface is not None:
                self.effects.append(Effect("impact", tr.end, color="spark", ttl=0.25, max_ttl=0.25))
        self.bus.emit(ev.ENEMY_FIRE, pos=origin, weapon=enemy.weapon.spec.id)
        self.add_noise(origin, enemy.weapon.spec.noise_radius * 0.6, "enemy_fire")
        enemy.flash_t = max(enemy.flash_t, 0.06)

    def _enemy_throw_grenade(self, enemy: Enemy, target: Vec3) -> None:
        start = enemy.pos + Vec3(0, 1.5, 0)
        d = (target - start).flat()
        dist = d.length()
        T = max(0.6, min(1.6, dist / 12.0))
        vh = d.normalized() * (dist / T)
        vy = (GRAVITY * T * T / 2 - start.y) / T
        self.grenades.append(Grenade(start, Vec3(vh.x, vy, vh.z), Team.HELIX, source=f"enemy{enemy.uid}"))
        self.bus.emit(ev.ENEMY_GRENADE, pos=target, thrower=enemy.uid)
        self.effects.append(
            Effect("grenade_warning", target, color="red", ttl=T + 1.2, max_ttl=T + 1.2, size=BLAST_RADIUS)
        )

    def _player_fire(self, dt: float, intent: PlayerIntent) -> None:
        w = self.inventory.weapon
        if w is None or not self.player.alive:
            return
        w.hand, w.support_hand = intent.hand, intent.support_hand
        recoil_scale = 0.5 if self.settings.comfort.reduced_camera_shake else 1.0
        rp, ry = w.take_recoil(dt)
        self.player.state.pitch = clamp(self.player.state.pitch + math.radians(rp) * recoil_scale, -1.45, 1.45)
        self.player.state.yaw += math.radians(ry) * recoil_scale
        if intent.reload:
            if self.settings.comfort.simplified_reload or intent.aim_override is None:
                if w.start_reload():
                    self.stats.reloads += 1
        if intent.drop_mag:
            w.drop_magazine()
        if intent.insert_mag:
            w.insert_magazine()
        if intent.charge:
            w.charge()
        if not w.pull_trigger(intent.fire):
            return
        origin, direction = self.player.aim_origin_dir(intent)
        model = WeaponFireModel(w.spec)
        spread = model.effective_spread(
            intent.aim,
            min(1.0, self.player.state.speed_xz / 4.0),
            self.player.state.stance is Stance.CROUCH,
            intent.stability,
        )
        w.consume_round()
        self.stats.shots += 1
        res = model.fire(
            origin,
            direction,
            Team.VECTOR,
            self.level.world,
            self.enemies,
            self.rng.stream("player_fire"),
            self.projectiles,
            spread_deg=spread,
            source="player",
        )
        muzzle = origin + direction * 0.5 + Vec3(0, -0.12, 0) if intent.aim_override is None else origin
        for tr in res.traces:
            self.effects.append(Effect("tracer", muzzle, tr.end, tr.tracer, 0.06, 0.06))
            if tr.hit_surface is not None:
                self.effects.append(Effect("impact", tr.end, color="spark", ttl=0.3, max_ttl=0.3))
                self.bus.emit(ev.IMPACT, pos=tr.end, material=tr.hit_surface.material.value)
        self.effects.append(Effect("flash", muzzle, color="amber", ttl=0.05, max_ttl=0.05))
        self.add_noise(self.player.state.pos, w.spec.noise_radius, "player_fire")
        if res.hits:
            self.stats.hits += 1
            self._register_hits(res, w.hand, w.support_hand)

    def _register_hits(self, res, hand: Hand, support: Hand | None) -> None:
        hands = [hand.value] + ([support.value] if support else [])
        for h in res.hits:
            self.stats.damage_dealt += h.damage
            if h.hitbox == "head":
                self.stats.headshots += 1
        self.last_hit_marker = self.t
        self.bus.emit(ev.HIT_CONFIRM, hands=hands)
        if res.kills:
            self.last_kill_marker = self.t
            self.bus.emit(ev.KILL_CONFIRM, hands=hands)

    def _update_projectiles(self, dt: float) -> None:
        if self.projectiles.active_count <= 0:
            return
        targets = [e for e in self.enemies if e.alive] + [self.player]
        for p, pt, info, _surface in self.projectiles.step(dt, self.level.world, targets):
            self.effects.append(
                Effect("impact", pt, color="blue" if p.tracer == "blue" else "spark", ttl=0.3, max_ttl=0.3)
            )
            if info is not None and p.team is Team.VECTOR:
                self.stats.hits += 1
                self.stats.damage_dealt += info.damage
                self.last_hit_marker = self.t
                self.bus.emit(ev.HIT_CONFIRM, hands=[self.player_hand().value])
                if info.killed:
                    self.last_kill_marker = self.t
                    self.bus.emit(ev.KILL_CONFIRM, hands=[self.player_hand().value])
        # tracer streaks for live projectiles
        for p in self.projectiles.pool:
            if p.active:
                self.effects.append(
                    Effect("tracer", p.pos, p.pos - p.vel.normalized() * 2.5, p.tracer, dt * 1.5, dt * 1.5)
                )

    def player_hand(self) -> Hand:
        w = self.inventory.weapon
        return w.hand if w else Hand.RIGHT

    def _throw_grenade(self, intent: PlayerIntent) -> None:
        fresh = intent.grenade and not self._grenade_prev
        self._grenade_prev = intent.grenade
        if not fresh or self.inventory.grenades <= 0 or not self.player.alive:
            return
        self.inventory.grenades -= 1
        origin, direction = self.player.aim_origin_dir(intent)
        vel = direction * 13.0 + Vec3(0, 3.2, 0)
        self.grenades.append(Grenade(origin + direction * 0.4, vel, Team.VECTOR, source="player"))
        self.stats.grenades += 1
        self.bus.emit(ev.GRENADE_THROWN, team="vector")

    def _update_grenades(self, dt: float) -> None:
        for g in list(self.grenades):
            if g.step(dt, self.level.world):
                self._explode(g)
        self.grenades = [g for g in self.grenades if g.alive]

    def _explode(self, g: Grenade) -> None:
        pos = g.pos + Vec3(0, 0.3, 0)
        self.effects.append(Effect("explosion", pos, color="amber", ttl=0.5, max_ttl=0.5, size=BLAST_RADIUS))
        dist_p = pos.dist(self.player.chest)
        self.bus.emit(ev.EXPLOSION, pos=pos, distance_to_player=dist_p)
        self.add_noise(pos, 60.0, "explosion")
        world = self.level.world
        for e in self.enemies:
            if not e.alive or e.team is g.team:
                continue
            c = e.pos + Vec3(0, 1.0, 0)
            dmg = blast_damage(c.dist(pos))
            if dmg <= 0:
                continue
            if not world.line_of_sight(pos, c):
                dmg *= 0.25
            was = e.alive
            e.apply_damage(dmg, "torso", pos, "grenade")
            if g.team is Team.VECTOR:
                self.stats.damage_dealt += dmg
                if was and not e.alive:
                    self.last_kill_marker = self.t
        dmg_p = blast_damage(dist_p)
        if dmg_p > 0 and self.player.alive:
            if not world.line_of_sight(pos, self.player.chest):
                dmg_p *= 0.25
            if g.team is Team.VECTOR:
                dmg_p *= 0.5
            self.player.apply_damage(dmg_p, "body", pos, g.source)

    # ---- main tick -----------------------------------------------------------------------------
    def step(self, dt: float, intent: PlayerIntent | None = None) -> None:
        if self.done:
            return
        intent = intent or PlayerIntent()
        self.t += dt
        self.tick += 1
        self.bus.time = self.t
        self.noises = [n for n in self.noises if self.t - n.t < NOISE_LIFETIME]
        self.nav.ensure_current(self.level.world)

        if self.player.alive:
            self.player.update(dt, intent, self.level.world)
            if intent.switch_slot is not None:
                self.inventory.switch_to(intent.switch_slot)
            if intent.cycle_weapon:
                self.inventory.cycle()
            self.inventory.update(dt)
            self._player_fire(dt, intent)
            self._throw_grenade(intent)
            self._update_interaction(dt, intent)
        self._update_projectiles(dt)
        self._update_grenades(dt)
        self._update_enemies(dt)
        self._update_cooldowns(dt)
        if self.waves is not None:
            self.waves.update(dt)
        if self.mr_director is not None:
            self.mr_director.update(dt)
        self.runner.update(dt)
        for e in self.effects:
            e.ttl -= dt
        while self.effects and self.effects[0].ttl <= 0:
            self.effects.popleft()
        if self.haptics is not None:
            self.haptics.update(dt)
        if self.runner.finished and not self.done:
            self._finalise()

    def _update_enemies(self, dt: float) -> None:
        if not self.enemies:
            return
        prof = DIFFICULTY[self.settings.game.difficulty]
        pl = self.player
        ctx = AIContext(
            player=pl,
            world=self.level.world,
            nav=self.nav,
            cover=self.cover,
            allies=self.enemies,
            noises=self.noises,
            rng=self.rng.stream("ai"),
            t=self.t,
            dt=dt,
            accuracy_mult=prof.enemy_accuracy,
            reaction_mult=prof.reaction,
            hotspot=self.hotspot,
            fire=self._enemy_fire,
            throw_grenade=self._enemy_throw_grenade,
            on_state=lambda e, o, n: self.bus.emit(ev.ENEMY_STATE, uid=e.uid, old=o.value, new=n.value),
            on_alert=lambda e: self.bus.emit(ev.ENEMY_ALERT, pos=e.pos, uid=e.uid),
        )
        updates = 0
        ppos = pl.state.pos
        for e in self.enemies:
            if e.uid in self._hunters and e.state is AIState.SEARCH and e.alive:
                if e.last_known is None or e.pos.dist_xz(e.last_known) < 2.0:
                    e.last_known = ppos
                    e.search_points = 0
                    e.goal = None
            if (
                e.alive
                and not e.inert
                and e.state in (AIState.IDLE, AIState.PATROL)
                and e.pos.dist_xz(ppos) > AI_ACTIVE_RADIUS
            ):
                continue
            if updates >= AI_MAX_UPDATES:
                break
            updates += 1
            was = e.alive
            e.update(ctx)
            if was and not e.alive:
                self.cover.release(e.uid)
        for e in self.enemies:
            if not e.alive and e.uid not in self._reported:
                self._reported.add(e.uid)
                if not e.inert:
                    self.stats.kills += 1
                self.bus.emit(
                    ev.ENEMY_DEFEATED,
                    uid=e.uid,
                    group=e.group,
                    role=e.spec.role.value,
                    pos=e.pos,
                    tag="training" if e.inert else "",
                )
            elif e.alive and e.uid in self._reported:
                self._reported.discard(e.uid)  # training target popped back up
        # drop dead hostiles after a while (bounded entity count)
        self.enemies = [e for e in self.enemies if e.alive or e.inert or e.dead_t < 6.0]

    def _update_cooldowns(self, dt: float) -> None:
        for iid in list(self._ammo_cooldowns):
            self._ammo_cooldowns[iid] -= dt
            if self._ammo_cooldowns[iid] <= 0 and self.mission.mode is not MissionMode.SURVIVAL:
                del self._ammo_cooldowns[iid]
                self.set_interactable_enabled(iid, True, reset=True)

    # ---- results -----------------------------------------------------------------------------------
    def build_result(self) -> MissionResult:
        r = self.runner
        prof = DIFFICULTY[self.settings.game.difficulty]
        waves_cleared = self.waves.waves_cleared if self.waves else 0
        primary_total = len(r.order)
        primary_done = r.primary_done
        if self.waves is not None:
            primary_total = max(1, self.waves.total)
            primary_done = min(primary_total, waves_cleared)
        score = compute_score(
            primary_done=primary_done,
            primary_total=primary_total,
            optional_done=r.optional_done,
            optional_total=r.optional_total,
            shots=self.stats.shots,
            hits=self.stats.hits,
            elapsed=r.elapsed,
            par_time=self.mission.par_time,
            damage_taken=self.player.state.damage_taken,
            completed=r.success,
            difficulty_multiplier=prof.score_multiplier,
        )
        return MissionResult(
            success=r.success,
            mission_id=self.mission.id,
            title=self.mission.title,
            reason=r.fail_reason,
            elapsed=r.elapsed,
            accuracy=self.stats.accuracy,
            shots=self.stats.shots,
            hits=self.stats.hits,
            kills=self.stats.kills,
            headshots=self.stats.headshots,
            damage_taken=self.player.state.damage_taken,
            primary_done=primary_done,
            primary_total=primary_total,
            optional_done=r.optional_done,
            optional_total=r.optional_total,
            score=score,
            waves_cleared=waves_cleared,
        )

    def _finalise(self) -> None:
        self.done = True
        self.result = self.build_result()

    def end_mission(self) -> None:
        """Force-finish (dev console / quit)."""
        if not self.done:
            self.runner.fail("Mission aborted")
            self._finalise()

    # ---- determinism helper ---------------------------------------------------------------------
    def state_hash(self) -> str:
        h = hashlib.sha256()
        p = self.player.state
        h.update(f"{self.tick}|{p.pos.x:.4f},{p.pos.z:.4f}|{p.health:.3f}|{p.yaw:.4f}".encode())
        w = self.inventory.weapon
        if w:
            h.update(f"|{w.spec.id}:{w.ammo}:{w.reserve}:{w.state.value}".encode())
        for e in self.enemies:
            h.update(f"|{e.uid}:{e.pos.x:.3f},{e.pos.z:.3f}:{e.health:.2f}:{e.state.value}".encode())
        h.update(f"|{self.runner.phase.value}:{self.runner.primary_done}:{self.rng.state_digest()}".encode())
        return h.hexdigest()[:16]

    # ---- queries for UI / renderer ------------------------------------------------------------
    def in_cover(self) -> bool:
        threats = [e.pos for e in self.enemies if e.alive and not e.inert and e.sees_player]
        if not threats:
            return False
        return (
            self.cover.player_cover_fraction(self.player.state.pos, self.player.state.stance is Stance.CROUCH, threats)
            > 0.5
        )

    def forward(self) -> Vec3:
        return forward_from_angles(self.player.state.yaw, self.player.state.pitch)
