"""JSON save system: progress, missions, weapons, settings, difficulty, accessibility, statistics.

Atomic writes (tmp + replace), schema versioning with a migration hook, and corruption-tolerant loading
(a bad file is moved aside as `.corrupt` and a fresh profile is created)."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import ClassVar

from pydantic import BaseModel, ConfigDict, Field

from ..core.config import Difficulty, Settings
from ..core.paths import user_data_dir

SCHEMA_VERSION = 2


class _S(BaseModel):
    model_config = ConfigDict(extra="ignore")


class MissionRecord(_S):
    completed: bool = False
    best_score: int = 0
    best_time: float = 0.0
    best_rank: str = ""
    attempts: int = 0
    optional_done: int = 0


class Statistics(_S):
    shots: int = 0
    hits: int = 0
    kills: int = 0
    headshots: int = 0
    deaths: int = 0
    play_seconds: float = 0.0
    missions_completed: int = 0
    grenades: int = 0

    @property
    def accuracy(self) -> float:
        return self.hits / self.shots if self.shots else 0.0


class LoadoutRecord(_S):
    primary: str = "ks4_kestrel"
    secondary: str = "p11_pilot"
    special: str = ""


class PlayerProgress(_S):
    callsign: str = "OPERATIVE"
    level: int = 1
    xp: int = 0


class SaveData(_S):
    version: int = SCHEMA_VERSION
    player_progress: PlayerProgress = PlayerProgress()
    missions: dict[str, MissionRecord] = Field(default_factory=dict)
    weapons_unlocked: list[str] = Field(
        default_factory=lambda: ["ks4_kestrel", "wr2_warden", "sp9_sparrow", "p11_pilot", "tr0_trainer"]
    )
    loadout: LoadoutRecord = LoadoutRecord()
    settings: Settings = Settings()
    difficulty: Difficulty = Difficulty.NORMAL
    accessibility: dict[str, bool] = Field(default_factory=dict)  # mirror of the comfort flags for quick reads
    statistics: Statistics = Statistics()

    UNLOCKS: ClassVar[dict[str, str]] = {"vector_01": "hm12_hammer", "vector_02": "arc9"}

    def record_result(self, r) -> list[str]:
        """Merge a MissionResult into the profile. Returns newly unlocked weapon ids."""
        rec = self.missions.setdefault(r.mission_id, MissionRecord())
        rec.attempts += 1
        st = self.statistics
        st.shots += r.shots
        st.hits += r.hits
        st.kills += r.kills
        st.headshots += r.headshots
        st.play_seconds += r.elapsed
        new: list[str] = []
        if r.success:
            rec.completed = True
            if r.score.total >= rec.best_score:
                rec.best_score, rec.best_rank = r.score.total, r.score.rank
            rec.best_time = r.elapsed if rec.best_time == 0 else min(rec.best_time, r.elapsed)
            rec.optional_done = max(rec.optional_done, r.optional_done)
            st.missions_completed += 1
            self.player_progress.xp += r.score.total // 10
            self.player_progress.level = 1 + self.player_progress.xp // 1500
            wid = self.UNLOCKS.get(r.mission_id)
            if wid and wid not in self.weapons_unlocked:
                self.weapons_unlocked.append(wid)
                new.append(wid)
        else:
            st.deaths += 1 if r.reason == "Operative down" else 0
        return new

    def sync_accessibility(self) -> None:
        c = self.settings.comfort
        self.accessibility = {
            "seated_mode": c.seated_mode,
            "reduced_motion": c.reduced_motion,
            "reduced_camera_shake": c.reduced_camera_shake,
            "simplified_reload": c.simplified_reload,
            "simplified_interaction": c.simplified_interaction,
            "haptics_reduced": self.settings.haptics.reduced,
        }
        self.difficulty = self.settings.game.difficulty


def _migrate(raw: dict) -> dict:
    v = raw.get("version", 1)
    if v < 2:
        raw.setdefault("accessibility", {})
        raw.setdefault("loadout", {})
        raw["version"] = 2
    return raw


def default_save_path() -> Path:
    return user_data_dir() / "save.json"


def save_game(data: SaveData, path: Path | None = None) -> Path:
    path = path or default_save_path()
    data.sync_accessibility()
    payload = data.model_dump(mode="json")
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".save-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as fh:
            json.dump(payload, fh, indent=2)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return path


def load_game(path: Path | None = None) -> SaveData:
    path = path or default_save_path()
    if not path.exists():
        return SaveData()
    try:
        raw = json.loads(path.read_text())
        return SaveData.model_validate(_migrate(raw))
    except Exception:
        try:
            path.replace(path.with_suffix(".corrupt"))
        except OSError:
            pass
        return SaveData()
