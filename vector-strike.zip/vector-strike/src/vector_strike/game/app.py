"""Desktop application: window, input, menus, mission flow. The simulation itself lives in GameSession."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field

import pygame

from ..audio.engine import AudioEngine, NullAudio, PygameAudio
from ..core.config import Settings, load_settings
from ..core.types import Hand
from ..haptics.devices import GamepadRumbleDevice, HapticDevice, NullHapticDevice
from ..missions.models import MissionDef, MissionMode, list_missions
from ..physics.vec import Vec3
from ..rendering.software import DebugFlags, SoftwareRenderer, ViewState
from ..rendering.viewmodel import draw_viewmodel
from ..tools.console import DevConsole
from ..ui import menu as M
from ..ui.debug import FrameTimer, draw_overlay, overlay_lines
from ..ui.hud import HudRenderer, build_hud, make_fonts
from ..ui.wrist import WristPanel, draw_wrist_preview
from ..vr.input import DesktopControls, VRInput, create_vr_input
from ..vr.mapping import VRIntentMapper
from ..weapons.spec import Slot
from .intent import PlayerIntent
from .save import SaveData, load_game, save_game
from .session import SIM_DT, GameSession

KEY_SLOTS = {pygame.K_1: Slot.PRIMARY, pygame.K_2: Slot.SECONDARY, pygame.K_3: Slot.SPECIAL}


@dataclass
class DesktopInput:
    """pygame -> PlayerIntent. Edges (reload, jump, grenade, switch) are consumed once per frame."""

    settings: Settings
    _edges: dict[str, bool] = field(default_factory=dict)
    _slot: Slot | None = None
    _cycle: bool = False
    _look: tuple[float, float] = (0.0, 0.0)

    def feed(self, e: pygame.event.Event) -> None:
        if e.type == pygame.KEYDOWN:
            if e.key == pygame.K_r:
                self._edges["reload"] = True
            elif e.key == pygame.K_g:
                self._edges["grenade"] = True
            elif e.key == pygame.K_SPACE:
                self._edges["jump"] = True
            elif e.key in KEY_SLOTS:
                self._slot = KEY_SLOTS[e.key]
            elif e.key == pygame.K_q:
                self._cycle = True
        elif e.type == pygame.MOUSEWHEEL and e.y != 0:
            self._cycle = True

    def build(self, mouse_rel: tuple[int, int], captured: bool) -> PlayerIntent:
        keys = pygame.key.get_pressed()
        btn = pygame.mouse.get_pressed(3) if captured else (False, False, False)
        sens = self.settings.player.mouse_sensitivity
        dx, dy = mouse_rel if captured else (0, 0)
        i = PlayerIntent()
        i.move_x = float(keys[pygame.K_d]) - float(keys[pygame.K_a])
        i.move_z = float(keys[pygame.K_w]) - float(keys[pygame.K_s])
        i.sprint = bool(keys[pygame.K_LSHIFT])
        i.crouch = bool(keys[pygame.K_LCTRL] or keys[pygame.K_c])
        i.fire = bool(btn[0])
        i.aim = bool(btn[2])
        i.interact = bool(keys[pygame.K_e])
        i.look_yaw = dx * sens
        i.look_pitch = -dy * sens * (-1 if self.settings.player.invert_y else 1)
        i.reload = self._edges.pop("reload", False)
        i.grenade = bool(keys[pygame.K_g])
        self._edges.pop("grenade", None)
        i.jump = self._edges.pop("jump", False)
        i.switch_slot, self._slot = self._slot, None
        i.cycle_weapon, self._cycle = self._cycle, False
        return i


def tick_intent(base: PlayerIntent, first: bool) -> PlayerIntent:
    """Edges and look deltas apply only on the first sim tick of a rendered frame."""
    if first:
        return base
    from dataclasses import replace

    return replace(base, look_yaw=0.0, look_pitch=0.0, reload=False, jump=False, switch_slot=None, cycle_weapon=False)


@dataclass
class App:
    settings: Settings
    save: SaveData
    headless: bool = False
    dev: bool = False
    vr_mode: str = "off"  # off | sim | hardware
    seed: int | None = None

    def __post_init__(self) -> None:
        pygame.init()
        w, h = self.settings.graphics.size
        flags = pygame.FULLSCREEN if self.settings.graphics.fullscreen else 0
        self.screen = pygame.display.set_mode((w, h), flags)
        pygame.display.set_caption("VECTOR STRIKE")
        self.fonts = make_fonts()
        self.hud = HudRenderer(self.fonts)
        self.clock = pygame.time.Clock()
        self.timer = FrameTimer()
        self.flags = DebugFlags()
        self.missions = list_missions()
        self.mission_by_id = {m.id: m for m in self.missions}
        self.running = True
        self.mode = "menu"
        self.stack: list[M.Screen] = []
        self.session: GameSession | None = None
        self.renderer: SoftwareRenderer | None = None
        self.audio: AudioEngine | None = None
        self.audio_backend = NullAudio() if self.headless or not self.settings.audio.enabled else PygameAudio()
        self.haptic_device: HapticDevice = NullHapticDevice() if self.headless else self._pick_haptics()
        self.ctx = M.MenuContext(
            self.settings, self.save, self.missions, self._ui_sound, self._apply_settings, self.dev
        )
        self.input = DesktopInput(self.settings)
        self.accum = 0.0
        self.captured = False
        self.view = ViewState()
        self.bob_phase = 0.0
        self.ads = 0.0
        self.console: DevConsole | None = None
        self.console_open = False
        self.console_text = ""
        self.console_log: list[str] = []
        self.show_wrist = False
        self.menu_session: GameSession | None = None
        self.menu_renderer: SoftwareRenderer | None = None
        self.menu_t = 0.0
        self.mission_def: MissionDef | None = None
        self.vr_input: VRInput | None = None
        self.vr_mapper: VRIntentMapper | None = None
        self.vr_controls = DesktopControls()
        if self.vr_mode != "off":
            self.vr_input = create_vr_input(self.vr_mode == "hardware", self.vr_controls)
            self.vr_mapper = VRIntentMapper(self.settings.comfort, self.settings.player)
        self._build_menu_scene()
        self.goto_main()

    # ---- plumbing ---------------------------------------------------------------------------------------------
    def _pick_haptics(self) -> HapticDevice:
        dev = GamepadRumbleDevice()
        return dev if dev.connect() else NullHapticDevice()

    def _ui_sound(self, kind: str) -> None:
        from . import events as ev

        if self.session is not None and self.mode in ("paused",):
            self.session.bus.emit(ev.UI_HOVER if kind == "hover" else ev.UI_SELECT)
        elif self.menu_session is not None:
            self.menu_session.bus.emit(ev.UI_HOVER if kind == "hover" else ev.UI_SELECT)

    def _apply_settings(self) -> None:
        if self.audio is not None:
            a = self.settings.audio
            self.audio.master, self.audio.effects, self.audio.spatial = a.master, a.effects, a.spatial

    def _build_menu_scene(self) -> None:
        s = GameSession.create(self.settings, "vector_01", seed=3, autostart=False)
        self.menu_session = s
        self.menu_renderer = SoftwareRenderer(s.level, self.fonts)
        self.audio_menu = AudioEngine(
            s.bus,
            self.audio_backend,
            master=self.settings.audio.master,
            effects=self.settings.audio.effects,
            spatial=False,
        )
        s.haptics.device = self.haptic_device if s.haptics else NullHapticDevice()  # type: ignore[union-attr]

    def goto_main(self) -> None:
        self.mode = "menu"
        self.stack = [M.MainMenu(self.ctx)]
        self._release_mouse()

    def _release_mouse(self) -> None:
        if not self.headless:
            pygame.event.set_grab(False)
            pygame.mouse.set_visible(True)
        self.captured = False

    def _capture_mouse(self) -> None:
        if not self.headless:
            pygame.event.set_grab(True)
            pygame.mouse.set_visible(False)
            pygame.mouse.get_rel()
        self.captured = True

    # ---- missions ----------------------------------------------------------------------------------------------
    def start_mission(self, mission_id: str) -> None:
        m = self.mission_by_id[mission_id]
        self.mission_def = m
        lo = self.save.loadout
        loadout = [w for w in (lo.primary, lo.secondary, lo.special) if w]
        self.session = GameSession.create(
            self.settings,
            m,
            seed=self.seed,
            loadout=loadout,
            haptic_device=self.haptic_device,
            autostart=False,
        )
        self.renderer = SoftwareRenderer(self.session.level, self.fonts)
        self.audio = AudioEngine(
            self.session.bus,
            self.audio_backend,
            master=self.settings.audio.master,
            effects=self.settings.audio.effects,
            spatial=self.settings.audio.spatial,
        )
        self.console = DevConsole(self.session, self.flags, self.start_mission) if self.dev else None
        self.ads, self.bob_phase, self.accum = 0.0, 0.0, 0.0
        self.mode = "briefing"
        self.stack = [M.Briefing(self.ctx, m)]
        self._release_mouse()

    def begin_play(self) -> None:
        assert self.session is not None
        self.session.start()
        self.mode = "play"
        self.stack = []
        self._capture_mouse()

    def finish_mission(self) -> None:
        s = self.session
        assert s is not None and s.result is not None
        new = self.save.record_result(s.result)
        save_game(self.save)
        self.mode = "results"
        self.stack = [M.Results(self.ctx, s.result, new)]
        self._release_mouse()

    # ---- screens ---------------------------------------------------------------------------------------------------
    def _make_screen(self, target: str) -> M.Screen | None:
        if target == "campaign":
            return M.MissionSelect(self.ctx, (MissionMode.MISSION,), "CAMPAIGN")
        if target == "loadout":
            return M.Loadout(self.ctx)
        if target == "settings":
            return M.Settings_(self.ctx, "main")
        if target == "settings:haptics":
            return M.Settings_(self.ctx, "haptics")
        if target == "settings:access":
            return M.Settings_(self.ctx, "access")
        return None

    def _apply_action(self, a: M.ScreenAction | None) -> None:
        if a is None or a.kind is M.Act.NONE:
            return
        if a.kind is M.Act.QUIT:
            self.running = False
        elif a.kind is M.Act.GOTO:
            if a.target == "mr":
                self.start_mission("mr_invasion")
                return
            scr = self._make_screen(a.target)
            if scr is not None:
                self.stack.append(scr)
        elif a.kind is M.Act.BACK:
            if len(self.stack) > 1:
                self.stack.pop()
        elif a.kind is M.Act.SAVE:
            save_game(self.save)
            if len(self.stack) > 1:
                self.stack.pop()
            elif self.mode == "results":
                pass
        elif a.kind is M.Act.START:
            self.start_mission(a.target)
        elif a.kind is M.Act.RESUME:
            if self.mode == "briefing":
                self.begin_play()
            elif self.mode == "paused":
                self.mode = "play"
                self.stack = []
                self._capture_mouse()
        elif a.kind is M.Act.RESTART:
            if self.mission_def:
                self.start_mission(self.mission_def.id)
        elif a.kind is M.Act.MENU:
            self.goto_main()

    # ---- frame --------------------------------------------------------------------------------------------------------
    def handle_event(self, e: pygame.event.Event) -> None:
        if e.type == pygame.QUIT:
            self.running = False
            return
        if self.mode == "play":
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    self.mode = "paused"
                    self.stack = [M.Pause(self.ctx)]
                    self._release_mouse()
                    return
                if e.key == pygame.K_F3:
                    self.flags.overlay = not self.flags.overlay
                elif e.key == pygame.K_TAB:
                    self.show_wrist = not self.show_wrist
                elif e.key == pygame.K_BACKQUOTE and self.console is not None:
                    self.console_open = not self.console_open
                    self.console_text = ""
                    return
                if self.console_open:
                    self._console_key(e)
                    return
            if not self.console_open:
                self.input.feed(e)
            return
        if e.type == pygame.KEYDOWN and e.key == pygame.K_F3:
            self.flags.overlay = not self.flags.overlay
        if self.stack:
            act = self.stack[-1].handle(e)
            if act is not None and act.kind is M.Act.GOTO and act.target == "loadout" and self.mode == "results":
                self.goto_main()
                self.stack.append(M.Loadout(self.ctx))
                return
            self._apply_action(act)
            if (
                self.stack
                and e.type == pygame.KEYDOWN
                and e.key == pygame.K_ESCAPE
                and len(self.stack) > 1
                and act is None
            ):
                self.stack.pop()

    def _console_key(self, e: pygame.event.Event) -> None:
        if e.key == pygame.K_RETURN:
            if self.console:
                out = self.console.run(self.console_text)
                self.console_log = (self.console_log + [f"> {self.console_text}", out])[-8:]
            self.console_text = ""
        elif e.key == pygame.K_BACKSPACE:
            self.console_text = self.console_text[:-1]
        elif e.unicode and e.unicode.isprintable():
            self.console_text += e.unicode

    def update(self, dt: float) -> None:
        self.timer.add(dt)
        if self.mode == "play" and self.session is not None:
            self._update_play(dt)
        else:
            if self.stack:
                self.stack[-1].update(dt)
            if self.menu_session is not None:
                self.menu_t += dt * 0.35
                self.menu_session.haptics.update(dt) if self.menu_session.haptics else None

    def _update_play(self, dt: float) -> None:
        s = self.session
        assert s is not None
        self.accum += min(dt, 0.1)
        rel = pygame.mouse.get_rel() if self.captured and not self.headless else (0, 0)
        intent = self._gather_intent(rel, dt)
        first = True
        n = 0
        while self.accum >= SIM_DT and n < 8:
            s.step(SIM_DT, tick_intent(intent, first))
            first = False
            self.accum -= SIM_DT
            n += 1
            if s.done:
                break
        target = 1.0 if intent.aim else 0.0
        self.ads += (target - self.ads) * min(1.0, 14 * dt)
        self.bob_phase += s.player.state.speed_xz * dt * 2.6
        if s.done and s.result is not None:
            self.finish_mission()

    def _gather_intent(self, rel: tuple[int, int], dt: float) -> PlayerIntent:
        s = self.session
        assert s is not None
        base = self.input.build(rel, self.captured and not self.console_open)
        if self.vr_input is not None and self.vr_mapper is not None:
            c = self.vr_controls
            c.move_x, c.move_z, c.fire, c.aim = base.move_x, base.move_z, base.fire, base.aim
            c.interact, c.reload, c.grenade, c.crouch, c.sprint = (
                base.interact,
                base.reload,
                base.grenade,
                base.crouch,
                base.sprint,
            )
            c.yaw, c.pitch = (
                s.player.state.yaw - self.vr_mapper.rig_yaw + base.look_yaw,
                max(-1.4, min(1.4, s.player.state.pitch + base.look_pitch)),
            )
            frame = self.vr_input.poll(s.t)
            intent = self.vr_mapper.map(frame, s, dt)
            intent.switch_slot, intent.cycle_weapon = base.switch_slot, base.cycle_weapon
            return intent
        return base

    # ---- drawing -----------------------------------------------------------------------------------------------------------
    def draw(self) -> None:
        surf = self.screen
        if self.mode in ("play", "paused", "results") and self.session is not None and self.renderer is not None:
            self._draw_world()
            if self.mode == "play":
                self._draw_hud()
        elif self.menu_session is not None and self.menu_renderer is not None:
            t = self.menu_t
            eye = Vec3(12.0 + (math.sin(t * 0.5) * 0.5 + 0.5) * 34.0, 1.7, 18.0 + math.sin(t * 0.8) * 2.0)
            view = ViewState(
                camera_override=(eye, 0.55 + math.sin(t * 0.4) * 0.25, -0.02),
                fov_deg=80,
                draw_distance=self.settings.graphics.draw_distance,
            )
            self.menu_renderer.render(self.menu_session, surf, DebugFlags(), view)
        if self.stack:
            self.stack[-1].draw(surf, self.fonts)
        if self.flags.overlay and self.session is not None and self.mode in ("play", "paused"):
            vr = (
                f"{self.vr_input.name} dom={self.settings.comfort.handedness.value}"
                if self.vr_input
                else "off (desktop)"
            )
            hb = None
            if self.session.haptics:
                ls = self.session.haptics.engine.last_samples
                hb = (ls[Hand.LEFT].amp, ls[Hand.RIGHT].amp)
            draw_overlay(
                surf,
                self.fonts,
                overlay_lines(
                    self.session,
                    self.timer,
                    vr_state=vr,
                    render_stats=self.renderer.stats if self.renderer else {},
                ),
                hb,
            )
        elif self.flags.show_fps:
            surf.blit(self.fonts["small"].render(f"{self.timer.fps:.0f} fps", True, (230, 230, 220)), (10, 10))
        if self.console_open:
            self._draw_console()

    def _view(self) -> ViewState:
        s = self.settings
        return ViewState(
            fov_deg=s.player.fov_degrees,
            draw_distance=s.graphics.draw_distance,
            reduced_motion=s.comfort.reduced_motion,
            bob_phase=self.bob_phase,
            ads=self.ads,
        )

    def _draw_world(self) -> None:
        s, r = self.session, self.renderer
        assert s is not None and r is not None
        if self.audio:
            self.audio.listener.set(s.player.state.pos, s.player.state.yaw)
        r.render(s, self.screen, self.flags, self._view())
        if self.mode == "play" and s.player.alive:
            w = s.inventory.weapon
            if w is not None:
                flash = max((e.ttl / e.max_ttl for e in s.effects if e.kind == "flash"), default=0.0)
                pos = draw_viewmodel(
                    self.screen,
                    w,
                    ads=self.ads,
                    bob_phase=self.bob_phase,
                    speed=s.player.state.speed_xz,
                    reduced_motion=self.settings.comfort.reduced_motion,
                    flash=flash,
                    t=s.t,
                )
                self._weapon_ui_pos = pos
        if not s.powered:
            ov = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            flick = 1.0 if self.settings.comfort.reduced_motion else 0.9 + 0.1 * math.sin(s.t * 3.1)
            ov.fill((40, 6, 4, int(26 * flick)))
            self.screen.blit(ov, (0, 0))
        if self.vr_mapper is not None and self.vr_mapper.vignette() > 0.02:
            self._draw_vignette(self.vr_mapper.vignette())

    def _draw_vignette(self, strength: float) -> None:
        w, h = self.screen.get_size()
        ov = pygame.Surface((w, h), pygame.SRCALPHA)
        for i in range(8):
            a = int(255 * strength * (1 - i / 8) * 0.55)
            pygame.draw.rect(ov, (0, 0, 0, a), (i * 18, i * 12, w - i * 36, h - i * 24), 22)
        self.screen.blit(ov, (0, 0))

    def _draw_hud(self) -> None:
        s = self.session
        assert s is not None
        m = build_hud(s)
        dirs = [(a, 1.0) for t, a in s.hit_dirs if s.t - t < 1.0]
        # damage direction from the latest hit
        if s.t - s.player.state.last_damage_t < 0.8:
            dirs = [(s.player.last_hit_angle, 1.0)]
        self.hud.draw(self.screen, m, 1 / 60, ads=self.ads, damage_dirs=dirs)
        if s.inventory.weapon is not None and s.player.alive:
            wp = getattr(self, "_weapon_ui_pos", (self.screen.get_width() * 0.7, self.screen.get_height() * 0.8))
            self.hud.draw_weapon_ui(self.screen, m, (int(wp[0]), int(wp[1])))
        if self.show_wrist:
            draw_wrist_preview(self.screen, WristPanel.from_hud(m), self.fonts, (24, self.screen.get_height() - 150))

    def _draw_console(self) -> None:
        w, h = self.screen.get_size()
        bg = pygame.Surface((w, 190), pygame.SRCALPHA)
        bg.fill((6, 8, 10, 225))
        self.screen.blit(bg, (0, h - 190))
        y = h - 184
        for line in self.console_log[-8:]:
            self.screen.blit(self.fonts["small"].render(line, True, (200, 200, 190)), (12, y))
            y += 16
        self.screen.blit(self.fonts["body"].render("> " + self.console_text + "_", True, (230, 168, 50)), (12, h - 34))

    # ---- loop -------------------------------------------------------------------------------------------------------------------
    def run(self) -> None:
        last = time.perf_counter()
        while self.running:
            now = time.perf_counter()
            dt = now - last
            last = now
            for e in pygame.event.get():
                self.handle_event(e)
            self.update(dt)
            self.draw()
            pygame.display.flip()
            self.clock.tick(self.settings.graphics.fps_cap)
        self.shutdown()

    def shutdown(self) -> None:
        save_game(self.save)
        self.audio_backend.shutdown()
        pygame.quit()


def make_app(
    *,
    headless: bool = False,
    dev: bool = False,
    vr_mode: str = "off",
    seed: int | None = None,
    settings: Settings | None = None,
    save: SaveData | None = None,
) -> App:
    sv = save or load_game()
    if settings is None:
        # a saved profile's settings win over the shipped defaults
        settings = sv.settings if sv.settings != Settings() else load_settings()
    if dev:
        settings.game.developer_mode = True
    sv.settings = settings
    return App(settings, sv, headless=headless, dev=dev, vr_mode=vr_mode, seed=seed)
