"""Device-independent per-tick player intent. Desktop and VR input layers both produce this."""

from __future__ import annotations

from dataclasses import dataclass

from ..core.types import Hand
from ..physics.vec import Vec3
from ..weapons.spec import Slot


@dataclass(slots=True)
class PlayerIntent:
    move_x: float = 0.0  # strafe, +right
    move_z: float = 0.0  # forward, +forward
    look_yaw: float = 0.0  # radians this tick
    look_pitch: float = 0.0
    fire: bool = False
    aim: bool = False
    reload: bool = False  # edge
    switch_slot: Slot | None = None
    cycle_weapon: bool = False
    grenade: bool = False  # edge
    interact: bool = False  # held
    sprint: bool = False
    crouch: bool = False
    jump: bool = False  # edge
    # --- VR extensions -----------------------------------------------------------------
    aim_override: tuple[Vec3, Vec3] | None = None  # (muzzle origin, direction) from controller pose
    hand: Hand = Hand.RIGHT
    support_hand: Hand | None = None
    teleport_to: Vec3 | None = None
    dash_dir: Vec3 | None = None
    room_delta: Vec3 | None = None  # physical room-scale displacement this tick
    drop_mag: bool = False
    insert_mag: bool = False
    charge: bool = False
    stability: float = 1.0  # <1 = steadier (shoulder / two-handed)
