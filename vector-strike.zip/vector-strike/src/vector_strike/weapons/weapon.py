"""Runtime weapon state: ammunition, cooldown, recoil accumulation and the reload state machine.

Reload comes in two flavours that share one state machine:
  * timed (desktop / simplified): start_reload() runs MAG_OUT -> MAG_IN -> CHAMBER -> READY on a timer
  * physical (VR): drop_magazine() / insert_magazine() / charge() are driven by hand interactions
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from ..core.types import Hand
from ..game import events as ev
from ..game.events import EventBus
from .spec import WeaponSpec


class WeaponState(str, Enum):
    READY = "ready"
    MAG_OUT = "mag_out"  # magazine removed, waiting for a fresh one
    CHAMBER_PENDING = "chamber"  # magazine seated, charging handle needed
    RELOADING_TIMED = "reloading"  # automatic timed reload in progress
    SWITCHING = "switching"


@dataclass
class Weapon:
    spec: WeaponSpec
    ammo: int = 0
    reserve: int = 0
    state: WeaponState = WeaponState.READY
    cooldown: float = 0.0
    recoil_pitch: float = 0.0  # accumulated view kick (degrees) awaiting recovery
    recoil_yaw: float = 0.0
    state_timer: float = 0.0
    _timed_stage: int = 0
    shots_since_trigger: int = 0
    trigger_held: bool = False
    bus: EventBus | None = field(default=None, repr=False)
    hand: Hand = Hand.RIGHT
    support_hand: Hand | None = None

    @staticmethod
    def create(spec: WeaponSpec, bus: EventBus | None = None, *, full: bool = True) -> Weapon:
        return Weapon(
            spec=spec,
            ammo=spec.magazine_capacity if full else 0,
            reserve=spec.reserve_default,
            bus=bus,
        )

    # ---- helpers --------------------------------------------------------
    def _emit(self, name: str, **data: object) -> None:
        if self.bus is not None:
            self.bus.emit(name, weapon=self.spec.id, hand=self.hand, support_hand=self.support_hand, **data)

    @property
    def can_fire(self) -> bool:
        return self.state is WeaponState.READY and self.cooldown <= 0.0 and self.ammo > 0

    @property
    def reloading(self) -> bool:
        return self.state in (
            WeaponState.MAG_OUT,
            WeaponState.CHAMBER_PENDING,
            WeaponState.RELOADING_TIMED,
        )

    @property
    def reserve_available(self) -> bool:
        return self.spec.infinite_reserve or self.reserve > 0

    # ---- firing ---------------------------------------------------------
    def pull_trigger(self, held: bool) -> bool:
        """Returns True if a round should be fired this tick. Handles semi/auto and dry-fire."""
        fresh = held and not self.trigger_held
        self.trigger_held = held
        if not held:
            self.shots_since_trigger = 0
            return False
        if self.state is not WeaponState.READY or self.cooldown > 0.0:
            return False
        if self.ammo <= 0:
            if fresh:
                self._emit(ev.WEAPON_DRY)
            return False
        if not self.spec.automatic and not fresh:
            return False
        return True

    def consume_round(self) -> None:
        self.ammo -= 1
        self.cooldown = self.spec.cooldown
        self.shots_since_trigger += 1
        scale = 1.0 + min(self.shots_since_trigger, 12) * 0.03
        self.recoil_pitch += self.spec.recoil * scale
        self.recoil_yaw += self.spec.recoil_yaw * ((self.shots_since_trigger * 7919) % 5 - 2) / 2.0
        self._emit(ev.WEAPON_FIRE, ammo=self.ammo, profile=self.spec.haptic)

    def take_recoil(self, dt: float, recovery_rate: float = 7.0) -> tuple[float, float]:
        """Pops recovered recoil (pitch, yaw degrees) for the view to apply gradually."""
        k = min(1.0, recovery_rate * dt)
        p, y = self.recoil_pitch * k, self.recoil_yaw * k
        self.recoil_pitch -= p
        self.recoil_yaw -= y
        return p, y

    # ---- reload: timed --------------------------------------------------
    def start_reload(self) -> bool:
        if self.reloading or self.ammo >= self.spec.magazine_capacity or not self.reserve_available:
            return False
        self.state = WeaponState.RELOADING_TIMED
        self.state_timer = 0.0
        self._timed_stage = 0
        self._emit(ev.WEAPON_RELOAD_START)
        return True

    def _timed_update(self, dt: float) -> None:
        self.state_timer += dt
        total = self.spec.reload_time
        if self._timed_stage == 0 and self.state_timer >= total * 0.25:
            self._timed_stage = 1
            self._emit(ev.MAGAZINE_DROP)
        if self._timed_stage == 1 and self.state_timer >= total * 0.65:
            self._timed_stage = 2
            self._load_magazine()
            self._emit(ev.MAGAZINE_INSERT)
        if self._timed_stage == 2 and self.state_timer >= total * 0.9 and self.spec.chamber_required:
            self._timed_stage = 3
            self._emit(ev.WEAPON_CHAMBER)
        if self.state_timer >= total:
            self.state = WeaponState.READY
            self._emit(ev.WEAPON_RELOAD_COMPLETE)

    def _load_magazine(self) -> None:
        need = self.spec.magazine_capacity - self.ammo
        take = need if self.spec.infinite_reserve else min(need, self.reserve)
        self.ammo += take
        if not self.spec.infinite_reserve:
            self.reserve -= take

    # ---- reload: physical (VR) -----------------------------------------
    def drop_magazine(self) -> bool:
        """Release the magazine. Remaining rounds go back to the reserve (tactical reload)."""
        if self.state not in (WeaponState.READY,) or self.state is WeaponState.MAG_OUT:
            return False
        if not self.reserve_available:
            return False
        if not self.spec.infinite_reserve:
            self.reserve += self.ammo
        self.ammo = 0
        self.state = WeaponState.MAG_OUT
        self._emit(ev.MAGAZINE_DROP)
        return True

    def insert_magazine(self) -> bool:
        if self.state is not WeaponState.MAG_OUT or not self.reserve_available:
            return False
        self._load_magazine()
        self._emit(ev.MAGAZINE_INSERT)
        if self.spec.chamber_required:
            self.state = WeaponState.CHAMBER_PENDING
        else:
            self.state = WeaponState.READY
            self._emit(ev.WEAPON_RELOAD_COMPLETE)
        return True

    def charge(self) -> bool:
        if self.state is not WeaponState.CHAMBER_PENDING:
            return False
        self.state = WeaponState.READY
        self._emit(ev.WEAPON_CHAMBER)
        self._emit(ev.WEAPON_RELOAD_COMPLETE)
        return True

    # ---- per-tick -------------------------------------------------------
    def update(self, dt: float) -> None:
        if self.cooldown > 0:
            self.cooldown = max(0.0, self.cooldown - dt)
        if self.state is WeaponState.RELOADING_TIMED:
            self._timed_update(dt)
        elif self.state is WeaponState.SWITCHING:
            self.state_timer -= dt
            if self.state_timer <= 0:
                self.state = WeaponState.READY

    def begin_draw(self) -> None:
        self.state = WeaponState.SWITCHING
        self.state_timer = self.spec.switch_time
        self.trigger_held = False
