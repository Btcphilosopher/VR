"""Thrown explosive (fictional 'concussion charge'): ballistic arc, bounces, fuse, falloff damage."""

from __future__ import annotations

from dataclasses import dataclass

from ..core.types import Team
from ..physics.shapes import AABB
from ..physics.vec import Vec3
from ..physics.world import World

GRAVITY = 9.81
FUSE = 2.4
BLAST_RADIUS = 6.5
BLAST_DAMAGE = 140.0


@dataclass(slots=True)
class Grenade:
    pos: Vec3
    vel: Vec3
    team: Team
    fuse: float = FUSE
    source: str = ""
    alive: bool = True
    bounces: int = 0

    def step(self, dt: float, world: World) -> bool:
        """Advance; returns True when it detonates this tick."""
        self.fuse -= dt
        self.vel = Vec3(self.vel.x, self.vel.y - GRAVITY * dt, self.vel.z)
        move = self.vel * dt
        nxt = self.pos + move
        r = 0.08
        box = AABB(nxt - Vec3(r, r, r), nxt + Vec3(r, r, r))
        hit = [c for c in world.query_aabb(box) if c.blocks_move and not c.open]
        if hit:
            # reflect on the axis with the deepest penetration direction
            c = hit[0].aabb
            cx = (c.min.x + c.max.x) / 2
            cz = (c.min.z + c.max.z) / 2
            ox, oz = (
                abs(self.pos.x - cx) - (c.max.x - c.min.x) / 2,
                abs(self.pos.z - cz) - (c.max.z - c.min.z) / 2,
            )
            if ox > oz:
                self.vel = Vec3(-self.vel.x * 0.4, self.vel.y, self.vel.z * 0.7)
            else:
                self.vel = Vec3(self.vel.x * 0.7, self.vel.y, -self.vel.z * 0.4)
            self.bounces += 1
            nxt = self.pos
        if nxt.y <= r:
            nxt = Vec3(nxt.x, r, nxt.z)
            if self.vel.y < 0:
                self.vel = Vec3(self.vel.x * 0.55, -self.vel.y * 0.35, self.vel.z * 0.55)
                if abs(self.vel.y) < 0.6:
                    self.vel = Vec3(self.vel.x, 0.0, self.vel.z)
        self.pos = nxt
        if self.fuse <= 0:
            self.alive = False
            return True
        return False


def blast_damage(dist: float, radius: float = BLAST_RADIUS, peak: float = BLAST_DAMAGE) -> float:
    if dist >= radius:
        return 0.0
    return peak * (1.0 - dist / radius) ** 1.2
