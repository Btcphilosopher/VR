"""Deterministic fire model: hitscan, projectile, penetration, spread, recoil and hit reporting."""

from __future__ import annotations

import math
import random
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Protocol

from ..core.rng import gauss_unit_disc
from ..core.types import Team
from ..physics.shapes import Hitbox, ray_aabb
from ..physics.vec import Vec3
from ..physics.world import Collider, RayHit, World
from .spec import FireMode, WeaponSpec


class Damageable(Protocol):
    team: Team

    @property
    def alive(self) -> bool: ...

    def hitboxes(self) -> list[Hitbox]: ...

    def apply_damage(self, amount: float, hitbox: str, source_pos: Vec3, source: str) -> bool:
        """Apply damage. Returns True if this killed the target."""
        ...


@dataclass(slots=True)
class HitInfo:
    target: Damageable
    hitbox: str
    damage: float
    point: Vec3
    killed: bool


@dataclass(slots=True)
class ShotTrace:
    origin: Vec3
    end: Vec3
    tracer: str
    hit_surface: Collider | None = None
    hit_target: bool = False


@dataclass(slots=True)
class FireResult:
    traces: list[ShotTrace] = field(default_factory=list)
    hits: list[HitInfo] = field(default_factory=list)
    spawned_projectiles: int = 0

    @property
    def kills(self) -> int:
        return sum(1 for h in self.hits if h.killed)


@dataclass(slots=True)
class Projectile:
    pos: Vec3 = Vec3()
    vel: Vec3 = Vec3()
    damage: float = 0.0
    ttl: float = 0.0
    team: Team = Team.NEUTRAL
    source: str = ""
    tracer: str = "amber"
    penetration: float = 0.0
    active: bool = False


def spread_direction(direction: Vec3, spread_deg: float, rng: random.Random) -> Vec3:
    """Perturb a unit direction within a cone (gaussian-biased towards the centre)."""
    if spread_deg <= 1e-6:
        return direction.normalized()
    d = direction.normalized()
    ref = Vec3(0, 1, 0) if abs(d.y) < 0.95 else Vec3(1, 0, 0)
    right = d.cross(ref).normalized()
    up = right.cross(d).normalized()
    ux, uy = gauss_unit_disc(rng)
    ang = math.radians(spread_deg)
    return (d + right * (ux * math.tan(ang)) + up * (uy * math.tan(ang))).normalized()


class WeaponFireModel:
    """Stateless per-weapon firing logic. Configurable via WeaponSpec; deterministic given an rng."""

    def __init__(self, spec: WeaponSpec) -> None:
        self.spec = spec

    def damage_at(self, base: float, dist: float) -> float:
        half = self.spec.range * 0.5
        if dist <= half:
            return base
        k = max(0.25, 1.0 - (dist - half) / max(half, 1e-6) * 0.75)
        return base * k

    def effective_spread(self, aiming: bool, moving: float, crouched: bool, stability: float = 1.0) -> float:
        s = self.spec.spread
        if aiming:
            s *= self.spec.aim_spread_mult
        s *= 1.0 + 0.6 * min(1.0, moving)
        if crouched:
            s *= 0.8
        return s * max(0.2, stability)

    def fire(
        self,
        origin: Vec3,
        direction: Vec3,
        team: Team,
        world: World,
        targets: Iterable[Damageable],
        rng: random.Random,
        projectiles: ProjectileSystem | None = None,
        *,
        spread_deg: float | None = None,
        damage_scale: float = 1.0,
        source: str = "",
    ) -> FireResult:
        spec = self.spec
        spread = spec.spread if spread_deg is None else spread_deg
        result = FireResult()
        tlist = [t for t in targets if t.alive and t.team is not team]
        for _ in range(spec.pellets):
            d = spread_direction(direction, spread, rng)
            if spec.fire_mode is FireMode.PROJECTILE and projectiles is not None:
                projectiles.spawn(
                    origin,
                    d * spec.projectile_speed,
                    spec.damage * damage_scale,
                    spec.range / spec.projectile_speed,
                    team,
                    source,
                    spec.tracer,
                )
                result.spawned_projectiles += 1
                continue
            self._hitscan(origin, d, team, world, tlist, result, damage_scale, source)
        return result

    def _hitscan(
        self,
        origin: Vec3,
        d: Vec3,
        team: Team,
        world: World,
        targets: list[Damageable],
        result: FireResult,
        damage_scale: float,
        source: str,
    ) -> None:
        spec = self.spec
        wall_hits = world.raycast_all(origin, d, spec.range)
        power = spec.penetration
        dmg_mult = 1.0
        # candidate target hits sorted along the ray
        thits: list[tuple[float, Damageable, Hitbox]] = []
        for tgt in targets:
            for hb in tgt.hitboxes():
                t = ray_aabb(origin, d, hb.box, spec.range)
                if t is not None:
                    thits.append((t, tgt, hb))
        thits.sort(key=lambda x: x[0])
        events: list[tuple[float, RayHit | tuple[Damageable, Hitbox]]] = [(t, (tg, hb)) for t, tg, hb in thits]
        events += [(h.t, h) for h in wall_hits]
        events.sort(key=lambda e: e[0])
        hit_targets: set[int] = set()
        end = origin + d * spec.range
        surface: Collider | None = None
        got_target = False
        for t, payload in events:
            if isinstance(payload, RayHit):
                h = payload
                c = h.collider
                power -= c.resistance
                if power < 0:
                    end, surface = h.point, c
                    break
                dmg_mult *= 0.6
            else:
                tg, hb = payload
                if id(tg) in hit_targets:
                    continue
                hit_targets.add(id(tg))
                dmg = self.damage_at(spec.damage, t) * hb.multiplier * dmg_mult * damage_scale
                killed = tg.apply_damage(dmg, hb.name, origin, source)
                result.hits.append(HitInfo(tg, hb.name, dmg, origin + d * t, killed))
                got_target = True
                dmg_mult *= 0.7  # bodies absorb energy
                power -= 1.0
                if power < 0:
                    end = origin + d * t
                    break
        result.traces.append(ShotTrace(origin, end, spec.tracer, surface, got_target))


class ProjectileSystem:
    """Pooled projectiles (no per-shot allocation after warm-up)."""

    def __init__(self, capacity: int = 256) -> None:
        self.pool = [Projectile() for _ in range(capacity)]
        self.active_count = 0

    def spawn(
        self, pos: Vec3, vel: Vec3, damage: float, ttl: float, team: Team, source: str, tracer: str
    ) -> Projectile | None:
        for p in self.pool:
            if not p.active:
                p.pos, p.vel, p.damage, p.ttl = pos, vel, damage, ttl
                p.team, p.source, p.tracer, p.active = team, source, tracer, True
                self.active_count += 1
                return p
        return None  # pool exhausted - drop (bounded cost)

    def step(
        self, dt: float, world: World, targets: Iterable[Damageable]
    ) -> list[tuple[Projectile, Vec3, HitInfo | None, Collider | None]]:
        """Advance projectiles; returns (projectile, impact_point, hit, surface) for each impact."""
        impacts: list[tuple[Projectile, Vec3, HitInfo | None, Collider | None]] = []
        tlist = [t for t in targets if t.alive]
        for p in self.pool:
            if not p.active:
                continue
            seg = p.vel * dt
            dist = seg.length()
            d = seg.normalized()
            best_t = dist
            hit: tuple[Damageable, Hitbox] | None = None
            surface: Collider | None = None
            wh = world.raycast(p.pos, d, dist) if dist > 0 else None
            if wh is not None:
                best_t, surface = wh.t, wh.collider
            for tg in tlist:
                if tg.team is p.team:
                    continue
                for hb in tg.hitboxes():
                    t = ray_aabb(p.pos, d, hb.box, best_t)
                    if t is not None and t <= best_t:
                        best_t, hit, surface = t, (tg, hb), None
            if hit is not None or surface is not None:
                pt = p.pos + d * best_t
                info = None
                if hit is not None:
                    tg, hb = hit
                    dmg = p.damage * hb.multiplier
                    killed = tg.apply_damage(dmg, hb.name, p.pos, p.source)
                    info = HitInfo(tg, hb.name, dmg, pt, killed)
                impacts.append((p, pt, info, surface))
                p.active = False
                self.active_count -= 1
                continue
            p.pos = p.pos + seg
            p.ttl -= dt
            if p.ttl <= 0:
                p.active = False
                self.active_count -= 1
        return impacts
