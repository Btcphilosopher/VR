"""Player inventory: three weapon slots, grenades and the active-weapon cursor."""

from __future__ import annotations

from dataclasses import dataclass, field

from ..game import events as ev
from ..game.events import EventBus
from .spec import CATALOGUE, Slot, get_spec
from .weapon import Weapon


@dataclass
class Inventory:
    bus: EventBus | None = None
    slots: dict[Slot, Weapon | None] = field(
        default_factory=lambda: {Slot.PRIMARY: None, Slot.SECONDARY: None, Slot.SPECIAL: None}
    )
    active: Slot | None = None
    grenades: int = 2
    max_grenades: int = 4

    def add_weapon(self, weapon_id: str, *, make_active: bool = True) -> Weapon:
        spec = get_spec(weapon_id)
        existing = self.slots[spec.slot]
        if existing is not None and existing.spec.id == weapon_id:
            existing.reserve += spec.magazine_capacity * 2
            return existing
        w = Weapon.create(spec, self.bus)
        self.slots[spec.slot] = w
        if make_active or self.active is None:
            self.switch_to(spec.slot, silent=True)
        if self.bus is not None:
            self.bus.emit(ev.WEAPON_PICKUP, weapon=weapon_id, hand=w.hand)
        return w

    @property
    def weapon(self) -> Weapon | None:
        return self.slots[self.active] if self.active is not None else None

    def switch_to(self, slot: Slot, *, silent: bool = False) -> bool:
        w = self.slots[slot]
        if w is None or (slot is self.active and not silent):
            return False
        prev = self.weapon
        if prev is not None:
            prev.trigger_held = False
        self.active = slot
        w.begin_draw()
        if self.bus is not None and not silent:
            self.bus.emit(ev.WEAPON_SWITCH, weapon=w.spec.id, slot=slot.value, hand=w.hand)
        return True

    def cycle(self) -> bool:
        order = [Slot.PRIMARY, Slot.SECONDARY, Slot.SPECIAL]
        start = order.index(self.active) if self.active in order else -1
        for i in range(1, 4):
            s = order[(start + i) % 3]
            if self.slots[s] is not None:
                return self.switch_to(s)
        return False

    def add_ammo(self, fraction_mags: float = 1.0) -> None:
        for w in self.slots.values():
            if w is not None and not w.spec.infinite_reserve:
                w.reserve = min(w.reserve + int(w.spec.magazine_capacity * fraction_mags), w.spec.reserve_default * 2)

    def update(self, dt: float) -> None:
        for w in self.slots.values():
            if w is not None:
                w.update(dt)

    def loadout_ids(self) -> list[str]:
        return [w.spec.id for w in self.slots.values() if w is not None]

    @staticmethod
    def weapon_ids() -> list[str]:
        return list(CATALOGUE)
