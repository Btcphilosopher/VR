"""Physical VR weapon handling: grips, shoulder/hip aiming, holsters, inspection and the magazine reload
interaction (drop -> reach -> insert -> chamber -> ready). All maths is in tracking space relative to the head,
so it is testable without a headset."""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

from ..core.config import Handedness
from ..core.types import Hand
from ..physics.vec import Vec3, right_from_yaw
from ..vr.actions import ControllerState, InputFrame, Pose
from .spec import Slot, WeaponSpec
from .weapon import Weapon, WeaponState


class GripMode(str, Enum):
    ONE_HANDED = "one_handed"
    TWO_HANDED = "two_handed"


class AimMode(str, Enum):
    HIP = "hip"
    SHOULDER = "shoulder"


@dataclass(slots=True)
class HandlingResult:
    grip: GripMode
    aim_mode: AimMode
    origin: Vec3  # muzzle position (tracking space)
    direction: Vec3
    stability: float  # multiplies spread (<1 = steadier)
    inspecting: bool


def _head_local(head: Pose, p: Vec3) -> Vec3:
    """Point relative to the head, rotated by head yaw only (x right, y up, z forward)."""
    d = p - head.position
    r = right_from_yaw(head.yaw)
    f = Vec3(math.sin(head.yaw), 0.0, math.cos(head.yaw))
    return Vec3(d.dot(r), d.y, d.dot(f))


def compute_handling(head: Pose, dom: ControllerState, sup: ControllerState, spec: WeaponSpec) -> HandlingResult:
    dpos, spos = dom.pose.position, sup.pose.position
    two = spec.two_handed and sup.grip > 0.5 and sup.tracked and dpos.dist(spos) < 0.65 and dpos.dist(spos) > 0.12
    if two:
        direction = (spos - dpos).normalized()
        grip = GripMode.TWO_HANDED
    else:
        direction = dom.pose.forward()
        grip = GripMode.ONE_HANDED
    origin = dpos + direction * (0.35 + 0.05 * spec.weight)
    loc = _head_local(head, dpos)
    shoulder = abs(loc.x) < 0.24 and 0.12 < loc.z < 0.5 and -0.28 < loc.y < 0.08
    stability = 1.0
    if grip is GripMode.TWO_HANDED:
        stability *= 0.6
    else:
        stability *= 1.2 + 0.1 * spec.weight
    if shoulder:
        stability *= 0.6
    inspecting = abs(dom.pose.roll) > 1.0 and dom.trigger < 0.2
    return HandlingResult(grip, AimMode.SHOULDER if shoulder else AimMode.HIP, origin, direction, stability, inspecting)


# ---- holsters --------------------------------------------------------------------------------------------------
@dataclass(frozen=True, slots=True)
class HolsterZone:
    name: str
    offset: Vec3  # head-local (x right, y up, z forward) for a right-handed player
    slot: Slot | None  # weapon slot drawn from this zone (None = magazine pouch)


ZONES: tuple[HolsterZone, ...] = (
    HolsterZone("hip_right", Vec3(0.22, -0.65, 0.05), Slot.SECONDARY),
    HolsterZone("shoulder_right", Vec3(0.20, -0.10, -0.22), Slot.PRIMARY),
    HolsterZone("shoulder_left", Vec3(-0.20, -0.10, -0.22), Slot.SPECIAL),
    HolsterZone("mag_pouch", Vec3(-0.20, -0.50, 0.12), None),
)
ZONE_RADIUS = 0.2


def mirror(offset: Vec3, handedness: Handedness) -> Vec3:
    return offset if handedness is Handedness.RIGHT else Vec3(-offset.x, offset.y, offset.z)


def zone_at(head: Pose, hand_pos: Vec3, handedness: Handedness, seated: bool = False) -> HolsterZone | None:
    loc = _head_local(head, hand_pos)
    drop = 0.3 if seated else 0.0
    for z in ZONES:
        o = mirror(z.offset, handedness)
        if math.dist((loc.x, loc.y, loc.z), (o.x, o.y + drop, o.z)) <= ZONE_RADIUS:
            return z
    return None


@dataclass(slots=True)
class HolsterAction:
    kind: str  # draw | holster
    slot: Slot
    hand: Hand


@dataclass
class HolsterRig:
    handedness: Handedness = Handedness.RIGHT
    seated: bool = False
    _grip_prev: dict[Hand, bool] = field(default_factory=lambda: {Hand.LEFT: False, Hand.RIGHT: False})

    def process(self, frame: InputFrame, holding: Slot | None, weapon_hand: Hand) -> HolsterAction | None:
        """Grip pressed inside a weapon zone draws that slot's weapon; releasing the weapon hand inside
        its own zone holsters (lets the player free both hands)."""
        action: HolsterAction | None = None
        for hand in (Hand.RIGHT, Hand.LEFT):
            c = frame.controller(hand)
            fresh = c.grip > 0.6 and not self._grip_prev[hand]
            self._grip_prev[hand] = c.grip > 0.6
            if not fresh:
                continue
            z = zone_at(frame.head, c.pose.position, self.handedness, self.seated)
            if z is not None and z.slot is not None and z.slot is not holding:
                action = HolsterAction("draw", z.slot, hand)
        return action


# ---- reload interaction -------------------------------------------------------------------------------------------
class ReloadStage(str, Enum):
    IDLE = "idle"
    MAG_OUT = "mag_out"  # old magazine dropped; reach for a new one
    MAG_IN_HAND = "mag_in_hand"  # support hand holds a fresh magazine
    CHAMBER = "chamber"  # magazine seated; pull the charging handle


@dataclass
class VRReloadController:
    """Drives Weapon.drop_magazine / insert_magazine / charge from hand poses.

    Gesture map (dominant = weapon hand):
      1. press A (dominant)            -> magazine released
      2. support hand grip at the pouch -> magazine in hand
      3. bring the hand to the magwell  -> magazine inserted
      4. support hand grips the rear of the weapon and pulls back -> charged -> READY
    Simplified reload: A (or the B accessibility key) completes the whole sequence as a timed reload.
    """

    stage: ReloadStage = ReloadStage.IDLE
    simplified: bool = False
    handedness: Handedness = Handedness.RIGHT
    _a_prev: bool = False
    _sup_grip_prev: bool = False
    _hist: deque = field(default_factory=lambda: deque(maxlen=24))
    _t: float = 0.0
    mag_in_hand: bool = False

    @staticmethod
    def magwell(dom: ControllerState) -> Vec3:
        p = dom.pose
        return p.position + p.forward() * 0.12 + p.up() * -0.12

    @staticmethod
    def charging_handle(dom: ControllerState) -> Vec3:
        p = dom.pose
        return p.position + p.forward() * 0.22 + p.up() * 0.07

    def process(self, frame: InputFrame, dom_hand: Hand, weapon: Weapon | None, dt: float) -> dict[str, bool]:
        """Returns intent flags: reload (timed), drop_mag, insert_mag, charge."""
        flags = {"reload": False, "drop_mag": False, "insert_mag": False, "charge": False}
        self._t += dt
        dom, sup = frame.controller(dom_hand), frame.controller(dom_hand.other)
        a_fresh = dom.a and not self._a_prev
        self._a_prev = dom.a
        if weapon is None:
            self.stage = ReloadStage.IDLE
            self.mag_in_hand = False
            return flags
        if self.simplified:
            if a_fresh and weapon.state is WeaponState.READY:
                flags["reload"] = True
            return flags

        # sync with the weapon's own state (the weapon is the source of truth)
        if weapon.state is WeaponState.READY and self.stage is not ReloadStage.IDLE:
            self.stage, self.mag_in_hand = ReloadStage.IDLE, False
        if self.stage is ReloadStage.IDLE:
            if (
                a_fresh
                and weapon.state is WeaponState.READY
                and weapon.ammo < weapon.spec.magazine_capacity + 1
                and weapon.reserve_available
            ):
                flags["drop_mag"] = True
                self.stage = ReloadStage.MAG_OUT
            return flags

        sup_grip = sup.grip > 0.6
        sup_fresh = sup_grip and not self._sup_grip_prev
        self._sup_grip_prev = sup_grip
        spos = sup.pose.position
        if self.stage is ReloadStage.MAG_OUT:
            zone = zone_at(frame.head, spos, self.handedness)
            if sup_fresh and zone is not None and zone.name == "mag_pouch":
                self.mag_in_hand = True
                self.stage = ReloadStage.MAG_IN_HAND
        elif self.stage is ReloadStage.MAG_IN_HAND:
            if sup_grip and spos.dist(self.magwell(dom)) < 0.14:
                flags["insert_mag"] = True
                self.mag_in_hand = False
                self.stage = ReloadStage.CHAMBER if weapon.spec.chamber_required else ReloadStage.IDLE
                self._hist.clear()
            elif not sup_grip:
                self.mag_in_hand = False
                self.stage = ReloadStage.MAG_OUT  # dropped it - go get another
        elif self.stage is ReloadStage.CHAMBER:
            ch = self.charging_handle(dom)
            if sup_grip and spos.dist(ch) < 0.22:
                axis = dom.pose.forward()
                along = (spos - dom.pose.position).dot(axis)
                self._hist.append((self._t, along))
                recent = [a for t, a in self._hist if self._t - t < 0.5]
                if recent and max(recent) - min(recent) >= 0.12 and recent[-1] < max(recent) - 0.08:
                    flags["charge"] = True
                    self.stage = ReloadStage.IDLE
                    self._hist.clear()
            else:
                self._hist.clear()
        return flags
