"""Fictional weapon catalogue. All designs, names and numbers are original game mechanics."""

from __future__ import annotations

from dataclasses import dataclass, replace
from enum import Enum
from typing import Any

from ..haptics.profile import HapticProfile


class WeaponKind(str, Enum):
    RIFLE = "rifle"
    CARBINE = "carbine"
    SMG = "smg"
    SHOTGUN = "shotgun"
    SIDEARM = "sidearm"
    ENERGY = "energy"
    TRAINING = "training"


class FireMode(str, Enum):
    HITSCAN = "hitscan"
    PROJECTILE = "projectile"


class Slot(str, Enum):
    PRIMARY = "primary"  # key 1
    SECONDARY = "secondary"  # key 2
    SPECIAL = "special"  # key 3


@dataclass(frozen=True, slots=True)
class WeaponSpec:
    id: str
    name: str
    kind: WeaponKind
    slot: Slot
    damage: float
    rate_of_fire: float  # rounds per minute
    magazine_capacity: int
    reload_time: float  # seconds (desktop / simplified full reload)
    spread: float  # degrees, hip-fire cone half-angle
    recoil: float  # degrees of view kick per shot
    range: float  # metres (damage falls off past range/2)
    reserve_default: int
    weight: float  # kg; affects handling stability
    handling: float  # 0..1; higher = faster aim/switch
    automatic: bool = True
    fire_mode: FireMode = FireMode.HITSCAN
    projectile_speed: float = 0.0
    pellets: int = 1
    penetration: float = 3.0
    noise_radius: float = 45.0
    aim_spread_mult: float = 0.35
    recoil_yaw: float = 0.25
    two_handed: bool = True
    infinite_reserve: bool = False
    chamber_required: bool = True
    tracer: str = "amber"
    haptic: HapticProfile = HapticProfile()

    @property
    def cooldown(self) -> float:
        return 60.0 / self.rate_of_fire

    @property
    def switch_time(self) -> float:
        return 0.55 - 0.35 * self.handling


CATALOGUE: dict[str, WeaponSpec] = {
    s.id: s
    for s in [
        WeaponSpec(
            "ks4_kestrel",
            "KS-4 Kestrel",
            WeaponKind.RIFLE,
            Slot.PRIMARY,
            damage=24,
            rate_of_fire=650,
            magazine_capacity=30,
            reload_time=2.2,
            spread=1.6,
            recoil=0.9,
            range=120,
            reserve_default=120,
            weight=3.6,
            handling=0.55,
            penetration=3.5,
            haptic=HapticProfile(kick=0.85, kick_ms=14, tail_ms=70, freq=0.40),
        ),
        WeaponSpec(
            "wr2_warden",
            "WR-2 Warden",
            WeaponKind.CARBINE,
            Slot.PRIMARY,
            damage=20,
            rate_of_fire=750,
            magazine_capacity=30,
            reload_time=1.9,
            spread=1.9,
            recoil=0.75,
            range=90,
            reserve_default=120,
            weight=2.9,
            handling=0.7,
            penetration=2.5,
            haptic=HapticProfile(kick=0.7, kick_ms=12, tail_ms=55, freq=0.50),
        ),
        WeaponSpec(
            "sp9_sparrow",
            "SP-9 Sparrow",
            WeaponKind.SMG,
            Slot.PRIMARY,
            damage=15,
            rate_of_fire=900,
            magazine_capacity=32,
            reload_time=1.7,
            spread=2.6,
            recoil=0.55,
            range=55,
            reserve_default=128,
            weight=2.2,
            handling=0.85,
            penetration=1.5,
            noise_radius=38.0,
            two_handed=False,
            haptic=HapticProfile(kick=0.5, kick_ms=8, tail_ms=40, freq=0.65, support_scale=0.3),
        ),
        WeaponSpec(
            "hm12_hammer",
            "HM-12 Hammer",
            WeaponKind.SHOTGUN,
            Slot.PRIMARY,
            damage=11,
            rate_of_fire=80,
            magazine_capacity=6,
            reload_time=3.0,
            spread=4.5,
            recoil=3.2,
            range=28,
            reserve_default=36,
            weight=3.9,
            handling=0.4,
            automatic=False,
            pellets=8,
            penetration=1.0,
            noise_radius=60.0,
            haptic=HapticProfile(kick=1.0, kick_ms=22, tail_ms=140, freq=0.22, support_scale=0.6),
        ),
        WeaponSpec(
            "p11_pilot",
            "P-11 Pilot",
            WeaponKind.SIDEARM,
            Slot.SECONDARY,
            damage=22,
            rate_of_fire=330,
            magazine_capacity=12,
            reload_time=1.4,
            spread=1.2,
            recoil=1.1,
            range=55,
            reserve_default=60,
            weight=0.9,
            handling=0.95,
            automatic=False,
            penetration=2.0,
            noise_radius=35.0,
            two_handed=False,
            haptic=HapticProfile(kick=0.65, kick_ms=10, tail_ms=50, freq=0.6, support_scale=0.35),
        ),
        WeaponSpec(
            "arc9",
            "ARC-9 Pulse Rifle",
            WeaponKind.ENERGY,
            Slot.SPECIAL,
            damage=28,
            rate_of_fire=420,
            magazine_capacity=24,
            reload_time=2.0,
            spread=0.8,
            recoil=0.4,
            range=100,
            reserve_default=96,
            weight=3.1,
            handling=0.6,
            fire_mode=FireMode.PROJECTILE,
            projectile_speed=90.0,
            penetration=0.0,
            noise_radius=22.0,
            tracer="blue",
            chamber_required=False,
            haptic=HapticProfile(kick=0.55, kick_ms=26, tail_ms=90, freq=0.85, support_scale=0.5),
        ),
        WeaponSpec(
            "tr0_trainer",
            "TR-0 Trainer",
            WeaponKind.TRAINING,
            Slot.PRIMARY,
            damage=12,
            rate_of_fire=500,
            magazine_capacity=20,
            reload_time=1.2,
            spread=1.0,
            recoil=0.3,
            range=80,
            reserve_default=0,
            weight=1.8,
            handling=0.8,
            infinite_reserve=True,
            chamber_required=False,
            noise_radius=20.0,
            haptic=HapticProfile(kick=0.3, kick_ms=8, tail_ms=40, freq=0.7, support_scale=0.3),
        ),
    ]
}


def get_spec(weapon_id: str) -> WeaponSpec:
    return CATALOGUE[weapon_id]


def enemy_variant(base_id: str, *, damage: float, spread: float, **kw: Any) -> WeaponSpec:
    """Enemy-tuned copy of a catalogue weapon (reduced damage, own spread)."""
    return replace(CATALOGUE[base_id], damage=damage, spread=spread, **kw)
