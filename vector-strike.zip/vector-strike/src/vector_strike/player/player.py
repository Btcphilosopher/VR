"""Player state and controller."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum

from ..core.config import PlayerCfg
from ..core.types import Team
from ..game import events as ev
from ..game.events import EventBus
from ..game.intent import PlayerIntent
from ..physics.shapes import AABB, Hitbox
from ..physics.vec import ZERO, Vec3, clamp, forward_from_angles, right_from_yaw, wrap_angle
from ..physics.world import World

STAND_EYE = 1.65
CROUCH_EYE = 1.05
SEATED_EYE_DROP = 0.35
RADIUS = 0.32
GRAVITY = 14.0
JUMP_V = 4.6
REGEN_DELAY = 4.0


class Stance(str, Enum):
    STAND = "stand"
    CROUCH = "crouch"


@dataclass
class PlayerState:
    pos: Vec3 = ZERO
    vel: Vec3 = ZERO
    yaw: float = 0.0
    pitch: float = 0.0
    health: float = 100.0
    max_health: float = 100.0
    stance: Stance = Stance.STAND
    grounded: bool = True
    sprinting: bool = False
    speed_xz: float = 0.0
    last_damage_t: float = -99.0
    damage_taken: float = 0.0
    step_accum: float = 0.0
    god_mode: bool = False
    seated: bool = False


@dataclass
class Player:
    cfg: PlayerCfg
    bus: EventBus
    state: PlayerState = field(default_factory=PlayerState)
    team: Team = Team.VECTOR
    damage_multiplier: float = 1.0
    regen_rate: float = 8.0
    last_hit_angle: float = 0.0

    # ---- Damageable -----------------------------------------------------
    @property
    def alive(self) -> bool:
        return self.state.health > 0.0

    @property
    def eye_height(self) -> float:
        h = CROUCH_EYE if self.state.stance is Stance.CROUCH else STAND_EYE
        return h - (SEATED_EYE_DROP if self.state.seated else 0.0)

    @property
    def eye(self) -> Vec3:
        return self.state.pos + Vec3(0, self.eye_height, 0)

    @property
    def forward(self) -> Vec3:
        return forward_from_angles(self.state.yaw, self.state.pitch)

    @property
    def chest(self) -> Vec3:
        return self.state.pos + Vec3(0, self.eye_height - 0.35, 0)

    def hitboxes(self) -> list[Hitbox]:
        p = self.state.pos
        h = self.eye_height + 0.15
        r = RADIUS
        head_y = self.eye_height
        return [
            Hitbox(
                "head",
                AABB(Vec3(p.x - 0.14, head_y - 0.18, p.z - 0.14), Vec3(p.x + 0.14, head_y + 0.12, p.z + 0.14)),
                1.8,
            ),
            Hitbox("body", AABB(Vec3(p.x - r, p.y, p.z - r), Vec3(p.x + r, p.y + h - 0.3, p.z + r)), 1.0),
        ]

    def apply_damage(self, amount: float, hitbox: str, source_pos: Vec3, source: str) -> bool:
        if not self.alive or self.state.god_mode:
            return False
        dmg = amount * self.damage_multiplier
        self.state.health = max(0.0, self.state.health - dmg)
        self.state.last_damage_t = self.bus.time
        self.state.damage_taken += dmg
        # angle of the attacker relative to where the player is looking (+ = right)
        to = source_pos - self.state.pos
        rel = wrap_angle(math.atan2(to.x, to.z) - self.state.yaw)
        self.last_hit_angle = rel
        self.bus.emit(ev.PLAYER_DAMAGED, amount=dmg, angle=rel, source=source, health=self.state.health)
        if self.state.health <= 0.0:
            self.bus.emit(ev.PLAYER_DOWN)
            return True
        return False

    # ---- controller -----------------------------------------------------
    def apply_look(self, intent: PlayerIntent) -> None:
        s = self.state
        s.yaw = wrap_angle(s.yaw + intent.look_yaw)
        s.pitch = clamp(s.pitch + intent.look_pitch, math.radians(-85), math.radians(85))

    def update(self, dt: float, intent: PlayerIntent, world: World) -> None:
        s = self.state
        if not self.alive:
            return
        self.apply_look(intent)
        s.stance = Stance.CROUCH if intent.crouch else Stance.STAND
        s.sprinting = intent.sprint and s.stance is Stance.STAND and intent.move_z > 0.2 and not intent.aim

        speed = self.cfg.movement_speed
        if s.sprinting:
            speed *= self.cfg.sprint_multiplier
        if s.stance is Stance.CROUCH:
            speed *= 0.55
        if intent.aim:
            speed *= 0.7

        wish = Vec3(0, 0, 0)
        fwd = Vec3(math.sin(s.yaw), 0, math.cos(s.yaw))
        right = right_from_yaw(s.yaw)
        wish = fwd * intent.move_z + right * intent.move_x
        if wish.length() > 1.0:
            wish = wish.normalized()
        target_v = wish * speed
        # snappy acceleration (arcade responsiveness), a little air control
        k = min(1.0, (18.0 if s.grounded else 4.0) * dt)
        s.vel = Vec3(s.vel.x + (target_v.x - s.vel.x) * k, s.vel.y, s.vel.z + (target_v.z - s.vel.z) * k)

        if intent.jump and s.grounded and s.stance is Stance.STAND:
            s.vel = Vec3(s.vel.x, JUMP_V, s.vel.z)
            s.grounded = False
        if not s.grounded:
            s.vel = Vec3(s.vel.x, s.vel.y - GRAVITY * dt, s.vel.z)

        delta = s.vel * dt
        if intent.room_delta is not None:
            delta = delta + intent.room_delta
        height = self.eye_height + 0.15
        s.pos, grounded = world.move_and_collide(s.pos, delta, RADIUS, height)
        if grounded and s.vel.y < 0:
            s.vel = Vec3(s.vel.x, 0.0, s.vel.z)
        s.grounded = grounded
        s.speed_xz = Vec3(s.vel.x, 0, s.vel.z).length()

        if intent.teleport_to is not None:
            s.pos = Vec3(intent.teleport_to.x, 0.0, intent.teleport_to.z)
            s.vel = ZERO
            self.bus.emit(ev.TELEPORT, pos=s.pos)
        if intent.dash_dir is not None:
            self.bus.emit(ev.DASH, direction=intent.dash_dir)

        # footsteps
        if s.grounded and s.speed_xz > 0.5:
            s.step_accum += s.speed_xz * dt
            stride = 2.1 if s.sprinting else 1.6
            if s.step_accum >= stride:
                s.step_accum = 0.0
                self.bus.emit(ev.FOOTSTEP, pos=s.pos, sprint=s.sprinting, crouch=s.stance is Stance.CROUCH)

        # health regeneration (readability: brief, after a quiet period)
        if s.health < s.max_health and self.bus.time - s.last_damage_t > REGEN_DELAY:
            s.health = min(s.max_health, s.health + self.regen_rate * dt)

    def aim_origin_dir(self, intent: PlayerIntent) -> tuple[Vec3, Vec3]:
        if intent.aim_override is not None:
            return intent.aim_override
        return self.eye + self.forward * 0.3 - Vec3(0, 0.0, 0.0), self.forward
