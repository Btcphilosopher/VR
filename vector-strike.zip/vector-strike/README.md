# VECTOR STRIKE

An original-IP **first-person VR / AR / MR action shooter vertical slice**, written in Python 3.12.
Fast, tactile and cinematic in intent; **fully playable on a desktop with no headset**, with a headset-agnostic
VR input stack, a mixed-reality room abstraction with a synthetic room scanner, and a complete haptics pipeline.

> Factions, characters, weapons, maps, UI and terminology are all original and fictional
> (**Vector Response Group** vs **HELIX**). Nothing is derived from any existing franchise.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"          # pygame, numpy, pydantic, pyyaml, pillow (+ pytest, ruff, mypy)
python -m vector_strike          # desktop mode: main menu
python -m vector_strike --mission training
python -m vector_strike --dev    # developer console (`) and tools
python -m vector_strike --vr sim # drive the game through the full VR input stack with an emulated headset
python -m vector_strike --selftest          # the 18-step acceptance walkthrough, headless
python -m vector_strike --headless-sim vector_01   # scripted bot plays a mission, prints the result
```

### Desktop controls

| Input | Action | | Input | Action |
|---|---|---|---|---|
| WASD | move | | R | reload |
| Mouse | look | | 1 / 2 / 3 | weapon slots (Q / wheel cycles) |
| Left mouse | fire | | G | grenade |
| Right mouse | aim down sights | | E | interact (hold) |
| Shift | sprint | | Space | jump |
| Ctrl / C | crouch | | Esc | menu / pause |
| F3 | debug overlay | | Tab | wrist-panel preview |
| ` | dev console (`--dev`) | | | |

## What is in the slice

| Area | Delivered |
|---|---|
| Modes | Campaign (BLACKOUT, TRANSIT), Survival/BREACH (5 waves incl. elite + boss), Training (8 drills + MR interaction), MR Invasion |
| Weapons | 7 fictional weapons (rifle, carbine, SMG, shotgun, sidearm, energy, trainer), hitscan + projectile + penetration + spread + recoil + tracers; timed **and** physical VR reload state machine |
| Haptics | Per-hand mixer, 20 authored patterns, weapon-profile recoil, directional damage, explosions, heartbeat, rate limiting, ducking, accessibility scaling, pluggable devices |
| Enemy AI | 9-state machine; vision/hearing/damage/ally/objective awareness; cover, flank, suppress, retreat, grenades; 5 role archetypes + boss phases |
| VR | `VRInput` abstraction, teleport / smooth / room-scale / dash / scripted movement, snap+smooth turn, vignette, seated, handedness, holsters, two-handed grip, shoulder aim, inspection |
| MR | `MixedRealityEnvironment` (planes, portals, surfaces, spatial objects, anchors, spawn/cover/breach points, validation, JSON), `MR-DEMO-ROOM-001` scanner simulator, passthrough abstraction (OpenCV + synthetic) |
| Systems | data-driven YAML missions, transparent scoring, JSON saves (atomic, migrating), pydantic config, dev console, F3 overlay, spatial audio abstraction, networking interfaces, procedural asset generator |
| Quality | 149 automated tests (incl. deterministic simulation + full bot playthroughs), `ruff` clean, `mypy` clean (78 files) |

## Repository layout

```
vector-strike/
├── src/vector_strike/
│   ├── game/        session (headless sim), app (pygame), events, intent, save, state
│   ├── player/      controller, stance, damage
│   ├── weapons/     specs, runtime weapon, fire model, grenades, inventory, VR handling
│   ├── enemies/     specs, AI state machine, cover system
│   ├── missions/    YAML schema, runner, waves, scoring, procedural levels
│   ├── physics/     vec/AABB/raycast, spatial-hash world, collision
│   ├── nav/         A* nav grid
│   ├── haptics/     patterns, mixer engine, devices, director
│   ├── vr/          actions, input backends, locomotion, intent mapping
│   ├── mr/          anchors, environment, scanner sim, passthrough, director
│   ├── rendering/   software renderer, palette, viewmodel
│   ├── audio/       event->sound, procedural synthesis, spatialisation
│   ├── ui/          HUD, wrist panel, menus, debug overlay
│   ├── net/         replication interfaces (+ loopback reference)
│   ├── assets/      procedural props (deterministic)
│   └── tools/       bot, dev console, art generator, screenshots, acceptance
├── assets/          concept_art, environments, weapons, characters, props, ui, textures, audio, generated
├── configs/         default.yaml, missions/*.yaml
├── docs/            ARCHITECTURE, HAPTICS, VR_MR, ART_BIBLE, art/*
├── tests/  scripts/  pyproject.toml  requirements.txt
```

## Honest status and limits

* **Rendering** is a deliberately simple pygame software renderer (boxes, painter's algorithm) so the entire game runs
  anywhere. There is **no stereo/OpenXR swapchain renderer**; `rendering.Renderer` is the seam where a ModernGL/OpenXR
  renderer plugs in. Art is graybox + procedural.
* **OpenXR / vendor SDK** adapters (`vr.OpenXRInput`, `mr.OpenXRSpatialProvider`, `haptics.OpenXRHapticDevice`) are
  integration points. They fall back cleanly when unavailable and have **not been tested against a headset**.
* **Concept art**: no image-generation model was available, so the art package ships production-ready prompts
  (`docs/art/CONCEPT_PROMPTS.md`, `assets/concept_art/*.json`) plus procedural placeholders rendered from the game itself
  (`assets/generated/*.png`).
* **Audio** is synthesised procedurally (no binary assets).
* **Networking** is interfaces only (`net.interfaces`) - no multiplayer.
* Python is the gameplay/sim language; a shipping VR title would move the hot loops (render, physics, XR) to native code
  behind the same interfaces.

See `docs/ARCHITECTURE.md`, `docs/HAPTICS.md`, `docs/VR_MR.md` and `docs/ART_BIBLE.md`.
