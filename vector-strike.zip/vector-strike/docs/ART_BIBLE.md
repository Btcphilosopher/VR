# Art Bible

**One line:** late-2020s military technology + industrial architecture + cinematic action film + realistic VR.
No neon cyberpunk, no purple gradients, no anime, no cartoon UI, no excessive holograms, no generic sci-fi corridors.

## Palette (`rendering/palette.py`)
Graphite `#1C1E21`, concrete `#5C5E60`, steel `#70777E`, olive `#4A4F3C`, **amber `#E0A030`** (player-relevant information, work lights),
**restrained blue `#3D6C8F`** (objective bearing, cover, server rooms), **red `#C0392B`** (danger only). Fog `#0D0F12`.

## Lighting
Practical, motivated sources only. Mains lights (cool white / warm) go dark on power failure; emergency red/amber lights take over and the
whole frame tints. Static lighting is baked per object and cached; entities sample the nearest lights.

## Environments (procedural, graybox)
* **Halden Works** (BLACKOUT): service yard, loading hall (containers, barriers, crates), security office, offices, corridor with blast door,
  server hall (racks, low walls), loading dock for extraction.
* **Kessler Interchange** (TRANSIT): entry plaza, concourse (pillars, ticket barriers, benches), service tunnel, control room, platform with train cars, lockdown shutter.
* **Forward Post** (BREACH): operations bay with four breach doors, barricades, resupply cache.
* **MR room**: domestic floor, walls, furniture as cover, virtual alcoves behind portals and breach panels.
* **Training hall**: stations for movement, aiming, weapons, grenades, cover, MR terminal.
Modules: concrete, steel, pipes, machinery, loading bays, offices, server rooms, platforms, tracks, concourses, control rooms, service tunnels, roads/alleys/warehouses (urban
service area is specified in the prompt library; the playable slice ships the four interiors above).

## Characters
**Vector Operative** - muted olive plate carrier, restrained blue marker light, wrist computer, tracked gloves.
**HELIX Operative** - graphite uniform, low-reflectance carrier, ballistic helmet with a small **red** identification band; elite/commander add **amber** trim and a chest light bar. Practical equipment, no excessive sci-fi armour.

## Weapons (`docs/art/WEAPONS.md`)
KS-4 Kestrel (rifle), WR-2 Warden (carbine), SP-9 Sparrow (SMG), HM-12 Hammer (shotgun), P-11 Pilot (sidearm), ARC-9 Pulse Rifle (energy), TR-0 Trainer.
Each has side profile, first-person, reload view, magazine, attachment configuration and materials; style = professional military-industrial product photography, no maker branding.

## UI
See `docs/art/UI_HUD_SPEC.md`. Rules: nothing glued to the face; ammo on the weapon; objectives in world space and on the wrist; damage indicators only when relevant; monospaced data type.

## Menus and screens
Main menu over a slowly dollying industrial scene (very subtle motion), mission select (location, difficulty, duration, objectives, completion), loadout (stat panel),
briefing (typed text on graphite), results (stats + transparent score table), settings with Haptics and Accessibility sub-pages. Rendered examples:
`assets/generated/menu_*.png`, `briefing_blackout.png`, `results_screen.png`.

## MR interface concepts
Breach = thin amber outline on the real wall that opens; floor spawns = small circular glyphs; objective = a terminal standing on the real table; furniture edges tinted green in
the debug mesh view; extraction = a floor ring around the player's play area. See `assets/generated/mr_invasion_room.png`.

## Deliverables
| Item | Location | State |
|---|---|---|
| 15 concept-art prompts (menu, FPV, facility, terminal, weapons, enemy, player kit, wrist UI, MR room, briefing, loading, results, inventory, mission select, key art) | `docs/art/CONCEPT_PROMPTS.md`, `assets/concept_art/*.json` | prompts only (no generator available) |
| Weapon & character specs with per-view prompts | `docs/art/WEAPONS.md`, `assets/weapons/*.json`, `assets/characters/*.json` | complete |
| Procedural props (OBJ + metadata, deterministic) | `assets/props/` | 56 files, regenerate with `--generate-assets` |
| In-engine placeholder renders | `assets/generated/*.png` | regenerate with `--screenshots` |
