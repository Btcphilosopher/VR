# Concept Art Prompt Library

Global style block (append to every prompt):

> late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos

## 01_main_menu - Main menu key art
*Aspect 16:9*

Slow-moving industrial interior at night seen through a low-angle camera, wet concrete floor reflecting amber work lights, steel gantries and stacked shipping containers receding into haze, a lone operative silhouette in practical plate carrier far off-centre, large negative space on the left for the title VECTOR STRIKE in a restrained grotesque sans (white, wide tracking), thin amber rule under the title

## 02_first_person_environment - First-person environment frame
*Aspect 16:9*

First-person VR view down a concrete loading hall, lowered rifle with weapon-mounted ammo counter in amber, low barrier cover mid-ground, overhead strip lights half-failed, volumetric dust, subtle red warning beacon at far end, depth-of-field tuned for headset comfort, no flat HUD on the face

## 03_industrial_facility - Industrial facility - Halden Works
*Aspect 21:9*

Exterior establishing shot of a fictional research and logistics complex at night: brutalist concrete blocks, rooftop plant, steel service stairs, sodium-amber floodlights, one lit server wing with cold blue glow, rain-slick asphalt service yard, security cameras with red status LEDs

## 04_transport_terminal - Transport terminal - Kessler Interchange
*Aspect 21:9*

High-speed rail terminal concourse at night, long platform with parked train cars in matte steel, concrete pillars, wayfinding in plain white-on-graphite signage, amber emergency lighting after a blackout, service tunnel entrance with hazard stripes, no real station branding

## 05_weapon_renders - Weapon hero renders (all seven)
*Aspect 16:9*

Professional military-industrial product photography on a graphite sweep, three-quarter studio lighting, matte polymer and hard-anodised aluminium, no manufacturer branding, small engraved model numbers (KS-4, WR-2, SP-9, HM-12, P-11, ARC-9, TR-0) only

## 06_enemy_character - HELIX Operative
*Aspect 3:2*

Full-body design sheet of a paramilitary technology contractor: dark graphite uniform, low-reflectance plate carrier, ballistic helmet with a small red identification band, practical comms headset, gloves, boots, modular pouches; elite variant with amber trim; front/side/back views, material callouts; avoid excessive sci-fi armour

## 07_player_equipment - Vector Operative equipment
*Aspect 3:2*

Equipment layout: muted olive plate carrier with MOLLE-style webbing, wrist computer on the left forearm (amber-on-graphite readout), magazine pouch left hip, sidearm holster right hip, helmet with restrained blue marker light, field radio, gloves with controller-tracking rings

## 08_vr_wrist_ui - VR wrist interface
*Aspect 16:9*

Concept of a world-space forearm display: matte graphite bezel, amber monospaced data (health %, ammo, heading, timer), thin blue accent for objective bearing, red only for warnings; physical buttons on the bezel; shown from the player's first-person view

## 09_mr_room - Mixed-reality room
*Aspect 16:9*

Passthrough living room with virtual overlays: translucent amber breach outline on a real wall, a virtual terminal standing on the real table, floor spawn markers as thin circular glyphs, furniture edges tinted green to show cover; restrained, no hologram excess

## 10_mission_briefing - Mission briefing screen
*Aspect 16:9*

Dark briefing table scene: top-down satellite-style plan of the complex drawn as thin amber line-work on graphite, objective pins, typed mission text block, paper dossier edge, subtle scan-line

## 11_loading_screen - Loading screen
*Aspect 16:9*

Minimal loading frame: single industrial detail (steel door seam with amber light spill) with a thin progress rule and a one-line tip, huge negative space

## 12_results_screen - Results screen
*Aspect 16:9*

After-action report layout: left column of stats in amber/white monospace, right column transparent score breakdown table, rank letter large in steel white, background a desaturated freeze-frame of the extraction vehicle

## 13_inventory - Inventory / loadout
*Aspect 16:9*

Loadout bay: weapon on a graphite rack under a single overhead lamp, stat bars as thin amber lines, attachment ghost outlines, equipment hanging on pegboard, no sci-fi hologram

## 14_mission_select - Mission selection
*Aspect 16:9*

Operations room wall: a row of mission folders (BLACKOUT, TRANSIT, BREACH, INVASION) pinned on corkboard-free steel panels, each with a location photo, difficulty pips and a completion stamp in red/blue

## 15_environment_key_art - Environment key art
*Aspect 21:9*

Wide cinematic key art: Vector operatives breach a dark server hall as the facility power fails, emergency amber/red lighting cutting through haze, silhouettes of HELIX contractors behind server racks, strong depth layers, anamorphic flare restrained
