# HUD & UI Specification

## Principles
- Nothing permanently glued to the face. Information lives on the **weapon**, in the **world**, on the **wrist**, or at the screen
  edge *only when relevant*.
- Colour roles: **amber** = player-relevant information, **cold blue** = objective bearing / cover state, **red** = danger only.
- One typeface family: monospaced for data (DejaVu Sans Mono fallback), grotesque sans for titles. Sizes tuned for >= 1.5 deg legibility in VR.

## Elements
| Element | Desktop | VR / MR | Behaviour |
|---|---|---|---|
| Reticle | 4 ticks + dot, centre | none (physical sights; soft aim dot optional) | fades 70% while aiming |
| Ammo | weapon-mounted readout | on the weapon body, rotates with the weapon | turns red <= 20% mag; shows INSERT MAG / CHARGE in physical reload |
| Health | thin bar bottom-left, hidden at full health | wrist panel + haptic heartbeat | red vignette below 30% |
| Damage direction | red wedge on a ring | wedge ring at 1.2 m + left/right haptic bias | 0.8 s |
| Objective | small text top-centre | wrist panel + world-space marker | marker = floor ring, vertical beam, diamond, distance |
| Interaction prompt | below reticle, progress bar | above the interactable, world-locked | hold-to-confirm; simplified-interaction shortens holds |
| Mission timer | top-right (only when a fail timer runs) | wrist panel | red below 30 s |
| Hit / kill marker | white X / red ring | haptic tick (+ small X) | 0.18 s / 0.35 s |

## Wrist interface
Left forearm, 14 x 8 cm, tilt-to-wake. Page *status* (HP, objective, ammo, heading, timer). Page *menu* opens the floating menu
(MISSION, LOADOUT, TRAINING, SETTINGS, ACCESSIBILITY, EXIT).

## Floating menu (VR)
World-space panel 1.6 m wide at 1.2 m distance, 12 degrees below eye line, never follows head roll. Laser-pointer or thumbstick
navigation; grip to go back. Same item model as the desktop menu (`ui.menu.MenuList`).

## Menus
`MAIN`: CAMPAIGN / SURVIVAL / TRAINING / MR INVASION / LOADOUT / SETTINGS / EXIT over a slowly dollying industrial background.
`MISSION SELECT`: location, difficulty, estimated duration, objectives, completion status. `RESULTS`: time, accuracy, objectives,
damage taken, enemies defeated, optional objectives, transparent score lines, then CONTINUE / REPLAY / LOADOUT.
