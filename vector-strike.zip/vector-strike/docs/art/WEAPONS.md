# Weapon Art Specification

All designs are original and fictional. Product-photography style, no manufacturer branding.

## KS-4 Kestrel (`ks4_kestrel`) - rifle

Damage 24 | 650 rpm | mag 30 | reload 2.2s | haptic kick 0.85

- **side_profile**: KS-4 Kestrel, fictional rifle, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the KS-4 Kestrel held two-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: KS-4 Kestrel reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: KS-4 Kestrel magazine, cut-away showing 30-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: KS-4 Kestrel attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## WR-2 Warden (`wr2_warden`) - carbine

Damage 20 | 750 rpm | mag 30 | reload 1.9s | haptic kick 0.70

- **side_profile**: WR-2 Warden, fictional carbine, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the WR-2 Warden held two-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: WR-2 Warden reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: WR-2 Warden magazine, cut-away showing 30-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: WR-2 Warden attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## SP-9 Sparrow (`sp9_sparrow`) - smg

Damage 15 | 900 rpm | mag 32 | reload 1.7s | haptic kick 0.50

- **side_profile**: SP-9 Sparrow, fictional smg, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the SP-9 Sparrow held one-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: SP-9 Sparrow reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: SP-9 Sparrow magazine, cut-away showing 32-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: SP-9 Sparrow attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## HM-12 Hammer (`hm12_hammer`) - shotgun

Damage 11 x8 | 80 rpm | mag 6 | reload 3.0s | haptic kick 1.00

- **side_profile**: HM-12 Hammer, fictional shotgun, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the HM-12 Hammer held two-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: HM-12 Hammer reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: HM-12 Hammer magazine, cut-away showing 6-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: HM-12 Hammer attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## P-11 Pilot (`p11_pilot`) - sidearm

Damage 22 | 330 rpm | mag 12 | reload 1.4s | haptic kick 0.65

- **side_profile**: P-11 Pilot, fictional sidearm, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the P-11 Pilot held one-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: P-11 Pilot reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: P-11 Pilot magazine, cut-away showing 12-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: P-11 Pilot attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## ARC-9 Pulse Rifle (`arc9`) - energy

Damage 28 | 420 rpm | mag 24 | reload 2.0s | haptic kick 0.55

- **side_profile**: ARC-9 Pulse Rifle, fictional energy, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the ARC-9 Pulse Rifle held two-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: ARC-9 Pulse Rifle reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: ARC-9 Pulse Rifle magazine, cut-away showing 24-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: ARC-9 Pulse Rifle attachment configuration sheet: optic, grip, muzzle device (energy emitter), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand

## TR-0 Trainer (`tr0_trainer`) - training

Damage 12 | 500 rpm | mag 20 | reload 1.2s | haptic kick 0.30

- **side_profile**: TR-0 Trainer, fictional training, orthographic side profile on graphite sweep, professional military-industrial product photography, matte materials, no branding. late-2020s military technology, industrial architecture, cinematic action film, realistic VR; palette: dark graphite, raw concrete, brushed steel, muted olive and khaki, amber work-light accents, restrained cold blue, red warning indicators; physically based materials, motivated practical lighting, shallow film grain; NO neon cyberpunk, NO purple gradients, NO anime, NO cartoon UI, NO excessive holograms, NO generic sci-fi corridors, NO real brands or logos
- **first_person_view**: First-person VR view of the TR-0 Trainer held two-handed, weapon-mounted amber ammo counter, hands in tracked gloves
- **reload_view**: TR-0 Trainer reload sequence in VR: magazine released, support hand reaching the pouch, magwell close-up, charging handle pull
- **magazine**: TR-0 Trainer magazine, cut-away showing 20-round capacity, polymer body with steel feed lips, amber round-count window
- **attachments**: TR-0 Trainer attachment configuration sheet: optic, grip, muzzle device (brake/suppressor), light

Materials: receiver: hard-anodised aluminium, matte graphite; furniture: glass-filled polymer, muted olive/black; barrel: nitrided steel, dark gunmetal; markings: engraved model number only, no maker brand
