# Haptics

Controller haptics are first-class and device-agnostic: gameplay emits events; a director maps them to patterns; a per-hand mixer
produces one `(amplitude, frequency)` sample per hand per tick; a `HapticDevice` backend delivers it.

```
 events ──► HapticDirector ──► HapticEngine (voices, mixing, gating) ──► HapticDevice (OpenXR | gamepad | recording | null)
```

## Patterns (`haptics/patterns.py`)
Keyframe envelopes (`t, amp 0..1, freq 0..1` -> 40-320 Hz). Library: `weapon_fire` (built from each weapon's `HapticProfile`),
`dry_fire`, `magazine_drop`, `magazine_insert`, `weapon_chamber`, `reload_ready`, `hit_confirm`, `kill_confirm`, `damage_taken`
(directional), `explosion` (distance falloff), `wall_breach` (MR), `power_fail`, `heartbeat` (looping, health-driven), `dash`,
`teleport`, `grab`, `holster`, `ui_hover`, `ui_select`, `objective_complete`, `interaction_tick`.

## Weapon feel
`HapticProfile(kick, kick_ms, tail_ms, freq, support_scale)` lives on the `WeaponSpec`. The shotgun is a long, deep, full-amplitude
thump; the SMG a short high-frequency tick; the energy weapon a smooth high-frequency buzz. Two-handed fire sends
`support_scale` of the impulse to the support hand; one-handed fire vibrates only the weapon hand.

## Reload choreography
`magazine_drop` (double click, weapon hand) -> `magazine_insert` (low thunk on the *support* hand, echo on the weapon hand) ->
`weapon_chamber` (sharp double tap, both hands) -> `reload_ready`. Each step is distinct so the reload can be performed eyes-free.

## Mixing rules
* Voices sum per hand, **soft-clipped** above 0.8, scaled by master intensity.
* **Priority ducking**: voices more than 2 priority levels below the loudest active voice are halved (a breach swamps UI ticks).
* **Rate limiting** per (pattern, hand) via `min_interval` so full-auto fire and hit ticks cannot saturate the actuator.
* Max 8 voices per hand; lowest-priority/oldest are evicted.
* Directional damage: attacker bearing relative to view biases amplitude between left and right hands.

## Accessibility / settings (`HapticsCfg`)
`enabled`, `intensity`, `reduced` (amplitude cap 0.5, ambient layer removed, weapon recoil x0.6), per-group toggles
(`weapons`, `impacts`, `ui`, `ambient`), per-hand toggles. Reachable from Settings > Haptics.

## Devices
`NullHapticDevice`, `RecordingHapticDevice` (tests / F3 overlay bars), `GamepadRumbleDevice` (desktop fallback: hands -> rumble
motors), `OpenXRHapticDevice` (pyopenxr `apply_haptic_feedback`; **hardware-untested**, falls back when unavailable).

## Developer tools
Console: `haptic_test` lists patterns; `haptic_test <pattern> [left|right]` fires one. F3 overlay shows live L/R amplitude and voice count.
