# Architecture

## Layering

```
 input (desktop | VR frames) ──► PlayerIntent ──► GameSession.step(dt, intent) ──► events ──► audio / haptics / HUD / mission
                                                       │
                          physics.World · nav.NavGrid · enemies · weapons · missions · mr
                                                       │
                              rendering.SoftwareRenderer (read-only consumer of the session)
```

* **`GameSession`** (`game/session.py`) is the whole simulation and is *headless*. Rendering, audio, haptics and UI only read
  it or subscribe to its `EventBus`. This is what makes bot playthroughs, determinism tests and the acceptance walkthrough
  possible without a display, a sound card or a headset.
* **`PlayerIntent`** is the single device-independent input vocabulary. `DesktopInput` and `VRIntentMapper` both produce it;
  gameplay never references a headset.
* **No global mutable state.** Settings (`core.config`) are pydantic models passed explicitly; randomness is isolated in named
  `GameRng` streams (`player_fire`, `enemy_fire`, `ai`) so one system never perturbs another.
* **Events** (`game/events.py`) decouple systems: `weapon_fire`, `magazine_drop`, `hit_confirm`, `player_damaged`,
  `explosion`, `objective_complete`, `mr_event`, ... Audio, haptics, HUD and mission logic all subscribe.

## Determinism

Fixed 60 Hz step (`SIM_DT`), seeded streams, no wall-clock reads in the simulation, deterministic procedural levels.
`GameSession.state_hash()` digests player, weapon, enemies, mission and RNG state; `tests/test_determinism_sim.py` proves two runs
with the same seed and the same scripted intents are bit-identical, and that different seeds diverge.

## Performance design (VR-minded)

| Technique | Where |
|---|---|
| Object pooling | `ProjectileSystem` (fixed pool, drop-on-exhaustion), bounded `effects` deque |
| Spatial partitioning | `World` uniform hash (4 m cells) with DDA ray traversal; broadphase for collision, LOS, hitscan |
| Efficient collision | axis-separated sweeps, AABB only; no physics for props that do not move |
| Bounded AI | decisions staggered at ~6.7 Hz per enemy, path budget 4 A* per tick, far idle enemies skipped, hard cap 64 updates/tick |
| Culling / LOD | distance + horizontal-frustum culling, back-face culling, near-plane polygon clipping, draw-distance setting, cached static lighting |
| Streaming/textures | levels are procedural (no textures); the loader is an interface point (`missions.levels.build_level`) |

## Mission model

`configs/missions/*.yaml` -> `missions.models.MissionDef` (strict pydantic, unknown keys rejected). `MissionRunner` implements
phases `BRIEFING -> INFILTRATION -> OBJECTIVE -> ESCALATION -> EXTRACTION -> RESULTS`, sequential primary objectives, optional
objectives, fail timers, and actions (`unlock_door`, `spawn_group`, `power_fail`, `start_timer`, `mr_event`, ...). Tests validate that every
zone, spawn point, route, door and interactable referenced by a mission file exists in its level.

## Scoring

`OBJECTIVES (4000) + OPTIONAL (500 each) + ACCURACY (1500) + TIME (1500) + DAMAGE TAKEN (1000)`, times a difficulty multiplier.
Kills are displayed but **never scored**; accuracy is hits/shots, so spraying lowers the score; time/damage bonuses are zero on failure.

## Extending

* New weapon: add a `WeaponSpec` (including a `HapticProfile`) to `weapons/spec.py`; art spec and tests pick it up.
* New enemy: `enemies/spec.py`. New mission: YAML + (optionally) a level builder in `missions/levels.py`.
* New renderer / XR backend: implement `rendering.Renderer`, `vr.VRInput`, `haptics.HapticDevice`, `mr.SpatialProvider`.
