# VR and MR

## Input abstraction
`vr/actions.py`: `InputAction` (LEFT_HAND, RIGHT_HAND, TRIGGER, GRIP, THUMBSTICK, THUMBPAD, A_BUTTON, B_BUTTON, MENU, HEAD_POSE,
CONTROLLER_POSE), `Pose`, `ControllerState`, `InputFrame`. `VRInput` backends: `DesktopEmulatedVR` (fake headset driven by mouse/keyboard),
`ScriptedVRInput` (tests/replays), `OpenXRInput` (skeleton, hardware-untested; raises `VRUnavailable` -> `create_vr_input` falls back).

Default VR bindings (right-handed; mirrored for left-handed): dominant trigger = fire, dominant A = magazine release,
dominant B = interact (hold), dominant stick = turn, dominant stick-click = sprint; support stick = move, support A = dash,
support B = grenade, support stick-click = crouch toggle, grips draw weapons from body zones / hold magazines, MENU = floating menu.

## Locomotion & comfort (`vr/locomotion.py`)
Teleport (ballistic arc, nav validated, optional fade), smooth, room-scale (physical displacement applied with collision), dash
(0.18 s glide; reduced-motion = instant blink), scripted/vehicle movement (reduced-motion = cut). Snap turn (default 30 degrees) and smooth
turn; comfort vignette scales with speed and turn rate; seated mode lowers the eye and disables physical crouch; left/right hand modes swap
roles; **no forced camera motion without an accessibility option**.

## Physical weapon handling (`weapons/handling.py`)
Two-handed grip (support hand within reach, grip held) aims along dominant->support; one-handed uses controller forward.
Shoulder detection (head-local) tightens spread; hip fire is looser; weight raises one-handed instability. Holster zones
(right hip: sidearm, shoulders: primary/special, left hip: magazine pouch) are head-relative and mirror for handedness.
Inspection = weapon rolled > ~57 degrees.

**Reload**: `A` drops the magazine -> reach the pouch and grip -> bring the magazine to the magwell (insert) -> grip the rear of the weapon
and pull back (charge) -> READY. The weapon is the source of truth, so a dropped magazine returns to "go get another". Energy weapons skip the
chamber step. `simplified_reload` collapses it to one press; `simplified_interaction` shortens holds and adds a button to charge.

## Mixed reality
`MixedRealityEnvironment` receives floor, ceiling, walls, **portals** (doors/windows), surfaces, spatial objects, **anchors**, play area,
safe zones. It validates the room (area, ceiling, play-area bounds, portals fit walls, spawn availability), derives spawn points
(farthest-point sampling clear of furniture and >= 1.8 m from the player), breach points (wall stretches free of portals/furniture), cover
(furniture 0.6-1.6 m), and serialises to JSON.

Gameplay mapping (`mr/director.py`):

| Real | Virtual |
|---|---|
| Wall | **Wall breach**: a panel opens onto a virtual alcove; hostiles pour in (haptic crack) |
| Door | Room invasion: hostiles enter through the real doors |
| Floor | Floor spawns at spatially valid positions |
| Table top | Objective terminal placed on the real table |
| Play area | Extraction zone is your own physical space |
| Furniture | Cover (also feeds enemy cover selection) |

`SimulatedRoomScanner` generates `MR-DEMO-ROOM-001` (5.2 x 4.2 m, door, door, window, sofa, table, chairs, shelf, cabinet) or seeded random rooms
with scan jitter/confidence. `OpenXRSpatialProvider` is the hardware seam (reports unavailable). `mr.passthrough` offers a synthetic feed and an
optional OpenCV camera, never assumed to exist.
