#!/usr/bin/env bash
# Launch VECTOR STRIKE in desktop mode (no headset required).
set -euo pipefail
cd "$(dirname "$0")/.."
exec python -m vector_strike "$@"
