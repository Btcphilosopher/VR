#!/usr/bin/env bash
# Regenerate procedural props, art-package docs and in-engine placeholder renders.
set -euo pipefail
cd "$(dirname "$0")/.."
python -m vector_strike --generate-assets
python -m vector_strike --screenshots assets/generated
