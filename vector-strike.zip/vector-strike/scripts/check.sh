#!/usr/bin/env bash
# Format, lint, type-check and test everything. Add `-m slow` semantics: the full suite includes bot playthroughs.
set -euo pipefail
cd "$(dirname "$0")/.."
ruff format --check src tests
ruff check src tests
mypy src
python -m pytest
python -m vector_strike --selftest
