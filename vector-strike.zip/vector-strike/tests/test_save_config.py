import json

import pytest
from pydantic import ValidationError

from vector_strike.core.config import Difficulty, Settings, dump_settings, load_settings
from vector_strike.game.save import SCHEMA_VERSION, SaveData, load_game, save_game
from vector_strike.game.session import GameSession
from vector_strike.tools.bot import run_bot


def test_default_yaml_loads_and_matches_spec_example():
    s = load_settings()
    assert s.game.difficulty is Difficulty.NORMAL and s.game.vr_enabled is False and s.game.mr_enabled is False
    assert s.player.movement_speed == 3.0 and s.player.snap_turn_degrees == 30
    assert s.graphics.size == (1280, 720) and s.graphics.quality == "high"


def test_settings_validation():
    with pytest.raises(ValidationError):
        Settings.model_validate({"graphics": {"resolution": "big"}})
    with pytest.raises(ValidationError):
        Settings.model_validate({"player": {"movement_speed": 99}})
    s = Settings()
    with pytest.raises(ValidationError):
        s.haptics.intensity = 3.0


def test_settings_yaml_roundtrip(tmp_path):
    s = Settings()
    s.comfort.seated_mode = True
    s.haptics.intensity = 0.4
    p = tmp_path / "c.yaml"
    dump_settings(s, p)
    assert load_settings(p) == s


def test_save_roundtrip_and_all_required_sections(tmp_path):
    sd = SaveData()
    sd.settings.comfort.simplified_reload = True
    sd.loadout.primary = "wr2_warden"
    p = save_game(sd, tmp_path / "s.json")
    raw = json.loads(p.read_text())
    for key in (
        "player_progress",
        "missions",
        "weapons_unlocked",
        "settings",
        "difficulty",
        "accessibility",
        "statistics",
    ):
        assert key in raw
    assert raw["accessibility"]["simplified_reload"] is True and raw["version"] == SCHEMA_VERSION
    back = load_game(p)
    assert back == sd or back.model_dump() == sd.model_dump()


def test_corrupt_save_is_quarantined(tmp_path):
    p = tmp_path / "s.json"
    p.write_text("{not json")
    sd = load_game(p)
    assert sd.version == SCHEMA_VERSION and (tmp_path / "s.corrupt").exists()


def test_old_schema_migrates(tmp_path):
    p = tmp_path / "s.json"
    p.write_text(json.dumps({"version": 1, "statistics": {"kills": 9}}))
    sd = load_game(p)
    assert sd.version == 2 and sd.statistics.kills == 9


def test_atomic_save_leaves_no_temp_files(tmp_path):
    save_game(SaveData(), tmp_path / "s.json")
    assert [f.name for f in tmp_path.iterdir()] == ["s.json"]


def test_record_result_unlocks_and_stats():
    s = GameSession.create(Settings(), "vector_01", seed=1)
    assert run_bot(s, 1200.0)
    sd = SaveData()
    unlocked = sd.record_result(s.result)
    assert unlocked == ["hm12_hammer"] and "hm12_hammer" in sd.weapons_unlocked
    rec = sd.missions["vector_01"]
    assert rec.completed and rec.best_score == s.result.score.total and sd.statistics.kills == s.result.kills
    assert sd.record_result(s.result) == []  # no duplicate unlock
    assert sd.missions["vector_01"].attempts == 2
