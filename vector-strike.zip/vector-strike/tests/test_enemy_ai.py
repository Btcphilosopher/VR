import math

from vector_strike.core.config import Settings
from vector_strike.enemies.enemy import AIState
from vector_strike.enemies.spec import ENEMIES, Role
from vector_strike.game import events as ev
from vector_strike.game.intent import PlayerIntent
from vector_strike.game.session import GameSession
from vector_strike.physics.vec import Vec3


def make(mission="survival_breach", seed=3):
    s = GameSession.create(Settings(), mission, seed=seed)
    s.enemies.clear()  # isolate the scenario from the mission's own starting groups
    return s


def run(s, seconds, intent=None):
    for _ in range(int(seconds * 60)):
        s.step(1 / 60, intent or PlayerIntent())


def test_all_states_exist():
    assert {a.value for a in AIState} == {
        "idle",
        "patrol",
        "alert",
        "search",
        "engage",
        "take_cover",
        "flank",
        "retreat",
        "defeated",
    }


def test_enemy_roles_cover_the_brief():
    assert {e.role for e in ENEMIES.values()} >= {
        Role.RIFLEMAN,
        Role.FLANKER,
        Role.SUPPRESSOR,
        Role.BREACHER,
        Role.ELITE,
        Role.BOSS,
    }


def test_idle_enemy_sees_player_alerts_then_engages():
    s = make("vector_01")
    s.level.world  # noqa: B018
    e = s.spawn_enemy("rifleman", Vec3(30, 0, 14), yaw=math.pi)  # looking toward the player at (30, 2.5)
    states = []
    s.bus.subscribe(ev.ENEMY_STATE, lambda x: states.append(x.data["new"]) if x.data["uid"] == e.uid else None)
    run(s, 3.0)
    assert "alert" in states and "engage" in states
    assert states.index("alert") < states.index("engage")


def test_enemy_hears_gunfire_through_walls():
    s = make("vector_01")
    e = s.spawn_enemy("rifleman", Vec3(12, 0, 30), yaw=0.0)  # inside the security room, out of sight
    s.add_noise(Vec3(30, 0, 12), 60.0, "test")
    run(s, 0.5)
    assert e.state in (AIState.ALERT, AIState.SEARCH)
    assert e.last_known is not None


def test_enemy_reacts_to_damage_from_behind():
    s = make("vector_01")
    e = s.spawn_enemy("rifleman", Vec3(30, 0, 30), yaw=0.0)
    e.apply_damage(5.0, "torso", Vec3(30, 0, 20), "test")
    run(s, 0.4)
    assert e.state is not AIState.IDLE


def test_allies_are_alerted_by_spotter():
    s = make("vector_01")
    a = s.spawn_enemy("rifleman", Vec3(30, 0, 14), yaw=math.pi)
    b = s.spawn_enemy("rifleman", Vec3(34, 0, 20), yaw=0.0)  # facing away, cannot see the player
    run(s, 2.0)
    assert b.state is not AIState.IDLE


def test_enemy_takes_cover_under_pressure_and_cover_blocks_los():
    s = make("survival_breach")
    p = s.player.state
    e = s.spawn_enemy("rifleman", Vec3(16, 0, 20), yaw=math.pi)
    e.state = AIState.ENGAGE
    e.recent_damage = 1.0
    e.last_known = p.pos
    states = set()
    s.bus.subscribe(ev.ENEMY_STATE, lambda x: states.add(x.data["new"]) if x.data["uid"] == e.uid else None)
    run(s, 6.0)
    assert states & {"take_cover", "retreat", "flank"}
    if e.cover_pos is not None and e.state is AIState.TAKE_COVER:
        eye_crouched = Vec3(e.cover_pos.x, 0.9, e.cover_pos.z)
        assert (
            not s.level.world.line_of_sight(Vec3(p.pos.x, 1.6, p.pos.z), eye_crouched) or e.cover_phase.value == "peek"
        )


def test_flanker_flanks_when_ally_pins_player():
    s = make("vector_01")
    s.player.state.pos = Vec3(30, 0, 16)
    r = s.spawn_enemy("rifleman", Vec3(30, 0, 24), yaw=math.pi)
    f = s.spawn_enemy("flanker", Vec3(26, 0, 24), yaw=math.pi)
    seen = set()
    s.bus.subscribe(ev.ENEMY_STATE, lambda x: seen.add((x.data["uid"], x.data["new"])))
    run(s, 12.0)
    assert any(uid == f.uid and st in ("flank", "take_cover", "engage") for uid, st in seen)


def test_enemies_do_not_simply_run_at_the_player():
    s = make("vector_01")
    s.player.state.pos = Vec3(30, 0, 14)
    s.player.state.god_mode = True
    es = [s.spawn_enemy("rifleman", Vec3(24 + i * 3, 0, 22), yaw=math.pi) for i in range(3)]
    states = set()
    s.bus.subscribe(ev.ENEMY_STATE, lambda x: states.add(x.data["new"]))
    run(s, 10.0)
    assert states & {"take_cover", "flank"}  # uses cover/flanking, not just 'engage'
    assert all(e.pos.dist_xz(s.player.state.pos) > 3.0 for e in es if e.alive)


def test_retreat_when_badly_hurt():
    s = make("vector_01")
    s.player.state.pos = Vec3(30, 0, 14)
    e = s.spawn_enemy("rifleman", Vec3(30, 0, 24), yaw=math.pi)
    run(s, 1.0)
    e.health = e.spec.health * 0.15
    e.last_seen_t = s.t
    e._set_state(AIState.ENGAGE, None)
    seen = []
    s.bus.subscribe(ev.ENEMY_STATE, lambda x: seen.append(x.data["new"]))
    run(s, 3.0)
    assert "retreat" in seen or not e.alive


def test_defeated_enemy_emits_once_and_stops_acting():
    s = make("vector_01")
    e = s.spawn_enemy("rifleman", Vec3(30, 0, 20))
    n = []
    s.bus.subscribe(ev.ENEMY_DEFEATED, lambda x: n.append(x.data["uid"]))
    e.apply_damage(1000, "head", Vec3(), "t")
    run(s, 1.0)
    assert n == [e.uid] and e.state is AIState.DEFEATED
    assert s.stats.kills == 1


def test_elite_throws_grenade_at_camping_player():
    s = make("survival_breach")
    p = s.player.state
    e = s.spawn_enemy("elite", Vec3(16, 0, 24), yaw=math.pi)
    e.last_known = p.pos
    e.last_seen_t = s.t
    e.state = AIState.ENGAGE
    thrown = []
    s.bus.subscribe(ev.ENEMY_GRENADE, lambda x: thrown.append(x))
    e.sees_player = False
    run(s, 2.0)
    assert thrown or any(g for g in s.grenades)


def test_ai_update_budget_bounded():
    s = make("vector_01")
    for i in range(120):
        s.spawn_enemy("rifleman", Vec3(10 + (i % 40), 0, 12 + (i // 40) * 3))
    import time

    t = time.perf_counter()
    run(s, 1.0)
    assert time.perf_counter() - t < 8.0  # 120 enemies stay tractable
