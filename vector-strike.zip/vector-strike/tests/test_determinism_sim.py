import pytest

from vector_strike.core.config import Difficulty, Settings
from vector_strike.game.session import GameSession
from vector_strike.tools.bot import AutoPilot, run_bot


def trace(mission, seed, ticks):
    s = GameSession.create(Settings(), mission, seed=seed)
    bot = AutoPilot(s)
    hashes = []
    for i in range(ticks):
        s.step(1 / 60, bot.decide(1 / 60))
        if i % 60 == 0:
            hashes.append(s.state_hash())
    return hashes


@pytest.mark.parametrize("mission", ["vector_01", "survival_breach", "mr_invasion"])
def test_simulation_is_bit_for_bit_deterministic(mission):
    a, b = trace(mission, 77, 60 * 25), trace(mission, 77, 60 * 25)
    assert a == b


def test_different_seeds_diverge():
    assert trace("vector_01", 1, 60 * 15) != trace("vector_01", 2, 60 * 15)


def test_deterministic_full_mission_outcome():
    def go():
        s = GameSession.create(Settings(), "vector_02", seed=9)
        ok = run_bot(s, 1200.0)
        r = s.result
        return ok, r.score.total, r.kills, r.shots, round(r.elapsed, 3), s.state_hash()

    assert go() == go()


@pytest.mark.slow
@pytest.mark.parametrize("mission", ["training", "vector_01", "vector_02", "mr_invasion"])
def test_scripted_bot_completes_missions(mission):
    s = GameSession.create(Settings(), mission, seed=1337)
    assert run_bot(s, 1500.0), s.result.reason if s.result else "timeout"
    assert s.result.primary_done == s.result.primary_total


def test_scripted_bot_survives_breach_waves_on_recruit():
    st = Settings()
    st.game.difficulty = Difficulty.RECRUIT
    s = GameSession.create(st, "survival_breach", seed=1337)
    run_bot(s, 1500.0)
    assert s.result is not None and s.result.waves_cleared >= 2
