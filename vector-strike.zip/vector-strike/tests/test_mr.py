import json

import pytest

from vector_strike.core.config import Settings
from vector_strike.game import events as ev
from vector_strike.game.intent import PlayerIntent
from vector_strike.game.session import GameSession
from vector_strike.mr.anchors import AnchorKind, Furniture, PlayArea, PortalKind
from vector_strike.mr.environment import MixedRealityEnvironment, environment_to_level
from vector_strike.mr.passthrough import SyntheticPassthrough, open_passthrough
from vector_strike.mr.scanner import (
    HardwareUnavailable,
    OpenXRSpatialProvider,
    SimulatedRoomScanner,
    get_spatial_provider,
)
from vector_strike.physics.vec import Vec3


def run(s, secs):
    for _ in range(int(secs * 60)):
        s.step(1 / 60, PlayerIntent())


def test_demo_room_is_valid_and_deterministic():
    a = SimulatedRoomScanner(1).scan("MR-DEMO-ROOM-001")
    b = SimulatedRoomScanner(1).scan("MR-DEMO-ROOM-001")
    assert a.meta.room_id == "MR-DEMO-ROOM-001" and a.is_valid()
    assert a.to_dict() == b.to_dict()
    assert {p.kind for p in a.portals} == {PortalKind.DOOR, PortalKind.WINDOW}
    assert {o.label for o in a.objects} >= {Furniture.TABLE, Furniture.SOFA, Furniture.CHAIR}
    assert len(a.walls) == 4 and a.floor.role.value == "floor"


def test_anchor_vocabulary_covers_spec():
    env = SimulatedRoomScanner(1).scan()
    kinds = {
        env.floor.kind,
        env.walls[0].kind,
        env.portals[0].anchor_kind,
        env.surfaces[0].kind,
        env.objects[0].kind,
        env.anchors[0].kind,
        env.derive_spawn_points()[0].kind,
        env.derive_cover_points()[0].kind,
    }
    assert kinds == set(AnchorKind)


def test_validation_catches_bad_rooms():
    env = SimulatedRoomScanner(1).scan()
    env.play_area = PlayArea(Vec3(0.2, 0, 0.2), 1.0, 1.0)
    codes = {i.code for i in env.validate() if i.severity == "error"}
    assert "PLAY_AREA_OUTSIDE" in codes
    tiny = SimulatedRoomScanner(1).scan()
    tiny.width, tiny.depth = 2.0, 2.0
    assert "FLOOR_TOO_SMALL" in {i.code for i in tiny.validate()}
    env2 = SimulatedRoomScanner(1).scan()
    env2.portals[0].along = 99.0
    assert "PORTAL_OFF_WALL" in {i.code for i in env2.validate()}


@pytest.mark.parametrize("room", ["lab-1", "den-7", "flat-3"])
def test_random_rooms_generate_valid_environments(room):
    env = SimulatedRoomScanner(4).scan(room)
    assert env.is_valid(), [i for i in env.validate() if i.severity == "error"]
    sp = env.derive_spawn_points()
    assert sp and all(not env.blocked(p.pos, 0.4) and p.pos.dist_xz(env.play_area.center) >= 1.8 for p in sp)


def test_spawn_points_clear_of_furniture_and_breach_avoids_portals():
    env = SimulatedRoomScanner(1).scan()
    for sp in env.derive_spawn_points():
        assert env.in_room(sp.pos, 0.4) and not env.blocked(sp.pos, 0.4)
    for bp in env.derive_breach_points():
        for p in env.portals:
            if p.wall_id == bp.wall_id:
                lo, hi = p.along - p.width / 2, p.along + p.width / 2
                t = (bp.pos - env.wall(bp.wall_id).a).length()
                assert not (lo - bp.width / 2 < t < hi + bp.width / 2)


def test_serialisation_roundtrip():
    env = SimulatedRoomScanner(1).scan()
    again = MixedRealityEnvironment.from_dict(json.loads(json.dumps(env.to_dict())))
    assert again.to_dict() == env.to_dict() and again.is_valid()


def test_furniture_becomes_cover_and_surfaces_exist():
    env = SimulatedRoomScanner(1).scan()
    cover = {o.label for o in env.furniture_cover()}
    assert Furniture.TABLE in cover and Furniture.SHELF not in cover
    assert env.find_surface("table") is not None


def test_level_conversion_has_alcoves_cover_and_closed_panels():
    env = SimulatedRoomScanner(1).scan()
    lvl = environment_to_level(env)
    names = set(lvl.spawn_points)
    assert any(n.startswith("breach_") for n in names) and any(n.startswith("portal_") for n in names)
    assert any(n.startswith("floor_") for n in names)
    panels = [c for c in lvl.world.colliders.values() if c.tag.startswith("breach_")]
    assert panels and all(not c.open for c in panels)
    assert lvl.cover_points


def test_providers_fall_back_without_hardware():
    with pytest.raises(HardwareUnavailable):
        OpenXRSpatialProvider().scan()
    prov = get_spatial_provider(prefer_hardware=True)
    assert prov.name == "simulated" and prov.scan().is_valid()
    src = open_passthrough(prefer_camera=False)
    assert isinstance(src, SyntheticPassthrough) and src.read().shape == (360, 640, 3)


def test_mr_session_events_breach_floor_invasion_object_extract():
    s = GameSession.create(Settings(), "mr_invasion", seed=5)
    s.player.state.god_mode = True
    r = s.runner
    assert r.active_primary().defn.id == "repel_breach"
    run(s, 0.2)
    assert "wall_breach" in s.mr_director.log and s.group_alive("mr_wall_breach") == 2
    assert any(e.name == ev.MR_EVENT and e.data["kind"] == "wall_breach" for e in s.bus.history)
    breach_names = [n for n in s.level.spawn_points if n.startswith("breach_")]
    assert any(c.open for n in breach_names for c in s.level.world.by_tag(n))  # virtual opening appeared
    for stage, _group in (
        ("repel_breach", "mr_wall_breach"),
        ("floor_spawn", "mr_floor_spawn"),
        ("room_invasion", "mr_room_invasion"),
    ):
        assert r.active_primary().defn.id == stage
        run(s, 0.3)
        for e in s.alive_enemies():
            e.apply_damage(1e6, "head", Vec3(), "t")
        run(s, 0.3)
    assert r.active_primary().defn.id == "secure_object" and "mr_objective" in s.interactables
    surf = s.mr_env.find_surface("table")
    assert abs(s.interactables["mr_objective"].pos.x - surf.center.x) < 1e-6  # terminal sits on the real table
    s.player.state.pos = Vec3(surf.center.x - 1.4, 0, surf.center.z)
    s.player.state.yaw = 3.14159 / 2
    for _ in range(300):
        s.step(1 / 60, PlayerIntent(interact=True))
    assert r.active_primary().defn.id == "mr_extract" and "mr_extract" in s.level.zones
    s.player.state.pos = s.mr_env.play_area.center
    run(s, 0.2)
    assert s.done and s.result.success


def test_mr_enemies_stay_inside_mapped_geometry():
    s = GameSession.create(Settings(), "mr_invasion", seed=5)
    s.player.state.god_mode = True
    run(s, 8.0)
    env = s.mr_env
    for e in s.alive_enemies():
        assert -4.0 <= e.pos.x <= env.width + 4.0 and -4.0 <= e.pos.z <= env.depth + 4.0
