import math

import pytest

from vector_strike.core.config import ComfortCfg, Handedness, LocomotionMode, PlayerCfg, Settings, TurnMode
from vector_strike.core.types import Hand
from vector_strike.game import events as ev
from vector_strike.game.session import GameSession
from vector_strike.physics.vec import Vec3
from vector_strike.vr.actions import ControllerState, InputFrame, Pose
from vector_strike.vr.input import (
    DesktopControls,
    DesktopEmulatedVR,
    OpenXRInput,
    ScriptedVRInput,
    VRUnavailable,
    create_vr_input,
)
from vector_strike.vr.locomotion import Locomotion, ScriptedMovement
from vector_strike.vr.mapping import VRIntentMapper
from vector_strike.weapons.handling import (
    AimMode,
    GripMode,
    ReloadStage,
    VRReloadController,
    compute_handling,
    zone_at,
)
from vector_strike.weapons.spec import CATALOGUE, Slot
from vector_strike.weapons.weapon import Weapon, WeaponState

HEAD = Pose(Vec3(0, 1.65, 0), 0.0, 0.0)


def frame(**kw) -> InputFrame:
    return InputFrame(0.0, kw.pop("head", HEAD), kw.pop("left", ControllerState()), kw.pop("right", ControllerState()))


def hand_at(x, y, z, **kw) -> ControllerState:
    return ControllerState(Pose(Vec3(x, y, z)), **kw)


# ---- input abstraction -------------------------------------------------------------------------------------------
def test_hardware_unavailable_falls_back_to_desktop():
    with pytest.raises(VRUnavailable):
        OpenXRInput()
    inp = create_vr_input(prefer_hardware=True)
    assert isinstance(inp, DesktopEmulatedVR)
    f = inp.poll(0.0)
    assert f.head.position.y > 1.0


def test_desktop_emulation_maps_controls():
    c = DesktopControls(move_z=1.0, fire=True, aim=True, interact=True)
    f = DesktopEmulatedVR(c).poll(0.0)
    assert f.right.trigger == 1.0 and f.left.stick == (0.0, 1.0) and f.right.b and f.left.grip == 1.0


def test_scripted_input_replays_frames():
    inp = ScriptedVRInput([frame(), frame(right=ControllerState(trigger=1.0))])
    assert inp.poll(0).right.trigger == 0.0 and inp.poll(0).right.trigger == 1.0
    assert (
        inp.value(__import__("vector_strike.vr.actions", fromlist=["InputAction"]).InputAction.TRIGGER, Hand.RIGHT)
        == 1.0
    )


# ---- locomotion ------------------------------------------------------------------------------------------------------
def loco(**comfort):
    return Locomotion(ComfortCfg(**comfort), PlayerCfg())


def test_snap_turn_once_per_flick():
    L = loco(turn_mode=TurnMode.SNAP)
    flick = frame(right=ControllerState(stick=(1.0, 0.0)))
    out = [L.process(flick, 0.0, Vec3(), None, 1 / 90).turn for _ in range(5)]
    assert out[0] == pytest.approx(math.radians(30)) and all(t == 0 for t in out[1:])
    L.process(frame(), 0.0, Vec3(), None, 1 / 90)  # recentre
    assert L.process(flick, 0.0, Vec3(), None, 1 / 90).turn != 0


def test_left_handed_swaps_turn_and_move_sticks():
    L = loco(handedness=Handedness.LEFT, turn_mode=TurnMode.SNAP)
    assert L.hands() == (Hand.LEFT, Hand.RIGHT)
    o = L.process(
        frame(left=ControllerState(stick=(1.0, 0)), right=ControllerState(stick=(0, 1.0))),
        0.0,
        Vec3(),
        None,
        1 / 90,
    )
    assert o.turn != 0 and o.move_z == 1.0


def test_smooth_turn_scales_with_input_and_reduced_motion():
    f = frame(right=ControllerState(stick=(1.0, 0.0)))
    normal = loco(turn_mode=TurnMode.SMOOTH).process(f, 0, Vec3(), None, 0.1).turn
    reduced = loco(turn_mode=TurnMode.SMOOTH, reduced_motion=True).process(f, 0, Vec3(), None, 0.1).turn
    assert reduced == pytest.approx(normal * 0.5)


def test_smooth_locomotion_and_vignette_scales_with_motion():
    L = loco(locomotion=LocomotionMode.SMOOTH, vignette=0.8)
    still = L.process(frame(), 0, Vec3(), None, 1 / 90)
    moving = L.process(frame(left=ControllerState(stick=(0, 1.0))), 0, Vec3(), None, 1 / 90)
    assert moving.move_z == 1.0 and moving.vignette > still.vignette == 0.0
    off = loco(vignette=0.0).process(frame(left=ControllerState(stick=(0, 1.0))), 0, Vec3(), None, 1 / 90)
    assert off.vignette == 0.0


def test_teleport_arc_then_release_teleports():
    s = GameSession.create(Settings(), "training", seed=1)
    L = loco(locomotion=LocomotionMode.TELEPORT)
    pose = Pose(Vec3(0, 1.2, 0.3), 0.0, -0.35)
    aim = frame(left=ControllerState(pose, stick=(0.0, 1.0)))
    o1 = L.process(aim, 0.0, s.player.state.pos, s.nav, 1 / 90)
    assert o1.teleport_arc and o1.teleport_to is None and o1.teleport_valid
    o2 = L.process(frame(left=ControllerState(pose)), 0.0, s.player.state.pos, s.nav, 1 / 90)
    assert o2.teleport_to is not None and o2.fade == 1.0
    assert s.nav.is_walkable_pos(o2.teleport_to)


def test_teleport_refuses_through_walls():
    s = GameSession.create(Settings(), "vector_01", seed=1)
    s.player.state.pos = Vec3(30, 0, 5)
    L = loco(locomotion=LocomotionMode.TELEPORT)
    pose = Pose(Vec3(0, 1.2, 0.3), 0.0, -0.18)  # long throw toward the hall wall / beyond
    L.process(frame(left=ControllerState(pose, stick=(0, 1.0))), 0.0, s.player.state.pos, s.nav, 1 / 90)
    o = L.process(frame(left=ControllerState(pose)), 0.0, s.player.state.pos, s.nav, 1 / 90)
    if o.teleport_to is not None:
        assert s.nav.line_walkable(s.player.state.pos, o.teleport_to)


def test_room_scale_applies_physical_displacement_only_in_that_mode():
    a = frame(head=Pose(Vec3(0, 1.65, 0)))
    b = frame(head=Pose(Vec3(0.2, 1.65, 0.1)))
    L = loco(locomotion=LocomotionMode.ROOM_SCALE)
    L.process(a, 0.0, Vec3(), None, 1 / 90)
    d = L.process(b, 0.0, Vec3(), None, 1 / 90).room_delta
    assert d is not None and d.x == pytest.approx(0.2) and d.z == pytest.approx(0.1)
    L2 = loco(locomotion=LocomotionMode.SMOOTH)
    L2.process(a, 0.0, Vec3(), None, 1 / 90)
    assert L2.process(b, 0.0, Vec3(), None, 1 / 90).room_delta is None


def test_dash_travels_then_cools_down_and_reduced_motion_blinks():
    L = loco()
    press = frame(left=ControllerState(a=True, stick=(0, 1.0)))
    total = Vec3()
    o = L.process(press, 0.0, Vec3(), None, 1 / 90)
    total = total + o.dash_delta
    for _ in range(40):
        o = L.process(frame(left=ControllerState(stick=(0, 1.0))), 0.0, Vec3(), None, 1 / 90)
        if o.dash_delta:
            total = total + o.dash_delta
    assert total.length() == pytest.approx(3.0, abs=0.05)
    assert L.process(press, 0.0, Vec3(), None, 1 / 90).dash_delta is None  # cooldown
    R = loco(reduced_motion=True)
    o = R.process(press, 0.0, Vec3(), None, 1 / 90)
    assert o.dash_delta.length() == pytest.approx(3.0) and o.fade > 0  # instant blink, no glide
    assert loco(dash_enabled=False).process(press, 0, Vec3(), None, 1 / 90).dash_delta is None


def test_scripted_movement_glides_or_cuts():
    m = ScriptedMovement([Vec3(0, 0, 10)], speed=5.0)
    pos, fade = m.step(Vec3(), 0.5)
    assert pos.z == pytest.approx(2.5) and fade == 0
    m2 = ScriptedMovement([Vec3(0, 0, 10)], reduced_motion=True)
    pos, fade = m2.step(Vec3(), 0.016)
    assert pos.z == 10 and fade == 1.0 and m2.done


# ---- weapon handling -----------------------------------------------------------------------------------------------------
def test_two_handed_grip_aims_along_hands_and_is_steadier():
    spec = CATALOGUE["ks4_kestrel"]
    dom = hand_at(0.15, 1.45, 0.3, trigger=0.0)
    sup = hand_at(0.15, 1.45, 0.7, grip=1.0)
    two = compute_handling(HEAD, dom, sup, spec)
    one = compute_handling(HEAD, dom, hand_at(0.15, 1.45, 0.7, grip=0.0), spec)
    assert two.grip is GripMode.TWO_HANDED and one.grip is GripMode.ONE_HANDED
    assert two.direction.z == pytest.approx(1.0) and two.stability < one.stability


def test_shoulder_aim_detected_and_stabilises():
    spec = CATALOGUE["ks4_kestrel"]
    sh = compute_handling(HEAD, hand_at(0.1, 1.55, 0.25), hand_at(0.1, 1.55, 0.7, grip=1.0), spec)
    hip = compute_handling(HEAD, hand_at(0.25, 1.0, 0.3), hand_at(0.25, 1.0, 0.75, grip=1.0), spec)
    assert sh.aim_mode is AimMode.SHOULDER and hip.aim_mode is AimMode.HIP and sh.stability < hip.stability


def test_inspection_detected_by_roll():
    d = ControllerState(Pose(Vec3(0.2, 1.3, 0.3), 0, 0, 1.4))
    assert compute_handling(HEAD, d, ControllerState(), CATALOGUE["p11_pilot"]).inspecting
    assert not compute_handling(
        HEAD, ControllerState(Pose(Vec3(0.2, 1.3, 0.3))), ControllerState(), CATALOGUE["p11_pilot"]
    ).inspecting


def test_holster_zones_mirror_for_left_handed():
    p = Vec3(0.22, 1.65 - 0.65, 0.05)
    assert zone_at(HEAD, p, Handedness.RIGHT).slot is Slot.SECONDARY
    assert zone_at(HEAD, Vec3(-p.x, p.y, p.z), Handedness.LEFT).slot is Slot.SECONDARY
    assert zone_at(HEAD, Vec3(0, 1.65, 0.5), Handedness.RIGHT) is None


def test_physical_reload_gesture_end_to_end(bus):
    """DROP MAGAZINE -> REACH MAGAZINE -> INSERT -> CHAMBER -> READY"""
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.ammo = 7
    rc = VRReloadController()
    dom_pose = Pose(Vec3(0.15, 1.3, 0.3))

    def fr(dom, sup):
        return frame(right=dom, left=sup)

    def run(dom, sup, n=1):
        flags = {}
        for _ in range(n):
            flags = rc.process(fr(dom, sup), Hand.RIGHT, w, 1 / 90)
            if flags["drop_mag"]:
                w.drop_magazine()
            if flags["insert_mag"]:
                w.insert_magazine()
            if flags["charge"]:
                w.charge()
        return flags

    rest_sup = ControllerState(Pose(Vec3(0.15, 1.3, 0.6)))
    run(ControllerState(dom_pose, a=True), rest_sup)  # 1. press mag release
    assert w.state is WeaponState.MAG_OUT and rc.stage is ReloadStage.MAG_OUT
    run(ControllerState(dom_pose), rest_sup)
    run(ControllerState(dom_pose), ControllerState(Pose(Vec3(-0.2, 1.65 - 0.5, 0.12)), grip=1.0))  # 2. grab from pouch
    assert rc.stage is ReloadStage.MAG_IN_HAND
    mag = VRReloadController.magwell(ControllerState(dom_pose))
    run(ControllerState(dom_pose), ControllerState(Pose(mag), grip=1.0))  # 3. insert
    assert w.state is WeaponState.CHAMBER_PENDING and w.ammo == 30 and not w.can_fire
    ch = VRReloadController.charging_handle(ControllerState(dom_pose))
    for back in (0.0, 0.05, 0.1, 0.16, 0.2):  # 4. pull back
        run(ControllerState(dom_pose), ControllerState(Pose(Vec3(ch.x, ch.y, ch.z - back)), grip=1.0))
    assert w.state is WeaponState.READY and w.can_fire


def test_dropped_magazine_goes_back_to_mag_out(bus):
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.drop_magazine()
    rc = VRReloadController(stage=ReloadStage.MAG_IN_HAND, mag_in_hand=True)
    rc.process(frame(), Hand.RIGHT, w, 1 / 90)
    assert rc.stage is ReloadStage.MAG_OUT


def test_simplified_reload_is_one_press(bus):
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.ammo = 3
    rc = VRReloadController(simplified=True)
    assert rc.process(frame(right=ControllerState(a=True)), Hand.RIGHT, w, 1 / 90)["reload"]


# ---- mapper (full stack) ---------------------------------------------------------------------------------------------------------
def make_mapper(**comfort):
    s = GameSession.create(Settings(), "training", seed=1)
    s.inventory.add_weapon("ks4_kestrel")
    s.enemies.clear()
    st = Settings()
    c = ComfortCfg(**comfort)
    return s, VRIntentMapper(c, st.player)


def test_mapper_fire_aim_and_hand_roles():
    s, m = make_mapper()
    f = frame(right=hand_at(0.1, 1.55, 0.25, trigger=1.0), left=hand_at(0.1, 1.55, 0.7, grip=1.0))
    i = m.map(f, s, 1 / 90)
    assert i.fire and i.aim_override is not None and i.support_hand is Hand.LEFT and i.aim and i.stability < 0.5
    assert i.aim_override[1].z == pytest.approx(1.0, abs=1e-6)


def test_mapper_trigger_hysteresis():
    s, m = make_mapper()
    for val, expect in ((0.7, True), (0.5, True), (0.3, False)):
        i = m.map(frame(right=hand_at(0.1, 1.5, 0.3, trigger=val)), s, 1 / 90)
        assert i.fire is expect


def test_mapper_left_handed_weapon_hand():
    s, m = make_mapper(handedness=Handedness.LEFT)
    i = m.map(frame(left=hand_at(0.1, 1.5, 0.3, trigger=1.0)), s, 1 / 90)
    assert i.fire and i.hand is Hand.LEFT


def test_mapper_draw_from_holster_zone():
    s, m = make_mapper()
    s.inventory.add_weapon("p11_pilot", make_active=False)
    hip = Vec3(0.22, 1.65 - 0.65, 0.05)
    m.map(frame(right=ControllerState(Pose(hip), grip=0.0)), s, 1 / 90)
    m.map(frame(right=ControllerState(Pose(hip), grip=1.0)), s, 1 / 90)
    assert s.inventory.active is Slot.SECONDARY
    assert any(e.name == ev.WEAPON_DRAW for e in s.bus.history)


def test_mapper_turn_updates_player_yaw_through_session():
    s, m = make_mapper(turn_mode=TurnMode.SNAP)
    y0 = s.player.state.yaw
    i = m.map(frame(right=ControllerState(stick=(1.0, 0.0))), s, 1 / 90)
    s.step(1 / 60, i)
    assert s.player.state.yaw - y0 == pytest.approx(math.radians(30), abs=1e-3)


def test_mapper_physical_crouch_and_toggle():
    s, m = make_mapper()
    low = Pose(Vec3(0, 1.0, 0))
    assert m.map(frame(head=low), s, 1 / 90).crouch
    s2, m2 = make_mapper(seated_mode=True)
    assert not m2.map(frame(head=low), s2, 1 / 90).crouch
    m3 = make_mapper()[1]
    assert m3.map(frame(left=ControllerState(stick_click=True)), s, 1 / 90).crouch


def test_vr_shot_travels_along_controller_direction_and_hits_target():
    """Hand pose -> intent -> session -> fire model -> hit, with haptics on both hands."""
    s, m = make_mapper()
    s.inventory.weapon.state = WeaponState.READY
    s.inventory.weapon.state_timer = 0
    s.player.state.pos = Vec3(8, 0, 8)
    tgt = s.spawn_enemy("training_target", Vec3(8, 0, 18))
    from vector_strike.haptics.devices import RecordingHapticDevice

    dev = RecordingHapticDevice()
    s.haptics.device = dev
    for _ in range(40):
        s.step(1 / 60)
    h0 = tgt.health
    f = frame(right=hand_at(0.0, 1.5, 0.3, trigger=1.0), left=hand_at(0.0, 1.5, 0.75, grip=1.0))
    i = m.map(f, s, 1 / 60)
    s.step(1 / 60, i)
    for _ in range(5):
        s.step(1 / 60)
    assert s.stats.shots == 1 and tgt.health < h0
    assert dev.peak(Hand.RIGHT) > dev.peak(Hand.LEFT) > 0
