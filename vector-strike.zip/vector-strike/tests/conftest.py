import os
import sys
import tempfile
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ["VECTOR_STRIKE_HOME"] = tempfile.mkdtemp(prefix="vs_test_home_")
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import pytest  # noqa: E402

from vector_strike.core.config import Settings  # noqa: E402
from vector_strike.game.events import EventBus  # noqa: E402


@pytest.fixture
def settings() -> Settings:
    return Settings()


@pytest.fixture
def bus() -> EventBus:
    return EventBus()
