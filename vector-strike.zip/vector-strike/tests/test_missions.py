import pytest
import yaml

from vector_strike.core.config import Settings
from vector_strike.game import events as ev
from vector_strike.game.intent import PlayerIntent
from vector_strike.game.session import GameSession
from vector_strike.missions.levels import LEVELS, build_level
from vector_strike.missions.models import MissionDef, MissionPhase, list_missions, load_mission, missions_dir
from vector_strike.missions.scoring import compute_score
from vector_strike.nav.grid import NavGrid
from vector_strike.physics.vec import Vec3


def tick(s, seconds=0.1, intent=None):
    for _ in range(max(1, int(seconds * 60))):
        s.step(1 / 60, intent or PlayerIntent())


def test_all_mission_files_validate_and_reference_real_things():
    ms = list_missions()
    assert {m.id for m in ms} == {"training", "vector_01", "vector_02", "survival_breach", "mr_invasion"}
    for m in ms:
        if m.mode.value != "mr":
            lvl = build_level(m.level)
            for name, entries in m.groups.items():
                for e in entries:
                    assert e.at in lvl.spawn_points, (m.id, name, e.at)
                    if e.route:
                        assert e.route in lvl.patrol_routes
            for o in m.objectives:
                if o.zone:
                    assert o.zone in lvl.zones, (m.id, o.zone)
                if o.type in ("interact", "pickup"):
                    assert o.target in lvl.interactables, (m.id, o.target)
                for a in o.on_activate + o.on_complete:
                    if a["action"] in ("unlock_door", "lock_door"):
                        assert a["id"] in lvl.doors
                    if a["action"] == "spawn_group":
                        assert a["group"] in m.groups


def test_unknown_mission_and_bad_schema_rejected(tmp_path):
    with pytest.raises(KeyError):
        load_mission("nope")
    with pytest.raises(Exception):
        MissionDef.model_validate({"id": "x", "title": "x", "level": "x", "bogus": 1})


def test_mission_spec_example_exists():
    raw = yaml.safe_load((missions_dir() / "vector_01.yaml").read_text())["mission"]
    assert raw["id"] == "vector_01" and raw["title"] == "BLACKOUT"
    ids = [o["id"] for o in raw["objectives"]]
    for needed in ("reach_entry_point", "secure_terminal", "extract"):
        assert needed in ids


@pytest.mark.parametrize("lid", list(LEVELS))
def test_levels_are_deterministic_and_navigable(lid):
    a, b = build_level(lid, 5), build_level(lid, 5)
    assert [c.aabb for c in a.world.colliders.values()] == [c.aabb for c in b.world.colliders.values()]
    nav = NavGrid(*a.bounds)
    nav.rebuild(a.world)
    assert nav.is_walkable_pos(a.player_start[0])


def test_blackout_phases_gating_and_events():
    s = GameSession.create(Settings(), "vector_01", seed=1)
    r = s.runner
    assert r.phase is MissionPhase.INFILTRATION and r.active_primary().defn.id == "reach_entry_point"
    assert s.level.doors["blast_door"].locked and not s.interactables["data_terminal"].enabled
    s.player.state.god_mode = True
    s.player.state.pos = s.level.zones["entry_point"].center
    tick(s, 0.1)
    assert r.active_primary().defn.id == "disable_security"
    s.player.state.pos = Vec3(10.6, 0, 32.2)
    s.player.state.yaw = 3.14159 / 2 * 0  # facing +z toward console
    tick(s, 3.5, PlayerIntent(interact=True))
    assert r.active_primary().defn.id == "reach_server" and not s.level.doors["blast_door"].locked
    s.player.state.pos = s.level.zones["server_room"].center
    tick(s, 0.1)
    assert r.active_primary().defn.id == "secure_terminal"
    for e in list(s.enemies):
        if e.group == "server":
            e.apply_damage(1e6, "head", Vec3(), "t")
    tick(s, 0.2)
    assert r.active_primary().defn.id == "download_data" and r.phase is MissionPhase.ESCALATION
    s.player.state.pos = Vec3(30, 0, 44.4)
    s.player.state.yaw = 0.0
    n_before = len(s.enemies)
    tick(s, 9.0, PlayerIntent(interact=True))
    assert not s.powered and r.phase is MissionPhase.EXTRACTION
    assert s.group_spawned("escalation_b") and not s.level.doors["dock_door"].locked
    s.player.state.pos = s.level.zones["extract"].center
    tick(s, 0.2)
    assert s.done and s.result.success and s.result.primary_done == s.result.primary_total


def test_player_death_fails_mission_and_scores_zero_completion():
    s = GameSession.create(Settings(), "vector_01", seed=1)
    s.player.apply_damage(500, "body", Vec3(), "t")
    tick(s, 0.1)
    assert s.done and not s.result.success and s.result.reason == "Operative down"
    assert s.result.score.lines[2].points == 0 and s.result.score.lines[3].points == 0


def test_lockdown_timer_failure_in_transit():
    s = GameSession.create(Settings(), "vector_02", seed=2)
    s.player.state.god_mode = True
    from vector_strike.missions.runner import MissionTimer

    s.runner.timers["lockdown"] = MissionTimer("lockdown", 0.5, True, "LOCKDOWN")
    tick(s, 1.0)
    assert s.done and s.result.reason == "LOCKDOWN"


def test_optional_objective_tracked():
    s = GameSession.create(Settings(), "vector_01", seed=1)
    assert s.runner.optional_total == 1 and s.interactables["intel_laptop"].enabled
    s.player.state.pos = Vec3(50.6, 0, 32.0)
    s.player.state.god_mode = True
    tick(s, 2.5, PlayerIntent(interact=True))
    assert s.runner.optional_done == 1


def test_training_flow_events():
    s = GameSession.create(Settings(), "training", seed=1)
    assert s.inventory.weapon is None
    ids = [o.id for o in s.mission.objectives]
    assert ids[0] == "move_a" and "mr_link" in ids and "grenade" in ids


def test_survival_waves_progress_and_boss_phases():
    s = GameSession.create(Settings(), "survival_breach", seed=1)
    s.player.state.god_mode = True
    w = s.waves
    seen = []
    s.bus.subscribe(ev.WAVE_START, lambda e: seen.append(e.data["tag"]))
    for _ in range(20000):
        tick(s, 0.05)
        for e in s.alive_enemies():
            e.apply_damage(1e6, "head", Vec3(), "t")  # clear every wave instantly
        if w.finished:
            break
    assert w.finished and seen == ["wave", "wave", "wave", "elite", "boss"]
    assert s.done and s.result.success and s.result.waves_cleared == 5


def test_scoring_is_transparent_and_not_kill_based():
    base = dict(
        primary_done=5,
        primary_total=5,
        optional_done=0,
        optional_total=1,
        shots=100,
        hits=50,
        elapsed=300,
        par_time=600,
        damage_taken=50,
        completed=True,
    )
    a = compute_score(**base)
    assert sum(l.points for l in a.lines) == a.total and [l.label for l in a.lines] == [
        "OBJECTIVES",
        "OPTIONAL OBJECTIVES",
        "ACCURACY",
        "TIME",
        "DAMAGE TAKEN",
    ]
    spray = compute_score(**{**base, "shots": 1000, "hits": 80})  # more hits, terrible accuracy
    assert spray.total < a.total
    reckless = compute_score(**{**base, "damage_taken": 400})
    assert reckless.total < a.total
    failed = compute_score(**{**base, "completed": False, "primary_done": 2})
    assert failed.total < a.total / 2
    assert compute_score(**{**base, "difficulty_multiplier": 1.3}).total > a.total
