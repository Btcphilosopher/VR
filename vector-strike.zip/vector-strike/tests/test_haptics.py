import pytest

from vector_strike.core.config import HapticsCfg
from vector_strike.core.types import Hand
from vector_strike.game import events as ev
from vector_strike.game.events import EventBus
from vector_strike.haptics.devices import RecordingHapticDevice
from vector_strike.haptics.director import HapticDirector
from vector_strike.haptics.engine import HapticEngine
from vector_strike.haptics.patterns import (
    Group,
    HapticPattern,
    Keyframe,
    get_pattern,
    pattern_names,
    weapon_fire,
)
from vector_strike.haptics.profile import HapticProfile
from vector_strike.weapons.spec import CATALOGUE
from vector_strike.weapons.weapon import Weapon


def run(director, seconds=0.3, dt=1 / 90):
    for _ in range(int(seconds / dt)):
        director.update(dt)


def make(cfg=None):
    bus = EventBus()
    dev = RecordingHapticDevice()
    return bus, dev, HapticDirector(bus, cfg or HapticsCfg(intensity=1.0), dev)


def test_pattern_sampling_interpolates_and_ends():
    p = HapticPattern("t", (Keyframe(0, 0, 0.5), Keyframe(0.1, 1.0, 0.5), Keyframe(0.2, 0, 0.5)), Group.UI)
    assert p.sample(0.05)[0] == pytest.approx(0.5)
    assert p.sample(0.1)[0] == pytest.approx(1.0)
    assert p.sample(0.25)[0] == 0.0 and p.duration == pytest.approx(0.2)


def test_library_nonempty_and_valid():
    names = pattern_names()
    assert len(names) >= 15
    for n in names:
        p = get_pattern(n)
        assert p.duration > 0 and all(0 <= k.amp <= 1 and 0 <= k.freq <= 1 for k in p.keyframes)


def test_every_weapon_profile_produces_a_pattern():
    for w in CATALOGUE.values():
        p = weapon_fire(w.haptic)
        assert max(k.amp for k in p.keyframes) == pytest.approx(w.haptic.kick)


def test_shotgun_kicks_harder_and_longer_than_smg():
    sg, smg = weapon_fire(CATALOGUE["hm12_hammer"].haptic), weapon_fire(CATALOGUE["sp9_sparrow"].haptic)
    assert sg.duration > smg.duration and max(k.amp for k in sg.keyframes) > max(k.amp for k in smg.keyframes)


def test_weapon_fire_event_drives_both_hands_two_handed():
    bus, dev, d = make()
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.hand, w.support_hand = Hand.RIGHT, Hand.LEFT
    assert w.pull_trigger(True)
    w.consume_round()
    run(d)
    r, l = dev.peak(Hand.RIGHT), dev.peak(Hand.LEFT)
    assert r > l > 0
    assert l == pytest.approx(r * CATALOGUE["ks4_kestrel"].haptic.support_scale, rel=0.2)


def test_one_handed_fire_only_vibrates_weapon_hand():
    bus, dev, d = make()
    w = Weapon.create(CATALOGUE["p11_pilot"], bus)
    w.hand, w.support_hand = Hand.LEFT, None
    w.pull_trigger(True)
    w.consume_round()
    run(d)
    assert dev.peak(Hand.LEFT) > 0 and dev.peak(Hand.RIGHT) == 0


def test_reload_events_have_distinct_haptic_signatures():
    bus, dev, d = make()
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.hand, w.support_hand = Hand.RIGHT, Hand.LEFT
    w.ammo = 5
    w.drop_magazine()
    run(d, 0.2)
    drop_peak = dev.peak(Hand.RIGHT)
    n_before = len(dev.log)
    w.insert_magazine()
    run(d, 0.3)
    assert drop_peak > 0 and len(dev.log) > n_before
    assert dev.peak(Hand.LEFT) > 0  # support hand seats the magazine
    w.charge()
    run(d, 0.3)


def test_hit_confirm_and_kill_confirm():
    bus, dev, d = make()
    bus.emit(ev.HIT_CONFIRM, hands=["right"])
    run(d, 0.1)
    hit = dev.peak(Hand.RIGHT)
    bus.emit(ev.KILL_CONFIRM, hands=["right"])
    run(d, 0.2)
    assert 0 < hit < dev.peak(Hand.RIGHT) + 1e-9 + 0.5


def test_damage_is_directional():
    bus, dev, d = make()
    bus.emit(ev.PLAYER_DAMAGED, amount=20.0, angle=1.5707)  # from the right
    run(d, 0.2)
    assert dev.peak(Hand.RIGHT) > dev.peak(Hand.LEFT) > 0
    bus2, dev2, d2 = make()
    bus2.emit(ev.PLAYER_DAMAGED, amount=20.0, angle=-1.5707)  # from the left
    run(d2, 0.2)
    assert dev2.peak(Hand.LEFT) > dev2.peak(Hand.RIGHT)


def test_explosion_falls_off_with_distance_and_is_culled():
    bus, dev, d = make()
    bus.emit(ev.EXPLOSION, distance_to_player=2.0)
    run(d, 0.5)
    near = dev.peak(Hand.LEFT)
    bus2, dev2, d2 = make()
    bus2.emit(ev.EXPLOSION, distance_to_player=20.0)
    run(d2, 0.5)
    bus3, dev3, d3 = make()
    bus3.emit(ev.EXPLOSION, distance_to_player=50.0)
    run(d3, 0.5)
    assert near > dev2.peak(Hand.LEFT) > 0 and dev3.peak(Hand.LEFT) == 0


def test_disabled_and_intensity_and_reduced_settings():
    bus, dev, d = make(HapticsCfg(enabled=False))
    bus.emit(ev.PLAYER_DAMAGED, amount=50.0, angle=0.0)
    run(d, 0.3)
    assert not dev.log
    full = make(HapticsCfg(intensity=1.0))
    half = make(HapticsCfg(intensity=0.5))
    for b, _dv, dr in (full, half):
        b.emit(ev.EXPLOSION, distance_to_player=1.0)
        run(dr, 0.4)
    assert half[1].peak(Hand.LEFT) == pytest.approx(full[1].peak(Hand.LEFT) * 0.5, rel=0.05)
    red = make(HapticsCfg(intensity=1.0, reduced=True))
    red[0].emit(ev.EXPLOSION, distance_to_player=0.5)
    run(red[2], 0.4)
    assert red[1].peak(Hand.LEFT) <= 0.5 + 1e-6


def test_group_and_hand_toggles():
    bus, dev, d = make(HapticsCfg(weapons=False, right_hand=False, intensity=1.0))
    w = Weapon.create(CATALOGUE["ks4_kestrel"], bus)
    w.pull_trigger(True)
    w.consume_round()
    bus.emit(ev.PLAYER_DAMAGED, amount=30.0, angle=0.0)
    run(d, 0.3)
    assert dev.peak(Hand.RIGHT) == 0 and dev.peak(Hand.LEFT) > 0  # weapon recoil off, right hand off


def test_mixer_soft_clips_and_ducks_low_priority():
    eng = HapticEngine(HapticsCfg(intensity=1.0))
    big = get_pattern("wall_breach")
    for _ in range(6):
        eng.voices[Hand.RIGHT].append(
            __import__("vector_strike.haptics.engine", fromlist=["Voice"]).Voice(big, Hand.RIGHT, 0.0, 1.0)
        )
    s = eng.update(0.01)[Hand.RIGHT]
    assert s.amp <= 1.0
    eng2 = HapticEngine(HapticsCfg(intensity=1.0))
    eng2.trigger(get_pattern("ui_hover"), Hand.LEFT)
    base = eng2.update(0.001)[Hand.LEFT].amp
    eng3 = HapticEngine(HapticsCfg(intensity=1.0))
    eng3.trigger(get_pattern("ui_hover"), Hand.LEFT)
    eng3.trigger(get_pattern("wall_breach"), Hand.LEFT)
    # hover (priority 1) is ducked under breach (priority 9): contribution halves
    assert eng3.update(0.001)[Hand.LEFT].amp > base


def test_rate_limit_and_voice_cap():
    eng = HapticEngine(HapticsCfg(intensity=1.0))
    p = get_pattern("hit_confirm")
    assert eng.trigger(p, Hand.RIGHT)
    assert not eng.trigger(p, Hand.RIGHT)  # min_interval
    eng.update(0.05)
    assert eng.trigger(p, Hand.RIGHT)
    for i in range(20):
        eng.t += 1.0
        eng.trigger(weapon_fire(HapticProfile(tail_ms=2000), f"w{i}"), Hand.LEFT)
    assert len(eng.voices[Hand.LEFT]) <= 8


def test_heartbeat_loops_when_health_low_and_stops():
    bus, dev, d = make()
    hp = [0.1]
    d.attach_health(lambda: hp[0])
    run(d, 1.5)
    assert dev.peak(Hand.LEFT) > 0
    hp[0] = 1.0
    run(d, 0.2)
    n = len(dev.log)
    run(d, 1.5)
    assert len(dev.log) == n  # silent once healthy


def test_trigger_named_for_dev_console():
    bus, dev, d = make()
    assert d.trigger_named("ui_select", Hand.LEFT)
    run(d, 0.1)
    assert dev.peak(Hand.LEFT) > 0
    with pytest.raises(KeyError):
        d.trigger_named("nope")
