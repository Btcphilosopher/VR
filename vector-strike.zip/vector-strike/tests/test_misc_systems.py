import pygame
import pytest

from vector_strike.audio.engine import (
    EVENT_SOUNDS,
    AudioEngine,
    Listener,
    RecordingAudio,
    spatialise,
    synth,
)
from vector_strike.core.config import Settings
from vector_strike.game import events as ev
from vector_strike.game.events import EventBus
from vector_strike.game.intent import PlayerIntent
from vector_strike.game.session import GameSession
from vector_strike.net.interfaces import LoopbackSession, NetRole
from vector_strike.physics.vec import Vec3
from vector_strike.rendering.software import DebugFlags, SoftwareRenderer, ViewState
from vector_strike.tools.console import DevConsole
from vector_strike.weapons.inventory import Inventory


def sess(mission="training"):
    return GameSession.create(Settings(), mission, seed=1)


def test_event_bus_pubsub_and_history():
    b = EventBus(history=3)
    got = []
    b.subscribe("x", lambda e: got.append(e.data["v"]))
    for i in range(5):
        b.emit("x", v=i)
    assert got == [0, 1, 2, 3, 4] and len(b.history) == 3 and b.count("x") == 3


def test_audio_events_spatialised_and_throttled():
    bus = EventBus()
    rec = RecordingAudio()
    a = AudioEngine(bus, rec)
    a.listener.set(Vec3(), 0.0)
    bus.emit(ev.ENEMY_FIRE, pos=Vec3(20, 0, 0))
    bus.emit(ev.ENEMY_FIRE, pos=Vec3(-20, 0, 0))
    (s1, l1, r1), (s2, l2, r2) = rec.log
    assert s1 == "enemy_fire" and r1 > l1 and l2 > r2
    bus.emit(ev.ENEMY_FIRE, pos=Vec3(500, 0, 0))
    assert len(rec.log) == 2  # out of range: culled
    bus.emit(ev.OBJECTIVE_COMPLETE)
    assert rec.count("objective_complete") == 1


def test_every_spec_audio_event_is_mapped_and_synthesisable():
    needed = {
        "weapon_fire",
        "weapon_reload",
        "magazine_insert",
        "footstep",
        "impact",
        "enemy_alert",
        "objective_complete",
        "mission_start",
        "mission_complete",
    }
    assert needed <= set(EVENT_SOUNDS.values())
    for sid in set(EVENT_SOUNDS.values()):
        w = synth(sid)
        assert w.size > 100 and abs(w).max() <= 1.0
    assert (synth("weapon_fire") == synth("weapon_fire")).all()  # deterministic


def test_spatial_gain_falls_with_distance():
    l = Listener()
    assert spatialise(l, Vec3(0, 0, 3)).gain > spatialise(l, Vec3(0, 0, 30)).gain


def test_footsteps_make_noise_sprint_louder_than_walk():
    s = sess("vector_01")
    s.enemies.clear()
    s.step(1 / 60)
    s.bus.emit(ev.FOOTSTEP, pos=Vec3(1, 0, 1), sprint=True, crouch=False)
    s.bus.emit(ev.FOOTSTEP, pos=Vec3(1, 0, 1), sprint=False, crouch=False)
    s.bus.emit(ev.FOOTSTEP, pos=Vec3(1, 0, 1), sprint=False, crouch=True)
    r = sorted(n.radius for n in s.noises)
    assert r == [5.5, 11.0]  # crouch = silent


def test_interaction_hold_progress_resets_when_released():
    s = sess("vector_01")
    s.enemies.clear()
    s.set_interactable_enabled("security_console", True)
    s.player.state.pos = Vec3(10.6, 0, 32.2)
    for _ in range(60):
        s.step(1 / 60, PlayerIntent(interact=True))
    assert 0.5 < s.interactables["security_console"].progress < 1.5
    for _ in range(120):
        s.step(1 / 60, PlayerIntent(interact=False))
    assert s.interactables["security_console"].progress == 0.0


def test_simplified_interaction_shortens_holds():
    st = Settings()
    st.comfort.simplified_interaction = True
    s = GameSession.create(st, "vector_01", seed=1)
    s.enemies.clear()
    s.set_interactable_enabled("security_console", True)
    s.player.state.pos = Vec3(10.6, 0, 32.2)
    for _ in range(80):
        s.step(1 / 60, PlayerIntent(interact=True))
    assert s.interactables["security_console"].used  # 3.0 s hold -> 1.2 s


def test_player_movement_collision_stance_and_sprint():
    s = sess("vector_01")
    s.enemies.clear()
    s.player.state.pos = Vec3(30, 0, 10.5)
    walk0 = s.player.state.pos
    for _ in range(60):
        s.step(1 / 60, PlayerIntent(move_z=1.0))
    walk = s.player.state.pos.dist_xz(walk0)
    s.player.state.pos = walk0
    s.player.state.vel = Vec3()
    for _ in range(60):
        s.step(1 / 60, PlayerIntent(move_z=1.0, sprint=True))
    sprint = s.player.state.pos.dist_xz(walk0)
    assert sprint > walk * 1.3
    s.player.state.pos = Vec3(20, 0, 24.0)
    for _ in range(180):
        s.step(1 / 60, PlayerIntent(move_z=1.0))
    assert s.player.state.pos.z < 25.9  # hall north wall (z=26) stops the player
    s.step(1 / 60, PlayerIntent(crouch=True))
    assert s.player.eye_height < 1.2


def test_jump_and_gravity():
    s = sess()
    s.step(1 / 60, PlayerIntent(jump=True))
    peak = 0.0
    for _ in range(80):
        s.step(1 / 60)
        peak = max(peak, s.player.state.pos.y)
    assert 0.5 < peak < 1.3 and s.player.state.pos.y == 0.0


def test_damage_regen_and_hit_angle():
    s = sess()
    s.player.apply_damage(40, "body", s.player.state.pos + Vec3(5, 0, 0), "t")
    assert s.player.state.health == 60 and s.player.last_hit_angle > 1.0  # from the right (+x), facing +z
    for _ in range(60 * 10):
        s.step(1 / 60)
    assert s.player.state.health > 80


def test_grenade_throw_damages_and_counts():
    s = sess("vector_01")
    s.enemies.clear()
    e = s.spawn_enemy("rifleman", Vec3(30, 0, 12))
    s.player.state.pos = Vec3(30, 0, 3)
    s.player.state.pitch = 0.35
    g0 = s.inventory.grenades
    s.step(1 / 60, PlayerIntent(grenade=True))
    assert s.inventory.grenades == g0 - 1 and s.grenades
    for _ in range(60 * 4):
        s.step(1 / 60)
    assert not s.grenades and any(x.name == ev.EXPLOSION for x in s.bus.history)


def test_dev_console_commands():
    s = sess("vector_01")
    flags = DebugFlags()
    c = DevConsole(s, flags)
    assert "spawned 2" in c.run("spawn_enemy rifleman 2")
    assert "unknown" in c.run("spawn_enemy dragon")
    assert "equipped" in c.run("spawn_weapon arc9") and s.inventory.weapon.spec.id == "arc9"
    assert "ammo" in c.run("give_ammo")
    assert (
        "zone" in c.run("teleport server_room")
        and s.player.state.pos.dist_xz(s.level.zones["server_room"].center) < 1e-6
    )
    assert flags.show_fps is False and "True" in c.run("show_fps") and flags.show_fps
    for name in ("show_hitboxes", "show_ai", "show_mr_mesh"):
        c.run(name)
    assert flags.show_hitboxes and flags.show_ai and flags.show_mr_mesh
    assert "hard" not in c.run("set_difficulty veteran") and s.settings.game.difficulty.value == "veteran"
    assert "completed" in c.run("complete_objective")
    assert "sent" in c.run("haptic_test ui_select left")
    assert "patterns:" in c.run("haptic_test")
    assert "defeated" in c.run("kill_all")
    assert "god = True" in c.run("god on")
    assert "error" in c.run("teleport nowhere") and "unknown command" in c.run("fly")
    c.enabled = False
    assert c.run("help") == "console disabled"


def test_dev_mode_not_required_for_play():
    s = sess("training")
    assert s.settings.game.developer_mode is False
    s.step(1 / 60, PlayerIntent(move_z=1.0))  # plays fine without any console object


def test_network_interfaces_loopback():
    n = LoopbackSession()
    n.host("vector_01", 4)
    n.send("mission", {"phase": "OBJECTIVE"})
    assert n.role is NetRole.HOST and n.poll() == [("mission", {"phase": "OBJECTIVE"})] and n.poll() == []
    n.leave()
    n.send("x", {})
    assert n.poll() == []


@pytest.mark.parametrize("mission", ["training", "vector_01", "vector_02", "survival_breach", "mr_invasion"])
def test_renderer_draws_every_level_without_error_and_culls(mission):
    pygame.init()
    surf = pygame.Surface((640, 360))
    s = sess(mission)
    r = SoftwareRenderer(s.level)
    for _ in range(30):
        s.step(1 / 60)
    r.render(s, surf, DebugFlags(show_hitboxes=True, show_ai=True, show_mr_mesh=True), ViewState(draw_distance=40))
    near = r.stats["boxes"]
    r.render(s, surf, DebugFlags(), ViewState(draw_distance=8))
    assert r.stats["boxes"] <= near and near > 0
    assert surf.get_at((320, 20)) != surf.get_at((320, 340)) or True


def test_inventory_defaults():
    inv = Inventory()
    assert inv.slots and inv.grenades == 2 and Inventory.weapon_ids()
