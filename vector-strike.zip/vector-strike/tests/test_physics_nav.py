import pytest

from vector_strike.nav.grid import NavGrid
from vector_strike.physics.shapes import AABB, ray_aabb
from vector_strike.physics.vec import Vec3, angles_from_direction, forward_from_angles, wrap_angle
from vector_strike.physics.world import Material, World
from vector_strike.weapons.grenade import BLAST_RADIUS, Grenade, blast_damage


def test_ray_aabb_hit_and_miss():
    b = AABB(Vec3(1, 0, -1), Vec3(2, 2, 1))
    assert ray_aabb(Vec3(0, 1, 0), Vec3(1, 0, 0), b) == pytest.approx(1.0)
    assert ray_aabb(Vec3(0, 5, 0), Vec3(1, 0, 0), b) is None
    assert ray_aabb(Vec3(1.5, 1, 0), Vec3(1, 0, 0), b) == 0.0  # origin inside


def test_world_raycast_order_and_los():
    w = World()
    w.add(AABB(Vec3(5, 0, -1), Vec3(5.3, 3, 1)), Material.CONCRETE)
    w.add(AABB(Vec3(3, 0, -1), Vec3(3.1, 3, 1)), Material.WOOD)
    hits = w.raycast_all(Vec3(0, 1, 0), Vec3(1, 0, 0), 20)
    assert [h.collider.material for h in hits] == [Material.WOOD, Material.CONCRETE]
    assert not w.line_of_sight(Vec3(0, 1, 0), Vec3(8, 1, 0))
    assert w.line_of_sight(Vec3(0, 1, 0), Vec3(2, 1, 0))


def test_open_door_unblocks():
    w = World()
    c = w.add(AABB(Vec3(2, 0, -1), Vec3(2.2, 2.6, 1)), Material.STEEL)
    assert not w.line_of_sight(Vec3(0, 1, 0), Vec3(4, 1, 0))
    w.set_open(c.id, True)
    assert w.line_of_sight(Vec3(0, 1, 0), Vec3(4, 1, 0))


def test_collision_slides_along_walls():
    w = World()
    w.add(AABB(Vec3(2, 0, -5), Vec3(2.3, 3, 5)))
    pos, grounded = w.move_and_collide(Vec3(1.5, 0, 0), Vec3(1.0, 0, 0.5), 0.3, 1.7)
    assert pos.x == pytest.approx(1.5) and pos.z == pytest.approx(0.5) and grounded


def test_gravity_floor_clamp():
    pos, g = World().move_and_collide(Vec3(0, 0.5, 0), Vec3(0, -2, 0), 0.3, 1.7)
    assert pos.y == 0.0 and g


def test_spatial_hash_query_matches_bruteforce():
    w = World()
    import random

    r = random.Random(1)
    boxes = []
    for _ in range(80):
        x, z = r.uniform(-40, 40), r.uniform(-40, 40)
        boxes.append(w.add(AABB(Vec3(x, 0, z), Vec3(x + r.uniform(0.3, 3), 2, z + r.uniform(0.3, 3)))))
    q = AABB(Vec3(-10, 0, -10), Vec3(12, 2, 15))
    assert {c.id for c in w.query_aabb(q)} == {c.id for c in boxes if c.aabb.intersects(q)}


def test_nav_path_around_wall_and_blocked():
    w = World()
    w.add(AABB(Vec3(5, 0, 0), Vec3(5.3, 3, 8)))
    nav = NavGrid(0, 0, 10, 10)
    nav.rebuild(w)
    path = nav.find_path(Vec3(2, 0, 2), Vec3(8, 0, 2))
    assert path and max(p.z for p in path) > 8
    w.add(AABB(Vec3(5, 0, 8), Vec3(5.3, 3, 10)))
    nav.rebuild(w)
    assert nav.find_path(Vec3(2, 0, 2), Vec3(8, 0, 2)) is None


def test_nav_does_not_jump_walls_when_hugging():
    w = World()
    w.add(AABB(Vec3(5, 0, 0), Vec3(5.3, 3, 10)))
    nav = NavGrid(0, 0, 10, 10)
    nav.rebuild(w)
    assert nav.find_path(Vec3(4.75, 0, 5), Vec3(8, 0, 5)) is None


def test_angles_roundtrip():
    f = forward_from_angles(0.7, 0.2)
    yaw, pitch = angles_from_direction(f)
    assert yaw == pytest.approx(0.7) and pitch == pytest.approx(0.2)
    assert wrap_angle(7.0) == pytest.approx(7.0 - 2 * 3.14159265, abs=1e-6)


def test_grenade_arc_bounce_and_fuse():
    w = World()
    g = Grenade(Vec3(0, 1.5, 0), Vec3(0, 3, 10), team=None)  # type: ignore[arg-type]
    exploded = False
    for _ in range(300):
        if g.step(1 / 60, w):
            exploded = True
            break
    assert exploded and g.pos.z > 5 and g.pos.y >= 0.0


def test_blast_falloff():
    assert blast_damage(0.0) > blast_damage(3.0) > blast_damage(BLAST_RADIUS - 0.1) > 0
    assert blast_damage(BLAST_RADIUS + 1) == 0
