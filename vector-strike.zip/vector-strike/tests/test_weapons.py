import random

import pytest

from vector_strike.core.types import Team
from vector_strike.game import events as ev
from vector_strike.physics.shapes import AABB, Hitbox
from vector_strike.physics.vec import Vec3
from vector_strike.physics.world import Material, World
from vector_strike.weapons.firemodel import ProjectileSystem, WeaponFireModel
from vector_strike.weapons.inventory import Inventory
from vector_strike.weapons.spec import CATALOGUE, Slot, get_spec
from vector_strike.weapons.weapon import Weapon, WeaponState


class Dummy:
    team = Team.HELIX

    def __init__(self, pos, hp=100.0):
        self.pos, self.hp, self.alive = pos, hp, True

    def hitboxes(self):
        p = self.pos
        return [
            Hitbox("head", AABB(Vec3(p.x - 0.15, 1.55, p.z - 0.15), Vec3(p.x + 0.15, 1.85, p.z + 0.15)), 2.0),
            Hitbox("torso", AABB(Vec3(p.x - 0.3, 0.85, p.z - 0.2), Vec3(p.x + 0.3, 1.55, p.z + 0.2)), 1.0),
        ]

    def apply_damage(self, amount, hitbox, source_pos, source):
        self.hp -= amount
        if self.hp <= 0:
            self.alive = False
        return not self.alive


def test_catalogue_complete():
    kinds = {w.kind.value for w in CATALOGUE.values()}
    assert kinds == {"rifle", "carbine", "smg", "shotgun", "sidearm", "energy", "training"}
    for w in CATALOGUE.values():
        assert w.damage > 0 and w.rate_of_fire > 0 and w.magazine_capacity > 0 and w.range > 0


def test_fire_consumes_ammo_and_respects_cooldown(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus)
    assert w.state_timer == 0 and w.ammo == 30
    w.state = WeaponState.READY
    assert w.pull_trigger(True)
    w.consume_round()
    assert w.ammo == 29 and not w.can_fire  # cooldown
    w.update(w.spec.cooldown + 1e-3)
    assert w.can_fire
    assert bus.count(ev.WEAPON_FIRE) == 1


def test_semi_auto_requires_new_trigger_pull(bus):
    w = Weapon.create(get_spec("p11_pilot"), bus)
    assert w.pull_trigger(True)
    w.consume_round()
    w.update(1.0)
    assert not w.pull_trigger(True)  # held, semi-auto
    w.pull_trigger(False)
    assert w.pull_trigger(True)


def test_dry_fire_event(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus, full=False)
    assert not w.pull_trigger(True)
    assert bus.count(ev.WEAPON_DRY) == 1


def test_timed_reload_sequence(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus)
    w.ammo = 3
    assert w.start_reload()
    for _ in range(int(w.spec.reload_time * 60) + 5):
        w.update(1 / 60)
    assert w.ammo == 30 and w.reserve == 120 - 27 and w.state is WeaponState.READY
    names = [e.name for e in bus.history]
    assert names.index(ev.MAGAZINE_DROP) < names.index(ev.MAGAZINE_INSERT) < names.index(ev.WEAPON_CHAMBER)
    assert ev.WEAPON_RELOAD_COMPLETE in names


def test_cannot_reload_full_or_without_reserve(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus)
    assert not w.start_reload()
    w.ammo, w.reserve = 5, 0
    assert not w.start_reload()


def test_physical_reload_state_machine(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus)
    w.ammo = 10
    assert w.drop_magazine()
    assert w.state is WeaponState.MAG_OUT and w.ammo == 0 and w.reserve == 130  # rounds returned (tactical)
    assert not w.charge()  # wrong order
    assert w.insert_magazine()
    assert w.state is WeaponState.CHAMBER_PENDING and w.ammo == 30
    assert not w.can_fire
    assert w.charge() and w.state is WeaponState.READY and w.can_fire


def test_energy_weapon_needs_no_chambering(bus):
    w = Weapon.create(get_spec("arc9"), bus)
    w.drop_magazine()
    w.insert_magazine()
    assert w.state is WeaponState.READY


def test_trainer_infinite_reserve(bus):
    w = Weapon.create(get_spec("tr0_trainer"), bus)
    w.ammo = 0
    assert w.start_reload()
    for _ in range(120):
        w.update(1 / 60)
    assert w.ammo == 20


def test_recoil_accumulates_and_recovers(bus):
    w = Weapon.create(get_spec("ks4_kestrel"), bus)
    for _ in range(5):
        w.cooldown = 0
        w.pull_trigger(True)
        w.consume_round()
    assert w.recoil_pitch > 3.0
    total = 0.0
    for _ in range(120):
        p, _ = w.take_recoil(1 / 60)
        total += p
    assert w.recoil_pitch < 0.01 and total > 3.0


def test_hitscan_hits_and_damage_falloff():
    world = World()
    t = Dummy(Vec3(0, 0, 10))
    model = WeaponFireModel(get_spec("ks4_kestrel"))
    rng = random.Random(1)
    res = model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, world, [t], rng, spread_deg=0.0)
    assert len(res.hits) == 1 and res.hits[0].hitbox == "torso" and res.hits[0].damage == pytest.approx(24)
    far = Dummy(Vec3(0, 0, 100))
    res2 = model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, world, [far], rng, spread_deg=0.0)
    assert res2.hits and res2.hits[0].damage < 24


def test_headshot_multiplier():
    t = Dummy(Vec3(0, 0, 8))
    model = WeaponFireModel(get_spec("ks4_kestrel"))
    res = model.fire(Vec3(0, 1.7, 0), Vec3(0, 0, 1), Team.VECTOR, World(), [t], random.Random(1), spread_deg=0.0)
    assert res.hits[0].hitbox == "head" and res.hits[0].damage == pytest.approx(48)


def test_wall_blocks_and_thin_material_penetrates():
    world = World()
    world.add(AABB(Vec3(-2, 0, 5), Vec3(2, 3, 5.3)), Material.CONCRETE)
    t = Dummy(Vec3(0, 0, 10))
    model = WeaponFireModel(get_spec("ks4_kestrel"))
    res = model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, world, [t], random.Random(1), spread_deg=0.0)
    assert not res.hits  # concrete blocks
    w2 = World()
    w2.add(AABB(Vec3(-2, 0, 5), Vec3(2, 3, 5.1)), Material.WOOD)
    res = model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, w2, [t], random.Random(1), spread_deg=0.0)
    assert res.hits and res.hits[0].damage < 24  # penetrated with loss


def test_shotgun_pellets_spread():
    t = Dummy(Vec3(0, 0, 6))
    model = WeaponFireModel(get_spec("hm12_hammer"))
    res = model.fire(Vec3(0, 1.2, 0), Vec3(0, 0, 1), Team.VECTOR, World(), [t], random.Random(3))
    assert len(res.traces) == 8


def test_fire_model_is_deterministic():
    model = WeaponFireModel(get_spec("sp9_sparrow"))

    def run():
        t = Dummy(Vec3(0, 0, 20))
        r = random.Random(42)
        return [
            tuple(round(c, 6) for c in tr.end.as_tuple())
            for _ in range(10)
            for tr in model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, World(), [t], r).traces
        ]

    assert run() == run()


def test_projectile_weapon_spawns_and_hits():
    t = Dummy(Vec3(0, 0, 20))
    ps = ProjectileSystem(8)
    model = WeaponFireModel(get_spec("arc9"))
    res = model.fire(Vec3(0, 1.4, 0), Vec3(0, 0, 1), Team.VECTOR, World(), [t], random.Random(1), ps, spread_deg=0.0)
    assert res.spawned_projectiles == 1 and ps.active_count == 1
    hits = []
    for _ in range(60):
        hits += [i for _, _, i, _ in ps.step(1 / 60, World(), [t]) if i]
    assert hits and ps.active_count == 0 and t.hp < 100


def test_projectile_pool_is_bounded():
    ps = ProjectileSystem(2)
    for _ in range(5):
        ps.spawn(Vec3(), Vec3(0, 0, 1), 1, 1, Team.VECTOR, "", "amber")
    assert ps.active_count == 2


def test_inventory_slots_and_switching(bus):
    inv = Inventory(bus)
    inv.add_weapon("ks4_kestrel")
    inv.add_weapon("p11_pilot", make_active=False)
    assert inv.active is Slot.PRIMARY
    assert inv.switch_to(Slot.SECONDARY) and inv.weapon.spec.id == "p11_pilot"
    assert not inv.switch_to(Slot.SPECIAL)  # empty slot
    assert bus.count(ev.WEAPON_SWITCH) == 1
    assert inv.cycle() and inv.active is Slot.PRIMARY
