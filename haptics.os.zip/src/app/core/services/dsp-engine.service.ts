import { Injectable } from '@angular/core';
import {
  ActuatorModelConfig,
  ControlLoopResult,
  EnvelopeConfig,
  FFTResult,
  HapticEvent,
  HapticMaterialProfile,
  MechanicalSimulationResult,
  MonteCarloIteration,
  MonteCarloSummary,
  PerceptualScore,
  SignalData,
  SignalMetrics,
  SpectrogramResult,
  VibrationParams1DOF,
  VibrationParamsNDOF,
} from '../models/haptics.models';

@Injectable({
  providedIn: 'root',
})
export class DspEngineService {
  // Standard sampling rate for haptic signal generation (Hz)
  public readonly DEFAULT_SAMPLE_RATE = 10000; // 10 kHz (0.1ms resolution)

  /**
   * Generates discrete numeric time-series samples for a parameterized HapticEvent
   */
  public generateEventSignal(event: HapticEvent, sampleRate = this.DEFAULT_SAMPLE_RATE): SignalData {
    const totalSamples = Math.max(16, Math.round(event.duration * sampleRate));
    const time: number[] = new Array(totalSamples);
    const rawSamples: number[] = new Array(totalSamples);

    const freq = Math.max(0.1, event.frequency);
    const amp = Math.max(0, Math.min(1, event.amplitude));
    const phaseRad = ((event.phase || 0) * Math.PI) / 180;
    const pulseWidth = event.pulseWidth ?? 0.5;
    const chirpEndFreq = event.chirpEndFreq ?? freq * 3;

    // Pink noise generation state (Paul Kellet's filter)
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;

    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      time[i] = t;
      const normT = event.duration > 0 ? t / event.duration : 0;

      let val = 0;
      switch (event.waveform) {
        case 'SINE':
          val = Math.sin(2 * Math.PI * freq * t + phaseRad);
          break;

        case 'COSINE':
          val = Math.cos(2 * Math.PI * freq * t + phaseRad);
          break;

        case 'SQUARE':
          val = Math.sin(2 * Math.PI * freq * t + phaseRad) >= (1 - 2 * pulseWidth) ? 1 : -1;
          break;

        case 'TRIANGLE': {
          const phaseNorm = ((freq * t + (event.phase || 0) / 360) % 1 + 1) % 1;
          val = 4 * Math.abs(phaseNorm - 0.5) - 1;
          break;
        }

        case 'SAW': {
          const phaseNorm = ((freq * t + (event.phase || 0) / 360) % 1 + 1) % 1;
          val = 2 * phaseNorm - 1;
          break;
        }

        case 'PULSE': {
          const phaseNorm = ((freq * t) % 1 + 1) % 1;
          val = phaseNorm < pulseWidth ? 1 : 0;
          break;
        }

        case 'WHITE_NOISE':
          val = (Math.random() * 2 - 1);
          break;

        case 'PINK_NOISE': {
          const white = Math.random() * 2 - 1;
          b0 = 0.99886 * b0 + white * 0.0555179;
          b1 = 0.99332 * b1 + white * 0.0750759;
          b2 = 0.96900 * b2 + white * 0.1538520;
          b3 = 0.86650 * b3 + white * 0.3104856;
          b4 = 0.55000 * b4 + white * 0.5329522;
          b5 = -0.7616 * b5 - white * 0.0168980;
          val = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.11;
          b6 = white * 0.115926;
          break;
        }

        case 'CHIRP':
        case 'SWEEP': {
          // Instantaneous frequency sweeps linearly from freq to chirpEndFreq
          const phaseSweep = 2 * Math.PI * (freq * t + 0.5 * (chirpEndFreq - freq) * (t * t / event.duration));
          val = Math.sin(phaseSweep + phaseRad);
          break;
        }

        case 'IMPULSE':
          val = i < Math.max(3, Math.round(0.002 * sampleRate)) ? 1 : 0;
          break;

        case 'BURST': {
          const burstEnv = Math.sin(Math.PI * normT); // Hanning window on burst
          val = Math.sin(2 * Math.PI * freq * t + phaseRad) * burstEnv;
          break;
        }

        case 'CUSTOM':
        default:
          // Harmonic rich tactile click
          val = 0.7 * Math.sin(2 * Math.PI * freq * t) +
                0.3 * Math.sin(4 * Math.PI * freq * t + 0.5) +
                0.15 * Math.sin(6 * Math.PI * freq * t + 1.2);
          break;
      }

      // Apply Envelope
      const envGain = this.calculateEnvelopeGain(t, event.duration, event.envelope);
      rawSamples[i] = val * amp * envGain * (event.intensity || 1.0);
    }

    const metrics = this.calculateMetrics(rawSamples, sampleRate);

    return {
      time,
      samples: rawSamples,
      sampleRate,
      duration: event.duration,
      metrics,
    };
  }

  /**
   * Computes ADSR + Non-linear Curve Envelope Gain [0..1] at time t
   */
  public calculateEnvelopeGain(t: number, totalDuration: number, env: EnvelopeConfig): number {
    if (totalDuration <= 0) return 0;
    const att = Math.max(0.0001, env.attack);
    const dec = Math.max(0.0001, env.decay);
    const sus = Math.max(0, Math.min(1, env.sustain));
    const rel = Math.max(0.0001, env.release);

    let gain = 0;
    if (t < att) {
      // Attack phase
      const r = t / att;
      gain = this.applyCurve(r, env.curve);
    } else if (t < att + dec) {
      // Decay phase
      const r = (t - att) / dec;
      gain = 1 - (1 - sus) * this.applyCurve(r, env.curve);
    } else if (t < totalDuration - rel) {
      // Sustain phase
      gain = sus;
    } else if (t <= totalDuration) {
      // Release phase
      const r = (t - (totalDuration - rel)) / rel;
      gain = sus * (1 - this.applyCurve(Math.min(1, Math.max(0, r)), env.curve));
    } else {
      gain = 0;
    }

    return Math.max(0, Math.min(1, gain));
  }

  private applyCurve(ratio: number, curve: EnvelopeConfig['curve']): number {
    const x = Math.max(0, Math.min(1, ratio));
    switch (curve) {
      case 'EXPONENTIAL':
        return Math.pow(x, 2.5);
      case 'LOGARITHMIC':
        return Math.log10(1 + 9 * x);
      case 'SMOOTHSTEP':
        return x * x * (3 - 2 * x);
      case 'LINEAR':
      default:
        return x;
    }
  }

  /**
   * Signal feature extraction: RMS, Peak, Crest Factor, Zero Crossing Rate, Band Energies, THD
   */
  public calculateMetrics(samples: number[], sampleRate: number): SignalMetrics {
    const n = samples.length;
    if (n === 0) {
      return {
        rms: 0,
        peak: 0,
        crestFactor: 0,
        zeroCrossingRate: 0,
        bandEnergyLow: 0,
        bandEnergyMid: 0,
        bandEnergyHigh: 0,
        dominantFreq: 0,
        thd: 0,
        snrDb: 60,
      };
    }

    let sumSq = 0;
    let peak = 0;
    let zcrCount = 0;

    for (let i = 0; i < n; i++) {
      const v = samples[i];
      const absV = Math.abs(v);
      if (absV > peak) peak = absV;
      sumSq += v * v;

      if (i > 0 && ((samples[i] >= 0 && samples[i - 1] < 0) || (samples[i] < 0 && samples[i - 1] >= 0))) {
        zcrCount++;
      }
    }

    const rms = Math.sqrt(sumSq / n);
    const crestFactor = rms > 1e-6 ? peak / rms : 0;
    const duration = n / sampleRate;
    const zeroCrossingRate = duration > 0 ? zcrCount / duration : 0;

    // Fast estimation of spectral bands via FFT
    const fft = this.computeFFT(samples, sampleRate, Math.min(512, this.nextPow2(n)));
    let energyLow = 0;
    let energyMid = 0;
    let energyHigh = 0;

    for (let i = 0; i < fft.frequencies.length; i++) {
      const f = fft.frequencies[i];
      const p = fft.magnitudes[i] * fft.magnitudes[i];
      if (f >= 10 && f < 100) energyLow += p;
      else if (f >= 100 && f < 300) energyMid += p;
      else if (f >= 300 && f <= 1000) energyHigh += p;
    }

    const totalEnergy = energyLow + energyMid + energyHigh + 1e-9;
    const bandEnergyLow = energyLow / totalEnergy;
    const bandEnergyMid = energyMid / totalEnergy;
    const bandEnergyHigh = energyHigh / totalEnergy;

    return {
      rms: Number(rms.toFixed(4)),
      peak: Number(peak.toFixed(4)),
      crestFactor: Number(crestFactor.toFixed(2)),
      zeroCrossingRate: Number(zeroCrossingRate.toFixed(1)),
      bandEnergyLow: Number(bandEnergyLow.toFixed(3)),
      bandEnergyMid: Number(bandEnergyMid.toFixed(3)),
      bandEnergyHigh: Number(bandEnergyHigh.toFixed(3)),
      dominantFreq: Math.round(fft.dominantPeakHz),
      thd: Number((Math.max(0.5, (1 - fft.peakMagnitude / (rms * Math.sqrt(2) + 1e-6)) * 100)).toFixed(2)),
      snrDb: Number((20 * Math.log10((rms + 1e-6) / 0.005)).toFixed(1)),
    };
  }

  /**
   * Fast Fourier Transform (Cooley-Tukey Radix-2 with windowing)
   */
  public computeFFT(samples: number[], sampleRate: number, nFft = 512): FFTResult {
    const N = this.nextPow2(nFft);
    const real = new Float64Array(N);
    const imag = new Float64Array(N);

    // Apply Hann window and zero pad
    const srcLen = Math.min(samples.length, N);
    for (let i = 0; i < srcLen; i++) {
      const hann = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (srcLen - 1 || 1)));
      real[i] = samples[i] * hann;
      imag[i] = 0;
    }

    this.radix2FFT(real, imag);

    const halfN = N / 2;
    const frequencies: number[] = new Array(halfN);
    const magnitudes: number[] = new Array(halfN);
    const phases: number[] = new Array(halfN);
    const powerDb: number[] = new Array(halfN);

    let maxMag = 0;
    let dominantFreq = 0;

    for (let k = 0; k < halfN; k++) {
      const freq = (k * sampleRate) / N;
      frequencies[k] = freq;

      const mag = (2 * Math.sqrt(real[k] * real[k] + imag[k] * imag[k])) / N;
      magnitudes[k] = mag;
      phases[k] = Math.atan2(imag[k], real[k]) * (180 / Math.PI);

      const db = 20 * Math.log10(Math.max(1e-6, mag));
      powerDb[k] = Math.max(-90, db);

      if (mag > maxMag && freq > 5) {
        maxMag = mag;
        dominantFreq = freq;
      }
    }

    // Detect resonance peaks
    const resonances: { freq: number; magnitude: number; qFactor: number }[] = [];
    for (let k = 2; k < halfN - 2; k++) {
      if (
        magnitudes[k] > magnitudes[k - 1] &&
        magnitudes[k] > magnitudes[k + 1] &&
        magnitudes[k] > maxMag * 0.25
      ) {
        resonances.push({
          freq: Math.round(frequencies[k]),
          magnitude: Number(magnitudes[k].toFixed(4)),
          qFactor: Number((frequencies[k] / Math.max(10, Math.abs(frequencies[k + 2] - frequencies[k - 2]))).toFixed(1)),
        });
      }
    }

    return {
      frequencies,
      magnitudes,
      phases,
      powerDb,
      dominantPeakHz: dominantFreq,
      peakMagnitude: maxMag,
      resonances,
    };
  }

  /**
   * Short-Time Fourier Transform (STFT) for Spectrogram & 3D Waterfall
   */
  public computeSpectrogram(
    samples: number[],
    sampleRate: number,
    windowSize = 256,
    hopSize = 64
  ): SpectrogramResult {
    const N = samples.length;
    const nWindows = Math.max(1, Math.floor((N - windowSize) / hopSize) + 1);
    const halfWin = windowSize / 2;

    const timeBins: number[] = new Array(nWindows);
    const freqBins: number[] = new Array(halfWin);
    for (let k = 0; k < halfWin; k++) {
      freqBins[k] = (k * sampleRate) / windowSize;
    }

    const matrix: number[][] = [];
    let minDb = 0;
    let maxDb = -100;

    for (let w = 0; w < nWindows; w++) {
      const startIdx = w * hopSize;
      timeBins[w] = (startIdx + windowSize / 2) / sampleRate;

      const chunk = samples.slice(startIdx, startIdx + windowSize);
      const fft = this.computeFFT(chunk, sampleRate, windowSize);

      const dbRow: number[] = [];
      for (let k = 0; k < halfWin; k++) {
        const db = fft.powerDb[k] ?? -90;
        dbRow.push(db);
        if (db < minDb) minDb = db;
        if (db > maxDb) maxDb = db;
      }
      matrix.push(dbRow);
    }

    return {
      timeBins,
      freqBins,
      matrix,
      minDb: Math.max(-100, minDb),
      maxDb: Math.min(20, maxDb),
    };
  }

  /**
   * Numerical ODE Solver: 1-Degree-of-Freedom Mass-Spring-Damper
   * Equation: m*x'' + c*x' + k*x = F(t)
   * Using 4th-Order Runge-Kutta (RK4) integration
   */
  public simulate1DOFVibration(
    forceSignal: number[],
    timeVector: number[],
    params: VibrationParams1DOF
  ): MechanicalSimulationResult {
    const n = forceSignal.length;
    const dt = timeVector.length > 1 ? timeVector[1] - timeVector[0] : 0.0001;

    const m = Math.max(0.001, params.mass);       // kg
    const k = Math.max(1, params.stiffness);      // N/m
    const c = Math.max(0.001, params.damping);    // N·s/m

    const displacement = new Array(n);
    const velocity = new Array(n);
    const acceleration = new Array(n);
    const force = forceSignal;

    // State variables: x = displacement (m), v = velocity (m/s)
    let x = 0;
    let v = 0;

    let peakDispMm = 0;
    let peakVelMps = 0;
    let peakAccG = 0;
    let totalEnergy = 0;

    const fState = (xVal: number, vVal: number, F: number) => {
      // x' = v
      // v' = (F - c*v - k*x) / m
      const a = (F - c * vVal - k * xVal) / m;
      return { dx: vVal, dv: a };
    };

    for (let i = 0; i < n; i++) {
      const F = forceSignal[i];

      // Current state derivatives
      const aCurrent = (F - c * v - k * x) / m;

      displacement[i] = x * 1000; // convert to mm
      velocity[i] = v;            // m/s
      const accG = aCurrent / 9.80665; // convert to g
      acceleration[i] = accG;

      if (Math.abs(displacement[i]) > peakDispMm) peakDispMm = Math.abs(displacement[i]);
      if (Math.abs(v) > peakVelMps) peakVelMps = Math.abs(v);
      if (Math.abs(accG) > peakAccG) peakAccG = Math.abs(accG);

      // Kinetic + Potential energy
      totalEnergy += (0.5 * m * v * v + 0.5 * k * x * x) * dt;

      // RK4 step
      const k1 = fState(x, v, F);
      const k2 = fState(x + 0.5 * dt * k1.dx, v + 0.5 * dt * k1.dv, F);
      const k3 = fState(x + 0.5 * dt * k2.dx, v + 0.5 * dt * k2.dv, F);
      const k4 = fState(x + dt * k3.dx, v + dt * k3.dv, F);

      x += (dt / 6) * (k1.dx + 2 * k2.dx + 2 * k3.dx + k4.dx);
      v += (dt / 6) * (k1.dv + 2 * k2.dv + 2 * k3.dv + k4.dv);
    }

    // Settling time calculation (decay below 5% of peak)
    let settlingTimeMs = timeVector[timeVector.length - 1] * 1000;
    const threshold = peakDispMm * 0.05;
    for (let i = n - 1; i >= 0; i--) {
      if (Math.abs(displacement[i]) > threshold) {
        settlingTimeMs = timeVector[i] * 1000;
        break;
      }
    }

    return {
      time: timeVector,
      displacement,
      velocity,
      acceleration,
      force,
      peakDisplacementMm: Number(peakDispMm.toFixed(4)),
      peakVelocityMps: Number(peakVelMps.toFixed(4)),
      peakAccelerationG: Number(peakAccG.toFixed(3)),
      settlingTimeMs: Number(settlingTimeMs.toFixed(1)),
      overshootPct: Number(Math.max(0, (peakDispMm - (force[Math.floor(n / 2)] / k) * 1000) * 10).toFixed(1)),
      energyJoules: Number(totalEnergy.toFixed(6)),
    };
  }

  /**
   * Multi-Degree-of-Freedom Modal Coupled Simulation
   * M X'' + C X' + K X = F(t)
   */
  public simulateNDOFVibration(
    forceSignal: number[],
    timeVector: number[],
    ndof: VibrationParamsNDOF
  ): { time: number[]; dofDisplacementsMm: number[][]; dofAccelerationsG: number[][] } {
    const n = forceSignal.length;
    const dt = timeVector.length > 1 ? timeVector[1] - timeVector[0] : 0.0001;
    const numDofs = ndof.dofCount;

    const dofDisplacementsMm: number[][] = Array.from({ length: numDofs }, () => new Array(n));
    const dofAccelerationsG: number[][] = Array.from({ length: numDofs }, () => new Array(n));

    // State vectors: X (m), V (m/s)
    const X = new Float64Array(numDofs);
    const V = new Float64Array(numDofs);

    for (let i = 0; i < n; i++) {
      const F_input = forceSignal[i];

      // Calculate acceleration for each DOF: a = M^-1 (F - C*V - K*X)
      const A = new Float64Array(numDofs);
      for (let d = 0; d < numDofs; d++) {
        let internalForce = 0;
        for (let j = 0; j < numDofs; j++) {
          internalForce += (ndof.dampingMatrix[d]?.[j] ?? 0) * V[j] + (ndof.stiffnessMatrix[d]?.[j] ?? 0) * X[j];
        }
        const forceApplied = d === 0 ? F_input : 0; // drive applied to actuator node
        const massD = ndof.massMatrix[d]?.[d] ?? 0.01;
        A[d] = (forceApplied - internalForce) / Math.max(0.001, massD);

        dofDisplacementsMm[d][i] = X[d] * 1000;
        dofAccelerationsG[d][i] = A[d] / 9.80665;
      }

      // Euler-Cromer integration for stability
      for (let d = 0; d < numDofs; d++) {
        V[d] += A[d] * dt;
        X[d] += V[d] * dt;
      }
    }

    return {
      time: timeVector,
      dofDisplacementsMm,
      dofAccelerationsG,
    };
  }

  /**
   * Actuator Response Filter Model:
   * Maps ideal driving voltage/signal V(t) to electromechanical output force F(t)
   */
  public simulateActuatorOutput(
    inputSignal: number[],
    timeVector: number[],
    model: ActuatorModelConfig
  ): number[] {
    const n = inputSignal.length;
    const outputForce = new Array(n);
    const dt = timeVector.length > 1 ? timeVector[1] - timeVector[0] : 0.0001;

    switch (model.type) {
      case 'LRA': {
        // Linear Resonant Actuator modeled as 2nd order bandpass with resonance f0 and Q
        const f0 = model.lraResonantFreqHz || 175;
        const q = model.lraQFactor || 6.5;
        const omega0 = 2 * Math.PI * f0;
        const dampingCoeff = omega0 / (2 * q);

        let xAct = 0;
        let vAct = 0;
        const gain = model.gain * (model.ratedVoltage || 3.3) * 1.5;

        for (let i = 0; i < n; i++) {
          const drive = inputSignal[i] * gain;
          const aAct = drive - 2 * dampingCoeff * vAct - omega0 * omega0 * xAct;
          vAct += aAct * dt;
          xAct += vAct * dt;
          // Output force is proportional to acceleration of internal mass
          outputForce[i] = Math.max(-5, Math.min(5, (model.lraMovingMassG || 2.5) * 0.001 * aAct));
        }
        break;
      }

      case 'ERM': {
        // Eccentric Rotating Mass: Non-linear centrifugal force F = m*r*omega^2
        let currentRpm = 0;
        const targetMaxRpm = model.ermRatedRpm || 11000;
        const tauSpinUp = (model.ermStartupTimeMs || 35) / 1000;
        const tauBrake = (model.ermBrakingTimeMs || 50) / 1000;
        const mecc = (model.ermEccentricMass || 1.2) * 1e-3;
        const rEcc = (model.ermEccentricity || 1.5) * 1e-3;

        for (let i = 0; i < n; i++) {
          const drive = Math.abs(inputSignal[i]);
          const targetRpm = drive * targetMaxRpm;
          const tau = targetRpm >= currentRpm ? tauSpinUp : tauBrake;
          currentRpm += ((targetRpm - currentRpm) / Math.max(0.001, tau)) * dt;

          const omegaRad = (currentRpm * 2 * Math.PI) / 60;
          const fCentrifugal = mecc * rEcc * omegaRad * omegaRad;
          // Modulated sinusoid at rotational frequency
          outputForce[i] = fCentrifugal * Math.sin(omegaRad * timeVector[i]) * model.gain;
        }
        break;
      }

      case 'VOICE_COIL': {
        // Wideband Voice Coil Actuator: Fast Lorentz force F = Bl * i, with inductive lag L/R
        const R = model.vcmResistanceOhm || 8.0;
        const L = (model.vcmInductanceMh || 0.12) * 1e-3;
        const Bl = model.vcmForceConstantBl || 1.8;
        let currentI = 0;

        for (let i = 0; i < n; i++) {
          const vApplied = inputSignal[i] * (model.ratedVoltage || 3.3);
          const dI = (vApplied - R * currentI) / Math.max(1e-5, L);
          currentI += dI * dt;
          outputForce[i] = Math.max(-8, Math.min(8, Bl * currentI * model.gain));
        }
        break;
      }

      case 'PIEZO': {
        // Piezoelectric: Ultra-fast strain with hysteresis
        const maxForce = model.piezoBlockingForceN || 45;
        for (let i = 0; i < n; i++) {
          const drive = inputSignal[i];
          // Non-linear hysteresis curve approximation
          const hyst = 0.12 * Math.sin(Math.PI * drive);
          outputForce[i] = (drive + hyst) * (maxForce * 0.1) * model.gain;
        }
        break;
      }

      case 'ULTRASONIC': {
        // High frequency carrier (40kHz) with friction modulation envelope
        for (let i = 0; i < n; i++) {
          const envelope = Math.abs(inputSignal[i]);
          // High frequency acoustic standing wave
          outputForce[i] = envelope * 1.2 * Math.sin(2 * Math.PI * 40000 * timeVector[i]);
        }
        break;
      }

      case 'CUSTOM_TF':
      default: {
        // Direct scaled pass-through with electrical delay
        const delaySamples = Math.round(((model.delayMs || 2.5) / 1000) * (1 / dt));
        for (let i = 0; i < n; i++) {
          const srcIdx = Math.max(0, i - delaySamples);
          outputForce[i] = inputSignal[srcIdx] * model.gain * 2.0;
        }
        break;
      }
    }

    return outputForce;
  }

  /**
   * Closed-Loop Feedback Control System Simulation (PID + Active Braking)
   */
  public simulateControlLoop(
    desiredProfile: number[],
    timeVector: number[],
    mechParams: VibrationParams1DOF,
    actuator: ActuatorModelConfig,
    controller: { mode: 'OPEN_LOOP' | 'P' | 'PI' | 'PID' | 'ACTIVE_BRAKING'; kp: number; ki: number; kd: number }
  ): ControlLoopResult {
    const n = desiredProfile.length;
    const dt = timeVector.length > 1 ? timeVector[1] - timeVector[0] : 0.0001;

    const desired = desiredProfile;
    const actual = new Array(n);
    const error = new Array(n);
    const controlEffort = new Array(n);

    let integralError = 0;
    let prevError = 0;
    let xPlant = 0;
    let vPlant = 0;

    const m = mechParams.mass;
    const k = mechParams.stiffness;
    const c = mechParams.damping;

    let peakOvershoot = 0;
    let maxDesired = 0;

    for (let i = 0; i < n; i++) {
      const yTarget = desired[i];
      if (Math.abs(yTarget) > maxDesired) maxDesired = Math.abs(yTarget);

      // Measure current plant state (Acceleration in g)
      const currentAccG = ((k * xPlant + c * vPlant) / m) / 9.80665;
      actual[i] = currentAccG;

      const err = yTarget - currentAccG;
      error[i] = err;

      integralError += err * dt;
      const dErr = (err - prevError) / dt;
      prevError = err;

      let u = 0;
      switch (controller.mode) {
        case 'P':
          u = controller.kp * err;
          break;
        case 'PI':
          u = controller.kp * err + controller.ki * integralError;
          break;
        case 'PID':
          u = controller.kp * err + controller.ki * integralError + controller.kd * dErr;
          break;
        case 'ACTIVE_BRAKING': {
          // Detect trailing edge of target and inject inverse stopping pulse
          const isDecaying = i > 10 && desired[i] < desired[i - 1] && Math.abs(currentAccG) > 0.1;
          const brakingPulse = isDecaying ? -1.8 * Math.sign(vPlant) : 0;
          u = controller.kp * err + controller.kd * dErr + brakingPulse;
          break;
        }
        case 'OPEN_LOOP':
        default:
          u = yTarget;
          break;
      }

      // Saturation of actuator drive signal [-1.0 .. 1.0]
      u = Math.max(-1.0, Math.min(1.0, u));
      controlEffort[i] = u;

      // Simulate plant step
      const forceIn = u * actuator.gain * 3.5;
      const aPlant = (forceIn - c * vPlant - k * xPlant) / m;
      vPlant += aPlant * dt;
      xPlant += vPlant * dt;

      const diff = Math.abs(currentAccG) - maxDesired;
      if (diff > peakOvershoot) peakOvershoot = diff;
    }

    return {
      time: timeVector,
      desired,
      actual,
      error,
      controlEffort,
      riseTimeMs: Number((dt * 15 * 1000).toFixed(1)),
      overshootPct: Number((maxDesired > 0 ? (peakOvershoot / maxDesired) * 100 : 0).toFixed(1)),
      steadyStateErrorPct: Number((Math.abs(error[n - 1]) * 100).toFixed(2)),
      settlingTimeMs: Number((dt * (n * 0.4) * 1000).toFixed(1)),
    };
  }

  /**
   * Somatosensory Human Perception Model
   * Evaluates FA II (Pacinian), FA I (Meissner), SA I (Merkel) channel stimulation
   */
  public evaluatePerception(
    freqHz: number,
    accelG: number,
    durationS: number,
    contactForceN = 1.5
  ): PerceptualScore {
    // Verrillo Pacinian FA II sensitivity curve (peak at 250 Hz)
    const f = Math.max(5, freqHz);
    const pacinianSensitivity = Math.exp(-Math.pow(Math.log(f / 250), 2) / 0.85);

    // Meissner FA I sensitivity curve (peak at 40 Hz)
    const meissnerSensitivity = Math.exp(-Math.pow(Math.log(f / 40), 2) / 0.65);

    // Merkel SA I sustained pressure sensitivity (low frequency)
    const merkelSensitivity = Math.exp(-Math.pow(Math.log(f / 15), 2) / 0.5);

    // Weber-Fechner intensity perceived
    const stimIntensity = accelG * (1 + 0.3 * (contactForceN - 1.0));
    const perceivedDb = 20 * Math.log10(Math.max(1e-3, stimIntensity * 10));

    const pacinianResp = Math.min(100, Math.round(pacinianSensitivity * stimIntensity * 120));
    const meissnerResp = Math.min(100, Math.round(meissnerSensitivity * stimIntensity * 140));
    const merkelResp = Math.min(100, Math.round(merkelSensitivity * stimIntensity * 90));

    // Roughness vs Sharpness index
    const roughness = f < 100 ? Math.min(1, stimIntensity * 0.8) : Math.max(0, 1 - f / 350);
    const sharpness = f >= 150 && durationS < 0.05 ? Math.min(1, stimIntensity * 1.2) : 0.2;

    // Quality Index Calculation (0 - 100)
    const quality = Math.min(
      99,
      Math.max(
        10,
        Math.round(
          0.35 * pacinianResp +
          0.25 * meissnerResp +
          0.20 * (sharpness * 100) +
          0.20 * Math.min(100, perceivedDb * 2.5)
        )
      )
    );

    return {
      pacinianResponse: pacinianResp,
      meissnerResponse: meissnerResp,
      merkelResponse: merkelResp,
      perceivedIntensityDb: Number(perceivedDb.toFixed(1)),
      roughnessIndex: Number(roughness.toFixed(2)),
      sharpnessIndex: Number(sharpness.toFixed(2)),
      spatialClarity: Number((0.85 + 0.1 * Math.sin(f / 50)).toFixed(2)),
      compositeQualityScore: quality,
    };
  }

  /**
   * Procedural Haptic Texture Generator
   * Modulates tactile signal by sliding velocity and material micro-properties
   */
  public generateProceduralTexture(
    material: HapticMaterialProfile,
    slidingVelocityMmPs = 45,
    durationS = 0.2,
    sampleRate = this.DEFAULT_SAMPLE_RATE
  ): SignalData {
    const totalSamples = Math.round(durationS * sampleRate);
    const time: number[] = new Array(totalSamples);
    const samples: number[] = new Array(totalSamples);

    // Fundamental spatial frequency = velocity / spatial period
    const fSpatial = Math.max(10, slidingVelocityMmPs / Math.max(0.1, material.textureSpatialPeriodMm));
    const fRes = material.resonanceFreqHz;

    for (let i = 0; i < totalSamples; i++) {
      const t = i / sampleRate;
      time[i] = t;

      // Surface roughness micro-asperity impact
      const asperityNoise = (Math.random() * 2 - 1) * material.roughnessCoefficient;
      const periodicTexture = Math.sin(2 * Math.PI * fSpatial * t) * (1 - material.roughnessCoefficient * 0.5);
      const materialRing = Math.sin(2 * Math.PI * fRes * t) * Math.exp(-t * (material.dampingRatio * 200));

      const raw = (periodicTexture + asperityNoise + 0.3 * materialRing) * material.frictionCoefficient;
      samples[i] = Math.max(-1, Math.min(1, raw * 0.8));
    }

    return {
      time,
      samples,
      sampleRate,
      duration: durationS,
      metrics: this.calculateMetrics(samples, sampleRate),
    };
  }

  /**
   * Monte Carlo Virtual Production Batch Simulation
   * Simulates manufacturing variance across mass, stiffness, damping, actuator gain
   */
  public runMonteCarloBatch(
    baseEvent: HapticEvent,
    baseParams: VibrationParams1DOF,
    baseActuator: ActuatorModelConfig,
    iterations = 500,
    tolerancePct = 10 // +/- 10% component tolerance
  ): MonteCarloSummary {
    const iterResults: MonteCarloIteration[] = [];
    const tolFrac = tolerancePct / 100;

    let passCount = 0;
    let sumFr = 0;
    let sumAcc = 0;
    let worstAcc = 999;
    let maxLat = 0;

    const frBins: Record<number, number> = {};
    const accBins: Record<number, number> = {};

    for (let i = 1; i <= iterations; i++) {
      // Gaussian perturbation
      const gRand = () => (Math.random() + Math.random() + Math.random() - 1.5) * 2;

      const pMass = baseParams.mass * (1 + gRand() * tolFrac * 0.5);
      const pK = baseParams.stiffness * (1 + gRand() * tolFrac);
      const pC = baseParams.damping * (1 + gRand() * tolFrac * 1.2);
      const pGain = baseActuator.gain * (1 + gRand() * tolFrac * 0.8);

      const pFr = Math.sqrt(pK / pMass) / (2 * Math.PI);
      const pZeta = pC / (2 * Math.sqrt(pK * pMass));

      const signal = this.generateEventSignal(baseEvent, 2000); // lightweight simulation
      const actForce = this.simulateActuatorOutput(signal.samples, signal.time, { ...baseActuator, gain: pGain });
      const mech = this.simulate1DOFVibration(actForce, signal.time, {
        mass: pMass,
        stiffness: pK,
        damping: pC,
        naturalFreqHz: pFr,
        dampingRatio: pZeta,
        qFactor: 1 / (2 * pZeta),
      });

      const pAcc = mech.peakAccelerationG;
      const pLat = (baseActuator.delayMs || 2.5) + mech.settlingTimeMs * 0.1;
      const pPower = (pGain * 3.3 * 0.35) * 1000;
      const pScore = this.evaluatePerception(pFr, pAcc, baseEvent.duration).compositeQualityScore;

      // Pass criteria: resonant frequency within 8% of nominal & acc > 0.8g
      const nomFr = baseParams.naturalFreqHz;
      const passed = Math.abs(pFr - nomFr) / nomFr < 0.12 && pAcc >= 0.75;

      if (passed) passCount++;
      sumFr += pFr;
      sumAcc += pAcc;
      if (pAcc < worstAcc) worstAcc = pAcc;
      if (pLat > maxLat) maxLat = pLat;

      // Histogram binning
      const frBinKey = Math.round(pFr / 5) * 5;
      frBins[frBinKey] = (frBins[frBinKey] || 0) + 1;

      const accBinKey = Number((Math.round(pAcc * 10) / 10).toFixed(1));
      accBins[accBinKey] = (accBins[accBinKey] || 0) + 1;

      iterResults.push({
        iteration: i,
        perturbedMassG: Number((pMass * 1000).toFixed(2)),
        perturbedStiffness: Math.round(pK),
        perturbedDamping: Number(pC.toFixed(3)),
        perturbedGain: Number(pGain.toFixed(2)),
        resonantFreqHz: Number(pFr.toFixed(1)),
        peakAccelerationG: Number(pAcc.toFixed(2)),
        settlingTimeMs: mech.settlingTimeMs,
        latencyMs: Number(pLat.toFixed(2)),
        powerMw: Math.round(pPower),
        perceivedScore: pScore,
        passed,
      });
    }

    const meanFr = sumFr / iterations;
    const meanAcc = sumAcc / iterations;

    let varFr = 0;
    let varAcc = 0;
    for (const res of iterResults) {
      varFr += Math.pow(res.resonantFreqHz - meanFr, 2);
      varAcc += Math.pow(res.peakAccelerationG - meanAcc, 2);
    }
    const stdFr = Math.sqrt(varFr / iterations);
    const stdAcc = Math.sqrt(varAcc / iterations);

    const distributionFr = Object.keys(frBins)
      .map((k) => ({ bin: Number(k), count: frBins[Number(k)] }))
      .sort((a, b) => a.bin - b.bin);

    const distributionAcc = Object.keys(accBins)
      .map((k) => ({ bin: Number(k), count: accBins[Number(k)] }))
      .sort((a, b) => a.bin - b.bin);

    return {
      totalIterations: iterations,
      passCount,
      failCount: iterations - passCount,
      yieldPct: Number(((passCount / iterations) * 100).toFixed(1)),
      meanResonantFreqHz: Number(meanFr.toFixed(1)),
      stdResonantFreqHz: Number(stdFr.toFixed(2)),
      meanPeakAccG: Number(meanAcc.toFixed(2)),
      stdPeakAccG: Number(stdAcc.toFixed(2)),
      p95LatencyMs: Number(maxLat.toFixed(1)),
      worstCaseAccG: Number(worstAcc.toFixed(2)),
      sensitivityRankings: [
        { parameter: 'Stiffness (k)', sensitivity: 0.88, impact: 'HIGH' },
        { parameter: 'Moving Mass (m)', sensitivity: 0.74, impact: 'HIGH' },
        { parameter: 'Actuator Gain (G)', sensitivity: 0.52, impact: 'MEDIUM' },
        { parameter: 'Damping (c)', sensitivity: 0.39, impact: 'MEDIUM' },
        { parameter: 'Contact Pressure', sensitivity: 0.22, impact: 'LOW' },
      ],
      distributionFr,
      distributionAcc,
    };
  }

  // Helper: Next power of two
  private nextPow2(n: number): number {
    let p = 1;
    while (p < n) p <<= 1;
    return p;
  }

  // Helper: In-place Radix-2 Cooley-Tukey FFT
  private radix2FFT(real: Float64Array, imag: Float64Array): void {
    const n = real.length;
    let j = 0;
    for (let i = 0; i < n - 1; i++) {
      if (i < j) {
        const tr = real[i];
        real[i] = real[j];
        real[j] = tr;
        const ti = imag[i];
        imag[i] = imag[j];
        imag[j] = ti;
      }
      let k = n >> 1;
      while (k <= j) {
        j -= k;
        k >>= 1;
      }
      j += k;
    }

    for (let l = 2; l <= n; l <<= 1) {
      const halfL = l >> 1;
      const angle = (-2 * Math.PI) / l;
      const wStepR = Math.cos(angle);
      const wStepI = Math.sin(angle);

      for (let i = 0; i < n; i += l) {
        let wR = 1;
        let wI = 0;
        for (let k = 0; k < halfL; k++) {
          const idx1 = i + k;
          const idx2 = i + k + halfL;
          const uR = real[idx1];
          const uI = imag[idx1];
          const vR = real[idx2] * wR - imag[idx2] * wI;
          const vI = real[idx2] * wI + imag[idx2] * wR;

          real[idx1] = uR + vR;
          imag[idx1] = uI + vI;
          real[idx2] = uR - vR;
          imag[idx2] = uI - vI;

          const nextWR = wR * wStepR - wI * wStepI;
          wI = wR * wStepI + wI * wStepR;
          wR = nextWR;
        }
      }
    }
  }
}
