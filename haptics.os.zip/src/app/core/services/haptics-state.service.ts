import { Injectable, computed, inject, signal } from '@angular/core';
import {
  ActuatorModelConfig,
  ControlLoopResult,
  ControllerMode,
  DeviceSpatialActuator,
  FFTResult,
  HapticDeviceTwin,
  HapticEvent,
  HapticMaterialProfile,
  HapticScoreFile,
  MechanicalSimulationResult,
  MonteCarloSummary,
  PerceptualScore,
  SignalData,
  SimulationFidelity,
  SpectrogramResult,
  VibrationParams1DOF,
} from '../models/haptics.models';
import { DspEngineService } from './dsp-engine.service';
import { RGeneratorService } from './r-generator.service';
import { TactileAudioService } from './tactile-audio.service';
import { HapticsAiService } from './haptics-ai.service';
import {
  DEFAULT_DEVICE_HAPTIC_01,
  DEFAULT_HAPTIC_EVENTS,
  DEFAULT_HAPTIC_MATERIALS,
} from '../data/default-presets';

export type ActiveLabView =
  | 'PIPELINE'
  | 'SIGNAL_LAB'
  | 'VIBRATION_ACTUATORS'
  | 'DIGITAL_TWIN'
  | 'PERCEPTION_PSYCHOPHYSICS'
  | 'CONTROL_SYSTEMS'
  | 'OPTIMISATION_MONTE_CARLO'
  | 'DESIGN_LIBRARY'
  | 'R_CONSOLE'
  | 'AI_ADVISOR';

@Injectable({
  providedIn: 'root',
})
export class HapticsStateService {
  private dsp = inject(DspEngineService);
  private rGen = inject(RGeneratorService);
  private audio = inject(TactileAudioService);
  private ai = inject(HapticsAiService);

  // Active Lab Navigation
  public activeView = signal<ActiveLabView>('PIPELINE');

  // Core State Signals
  public deviceTwin = signal<HapticDeviceTwin>(DEFAULT_DEVICE_HAPTIC_01);
  public eventsList = signal<HapticEvent[]>(DEFAULT_HAPTIC_EVENTS);
  public activeEvent = signal<HapticEvent>(DEFAULT_HAPTIC_EVENTS[0]);
  public activeActuator = signal<DeviceSpatialActuator>(DEFAULT_DEVICE_HAPTIC_01.actuators[0]);
  public activeMaterial = signal<HapticMaterialProfile>(DEFAULT_HAPTIC_MATERIALS[0]);
  public materialsList = signal<HapticMaterialProfile[]>(DEFAULT_HAPTIC_MATERIALS);

  public simulationFidelity = signal<SimulationFidelity>('ENGINEERING');
  public audioMuted = signal<boolean>(false);
  public contactForceN = signal<number>(1.5);
  public isScrubbing = signal<boolean>(false);
  public scrubTimeMs = signal<number>(0);

  // Controller Tuning Signal
  public controllerConfig = signal<{ mode: ControllerMode; kp: number; ki: number; kd: number }>({
    mode: 'PID',
    kp: 1.8,
    ki: 0.05,
    kd: 0.12,
  });

  // Monte Carlo & Optimisation Cache
  public monteCarloSummary = signal<MonteCarloSummary | null>(null);
  public isRunningMonteCarlo = signal<boolean>(false);
  public aiDiagnosticOutput = signal<string>('');
  public isAiDiagnosing = signal<boolean>(false);

  // Computed: Real-time Synthesized Input Signal
  public generatedSignal = computed<SignalData>(() => {
    const evt = this.activeEvent();
    return this.dsp.generateEventSignal(evt, 10000);
  });

  // Computed: Actuator Force Output F(t)
  public actuatorForce = computed<number[]>(() => {
    const sig = this.generatedSignal();
    const act = this.activeActuator().actuatorModel;
    return this.dsp.simulateActuatorOutput(sig.samples, sig.time, act);
  });

  // Computed: 1-DOF Mechanical System Response x(t), v(t), a(t)
  public mechSimulation = computed<MechanicalSimulationResult>(() => {
    const force = this.actuatorForce();
    const sig = this.generatedSignal();
    const params = this.deviceTwin().vibration1DOF;
    return this.dsp.simulate1DOFVibration(force, sig.time, params);
  });

  // Computed: FFT Analysis of Mechanical Acceleration
  public fftAnalysis = computed<FFTResult>(() => {
    const mech = this.mechSimulation();
    const sig = this.generatedSignal();
    return this.dsp.computeFFT(mech.acceleration, sig.sampleRate, 512);
  });

  // Computed: STFT Spectrogram Matrix
  public spectrogramAnalysis = computed<SpectrogramResult>(() => {
    const mech = this.mechSimulation();
    const sig = this.generatedSignal();
    return this.dsp.computeSpectrogram(mech.acceleration, sig.sampleRate, 256, 64);
  });

  // Computed: Closed-Loop Control Response
  public controlLoopResult = computed<ControlLoopResult>(() => {
    const sig = this.generatedSignal();
    const mech = this.deviceTwin().vibration1DOF;
    const act = this.activeActuator().actuatorModel;
    const ctrl = this.controllerConfig();
    return this.dsp.simulateControlLoop(sig.samples, sig.time, mech, act, ctrl);
  });

  // Computed: Perceptual Somatosensory Score
  public perceptualScore = computed<PerceptualScore>(() => {
    const evt = this.activeEvent();
    const mech = this.mechSimulation();
    const forceN = this.contactForceN();
    return this.dsp.evaluatePerception(evt.frequency, mech.peakAccelerationG, evt.duration, forceN);
  });

  // Computed: R Script Output for Current State
  public rScriptCode = computed<string>(() => {
    const evt = this.activeEvent();
    const dev = this.deviceTwin();
    const act = this.activeActuator().actuatorModel;
    return this.rGen.generateRSimulationScript(evt, dev.vibration1DOF, act, 10000);
  });

  // Computed: .haptic Machine-Readable Score File
  public hapticScoreJson = computed<HapticScoreFile>(() => {
    const evt = this.activeEvent();
    const act = this.activeActuator().actuatorModel;
    const dev = this.deviceTwin();
    return this.rGen.generateHapticScoreFile(evt, act, dev.vibration1DOF);
  });

  constructor() {
    // Run initial baseline Monte Carlo simulation on startup
    setTimeout(() => {
      this.runMonteCarlo();
    }, 200);
  }

  /**
   * Triggers tactile audio acoustic reproduction and haptic feedback
   */
  public playHapticFeedback(): void {
    const sig = this.generatedSignal();
    const mech = this.mechSimulation();
    this.audio.playTactileBuffer(mech.acceleration, sig.sampleRate, 0.7);

    // If browser supports navigator.vibrate (e.g. Android/Chrome devices)
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        const ms = Math.min(250, Math.round(this.activeEvent().duration * 1000));
        navigator.vibrate(ms);
      } catch {
        // Safe fallback
      }
    }
  }

  /**
   * Selects an event from library or creates a custom parameter variation
   */
  public selectEvent(event: HapticEvent): void {
    this.activeEvent.set(event);
    this.playHapticFeedback();
  }

  public updateActiveEvent(partial: Partial<HapticEvent>): void {
    this.activeEvent.update((curr) => ({ ...curr, ...partial }));
  }

  public updateActiveEnvelope(partial: Partial<HapticEvent['envelope']>): void {
    this.activeEvent.update((curr) => ({
      ...curr,
      envelope: { ...curr.envelope, ...partial },
    }));
  }

  public updateVibration1DOF(partial: Partial<VibrationParams1DOF>): void {
    this.deviceTwin.update((curr) => {
      const updated = { ...curr.vibration1DOF, ...partial };
      // Recalculate derived natural frequency and damping ratio
      const m = updated.mass;
      const k = updated.stiffness;
      const c = updated.damping;
      updated.naturalFreqHz = Number((Math.sqrt(k / m) / (2 * Math.PI)).toFixed(1));
      updated.dampingRatio = Number((c / (2 * Math.sqrt(k * m))).toFixed(4));
      updated.qFactor = Number((1 / (2 * updated.dampingRatio)).toFixed(2));
      return { ...curr, vibration1DOF: updated };
    });
  }

  public updateActiveActuatorModel(partial: Partial<ActuatorModelConfig>): void {
    this.activeActuator.update((curr) => ({
      ...curr,
      actuatorModel: { ...curr.actuatorModel, ...partial },
    }));
  }

  public toggleAudio(): void {
    const newMuted = !this.audioMuted();
    this.audioMuted.set(newMuted);
    this.audio.setMuted(newMuted);
  }

  public runMonteCarlo(iterations = 500): void {
    this.isRunningMonteCarlo.set(true);
    setTimeout(() => {
      const summary = this.dsp.runMonteCarloBatch(
        this.activeEvent(),
        this.deviceTwin().vibration1DOF,
        this.activeActuator().actuatorModel,
        iterations,
        10
      );
      this.monteCarloSummary.set(summary);
      this.isRunningMonteCarlo.set(false);
    }, 50);
  }

  public optimizeHapticParameters(): void {
    // Multi-objective optimization: Auto-tune frequency to device natural resonance and shape envelope
    const fn = this.deviceTwin().vibration1DOF.naturalFreqHz;
    this.activeEvent.update((curr) => ({
      ...curr,
      frequency: fn,
      envelope: {
        ...curr.envelope,
        attack: 0.004,
        decay: 0.015,
        sustain: 0.25,
        release: 0.03,
        curve: 'SMOOTHSTEP',
      },
      metadata: {
        ...curr.metadata,
        targetFeeling: 'Resonance-Matched Multi-Objective Optimized Feedback',
        provenance: 'CALIBRATED',
      },
    }));
    this.playHapticFeedback();
  }

  public askAiDiagnostic(userPrompt?: string): void {
    this.isAiDiagnosing.set(true);
    const evt = this.activeEvent();
    const dev = this.deviceTwin();
    const mech = this.mechSimulation();
    const fft = this.fftAnalysis();
    const ctrl = this.controlLoopResult();

    const telemetryContext = {
      device: dev.name,
      actuator: this.activeActuator().name,
      actuatorType: this.activeActuator().type,
      frequency: evt.frequency,
      waveform: evt.waveform,
      amplitude: evt.amplitude,
      naturalFreq: dev.vibration1DOF.naturalFreqHz,
      dampingRatioZeta: dev.vibration1DOF.dampingRatio,
      qFactor: dev.vibration1DOF.qFactor,
      peakAccelerationG: mech.peakAccelerationG,
      peakDisplacementMm: mech.peakDisplacementMm,
      settlingTimeMs: mech.settlingTimeMs,
      overshootPct: ctrl.overshootPct,
      dominantSpectrumPeakHz: fft.dominantPeakHz,
      pacinianScore: this.perceptualScore().pacinianResponse,
      compositeScore: this.perceptualScore().compositeQualityScore,
    };

    const prompt = userPrompt || 'Perform an engineering diagnostic on this haptic system: analyze resonance matching, transient overshoot, power efficiency, and tactile feel.';

    this.ai.diagnoseTelemetry(prompt, telemetryContext).subscribe({
      next: (answer) => {
        this.aiDiagnosticOutput.set(answer);
        this.isAiDiagnosing.set(false);
      },
      error: () => {
        this.isAiDiagnosing.set(false);
      },
    });
  }
}
