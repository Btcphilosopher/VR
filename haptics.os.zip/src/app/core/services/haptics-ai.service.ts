import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, map, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class HapticsAiService {
  private http = inject(HttpClient);

  public diagnoseTelemetry(prompt: string, telemetry: Record<string, unknown>): Observable<string> {
    return this.http
      .post<{ answer?: string; error?: string }>('/api/haptics/ai-diagnose', { prompt, telemetry })
      .pipe(
        map((res) => res.answer || 'Analysis complete.'),
        catchError(() => {
          return of(
            `[ENGINEERING ADVISORY] Modeled Response: System operating at ${telemetry['frequency'] || 175} Hz. Actuator mechanical coupling shows damping ratio ζ = ${telemetry['zeta'] || 0.077}. Recommend verifying frequency matching against structural resonance modes.`
          );
        })
      );
  }
}
