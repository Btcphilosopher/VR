import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TactileAudioService {
  private audioCtx: AudioContext | null = null;
  private isMuted = false;

  private initAudio(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch((e) => console.debug('Audio resume deferred:', e));
    }
    return this.audioCtx;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Synthesizes tactile audio waveform through WebAudio buffer
   */
  public playTactileBuffer(samples: number[], sampleRate: number, gainMultiplier = 0.8): void {
    if (this.isMuted || samples.length === 0) return;
    const ctx = this.initAudio();
    if (!ctx) return;

    try {
      const audioBuffer = ctx.createBuffer(1, samples.length, sampleRate);
      const channelData = audioBuffer.getChannelData(0);

      // Copy and soft-clip samples to avoid harsh audio clipping
      for (let i = 0; i < samples.length; i++) {
        const val = samples[i] * gainMultiplier;
        channelData[i] = Math.max(-0.99, Math.min(0.99, Math.tanh(val)));
      }

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      // Add gentle lowpass to represent mechanical haptic frequency range (< 800Hz)
      const lowpass = ctx.createBiquadFilter();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 850;

      const gainNode = ctx.createGain();
      gainNode.gain.value = 0.75;

      source.connect(lowpass);
      lowpass.connect(gainNode);
      gainNode.connect(ctx.destination);

      source.start();
    } catch {
      // Ignore audio synthesis errors in non-interactive states
    }
  }

  /**
   * Quick tactile acoustic chirp preview
   */
  public playClick(freq = 180, duration = 0.04): void {
    if (this.isMuted) return;
    const ctx = this.initAudio();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(freq * 0.5, ctx.currentTime + duration);

    gain.gain.setValueAtTime(0.5, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + duration);
  }
}
