import { Injectable } from '@angular/core';
import {
  ActuatorModelConfig,
  HapticEvent,
  HapticScoreFile,
  VibrationParams1DOF,
} from '../models/haptics.models';

@Injectable({
  providedIn: 'root',
})
export class RGeneratorService {
  /**
   * Generates a complete, executable R 4.x script for Haptic Simulation & Signal Analysis
   */
  public generateRSimulationScript(
    event: HapticEvent,
    mechParams: VibrationParams1DOF,
    actuator: ActuatorModelConfig,
    sampleRate = 10000
  ): string {
    const timestamp = new Date().toISOString();
    return `# ==============================================================================
# HAPTICS.OS: DESIGN THE FEELING (R Core v4.3 Engine)
# Engineering Simulation, Signal Processing & Mechanical Response Pipeline
# Generated: ${timestamp}
# Device Target: ${event.deviceId} | Actuator: ${actuator.name} (${actuator.type})
# ==============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(signal)
  library(pracma)
  library(ggplot2)
  library(Matrix)
  library(jsonlite)
})

# ------------------------------------------------------------------------------
# 1. HAPTIC EVENT & NUMERICAL SIGNAL GENERATION
# ------------------------------------------------------------------------------
fs <- ${sampleRate} # Sampling rate in Hz
duration <- ${event.duration} # Duration in seconds
N <- round(duration * fs)
t <- seq(0, duration - 1/fs, length.out = N)

# Event Parameters
freq <- ${event.frequency}
amp <- ${event.amplitude}
phase_rad <- ${((event.phase || 0) * Math.PI) / 180}
waveform_type <- "${event.waveform}"

cat(sprintf("[HAPTICS.OS] Synthesizing %s waveform at %.1f Hz (Duration: %.3f s, Samples: %d)\\n",
            waveform_type, freq, duration, N))

# Waveform synthesis
raw_signal <- switch(waveform_type,
  "SINE"        = amp * sin(2 * pi * freq * t + phase_rad),
  "COSINE"      = amp * cos(2 * pi * freq * t + phase_rad),
  "SQUARE"      = amp * ifelse(sin(2 * pi * freq * t + phase_rad) >= 0, 1, -1),
  "TRIANGLE"    = amp * (4 * abs(((freq * t + 0.25) %% 1) - 0.5) - 1),
  "SAW"         = amp * (2 * ((freq * t) %% 1) - 1),
  "WHITE_NOISE" = amp * runif(N, -1, 1),
  "CHIRP"       = amp * chirp(t, f0 = freq, t1 = duration, f1 = freq * 2.5),
  # Default fallback
  amp * sin(2 * pi * freq * t + phase_rad)
)

# ADSR Envelope Sculptor
attack_t  <- ${event.envelope.attack}
decay_t   <- ${event.envelope.decay}
sustain_l <- ${event.envelope.sustain}
release_t <- ${event.envelope.release}

calculate_envelope <- function(time_vec, dur, att, dec, sus, rel) {
  env <- numeric(length(time_vec))
  for (i in seq_along(time_vec)) {
    ti <- time_vec[i]
    if (ti < att) {
      env[i] <- (ti / att)^1.5
    } else if (ti < att + dec) {
      env[i] <- 1 - (1 - sus) * ((ti - att) / dec)
    } else if (ti < dur - rel) {
      env[i] <- sus
    } else if (ti <= dur) {
      env[i] <- sus * (1 - (ti - (dur - rel)) / rel)
    } else {
      env[i] <- 0
    }
  }
  return(pmax(0, pmin(1, env)))
}

envelope_gain <- calculate_envelope(t, duration, attack_t, decay_t, sustain_l, release_t)
u_drive <- raw_signal * envelope_gain

# ------------------------------------------------------------------------------
# 2. ACTUATOR ELECTROMECHANICAL TRANSFER MODEL (${actuator.type})
# ------------------------------------------------------------------------------
actuator_gain <- ${actuator.gain}
rated_voltage <- ${actuator.ratedVoltage || 3.3}

# Simulating actuator electromechanical drive force F_actuator(t)
${this.generateActuatorRCode(actuator)}

# ------------------------------------------------------------------------------
# 3. 1-DOF MECHANICAL SYSTEM (m * x'' + c * x' + k * x = F(t))
# ------------------------------------------------------------------------------
m_kg <- ${mechParams.mass}       # Mass (kg)
k_Nm <- ${mechParams.stiffness}  # Stiffness (N/m)
c_Ns_m <- ${mechParams.damping}  # Damping (N*s/m)

omega_n <- sqrt(k_Nm / m_kg)
f_n <- omega_n / (2 * pi)
zeta <- c_Ns_m / (2 * sqrt(k_Nm * m_kg))

cat(sprintf("[HAPTICS.OS] Natural Frequency f_n = %.2f Hz | Damping Ratio zeta = %.4f | Q = %.2f\\n",
            f_n, zeta, 1 / (2 * zeta)))

# State-Space RK4 Numerical Integration
dt <- 1 / fs
x_disp <- numeric(N)
v_vel  <- numeric(N)
a_acc  <- numeric(N)

x_curr <- 0
v_curr <- 0

f_state <- function(x_val, v_val, force_val) {
  a_val <- (force_val - c_Ns_m * v_val - k_Nm * x_val) / m_kg
  return(c(dx = v_val, dv = a_val))
}

for (i in seq_len(N)) {
  F_in <- F_act[i]
  a_acc[i] <- (F_in - c_Ns_m * v_curr - k_Nm * x_curr) / (m_kg * 9.80665) # in Gs
  x_disp[i] <- x_curr * 1000 # in mm
  v_vel[i]  <- v_curr

  # Runge-Kutta 4th Order
  k1 <- f_state(x_curr, v_curr, F_in)
  k2 <- f_state(x_curr + 0.5 * dt * k1["dx"], v_curr + 0.5 * dt * k1["dv"], F_in)
  k3 <- f_state(x_curr + 0.5 * dt * k2["dx"], v_curr + 0.5 * dt * k2["dv"], F_in)
  k4 <- f_state(x_curr + dt * k3["dx"], v_curr + dt * k3["dv"], F_in)

  x_curr <- x_curr + (dt / 6) * (k1["dx"] + 2 * k2["dx"] + 2 * k3["dx"] + k4["dx"])
  v_curr <- v_curr + (dt / 6) * (k1["dv"] + 2 * k2["dv"] + 2 * k3["dv"] + k4["dv"])
}

# ------------------------------------------------------------------------------
# 4. FREQUENCY DOMAIN & STATISTICAL METRICS
# ------------------------------------------------------------------------------
haptic_dt <- data.table(
  time_ms = t * 1000,
  drive_input = u_drive,
  actuator_force_N = F_act,
  disp_mm = x_disp,
  accel_g = a_acc
)

# FFT Analysis
fft_res <- fft(a_acc)
mag <- Mod(fft_res)[1:(N/2)] / (N/2)
freqs <- (0:(N/2 - 1)) * (fs / N)
psd_db <- 20 * log10(pmax(1e-6, mag))

dom_idx <- which.max(mag[freqs > 10])
dominant_freq <- freqs[dom_idx]

cat(sprintf("[HAPTICS.OS] Peak Acceleration = %.2f G | Dominant Frequency = %.1f Hz\\n",
            max(abs(a_acc)), dominant_freq))

# Export / Return Simulation Table
summary(haptic_dt)
`;
  }

  private generateActuatorRCode(actuator: ActuatorModelConfig): string {
    switch (actuator.type) {
      case 'LRA':
        return `# Linear Resonant Actuator Electromechanical Coupling
lra_f0 <- ${actuator.lraResonantFreqHz || 175}
lra_q  <- ${actuator.lraQFactor || 6.5}
omega_act <- 2 * pi * lra_f0
damp_act <- omega_act / (2 * lra_q)

F_act <- numeric(N)
x_act <- 0
v_act <- 0
for (i in seq_len(N)) {
  drv <- u_drive[i] * actuator_gain * rated_voltage * 1.5
  a_act <- drv - 2 * damp_act * v_act - (omega_act^2) * x_act
  v_act <- v_act + a_act * (1/fs)
  x_act <- x_act + v_act * (1/fs)
  F_act[i] <- pmax(-5, pmin(5, ${actuator.lraMovingMassG || 2.5} * 0.001 * a_act))
}`;

      case 'VOICE_COIL':
        return `# Wideband Voice Coil Lorentz Force Simulation
R_coil <- ${actuator.vcmResistanceOhm || 8.0}
L_coil <- ${(actuator.vcmInductanceMh || 0.12) * 1e-3}
Bl_const <- ${actuator.vcmForceConstantBl || 1.8}

i_current <- numeric(N)
curr_i <- 0
for (i in seq_len(N)) {
  v_app <- u_drive[i] * rated_voltage
  di <- (v_app - R_coil * curr_i) / max(1e-5, L_coil)
  curr_i <- curr_i + di * (1/fs)
  i_current[i] <- curr_i
}
F_act <- pmax(-8, pmin(8, Bl_const * i_current * actuator_gain))`;

      case 'ERM':
      default:
        return `# ERM / General Dynamic Force
F_act <- u_drive * actuator_gain * 2.8`;
    }
  }

  /**
   * Generates machine-readable `.haptic` JSON file payload
   */
  public generateHapticScoreFile(
    event: HapticEvent,
    actuator: ActuatorModelConfig,
    mechParams: VibrationParams1DOF
  ): HapticScoreFile {
    return {
      hapticsOsVersion: '3.7.0-R4',
      formatVersion: '1.0.0',
      timestamp: new Date().toISOString(),
      author: 'HAPTICS.OS Engineering Suite',
      scoreTitle: `${event.name} — Tactile Definition`,
      deviceTarget: event.deviceId,
      sampleRate: 10000,
      duration: event.duration,
      events: [event],
      deviceConstraints: {
        maxPeakCurrentA: actuator.currentLimitA || 0.45,
        maxThermalTempC: 65.0,
        maxStrokeMm: actuator.strokeLimitMm || 0.8,
        preferredResonanceHz: mechParams.naturalFreqHz,
      },
      provenance: {
        engine: 'HAPTICS.OS R-CORE',
        reproducibleSeed: 42891,
        rPackagesUsed: ['data.table', 'signal', 'pracma', 'ggplot2', 'Matrix', 'jsonlite'],
      },
    };
  }
}
