export type WaveformType =
  | 'SINE'
  | 'COSINE'
  | 'SQUARE'
  | 'TRIANGLE'
  | 'SAW'
  | 'PULSE'
  | 'WHITE_NOISE'
  | 'PINK_NOISE'
  | 'CHIRP'
  | 'SWEEP'
  | 'IMPULSE'
  | 'BURST'
  | 'CUSTOM';

export type EnvelopeCurve = 'LINEAR' | 'EXPONENTIAL' | 'LOGARITHMIC' | 'SMOOTHSTEP' | 'CUSTOM';

export type ActuatorType = 'ERM' | 'LRA' | 'VOICE_COIL' | 'PIEZO' | 'ULTRASONIC' | 'CUSTOM_TF';

export type FilterType = 'LOW_PASS' | 'HIGH_PASS' | 'BAND_PASS' | 'BAND_STOP' | 'NOTCH';

export type SimulationFidelity = 'CONCEPT' | 'ENGINEERING' | 'CALIBRATED' | 'EXPERIMENTAL' | 'MONTE_CARLO' | 'REAL_TIME';

export type ControllerMode = 'OPEN_LOOP' | 'P' | 'PI' | 'PID' | 'ACTIVE_BRAKING';

export interface EnvelopeConfig {
  attack: number;     // seconds (e.g. 0.01)
  decay: number;      // seconds (e.g. 0.02)
  sustain: number;    // ratio 0..1 (e.g. 0.6)
  release: number;    // seconds (e.g. 0.03)
  curve: EnvelopeCurve;
  customCurveExponent?: number;
}

export interface HapticEvent {
  id: string;
  name: string;
  type: string;
  timestamp: number;       // relative start time in seconds
  duration: number;        // seconds (e.g. 0.08)
  intensity: number;       // 0..1
  frequency: number;       // Hz (e.g. 175)
  waveform: WaveformType;
  amplitude: number;       // 0..1 nominal (or V / N)
  envelope: EnvelopeConfig;
  phase: number;           // degrees (0..360)
  pulseWidth?: number;     // 0..1 for square/pulse
  chirpEndFreq?: number;   // for CHIRP / SWEEP (Hz)
  direction: [number, number, number]; // 3D unit vector
  location: [number, number, number];  // x, y, z normalized (-1 to 1)
  priority: number;        // 1 to 10
  deviceId: string;
  actuatorId: string;
  channel: number;         // 1..4
  metadata: {
    intent: string;
    targetFeeling: string;
    designDomain: string;
    provenance: 'SYNTHETIC' | 'SIMULATED' | 'CALIBRATED' | 'MEASURED';
  };
}

export interface SignalData {
  time: number[];
  samples: number[];
  sampleRate: number;
  duration: number;
  metrics: SignalMetrics;
}

export interface SignalMetrics {
  rms: number;
  peak: number;
  crestFactor: number;
  zeroCrossingRate: number;
  bandEnergyLow: number;  // 10 - 100 Hz
  bandEnergyMid: number;  // 100 - 300 Hz
  bandEnergyHigh: number; // 300 - 1000 Hz
  dominantFreq: number;
  thd: number;            // Total Harmonic Distortion %
  snrDb: number;
}

export interface FFTResult {
  frequencies: number[];
  magnitudes: number[];
  phases: number[];
  powerDb: number[];
  dominantPeakHz: number;
  peakMagnitude: number;
  resonances: { freq: number; magnitude: number; qFactor: number }[];
}

export interface SpectrogramResult {
  timeBins: number[];
  freqBins: number[];
  matrix: number[][]; // [timeIdx][freqIdx] power in dB
  minDb: number;
  maxDb: number;
}

export interface WaterfallPoint {
  time: number;
  freq: number;
  amplitude: number;
}

export interface VibrationParams1DOF {
  mass: number;           // kg (e.g. 0.015 kg = 15g)
  stiffness: number;      // N/m (e.g. 18500 N/m)
  damping: number;        // N·s/m (e.g. 0.45)
  naturalFreqHz: number;  // calculated sqrt(k/m)/(2*pi)
  dampingRatio: number;   // calculated c / (2*sqrt(k*m))
  qFactor: number;        // 1 / (2*zeta)
}

export interface VibrationParamsNDOF {
  dofCount: number;
  massMatrix: number[][];      // M (kg)
  dampingMatrix: number[][];   // C (N·s/m)
  stiffnessMatrix: number[][]; // K (N/m)
  modalFrequencies: number[];  // Hz for each mode
}

export interface MechanicalSimulationResult {
  time: number[];
  displacement: number[];    // x(t) in mm
  velocity: number[];        // v(t) in m/s
  acceleration: number[];    // a(t) in m/s^2 or g
  force: number[];           // F(t) input in N
  peakDisplacementMm: number;
  peakVelocityMps: number;
  peakAccelerationG: number;
  settlingTimeMs: number;    // time to decay to 5%
  overshootPct: number;
  energyJoules: number;
}

export interface ActuatorModelConfig {
  id: string;
  name: string;
  type: ActuatorType;
  // Common
  gain: number;
  ratedVoltage: number;      // V (e.g. 3.3V)
  currentLimitA: number;     // A (e.g. 0.45A)
  strokeLimitMm: number;     // mm (e.g. 0.8 mm)
  delayMs: number;           // electrical latency (ms)
  // ERM specific
  ermTorqueConstant?: number; // N·m/A
  ermBackEmf?: number;        // V/(rad/s)
  ermEccentricMass?: number;  // g
  ermEccentricity?: number;   // mm
  ermRatedRpm?: number;       // RPM (e.g. 11000)
  ermStartupTimeMs?: number;  // ms (e.g. 35 ms)
  ermBrakingTimeMs?: number;  // ms (e.g. 50 ms)
  // LRA specific
  lraResonantFreqHz?: number;// Hz (e.g. 175 Hz)
  lraMovingMassG?: number;   // g (e.g. 2.8g)
  lraQFactor?: number;       // Q (e.g. 6.5)
  lraSpringStiffness?: number;// N/m
  // Voice Coil specific
  vcmResistanceOhm?: number; // Ohm (e.g. 8.0)
  vcmInductanceMh?: number;  // mH (e.g. 0.12)
  vcmForceConstantBl?: number;// N/A (e.g. 1.8)
  vcmMovingMassG?: number;   // g (e.g. 3.5)
  // Piezo specific
  piezoCapacitanceNf?: number;// nF (e.g. 180)
  piezoD33Constant?: number;  // pm/V (e.g. 650)
  piezoBlockingForceN?: number;// N (e.g. 45 N)
  piezoHysteresisPct?: number; // % (e.g. 12%)
  // Custom Transfer Function
  customNumerator?: number[];
  customDenominator?: number[];
}

export interface SensorChannel {
  id: string;
  name: string;
  type: 'ACCELEROMETER' | 'FORCE' | 'DISPLACEMENT' | 'VELOCITY' | 'CURRENT' | 'TEMPERATURE';
  unit: string;
  samplingRateHz: number;
  noiseDensity: number;      // noise floor
  saturationLimit: number;
  sensitivity: number;       // mV/unit
  location: [number, number, number];
}

export interface DeviceSpatialActuator {
  id: string;
  name: string;
  type: ActuatorType;
  channel: number;
  position: [number, number, number]; // x, y, z normalized (-1..1)
  direction: [number, number, number];
  weightFactor: number;
  actuatorModel: ActuatorModelConfig;
}

export interface HapticDeviceTwin {
  id: string;
  name: string;
  deviceType: 'SMARTPHONE' | 'GAME_CONTROLLER' | 'STEERING_WHEEL' | 'WEARABLE' | 'VR_TRACKER' | 'TOUCHSCREEN' | 'INDUSTRIAL_PANEL';
  dimensionsMm: [number, number, number]; // [width, height, depth]
  totalMassG: number;
  chassisMaterial: string;
  surfaceMaterial: string;
  actuators: DeviceSpatialActuator[];
  sensors: SensorChannel[];
  vibration1DOF: VibrationParams1DOF;
  vibrationNDOF: VibrationParamsNDOF;
  thermal: {
    ambientTempC: number;
    thermalResistanceCW: number; // °C/W
    thermalMassJouleC: number;   // J/°C
    maxSafeTempC: number;
  };
  electrical: {
    batteryVoltageV: number;
    batteryCapacityMah: number;
    maxPeakCurrentA: number;
  };
  calibration: {
    gainMultiplier: number;
    offsetNull: number;
    phaseCalibrationDeg: number;
    latencyCompensationMs: number;
    lastCalibrated: string;
    status: 'CALIBRATED' | 'DEFAULT' | 'UNCALIBRATED';
  };
}

export interface PerceptualScore {
  pacinianResponse: number;   // FA II channel (high freq, 250Hz optimal)
  meissnerResponse: number;   // FA I channel (low freq, 30-50Hz)
  merkelResponse: number;     // SA I channel (sustained pressure)
  perceivedIntensityDb: number; // subjective dB
  roughnessIndex: number;     // 0..1
  sharpnessIndex: number;     // 0..1 (clickiness vs rumble)
  spatialClarity: number;     // 0..1
  compositeQualityScore: number; // 0..100 weighted index
}

export interface ControlLoopResult {
  time: number[];
  desired: number[];
  actual: number[];
  error: number[];
  controlEffort: number[];
  riseTimeMs: number;
  overshootPct: number;
  steadyStateErrorPct: number;
  settlingTimeMs: number;
}

export interface MonteCarloIteration {
  iteration: number;
  perturbedMassG: number;
  perturbedStiffness: number;
  perturbedDamping: number;
  perturbedGain: number;
  resonantFreqHz: number;
  peakAccelerationG: number;
  settlingTimeMs: number;
  latencyMs: number;
  powerMw: number;
  perceivedScore: number;
  passed: boolean;
}

export interface MonteCarloSummary {
  totalIterations: number;
  passCount: number;
  failCount: number;
  yieldPct: number;
  meanResonantFreqHz: number;
  stdResonantFreqHz: number;
  meanPeakAccG: number;
  stdPeakAccG: number;
  p95LatencyMs: number;
  worstCaseAccG: number;
  sensitivityRankings: { parameter: string; sensitivity: number; impact: 'HIGH' | 'MEDIUM' | 'LOW' }[];
  distributionFr: { bin: number; count: number }[];
  distributionAcc: { bin: number; count: number }[];
}

export interface PsychophysicsTrial {
  trialId: number;
  stimulusA: { freq: number; amp: number; waveform: WaveformType };
  stimulusB: { freq: number; amp: number; waveform: WaveformType };
  userChoice: 'A' | 'B' | 'EQUAL';
  reactionTimeMs: number;
  confidenceRating: number; // 1..5
}

export interface HapticMaterialProfile {
  id: string;
  name: string;
  stiffnessN_m: number;
  dampingRatio: number;
  roughnessCoefficient: number;
  frictionCoefficient: number;
  textureSpatialPeriodMm: number;
  resonanceFreqHz: number;
  soundVelocityM_s: number;
  description: string;
}

export interface HapticScoreFile {
  hapticsOsVersion: string;
  formatVersion: '1.0.0';
  timestamp: string;
  author: string;
  scoreTitle: string;
  deviceTarget: string;
  sampleRate: number;
  duration: number;
  events: HapticEvent[];
  deviceConstraints: {
    maxPeakCurrentA: number;
    maxThermalTempC: number;
    maxStrokeMm: number;
    preferredResonanceHz: number;
  };
  provenance: {
    engine: 'HAPTICS.OS R-CORE';
    reproducibleSeed: number;
    rPackagesUsed: string[];
  };
}
