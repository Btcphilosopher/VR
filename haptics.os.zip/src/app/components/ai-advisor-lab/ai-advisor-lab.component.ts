import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-ai-advisor-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Context Telemetry & Prompt Starters -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">psychology_alt</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Haptics AI Advisor</h2>
            </div>
            <span class="font-mono text-[10px] text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
              GEMINI 3.8 CORE
            </span>
          </div>

          <p class="text-slate-400 text-[11px] leading-relaxed">
            Direct AI-grounded engineering consultation analyzing live physics parameters, actuator dynamics, Bode resonance matching, and somatosensory perception.
          </p>

          <!-- Current Telemetry Feed Preview -->
          <div class="bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2.5 font-mono text-[11px] space-y-1">
            <span class="text-[10px] text-slate-500 uppercase block mb-1">Live Telemetry Snapshot</span>
            <div class="flex justify-between">
              <span class="text-slate-400">Operating Frequency:</span>
              <span class="text-cyan-300 font-bold">{{ state.activeEvent().frequency }} Hz</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Natural Resonance:</span>
              <span class="text-amber-300 font-bold">{{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Peak Accel / Settling:</span>
              <span class="text-emerald-400 font-bold">{{ state.mechSimulation().peakAccelerationG }} G / {{ state.mechSimulation().settlingTimeMs }} ms</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Pacinian FA II:</span>
              <span class="text-indigo-300 font-bold">{{ state.perceptualScore().pacinianResponse }}%</span>
            </div>
          </div>

          <!-- Suggested Engineering Questions -->
          <div class="space-y-1.5 pt-2">
            <span class="font-mono text-[10px] text-slate-400 uppercase font-semibold block">Diagnostic Queries</span>
            @for (query of promptPresets; track query) {
              <button
                type="button"
                (click)="askQuestion(query)"
                class="w-full text-left p-2 rounded bg-[#0b0e14] hover:bg-slate-800/80 border border-slate-800 text-slate-300 text-[11px] font-mono transition-colors truncate"
              >
                &bull; {{ query }}
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Right Column: AI Output Diagnostic Terminal -->
      <div class="flex-1 bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col min-h-[440px]">
        <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div class="flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-base">terminal</mat-icon>
            <span class="font-mono font-bold text-sm text-slate-100 uppercase">Engineering Diagnostic Output</span>
          </div>
          @if (state.isAiDiagnosing()) {
            <span class="font-mono text-[11px] text-cyan-400 animate-pulse">ANALYZING TELEMETRY...</span>
          }
        </div>

        <!-- Output Terminal -->
        <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-4 font-mono text-xs overflow-y-auto leading-relaxed text-slate-200 select-text">
          @if (state.isAiDiagnosing()) {
            <div class="flex items-center justify-center h-full gap-3 text-cyan-400">
              <mat-icon class="animate-spin text-2xl">refresh</mat-icon>
              <span>Consulting Lead Haptic &amp; Vibration Specialist...</span>
            </div>
          } @else if (state.aiDiagnosticOutput()) {
            <div class="whitespace-pre-wrap leading-relaxed">{{ state.aiDiagnosticOutput() }}</div>
          } @else {
            <div class="text-slate-500 text-center flex flex-col items-center justify-center h-full gap-2">
              <mat-icon class="text-4xl text-slate-700">insights</mat-icon>
              <span>Select a diagnostic query or click "Run System Diagnostic" to evaluate this haptic profile.</span>
            </div>
          }
        </div>

        <!-- Custom Prompt Input Box -->
        <div class="mt-3 flex gap-2">
          <input
            type="text"
            #customInput
            (keyup.enter)="askCustom(customInput)"
            placeholder="Ask specific vibration, filter, control, or psychophysics question..."
            class="flex-1 bg-[#0b0e14] border border-slate-800 rounded-lg px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-cyan-500"
          />
          <button
            type="button"
            (click)="askCustom(customInput)"
            [disabled]="state.isAiDiagnosing()"
            class="px-4 py-2 rounded bg-cyan-600 hover:bg-cyan-500 text-white font-mono font-bold text-xs shadow-md shadow-cyan-600/30 flex items-center gap-1.5 disabled:opacity-50"
          >
            <mat-icon class="text-xs">send</mat-icon>
            <span>ANALYZE</span>
          </button>
        </div>
      </div>
    </div>
  `,
})
export class AiAdvisorLabComponent {
  public state = inject(HapticsStateService);

  public promptPresets: string[] = [
    'Analyze resonance matching between event frequency and chassis f_n.',
    'How do I eliminate unwanted mechanical ringing / trailing overshoot?',
    'Evaluate human tactile clarity for Pacinian vs Meissner channels.',
    'Recommend optimal PID gains and Active Braking feedforward parameters.',
    'Evaluate power dissipation and battery life for this actuation waveform.',
  ];

  public askQuestion(query: string): void {
    this.state.askAiDiagnostic(query);
  }

  public askCustom(input: HTMLInputElement): void {
    const q = input.value.trim();
    if (!q) return;
    this.state.askAiDiagnostic(q);
    input.value = '';
  }
}
