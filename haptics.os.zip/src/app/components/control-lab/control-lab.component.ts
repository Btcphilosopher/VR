import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';
import { ControllerMode } from '../../core/models/haptics.models';

@Component({
  selector: 'app-control-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Closed-Loop Controller Tuning -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <!-- Controller Architecture Panel -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">alt_route</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Feedback Controller</h2>
            </div>
            <span class="font-mono text-[10px] text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40 font-bold">
              {{ state.controllerConfig().mode }}
            </span>
          </div>

          <!-- Controller Mode Selector -->
          <div>
            <span class="font-mono text-[11px] text-slate-400 block mb-1.5 font-semibold">CONTROL TOPOLOGY</span>
            <div class="grid grid-cols-2 gap-1.5">
              @for (mode of modes; track mode.id) {
                <button
                  type="button"
                  (click)="onModeSelect(mode.id)"
                  class="flex items-center gap-1.5 px-2 py-1.5 rounded font-mono text-[10px] font-semibold border transition-all"
                  [class.bg-cyan-950]="state.controllerConfig().mode === mode.id"
                  [class.text-cyan-300]="state.controllerConfig().mode === mode.id"
                  [class.border-cyan-600]="state.controllerConfig().mode === mode.id"
                  [class.bg-[#0b0e14]]="state.controllerConfig().mode !== mode.id"
                  [class.text-slate-400]="state.controllerConfig().mode !== mode.id"
                  [class.border-slate-800]="state.controllerConfig().mode !== mode.id"
                >
                  <mat-icon class="text-xs">{{ mode.icon }}</mat-icon>
                  <span>{{ mode.label }}</span>
                </button>
              }
            </div>
          </div>

          <!-- PID Tuning Sliders -->
          <div class="space-y-3 pt-2">
            <!-- Kp Slider -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Proportional Gain (K_p):</span>
                <span class="text-cyan-300 font-bold">{{ state.controllerConfig().kp }}</span>
              </div>
              <input
                type="range"
                min="0.1"
                max="5.0"
                step="0.1"
                [value]="state.controllerConfig().kp"
                (input)="onKpChange($event)"
                class="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <!-- Ki Slider -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Integral Gain (K_i):</span>
                <span class="text-amber-300 font-bold">{{ state.controllerConfig().ki }}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.5"
                step="0.01"
                [value]="state.controllerConfig().ki"
                (input)="onKiChange($event)"
                class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <!-- Kd Slider -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Derivative Gain (K_d):</span>
                <span class="text-emerald-400 font-bold">{{ state.controllerConfig().kd }}</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="0.8"
                step="0.02"
                [value]="state.controllerConfig().kd"
                (input)="onKdChange($event)"
                class="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        <!-- Performance Summary Card -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-2 font-mono text-[11px]">
          <span class="font-bold text-slate-200">Step Response Metrics</span>
          <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 space-y-1.5">
            <div class="flex justify-between">
              <span class="text-slate-400">Rise Time (t_r):</span>
              <span class="text-cyan-300 font-bold">{{ state.controlLoopResult().riseTimeMs }} ms</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Peak Overshoot (M_p):</span>
              <span class="text-amber-300 font-bold">{{ state.controlLoopResult().overshootPct }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Settling Time (t_s):</span>
              <span class="text-slate-200 font-semibold">{{ state.controlLoopResult().settlingTimeMs }} ms</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Steady State Error (e_ss):</span>
              <span class="text-emerald-400 font-bold">{{ state.controlLoopResult().steadyStateErrorPct }}%</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column: Real-Time Comparative Closed-Loop Oscilloscope -->
      <div class="flex-1 bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col min-h-[440px]">
        <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
          <div class="flex items-center gap-3">
            <span class="font-mono font-bold text-sm text-slate-100">CLOSED-LOOP TRACKING SCOPE</span>
            <div class="flex items-center gap-3 font-mono text-[11px]">
              <span class="text-cyan-400 font-bold">&bull; Reference Desired r(t)</span>
              <span class="text-emerald-400 font-bold">&bull; Actual Acceleration y(t)</span>
              <span class="text-red-400">&bull; Error e(t)</span>
              <span class="text-indigo-400">&bull; Control Effort u(t)</span>
            </div>
          </div>
          <span class="font-mono text-[10px] text-slate-400">Time: 0..{{ state.activeEvent().duration * 1000 | number:'1.0-0' }} ms</span>
        </div>

        <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 relative flex items-center justify-center">
          <svg class="w-full h-full" viewBox="0 0 800 320" preserveAspectRatio="none">
            <!-- Grid -->
            @for (y of [40, 100, 160, 220, 280]; track y) {
              <line x1="0" [attr.y1]="y" x2="800" [attr.y2]="y" stroke="#1e293b" stroke-width="1" stroke-dasharray="4" />
            }
            @for (x of [100, 200, 300, 400, 500, 600, 700]; track x) {
              <line [attr.x1]="x" y1="0" [attr.x2]="x" y2="320" stroke="#172033" stroke-width="1" />
            }

            <!-- Reference (Cyan dashed) -->
            <path [attr.d]="desiredPath()" fill="none" stroke="#22d3ee" stroke-width="2" stroke-dasharray="4,2" />
            <!-- Error (Red) -->
            <path [attr.d]="errorPath()" fill="none" stroke="#ef4444" stroke-width="1.2" />
            <!-- Control Effort (Indigo) -->
            <path [attr.d]="effortPath()" fill="none" stroke="#818cf8" stroke-width="1.5" />
            <!-- Actual Output (Emerald) -->
            <path [attr.d]="actualPath()" fill="none" stroke="#34d399" stroke-width="2.5" stroke-linecap="round" />
          </svg>

          <div class="absolute top-3 right-4 font-mono text-[11px] bg-[#121622]/90 border border-slate-800 p-2.5 rounded space-y-1 text-right">
            <div class="text-cyan-400 font-bold">Target Peak: 1.0 G</div>
            <div class="text-emerald-400 font-bold">Plant Output: {{ state.mechSimulation().peakAccelerationG }} G</div>
            <div class="text-amber-300">Overshoot: {{ state.controlLoopResult().overshootPct }}%</div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ControlLabComponent {
  public state = inject(HapticsStateService);

  public modes: { id: ControllerMode; label: string; icon: string }[] = [
    { id: 'OPEN_LOOP', label: 'OPEN LOOP', icon: 'sync_disabled' },
    { id: 'P', label: 'P ONLY', icon: 'timeline' },
    { id: 'PI', label: 'PI CONTROL', icon: 'show_chart' },
    { id: 'PID', label: 'PID CONTROL', icon: 'tune' },
    { id: 'ACTIVE_BRAKING', label: 'ACTIVE BRAKE', icon: 'back_hand' },
  ];

  public onModeSelect(mode: ControllerMode): void {
    this.state.controllerConfig.update((c) => ({ ...c, mode }));
    this.state.playHapticFeedback();
  }

  public onKpChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.controllerConfig.update((c) => ({ ...c, kp: val }));
  }

  public onKiChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.controllerConfig.update((c) => ({ ...c, ki: val }));
  }

  public onKdChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.controllerConfig.update((c) => ({ ...c, kd: val }));
  }

  public desiredPath = computed(() => {
    const samples = this.state.controlLoopResult().desired;
    return this.buildSvgPath(samples, 800, 320, 1.0);
  });

  public actualPath = computed(() => {
    const samples = this.state.controlLoopResult().actual;
    return this.buildSvgPath(samples, 800, 320, 1.0);
  });

  public errorPath = computed(() => {
    const samples = this.state.controlLoopResult().error;
    return this.buildSvgPath(samples, 800, 320, 1.0);
  });

  public effortPath = computed(() => {
    const samples = this.state.controlLoopResult().controlEffort;
    return this.buildSvgPath(samples, 800, 320, 1.0);
  });

  private buildSvgPath(samples: number[], width: number, height: number, scaleMax: number): string {
    if (!samples || samples.length === 0) return 'M 0 160';
    const n = samples.length;
    const step = Math.max(1, Math.floor(n / width));
    const points: string[] = [];

    const midY = height / 2;
    for (let i = 0; i < n; i += step) {
      const x = (i / (n - 1 || 1)) * width;
      const normalized = samples[i] / (scaleMax || 1);
      const y = midY - normalized * (midY * 0.85);
      points.push(`${points.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  }
}
