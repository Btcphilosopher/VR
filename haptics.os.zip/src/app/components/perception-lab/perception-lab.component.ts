import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-perception-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Somatosensory Receptors & Contact Dynamics -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <!-- Receptors Panel -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-indigo-400 text-base">fingerprint</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Tactile Receptors</h2>
            </div>
            <span class="font-mono text-[10px] text-indigo-300 px-1.5 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/40 font-bold">
              VERRILLO MODEL
            </span>
          </div>

          <!-- Receptor Energy Gauges -->
          <div class="space-y-3 font-mono text-[11px]">
            <!-- Pacinian FA II -->
            <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 space-y-1">
              <div class="flex justify-between">
                <span class="text-indigo-300 font-bold">FA II (Pacinian)</span>
                <span class="text-indigo-400 font-bold">{{ state.perceptualScore().pacinianResponse }}%</span>
              </div>
              <div class="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div class="bg-indigo-500 h-full rounded-full transition-all duration-150" [style.width.%]="state.perceptualScore().pacinianResponse"></div>
              </div>
              <span class="text-[10px] text-slate-400 block">Band: 150 - 400 Hz (Peak 250 Hz) &bull; Transient Snap</span>
            </div>

            <!-- Meissner FA I -->
            <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 space-y-1">
              <div class="flex justify-between">
                <span class="text-blue-300 font-bold">FA I (Meissner)</span>
                <span class="text-blue-400 font-bold">{{ state.perceptualScore().meissnerResponse }}%</span>
              </div>
              <div class="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div class="bg-blue-500 h-full rounded-full transition-all duration-150" [style.width.%]="state.perceptualScore().meissnerResponse"></div>
              </div>
              <span class="text-[10px] text-slate-400 block">Band: 20 - 80 Hz (Peak 40 Hz) &bull; Surface Slip / Flutter</span>
            </div>

            <!-- Merkel SA I -->
            <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 space-y-1">
              <div class="flex justify-between">
                <span class="text-emerald-300 font-bold">SA I (Merkel)</span>
                <span class="text-emerald-400 font-bold">{{ state.perceptualScore().merkelResponse }}%</span>
              </div>
              <div class="w-full bg-slate-900 h-2 rounded-full overflow-hidden">
                <div class="bg-emerald-500 h-full rounded-full transition-all duration-150" [style.width.%]="state.perceptualScore().merkelResponse"></div>
              </div>
              <span class="text-[10px] text-slate-400 block">Band: 0.5 - 15 Hz &bull; Sustained Static Pressure</span>
            </div>
          </div>
        </div>

        <!-- Finger Contact Dynamics & Normal Force -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-base">touch_app</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Contact Dynamics</h2>
            </div>
          </div>

          <div class="space-y-3 font-mono text-[11px]">
            <div>
              <div class="flex justify-between mb-1">
                <span class="text-slate-400">Finger Normal Contact Force:</span>
                <span class="text-amber-300 font-bold">{{ state.contactForceN() }} N</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="5.0"
                step="0.1"
                [value]="state.contactForceN()"
                (input)="onContactForceChange($event)"
                class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
              <div class="flex justify-between text-[9px] text-slate-500 mt-0.5">
                <span>0.2N (Feather)</span>
                <span>1.5N (Nominal Tap)</span>
                <span>5.0N (Heavy Press)</span>
              </div>
            </div>

            <!-- Subjective Quality Metric Output -->
            <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-3 space-y-1.5 mt-2">
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Perceived Intensity:</span>
                <span class="text-emerald-400 font-bold text-sm">{{ state.perceptualScore().perceivedIntensityDb }} dB</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Sharpness Index:</span>
                <span class="text-cyan-300 font-bold">{{ state.perceptualScore().sharpnessIndex }}</span>
              </div>
              <div class="flex justify-between items-center">
                <span class="text-slate-400">Roughness Index:</span>
                <span class="text-amber-300 font-bold">{{ state.perceptualScore().roughnessIndex }}</span>
              </div>
              <div class="flex justify-between items-center pt-2 border-t border-slate-800">
                <span class="text-slate-300 font-bold">Composite Quality Score:</span>
                <span class="text-cyan-400 font-extrabold text-sm">{{ state.perceptualScore().compositeQualityScore }}/100</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column: Equal-Sensation Curves & 2AFC Psychometric Curve Simulator -->
      <div class="flex-1 flex flex-col gap-4">
        <!-- Verrillo Equal-Sensation Threshold Plot -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col flex-1 min-h-[300px]">
          <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
            <div>
              <span class="font-mono font-bold text-sm text-slate-100">VERRILLO EQUAL-SENSATION CONTOURS (dB vs Hz)</span>
              <p class="text-[11px] text-slate-400 mt-0.5">Absolute detection threshold &amp; supra-threshold sensation curves across human hand.</p>
            </div>
            <div class="flex items-center gap-2 font-mono text-[10px]">
              <span class="text-red-400 font-bold">&bull; Current Event Operating Point ({{ state.activeEvent().frequency }} Hz)</span>
            </div>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 relative flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 800 240" preserveAspectRatio="none">
              <!-- Grid -->
              @for (y of [40, 80, 120, 160, 200]; track y; let idx = $index) {
                <line x1="0" [attr.y1]="y" x2="800" [attr.y2]="y" stroke="#1e293b" stroke-width="1" stroke-dasharray="3" />
                <text x="8" [attr.y]="y - 4" fill="#64748b" font-family="monospace" font-size="9">{{ 60 - idx * 20 }} dB</text>
              }

              <!-- Verrillo Sensitivity Threshold Curve (Deep U-shape dip at 250Hz) -->
              <path [attr.d]="verrilloCurvePath()" fill="none" stroke="#6366f1" stroke-width="2.5" />
              <!-- Current Operating Frequency Marker -->
              <circle [attr.cx]="operatingFreqX()" [attr.cy]="operatingFreqY()" r="6" fill="#ef4444" stroke="#ffffff" stroke-width="2" class="animate-pulse" />
              <line [attr.x1]="operatingFreqX()" y1="0" [attr.x2]="operatingFreqX()" y2="240" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="3,3" />
            </svg>
            <div class="absolute bottom-2 left-3 font-mono text-[10px] text-slate-500">10 Hz</div>
            <div class="absolute bottom-2 [left:calc(60%-20px)] font-mono text-[10px] text-indigo-400 font-bold">250 Hz (Pacinian Minimum ~ -20dB)</div>
            <div class="absolute bottom-2 right-3 font-mono text-[10px] text-slate-500">600 Hz</div>
          </div>
        </div>

        <!-- Psychophysics 2AFC / JND Experiment Simulator -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-base">psychology</mat-icon>
              <h3 class="font-mono font-bold text-xs text-slate-100 uppercase">2AFC Psychometric JND Curve Fitting (Weibull Sigmoid)</h3>
            </div>
            <button
              type="button"
              (click)="runPsychophysicsTrial()"
              class="px-2.5 py-1 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 font-mono text-[11px] font-bold hover:bg-emerald-900"
            >
              RUN N=50 JND TRIAL
            </button>
          </div>

          <div class="grid grid-cols-1 lg:grid-cols-3 gap-3">
            <div class="lg:col-span-2 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2.5 h-36 relative flex items-center justify-center">
              <svg class="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
                <!-- 50% chance line -->
                <line x1="0" y1="90" x2="500" y2="90" stroke="#334155" stroke-width="1" stroke-dasharray="2" />
                <text x="6" y="86" fill="#64748b" font-family="monospace" font-size="8">50% Guess Rate</text>
                <!-- 75% JND Threshold line -->
                <line x1="0" y1="45" x2="500" y2="45" stroke="#059669" stroke-width="1" stroke-dasharray="3" />
                <text x="6" y="41" fill="#10b981" font-family="monospace" font-size="8">75% JND Threshold</text>
                <!-- Sigmoidal curve -->
                <path [attr.d]="psychometricPath()" fill="none" stroke="#10b981" stroke-width="2" />
              </svg>
            </div>

            <!-- Statistical ANOVA / JND Output Table -->
            <div class="bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2.5 font-mono text-[11px] space-y-1.5 flex flex-col justify-center">
              <div class="flex justify-between">
                <span class="text-slate-400">Weber Fraction (k):</span>
                <span class="text-emerald-400 font-bold">0.142 (14.2%)</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">JND (ΔI):</span>
                <span class="text-cyan-300 font-bold">0.12 G</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">ANOVA F(1,48):</span>
                <span class="text-slate-200 font-semibold">28.45</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">p-value:</span>
                <span class="text-emerald-400 font-bold">&lt; 0.0001 (Sig)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PerceptionLabComponent {
  public state = inject(HapticsStateService);

  public onContactForceChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.contactForceN.set(val);
  }

  public runPsychophysicsTrial(): void {
    this.state.playHapticFeedback();
  }

  public operatingFreqX = computed(() => {
    const f = Math.max(10, Math.min(600, this.state.activeEvent().frequency));
    const minLog = Math.log10(10);
    const maxLog = Math.log10(600);
    return ((Math.log10(f) - minLog) / (maxLog - minLog)) * 800;
  });

  public operatingFreqY = computed(() => {
    const f = this.state.activeEvent().frequency;
    // Verrillo threshold approximation
    const thDb = this.calculateVerrilloThreshold(f);
    // Map [-30dB..+50dB] to height [200..30]
    const norm = Math.max(0, Math.min(1, (thDb + 30) / 80));
    return 200 - norm * 160;
  });

  public verrilloCurvePath = computed(() => {
    const points: string[] = [];
    const minLog = Math.log10(10);
    const maxLog = Math.log10(600);

    for (let px = 0; px <= 800; px += 5) {
      const fLog = minLog + (px / 800) * (maxLog - minLog);
      const f = Math.pow(10, fLog);

      const thDb = this.calculateVerrilloThreshold(f);
      const norm = Math.max(0, Math.min(1, (thDb + 30) / 80));
      const y = 200 - norm * 160;
      points.push(`${px === 0 ? 'M' : 'L'} ${px.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  });

  public psychometricPath = computed(() => {
    // Sigmoid P(x) = 0.5 + 0.5 / (1 + exp(-k * (x - x0)))
    const points: string[] = [];
    for (let x = 0; x <= 500; x += 5) {
      const stimulus = (x / 500) * 1.0; // 0 to 1.0 G
      const p = 0.5 + 0.5 / (1 + Math.exp(-12 * (stimulus - 0.4)));
      // Map P [0.5..1.0] to SVG [90..15]
      const y = 90 - (p - 0.5) * 150;
      points.push(`${x === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  });

  private calculateVerrilloThreshold(f: number): number {
    // U-shaped absolute threshold: high at 10Hz, minimum (-20dB) at 250Hz, rising after 300Hz
    const meissner = 25 * Math.pow(Math.log10(f / 35), 2);
    const pacinian = -20 + 35 * Math.pow(Math.log10(f / 250), 2);
    return Math.min(meissner, pacinian);
  }
}
