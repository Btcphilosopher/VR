import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';
import { HapticEvent, HapticMaterialProfile } from '../../core/models/haptics.models';
import { DspEngineService } from '../../core/services/dsp-engine.service';
import { TactileAudioService } from '../../core/services/tactile-audio.service';

@Component({
  selector: 'app-library-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: 18+ Canonical Haptic Event Primitives -->
      <div class="w-full lg:w-1/2 flex flex-col gap-3">
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">library_music</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Haptic Event Library</h2>
            </div>
            <span class="font-mono text-[10px] text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
              {{ state.eventsList().length }} PRESETS
            </span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            @for (evt of state.eventsList(); track evt.id) {
              <div
                tabindex="0"
                role="button"
                (click)="onSelectEvent(evt)"
                (keydown.enter)="onSelectEvent(evt)"
                class="bg-[#0b0e14] border rounded-lg p-3 cursor-pointer transition-all flex flex-col justify-between hover:border-cyan-600 outline-none focus:border-cyan-500"
                [class.border-cyan-500]="state.activeEvent().id === evt.id"
                [class.border-slate-800]="state.activeEvent().id !== evt.id"
                [class.bg-cyan-950/20]="state.activeEvent().id === evt.id"
              >
                <div>
                  <div class="flex items-center justify-between mb-1">
                    <span class="font-mono font-bold text-slate-100">{{ evt.name }}</span>
                    <span class="font-mono text-[9px] px-1 rounded bg-slate-800 text-slate-300">{{ evt.waveform }}</span>
                  </div>
                  <p class="text-[11px] text-slate-400 leading-snug">{{ evt.metadata.intent }}</p>
                </div>

                <div class="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between font-mono text-[10px]">
                  <span class="text-cyan-300">{{ evt.frequency }} Hz</span>
                  <span class="text-amber-300">{{ evt.duration * 1000 }} ms</span>
                  <button
                    type="button"
                    (click)="playPreset($event, evt)"
                    class="px-2 py-0.5 rounded bg-cyan-900/60 hover:bg-cyan-800 text-cyan-300 border border-cyan-700/50 flex items-center gap-1"
                  >
                    <mat-icon class="text-xs">play_arrow</mat-icon>
                    <span>PLAY</span>
                  </button>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Right Column: Procedural Haptic Material Simulator -->
      <div class="w-full lg:w-1/2 flex flex-col gap-3">
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-base">texture</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Procedural Materials</h2>
            </div>
            <span class="font-mono text-[10px] text-amber-300 px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-800/40">
              MICRO-TEXTURE DSP
            </span>
          </div>

          <p class="text-slate-400 text-[11px] leading-relaxed">
            Physics-based friction modulation, surface roughness asperity impacts, and material acoustic speed of sound.
          </p>

          <!-- Material Grid -->
          <div class="grid grid-cols-2 md:grid-cols-3 gap-2">
            @for (mat of state.materialsList(); track mat.id) {
              <button
                type="button"
                (click)="onSelectMaterial(mat)"
                class="p-2.5 rounded-lg border text-left transition-all font-mono"
                [class.bg-amber-950/40]="state.activeMaterial().id === mat.id"
                [class.text-amber-300]="state.activeMaterial().id === mat.id"
                [class.border-amber-600]="state.activeMaterial().id === mat.id"
                [class.bg-[#0b0e14]]="state.activeMaterial().id !== mat.id"
                [class.text-slate-300]="state.activeMaterial().id !== mat.id"
                [class.border-slate-800]="state.activeMaterial().id !== mat.id"
              >
                <div class="font-bold text-xs truncate">{{ mat.name.split(' ')[0] }}</div>
                <div class="text-[10px] text-slate-400 mt-1">f₀: {{ mat.resonanceFreqHz }} Hz</div>
                <div class="text-[10px] text-slate-500">μ: {{ mat.frictionCoefficient }}</div>
              </button>
            }
          </div>

          <!-- Active Material Detailed Parameters -->
          <div class="bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 space-y-2 font-mono text-[11px] mt-2">
            <div class="font-bold text-slate-100 text-xs">{{ state.activeMaterial().name }}</div>
            <p class="text-slate-400 text-[10px] font-sans">{{ state.activeMaterial().description }}</p>

            <div class="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[10px]">
              <div>Stiffness: <span class="text-slate-200 font-bold">{{ state.activeMaterial().stiffnessN_m }} N/m</span></div>
              <div>Damping ζ: <span class="text-cyan-300 font-bold">{{ state.activeMaterial().dampingRatio }}</span></div>
              <div>Friction (μ): <span class="text-amber-300 font-bold">{{ state.activeMaterial().frictionCoefficient }}</span></div>
              <div>Roughness: <span class="text-emerald-400 font-bold">{{ state.activeMaterial().roughnessCoefficient }}</span></div>
            </div>

            <!-- Scrub Texture Simulator Stage -->
            <div class="pt-3 border-t border-slate-800">
              <span class="text-[10px] text-slate-400 block mb-1 font-semibold">SCRUB / SLIDE VELOCITY: {{ slidingVelocity() }} mm/s</span>
              <input
                type="range"
                min="5"
                max="150"
                step="5"
                [value]="slidingVelocity()"
                (input)="onVelocityChange($event)"
                class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />

              <button
                type="button"
                (click)="playMaterialTexture()"
                class="w-full mt-3 py-2 rounded bg-amber-900/60 hover:bg-amber-800 border border-amber-600 text-amber-200 font-mono text-xs font-bold flex items-center justify-center gap-2"
              >
                <mat-icon class="text-sm">waves</mat-icon>
                <span>SYNTHESIZE MATERIAL FRICTION</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class LibraryLabComponent {
  public state = inject(HapticsStateService);
  private dsp = inject(DspEngineService);
  private audio = inject(TactileAudioService);

  public slidingVelocity = signal<number>(45);

  public onSelectEvent(evt: HapticEvent): void {
    this.state.selectEvent(evt);
  }

  public playPreset(event: MouseEvent, evt: HapticEvent): void {
    event.stopPropagation();
    this.state.selectEvent(evt);
  }

  public onSelectMaterial(mat: HapticMaterialProfile): void {
    this.state.activeMaterial.set(mat);
    this.playMaterialTexture();
  }

  public onVelocityChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.slidingVelocity.set(val);
  }

  public playMaterialTexture(): void {
    const mat = this.state.activeMaterial();
    const vel = this.slidingVelocity();
    const sig = this.dsp.generateProceduralTexture(mat, vel, 0.25, 10000);
    this.audio.playTactileBuffer(sig.samples, sig.sampleRate, 0.85);
  }
}
