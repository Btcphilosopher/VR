import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';
import { ActuatorType } from '../../core/models/haptics.models';

@Component({
  selector: 'app-actuator-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Actuator Electromechanical Model & Mechanical Parameters -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <!-- Actuator Type & Parameters -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-base">sensors</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Actuator Model</h2>
            </div>
            <span class="font-mono text-[10px] text-amber-300 px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-800/40 font-bold">
              {{ state.activeActuator().type }}
            </span>
          </div>

          <!-- Actuator Type Selection -->
          <div>
            <span class="font-mono text-[11px] text-slate-400 block mb-1.5 font-semibold">ELECTROMECHANICAL TOPOLOGY</span>
            <div class="grid grid-cols-3 gap-1.5">
              @for (act of actuatorTypes; track act.id) {
                <button
                  type="button"
                  (click)="onActuatorTypeSelect(act.id)"
                  class="flex items-center gap-1.5 px-2 py-1.5 rounded font-mono text-[10px] font-semibold border transition-all"
                  [class.bg-amber-950]="state.activeActuator().type === act.id"
                  [class.text-amber-300]="state.activeActuator().type === act.id"
                  [class.border-amber-600]="state.activeActuator().type === act.id"
                  [class.bg-[#0b0e14]]="state.activeActuator().type !== act.id"
                  [class.text-slate-400]="state.activeActuator().type !== act.id"
                  [class.border-slate-800]="state.activeActuator().type !== act.id"
                >
                  <mat-icon class="text-xs">{{ act.icon }}</mat-icon>
                  <span>{{ act.label }}</span>
                </button>
              }
            </div>
          </div>

          <!-- Topology Specific Sliders -->
          <div class="space-y-3 pt-2">
            <!-- Actuator Gain Slider -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Actuator Gain (G):</span>
                <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.gain }}x</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="3.0"
                step="0.1"
                [value]="state.activeActuator().actuatorModel.gain"
                (input)="onGainChange($event)"
                class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <!-- Hardware Electrical Latency / Delay -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Electrical Delay (τ_e):</span>
                <span class="text-cyan-400 font-bold">{{ state.activeActuator().actuatorModel.delayMs }} ms</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="12.0"
                step="0.5"
                [value]="state.activeActuator().actuatorModel.delayMs"
                (input)="onDelayChange($event)"
                class="w-full accent-cyan-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            @if (state.activeActuator().type === 'LRA') {
              <!-- LRA Resonance f0 -->
              <div>
                <div class="flex justify-between font-mono text-[11px] mb-1">
                  <span class="text-slate-400">LRA Nominal Resonance (f₀):</span>
                  <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.lraResonantFreqHz || 175 }} Hz</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="320"
                  step="1"
                  [value]="state.activeActuator().actuatorModel.lraResonantFreqHz || 175"
                  (input)="onLraF0Change($event)"
                  class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                />
              </div>

              <!-- LRA Q Factor -->
              <div>
                <div class="flex justify-between font-mono text-[11px] mb-1">
                  <span class="text-slate-400">LRA Mechanical Q-Factor:</span>
                  <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.lraQFactor || 6.5 }}</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="20"
                  step="0.5"
                  [value]="state.activeActuator().actuatorModel.lraQFactor || 6.5"
                  (input)="onLraQChange($event)"
                  class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                />
              </div>
            }

            @if (state.activeActuator().type === 'VOICE_COIL') {
              <!-- Coil Resistance R -->
              <div>
                <div class="flex justify-between font-mono text-[11px] mb-1">
                  <span class="text-slate-400">Coil Resistance (R):</span>
                  <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.vcmResistanceOhm || 8.0 }} Ω</span>
                </div>
                <input
                  type="range"
                  min="2.0"
                  max="32.0"
                  step="0.5"
                  [value]="state.activeActuator().actuatorModel.vcmResistanceOhm || 8.0"
                  (input)="onVcmResistanceChange($event)"
                  class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                />
              </div>

              <!-- Force Constant Bl -->
              <div>
                <div class="flex justify-between font-mono text-[11px] mb-1">
                  <span class="text-slate-400">Force Constant (Bl):</span>
                  <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.vcmForceConstantBl || 1.8 }} N/A</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="5.0"
                  step="0.1"
                  [value]="state.activeActuator().actuatorModel.vcmForceConstantBl || 1.8"
                  (input)="onVcmBlChange($event)"
                  class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                />
              </div>
            }

            @if (state.activeActuator().type === 'ERM') {
              <div>
                <div class="flex justify-between font-mono text-[11px] mb-1">
                  <span class="text-slate-400">Spin-Up Time Constant (τ_spin):</span>
                  <span class="text-amber-300 font-bold">{{ state.activeActuator().actuatorModel.ermStartupTimeMs || 35 }} ms</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  step="2"
                  [value]="state.activeActuator().actuatorModel.ermStartupTimeMs || 35"
                  (input)="onErmStartupChange($event)"
                  class="w-full accent-amber-400 bg-slate-800 h-1.5 rounded cursor-pointer"
                />
              </div>
            }
          </div>
        </div>

        <!-- 1-DOF Mechanical ODE Mass-Spring-Damper (m*x'' + c*x' + k*x = F) -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-base">motion_photos_on</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Mechanical System</h2>
            </div>
            <span class="font-mono text-[10px] text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950/60 border border-emerald-800/40">
              RK4 ODE SOLVER
            </span>
          </div>

          <div class="space-y-3">
            <!-- Effective Mass m -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Effective Mass (m):</span>
                <span class="text-emerald-400 font-bold">{{ state.deviceTwin().vibration1DOF.mass * 1000 | number:'1.1-1' }} g</span>
              </div>
              <input
                type="range"
                min="5"
                max="80"
                step="1"
                [value]="state.deviceTwin().vibration1DOF.mass * 1000"
                (input)="onMassChange($event)"
                class="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <!-- Suspension Stiffness k -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Stiffness (k):</span>
                <span class="text-emerald-400 font-bold">{{ state.deviceTwin().vibration1DOF.stiffness | number:'1.0-0' }} N/m</span>
              </div>
              <input
                type="range"
                min="5000"
                max="90000"
                step="1000"
                [value]="state.deviceTwin().vibration1DOF.stiffness"
                (input)="onStiffnessChange($event)"
                class="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>

            <!-- Viscous Damping c -->
            <div>
              <div class="flex justify-between font-mono text-[11px] mb-1">
                <span class="text-slate-400">Viscous Damping (c):</span>
                <span class="text-emerald-400 font-bold">{{ state.deviceTwin().vibration1DOF.damping | number:'1.3-3' }} N·s/m</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="2.5"
                step="0.02"
                [value]="state.deviceTwin().vibration1DOF.damping"
                (input)="onDampingChange($event)"
                class="w-full accent-emerald-400 bg-slate-800 h-1.5 rounded cursor-pointer"
              />
            </div>
          </div>

          <!-- Derived Physics Telemetry -->
          <div class="mt-2 pt-2 border-t border-slate-800/80 font-mono text-[11px] space-y-1 bg-[#0b0e14] p-2 rounded">
            <div class="flex justify-between">
              <span class="text-slate-400">Natural Resonance (f_n):</span>
              <span class="text-amber-300 font-bold">{{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Damping Ratio (ζ):</span>
              <span class="text-cyan-300 font-bold">{{ state.deviceTwin().vibration1DOF.dampingRatio }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Q-Factor:</span>
              <span class="text-slate-200 font-bold">{{ state.deviceTwin().vibration1DOF.qFactor }}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Right Column: State-Space Mechanical Response x(t), v(t), a(t) & Bode Frequency Response -->
      <div class="flex-1 flex flex-col gap-4">
        <!-- Mechanical Response Tri-Scope -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col flex-1 min-h-[360px]">
          <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
            <div class="flex items-center gap-3">
              <span class="font-mono font-bold text-sm text-slate-100">NUMERICAL STATE-SPACE RESPONSE</span>
              <div class="flex items-center gap-3 font-mono text-[11px]">
                <span class="text-cyan-400">&bull; Disp x(t) [mm]</span>
                <span class="text-amber-400">&bull; Velocity v(t) [m/s]</span>
                <span class="text-emerald-400 font-bold">&bull; Accel a(t) [G]</span>
              </div>
            </div>
            <span class="font-mono text-[10px] text-slate-400">t = {{ state.activeEvent().duration * 1000 | number:'1.0-0' }} ms</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 relative flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 800 320" preserveAspectRatio="none">
              <!-- Grid -->
              @for (y of [40, 100, 160, 220, 280]; track y) {
                <line x1="0" [attr.y1]="y" x2="800" [attr.y2]="y" stroke="#1e293b" stroke-width="1" stroke-dasharray="4" />
              }
              @for (x of [100, 200, 300, 400, 500, 600, 700]; track x) {
                <line [attr.x1]="x" y1="0" [attr.x2]="x" y2="320" stroke="#172033" stroke-width="1" />
              }

              <!-- Displacement Path (Cyan) -->
              <path [attr.d]="dispPath()" fill="none" stroke="#22d3ee" stroke-width="1.8" stroke-dasharray="2,2" />
              <!-- Velocity Path (Amber) -->
              <path [attr.d]="velPath()" fill="none" stroke="#fbbf24" stroke-width="1.5" />
              <!-- Acceleration Path (Emerald) -->
              <path [attr.d]="accPath()" fill="none" stroke="#34d399" stroke-width="2.2" stroke-linecap="round" />
            </svg>

            <div class="absolute bottom-3 right-4 font-mono text-[11px] bg-[#121622]/90 border border-slate-800 p-2 rounded space-y-0.5 text-right">
              <div class="text-emerald-400 font-bold">Peak Accel: {{ state.mechSimulation().peakAccelerationG }} G</div>
              <div class="text-cyan-400">Peak Disp: {{ state.mechSimulation().peakDisplacementMm }} mm</div>
              <div class="text-amber-400">Settling Time: {{ state.mechSimulation().settlingTimeMs }} ms</div>
            </div>
          </div>
        </div>

        <!-- Frequency Domain Bode Plot -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col">
          <div class="flex items-center justify-between mb-2">
            <span class="font-mono font-bold text-xs text-slate-200">SYSTEM BODE FREQUENCY RESPONSE |H(jω)|</span>
            <span class="font-mono text-[10px] text-amber-300">Mechanical Resonance Mode Peak at {{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz</span>
          </div>

          <div class="bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2.5 h-36 relative flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 800 120" preserveAspectRatio="none">
              <!-- Bode Magnitude Curve -->
              <path [attr.d]="bodeMagnitudePath()" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" />
              <!-- Natural Frequency Marker -->
              <line [attr.x1]="bodeResonanceX()" y1="0" [attr.x2]="bodeResonanceX()" y2="120" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="3,3" />
            </svg>
            <div class="absolute top-2 left-3 font-mono text-[10px] text-slate-500">10 Hz</div>
            <div class="absolute top-2 right-3 font-mono text-[10px] text-slate-500">1000 Hz</div>
            <div class="absolute bottom-1 [left:calc(50%-40px)] font-mono text-[10px] text-red-400 font-bold">
              f_n = {{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ActuatorLabComponent {
  public state = inject(HapticsStateService);

  public actuatorTypes: { id: ActuatorType; label: string; icon: string }[] = [
    { id: 'LRA', label: 'LRA', icon: 'vibration' },
    { id: 'VOICE_COIL', label: 'VCM', icon: 'volume_up' },
    { id: 'ERM', label: 'ERM', icon: 'sync' },
    { id: 'PIEZO', label: 'PIEZO', icon: 'bolt' },
    { id: 'ULTRASONIC', label: 'ULTRASONIC', icon: 'grain' },
    { id: 'CUSTOM_TF', label: 'CUSTOM', icon: 'tune' },
  ];

  public onActuatorTypeSelect(type: ActuatorType): void {
    this.state.updateActiveActuatorModel({ type });
    this.state.activeActuator.update((curr) => ({ ...curr, type }));
    this.state.playHapticFeedback();
  }

  public onGainChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ gain: val });
  }

  public onDelayChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ delayMs: val });
  }

  public onLraF0Change(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ lraResonantFreqHz: val });
  }

  public onLraQChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ lraQFactor: val });
  }

  public onVcmResistanceChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ vcmResistanceOhm: val });
  }

  public onVcmBlChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ vcmForceConstantBl: val });
  }

  public onErmStartupChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveActuatorModel({ ermStartupTimeMs: val });
  }

  public onMassChange(event: Event): void {
    const valG = Number((event.target as HTMLInputElement).value);
    this.state.updateVibration1DOF({ mass: valG / 1000 });
  }

  public onStiffnessChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateVibration1DOF({ stiffness: val });
  }

  public onDampingChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateVibration1DOF({ damping: val });
  }

  public dispPath = computed(() => {
    const samples = this.state.mechSimulation().displacement;
    const maxVal = Math.max(0.01, this.state.mechSimulation().peakDisplacementMm);
    return this.buildSvgPath(samples, 800, 320, maxVal);
  });

  public velPath = computed(() => {
    const samples = this.state.mechSimulation().velocity;
    const maxVal = Math.max(0.01, this.state.mechSimulation().peakVelocityMps);
    return this.buildSvgPath(samples, 800, 320, maxVal);
  });

  public accPath = computed(() => {
    const samples = this.state.mechSimulation().acceleration;
    const maxVal = Math.max(0.1, this.state.mechSimulation().peakAccelerationG);
    return this.buildSvgPath(samples, 800, 320, maxVal);
  });

  public bodeResonanceX = computed(() => {
    const fn = this.state.deviceTwin().vibration1DOF.naturalFreqHz;
    // Log scale from 10Hz to 1000Hz across 800px width
    const minLog = Math.log10(10);
    const maxLog = Math.log10(1000);
    const fnLog = Math.log10(Math.max(10, Math.min(1000, fn)));
    return ((fnLog - minLog) / (maxLog - minLog)) * 800;
  });

  public bodeMagnitudePath = computed(() => {
    const fn = this.state.deviceTwin().vibration1DOF.naturalFreqHz;
    const zeta = this.state.deviceTwin().vibration1DOF.dampingRatio;
    const points: string[] = [];

    const minLog = Math.log10(10);
    const maxLog = Math.log10(1000);

    for (let px = 0; px <= 800; px += 4) {
      const fLog = minLog + (px / 800) * (maxLog - minLog);
      const f = Math.pow(10, fLog);

      const r = f / fn;
      // 2nd Order Transfer Function |H(r)| = 1 / sqrt((1 - r^2)^2 + (2*zeta*r)^2)
      const mag = 1 / Math.sqrt(Math.pow(1 - r * r, 2) + Math.pow(2 * zeta * r, 2));
      const db = 20 * Math.log10(Math.max(1e-4, mag));

      // Map dB [-30dB .. +24dB] to SVG height [120 .. 10]
      const normY = Math.max(0, Math.min(1, (db + 30) / 54));
      const y = 110 - normY * 100;
      points.push(`${px === 0 ? 'M' : 'L'} ${px.toFixed(1)} ${y.toFixed(1)}`);
    }

    return points.join(' ');
  });

  private buildSvgPath(samples: number[], width: number, height: number, scaleMax: number): string {
    if (!samples || samples.length === 0) return 'M 0 160';
    const n = samples.length;
    const step = Math.max(1, Math.floor(n / width));
    const points: string[] = [];

    const midY = height / 2;
    for (let i = 0; i < n; i += step) {
      const x = (i / (n - 1 || 1)) * width;
      const normalized = samples[i] / (scaleMax || 1);
      const y = midY - normalized * (midY * 0.85);
      points.push(`${points.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  }
}
