import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-r-console-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Toolbar & Export Actions -->
      <div class="bg-[#121622] border border-slate-800 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-400 text-base">code</mat-icon>
            <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">R 4.3 Simulation Script &amp; Artifacts</h2>
          </div>

          <!-- View Mode Toggle -->
          <div class="flex items-center bg-[#0b0e14] border border-slate-800 rounded p-0.5">
            <button
              type="button"
              (click)="activeTab.set('R_SCRIPT')"
              class="px-2.5 py-1 rounded font-mono text-[11px] font-semibold transition-all"
              [class.bg-blue-950]="activeTab() === 'R_SCRIPT'"
              [class.text-blue-300]="activeTab() === 'R_SCRIPT'"
              [class.text-slate-400]="activeTab() !== 'R_SCRIPT'"
            >
              R SCRIPT (.R)
            </button>
            <button
              type="button"
              (click)="activeTab.set('HAPTIC_JSON')"
              class="px-2.5 py-1 rounded font-mono text-[11px] font-semibold transition-all"
              [class.bg-blue-950]="activeTab() === 'HAPTIC_JSON'"
              [class.text-blue-300]="activeTab() === 'HAPTIC_JSON'"
              [class.text-slate-400]="activeTab() !== 'HAPTIC_JSON'"
            >
              HAPTIC DEFINITION (.haptic)
            </button>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="copyCurrentCode()"
            class="px-3 py-1.5 rounded bg-[#0b0e14] hover:bg-slate-800 border border-slate-700 text-slate-200 font-mono text-[11px] flex items-center gap-1.5"
          >
            <mat-icon class="text-xs">{{ copyFeedback() ? 'check' : 'content_copy' }}</mat-icon>
            <span>{{ copyFeedback() ? 'COPIED TO CLIPBOARD' : 'COPY CODE' }}</span>
          </button>

          <button
            type="button"
            (click)="downloadArtifact()"
            class="px-3 py-1.5 rounded bg-blue-900/80 hover:bg-blue-800 border border-blue-600 text-blue-200 font-mono text-[11px] font-bold flex items-center gap-1.5"
          >
            <mat-icon class="text-xs">download</mat-icon>
            <span>DOWNLOAD ARTIFACT</span>
          </button>
        </div>
      </div>

      <!-- Code Console Editor Display -->
      <div class="flex-1 bg-[#10141d] border border-slate-800 rounded-xl p-4 font-mono text-xs overflow-auto flex flex-col">
        @if (activeTab() === 'R_SCRIPT') {
          <pre class="text-slate-300 leading-relaxed selection:bg-blue-900 select-text font-mono"><code>{{ state.rScriptCode() }}</code></pre>
        } @else {
          <pre class="text-emerald-300 leading-relaxed selection:bg-emerald-950 select-text font-mono"><code>{{ state.hapticScoreJson() | json }}</code></pre>
        }
      </div>
    </div>
  `,
})
export class RConsoleLabComponent {
  public state = inject(HapticsStateService);
  public activeTab = signal<'R_SCRIPT' | 'HAPTIC_JSON'>('R_SCRIPT');
  public copyFeedback = signal<boolean>(false);

  public copyCurrentCode(): void {
    const text =
      this.activeTab() === 'R_SCRIPT'
        ? this.state.rScriptCode()
        : JSON.stringify(this.state.hapticScoreJson(), null, 2);

    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => {
        this.copyFeedback.set(true);
        setTimeout(() => this.copyFeedback.set(false), 2000);
      });
    }
  }

  public downloadArtifact(): void {
    if (typeof window === 'undefined') return;
    const isR = this.activeTab() === 'R_SCRIPT';
    const text = isR
      ? this.state.rScriptCode()
      : JSON.stringify(this.state.hapticScoreJson(), null, 2);
    const filename = isR
      ? `haptics_simulation_${this.state.activeEvent().id.toLowerCase()}.R`
      : `${this.state.activeEvent().id.toLowerCase()}.haptic`;

    const blob = new Blob([text], { type: isR ? 'text/plain' : 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }
}
