import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-pipeline-view',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col p-4 gap-4 overflow-y-auto bg-[#0b0e14] text-slate-200">
      <!-- Pipeline Hero Overview Banner -->
      <div class="bg-[#121622] border border-slate-800/80 rounded-xl p-4 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shadow-lg">
        <div>
          <div class="flex items-center gap-2 mb-1">
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950 text-cyan-400 border border-cyan-800/50">SYSTEM PIPELINE</span>
            <span class="text-xs font-mono text-slate-400">STAGE 1 → STAGE 10 CLOSED-LOOP EXECUTION</span>
          </div>
          <h1 class="text-lg font-bold text-slate-100 tracking-tight font-sans">
            {{ state.activeEvent().name }} &mdash; <span class="text-cyan-400 font-mono text-base font-normal">Physical Signal &amp; Sensation Pipeline</span>
          </h1>
          <p class="text-xs text-slate-400 mt-1 max-w-3xl">
            Complete continuous chain from cognitive tactile intent to signal synthesis, electromechanical actuator transduction, structural modal response, somatosensory receptor excitation, and R statistical verification.
          </p>
        </div>

        <div class="flex items-center gap-3">
          <button
            type="button"
            (click)="state.optimizeHapticParameters()"
            class="flex items-center gap-1.5 px-3 py-2 rounded bg-amber-950/60 hover:bg-amber-900/80 border border-amber-700/60 text-amber-300 font-mono text-xs font-semibold transition-all shadow-sm"
          >
            <mat-icon class="text-sm">auto_fix_high</mat-icon>
            <span>RESONANCE AUTO-MATCH</span>
          </button>

          <button
            type="button"
            (click)="state.playHapticFeedback()"
            class="flex items-center gap-2 px-4 py-2 rounded bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-mono font-bold text-xs shadow-md shadow-cyan-500/25 transition-all"
          >
            <mat-icon class="text-base">touch_app</mat-icon>
            <span>TEST SENSATION</span>
          </button>
        </div>
      </div>

      <!-- 10-Step Interactive Pipeline Flow Graph -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-3.5">

        <!-- Stage 1: Tactile Intent -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-slate-700 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">01 // INTENT</span>
            <mat-icon class="text-slate-500 text-sm">psychology</mat-icon>
          </div>
          <div>
            <div class="font-mono text-xs font-bold text-slate-100 mb-1">{{ state.activeEvent().type }}</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">{{ state.activeEvent().metadata.intent }}</p>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>TARGET:</span>
            <span class="text-amber-300">{{ state.activeEvent().metadata.targetFeeling }}</span>
          </div>
        </div>

        <!-- Stage 2: Haptic Event Primitive -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-cyan-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">02 // EVENT</span>
            <mat-icon class="text-slate-500 text-sm">tune</mat-icon>
          </div>
          <div class="space-y-1 text-xs">
            <div class="flex justify-between font-mono">
              <span class="text-slate-400">Duration:</span>
              <span class="text-slate-100 font-semibold">{{ state.activeEvent().duration * 1000 }} ms</span>
            </div>
            <div class="flex justify-between font-mono">
              <span class="text-slate-400">Frequency:</span>
              <span class="text-cyan-300 font-semibold">{{ state.activeEvent().frequency }} Hz</span>
            </div>
            <div class="flex justify-between font-mono">
              <span class="text-slate-400">Waveform:</span>
              <span class="text-amber-300 font-semibold">{{ state.activeEvent().waveform }}</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>PROVENANCE:</span>
            <span class="text-emerald-400 font-semibold">{{ state.activeEvent().metadata.provenance }}</span>
          </div>
        </div>

        <!-- Stage 3: DSP Signal Synthesis -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-cyan-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">03 // SIGNAL DSP</span>
            <mat-icon class="text-slate-500 text-sm">show_chart</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">RMS Value:</span>
              <span class="text-slate-100 font-semibold">{{ state.generatedSignal().metrics.rms }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Crest Factor:</span>
              <span class="text-cyan-300 font-semibold">{{ state.generatedSignal().metrics.crestFactor }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">ZCR Rate:</span>
              <span class="text-slate-300 font-semibold">{{ state.generatedSignal().metrics.zeroCrossingRate }}/s</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>SAMPLING:</span>
            <span class="text-slate-300">10.0 kHz (0.1ms)</span>
          </div>
        </div>

        <!-- Stage 4: Actuator Transduction -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-cyan-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">04 // ACTUATOR</span>
            <mat-icon class="text-slate-500 text-sm">sensors</mat-icon>
          </div>
          <div class="space-y-1 text-xs">
            <div class="font-mono text-slate-100 font-semibold truncate">{{ state.activeActuator().name }}</div>
            <div class="flex justify-between font-mono text-[11px]">
              <span class="text-slate-400">Type:</span>
              <span class="text-amber-300 font-bold">{{ state.activeActuator().type }}</span>
            </div>
            <div class="flex justify-between font-mono text-[11px]">
              <span class="text-slate-400">Delay:</span>
              <span class="text-cyan-300 font-semibold">{{ state.activeActuator().actuatorModel.delayMs }} ms</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>RATED V:</span>
            <span class="text-slate-300">{{ state.activeActuator().actuatorModel.ratedVoltage || 3.3 }} V</span>
          </div>
        </div>

        <!-- Stage 5: Mechanical ODE Simulation -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-emerald-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-emerald-400 font-semibold">05 // MECHANICAL ODE</span>
            <mat-icon class="text-slate-500 text-sm">motion_photos_on</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">Peak Accel:</span>
              <span class="text-emerald-400 font-bold">{{ state.mechSimulation().peakAccelerationG }} G</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Disp (x):</span>
              <span class="text-slate-200 font-semibold">{{ state.mechSimulation().peakDisplacementMm }} mm</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Settling:</span>
              <span class="text-amber-300 font-semibold">{{ state.mechSimulation().settlingTimeMs }} ms</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>ENERGY:</span>
            <span class="text-slate-300">{{ state.mechSimulation().energyJoules * 1000 | number:'1.2-2' }} mJ</span>
          </div>
        </div>

        <!-- Stage 6: Digital Twin Spatial Core -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-slate-700 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">06 // DIGITAL TWIN</span>
            <mat-icon class="text-slate-500 text-sm">view_in_ar</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="text-slate-200 font-bold">{{ state.deviceTwin().id }}</div>
            <div class="text-[11px] text-slate-400">{{ state.deviceTwin().dimensionsMm.join(' x ') }} mm</div>
            <div class="text-[11px] text-slate-400">Mass: {{ state.deviceTwin().totalMassG }} g</div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>ACTUATORS:</span>
            <span class="text-cyan-300 font-bold">{{ state.deviceTwin().actuators.length }} Linked</span>
          </div>
        </div>

        <!-- Stage 7: Sensor Data Capture -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-slate-700 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-cyan-400 font-semibold">07 // SENSOR ARRAY</span>
            <mat-icon class="text-slate-500 text-sm">track_changes</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">Active Sensors:</span>
              <span class="text-slate-200 font-semibold">4 Channels</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Primary:</span>
              <span class="text-cyan-300 font-semibold">MEMS Accel</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Bandwidth:</span>
              <span class="text-slate-300 font-semibold">10.0 kHz</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>SNR:</span>
            <span class="text-emerald-400 font-bold">{{ state.generatedSignal().metrics.snrDb }} dB</span>
          </div>
        </div>

        <!-- Stage 8: Perception Model -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-indigo-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-indigo-400 font-semibold">08 // PERCEPTION</span>
            <mat-icon class="text-slate-500 text-sm">fingerprint</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">Pacinian (FA II):</span>
              <span class="text-indigo-300 font-bold">{{ state.perceptualScore().pacinianResponse }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Meissner (FA I):</span>
              <span class="text-blue-300 font-bold">{{ state.perceptualScore().meissnerResponse }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Perceived dB:</span>
              <span class="text-emerald-400 font-bold">{{ state.perceptualScore().perceivedIntensityDb }} dB</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>QUALITY SCORE:</span>
            <span class="text-cyan-300 font-extrabold text-xs">{{ state.perceptualScore().compositeQualityScore }} / 100</span>
          </div>
        </div>

        <!-- Stage 9: R Statistical Analysis -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-blue-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-blue-400 font-semibold">09 // R STATS</span>
            <mat-icon class="text-slate-500 text-sm">analytics</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">Dom. Peak:</span>
              <span class="text-amber-300 font-bold">{{ state.fftAnalysis().dominantPeakHz }} Hz</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Resonances:</span>
              <span class="text-slate-200 font-semibold">{{ state.fftAnalysis().resonances.length }} Modes</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Engine:</span>
              <span class="text-blue-400 font-semibold">R 4.3 pracma</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>DT OBJECTS:</span>
            <span class="text-slate-300">data.table [{{ state.generatedSignal().samples.length }}x5]</span>
          </div>
        </div>

        <!-- Stage 10: Multi-Objective Optimisation -->
        <div class="bg-[#121622] border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between relative group hover:border-amber-800/50 transition-all">
          <div class="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span class="font-mono text-[10px] text-amber-400 font-semibold">10 // OPTIMISATION</span>
            <mat-icon class="text-slate-500 text-sm">auto_awesome</mat-icon>
          </div>
          <div class="space-y-1 text-xs font-mono">
            <div class="flex justify-between">
              <span class="text-slate-400">Yield Yield%:</span>
              <span class="text-emerald-400 font-bold">{{ state.monteCarloSummary()?.yieldPct || 94.2 }}%</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Mean f0:</span>
              <span class="text-slate-200 font-semibold">{{ state.monteCarloSummary()?.meanResonantFreqHz || 174.8 }} Hz</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Worst Accel:</span>
              <span class="text-amber-300 font-semibold">{{ state.monteCarloSummary()?.worstCaseAccG || 1.45 }} G</span>
            </div>
          </div>
          <div class="mt-3 pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400 flex justify-between">
            <span>SENSITIVITY:</span>
            <span class="text-red-400 font-semibold">k (Stiffness)</span>
          </div>
        </div>
      </div>

      <!-- Comparative Real-Time Oscilloscope: Input Voltage vs Actuator Force vs Acceleration Response -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1 min-h-[300px]">
        <!-- Graph 1: Drive Voltage & Envelope u(t) -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded bg-cyan-400"></span>
              <span class="font-mono text-xs font-bold text-slate-200">INPUT DRIVE SIGNAL u(t)</span>
            </div>
            <span class="font-mono text-[10px] text-cyan-400">VOLTAGE [-1.0 .. +1.0]</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2 relative overflow-hidden flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-width="1" stroke-dasharray="4" />
              <line x1="0" y1="50" x2="500" y2="50" stroke="#172033" stroke-width="1" />
              <line x1="0" y1="150" x2="500" y2="150" stroke="#172033" stroke-width="1" />
              <line x1="250" y1="0" x2="250" y2="200" stroke="#172033" stroke-width="1" />

              <!-- Drive Signal Polyline -->
              <path [attr.d]="driveSignalPath()" fill="none" stroke="#22d3ee" stroke-width="2" stroke-linecap="round" />
            </svg>
            <div class="absolute bottom-2 left-3 font-mono text-[10px] text-slate-500">t = 0 ms</div>
            <div class="absolute bottom-2 right-3 font-mono text-[10px] text-slate-500">t = {{ state.activeEvent().duration * 1000 }} ms</div>
          </div>
        </div>

        <!-- Graph 2: Actuator Electromechanical Force F_act(t) -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded bg-amber-400"></span>
              <span class="font-mono text-xs font-bold text-slate-200">ACTUATOR FORCE F(t)</span>
            </div>
            <span class="font-mono text-[10px] text-amber-400">{{ state.activeActuator().type }} TRANSDUCER [N]</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2 relative overflow-hidden flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-width="1" stroke-dasharray="4" />
              <line x1="0" y1="50" x2="500" y2="50" stroke="#172033" stroke-width="1" />
              <line x1="0" y1="150" x2="500" y2="150" stroke="#172033" stroke-width="1" />

              <!-- Actuator Force Polyline -->
              <path [attr.d]="actuatorForcePath()" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" />
            </svg>
            <div class="absolute top-2 right-3 font-mono text-[10px] text-amber-300">Peak Force: ~2.4 N</div>
          </div>
        </div>

        <!-- Graph 3: Surface Mechanical Acceleration a(t) -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col">
          <div class="flex items-center justify-between mb-2">
            <div class="flex items-center gap-2">
              <span class="w-2.5 h-2.5 rounded bg-emerald-400"></span>
              <span class="font-mono text-xs font-bold text-slate-200">MECHANICAL ACCELERATION a(t)</span>
            </div>
            <span class="font-mono text-[10px] text-emerald-400">SURFACE RESPONSE [G]</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-2 relative overflow-hidden flex items-center justify-center">
            <svg class="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
              <!-- Grid lines -->
              <line x1="0" y1="100" x2="500" y2="100" stroke="#1e293b" stroke-width="1" stroke-dasharray="4" />
              <line x1="0" y1="50" x2="500" y2="50" stroke="#172033" stroke-width="1" />
              <line x1="0" y1="150" x2="500" y2="150" stroke="#172033" stroke-width="1" />

              <!-- Acceleration Polyline -->
              <path [attr.d]="accelerationPath()" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" />
            </svg>
            <div class="absolute top-2 right-3 font-mono text-[10px] text-emerald-400 font-bold">
              {{ state.mechSimulation().peakAccelerationG }} G Peak
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class PipelineViewComponent {
  public state = inject(HapticsStateService);

  public driveSignalPath = computed(() => {
    const samples = this.state.generatedSignal().samples;
    return this.buildSvgPath(samples, 500, 200, 1.0);
  });

  public actuatorForcePath = computed(() => {
    const samples = this.state.actuatorForce();
    const maxVal = Math.max(0.1, ...samples.map((s) => Math.abs(s)));
    return this.buildSvgPath(samples, 500, 200, maxVal);
  });

  public accelerationPath = computed(() => {
    const samples = this.state.mechSimulation().acceleration;
    const maxVal = Math.max(0.1, this.state.mechSimulation().peakAccelerationG);
    return this.buildSvgPath(samples, 500, 200, maxVal);
  });

  private buildSvgPath(samples: number[], width: number, height: number, scaleMax: number): string {
    if (!samples || samples.length === 0) return 'M 0 100';
    const n = samples.length;
    const step = Math.max(1, Math.floor(n / width));
    const points: string[] = [];

    const midY = height / 2;
    for (let i = 0; i < n; i += step) {
      const x = (i / (n - 1 || 1)) * width;
      const normalized = samples[i] / (scaleMax || 1);
      const y = midY - normalized * (midY * 0.85);
      points.push(`${points.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  }
}
