import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';
import { SimulationFidelity } from '../../core/models/haptics.models';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-12 bg-[#141414] border-b border-[#2D2D2D] px-4 flex items-center justify-between select-none text-xs">
      <!-- Brand & Status Group -->
      <div class="flex items-center gap-6">
        <div class="flex items-center gap-3">
          <span class="font-black tracking-tighter text-lg text-white font-mono">HAPTICS.OS</span>
          <span class="text-[9px] font-mono text-[#F27D26] uppercase font-bold tracking-widest px-1.5 py-0.5 bg-[#F27D26]/10 border border-[#F27D26]/20 rounded-sm">
            v3.7.0
          </span>
        </div>

        <!-- Telemetry Status Pills -->
        <div class="hidden lg:flex items-center gap-3 font-mono text-[10px]">
          <div class="flex items-center gap-2 bg-[#00FF41]/10 px-2 py-1 border border-[#00FF41]/20 rounded-sm">
            <div class="w-1.5 h-1.5 rounded-full bg-[#00FF41]"></div>
            <span class="text-[#00FF41] uppercase font-semibold">Hardware: {{ state.deviceTwin().id }}</span>
          </div>

          <div class="hidden xl:flex items-center gap-1.5 px-2 py-1 rounded-sm bg-[#0F0F0F] border border-[#2D2D2D] text-[#8E9299]">
            <span class="opacity-50">Resonance:</span>
            <span class="text-[#E4E3E0] font-bold">{{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz</span>
          </div>

          <div class="hidden xl:flex items-center gap-1.5 px-2 py-1 rounded-sm bg-[#0F0F0F] border border-[#2D2D2D] text-[#8E9299]">
            <span class="opacity-50">Latency:</span>
            <span class="text-[#00FF41] font-bold">{{ state.activeActuator().actuatorModel.delayMs }} ms</span>
          </div>
        </div>
      </div>

      <!-- Action Controls -->
      <div class="flex items-center gap-3">
        <!-- Fidelity Selector -->
        <div class="flex items-center bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm px-2 py-1">
          <span class="text-[9px] font-mono uppercase tracking-widest text-[#8E9299] mr-1.5">Fidelity:</span>
          <select
            class="bg-transparent text-[#F27D26] font-mono text-[10px] font-bold uppercase tracking-wider focus:outline-none cursor-pointer pr-1"
            [value]="state.simulationFidelity()"
            (change)="onFidelityChange($event)"
          >
            <option value="CONCEPT" class="bg-[#141414] text-[#E4E3E0]">CONCEPT (Ideal Math)</option>
            <option value="ENGINEERING" class="bg-[#141414] text-[#E4E3E0]">ENGINEERING (ODE Physics)</option>
            <option value="CALIBRATED" class="bg-[#141414] text-[#E4E3E0]">CALIBRATED (HW Matched)</option>
            <option value="EXPERIMENTAL" class="bg-[#141414] text-[#E4E3E0]">EXPERIMENTAL (Sensor Data)</option>
            <option value="MONTE_CARLO" class="bg-[#141414] text-[#E4E3E0]">MONTE CARLO (Yield Batch)</option>
          </select>
        </div>

        <!-- Audio Mute Toggle -->
        <button
          type="button"
          (click)="state.toggleAudio()"
          class="flex items-center gap-1 px-2.5 py-1 rounded-sm font-mono text-[10px] uppercase tracking-wider font-bold transition-colors border"
          [class.bg-[#0F0F0F]]="state.audioMuted()"
          [class.text-[#8E9299]]="state.audioMuted()"
          [class.border-[#2D2D2D]]="state.audioMuted()"
          [class.bg-[#1A1A1A]]="!state.audioMuted()"
          [class.text-[#00FF41]]="!state.audioMuted()"
          [class.border-[#00FF41]/40]="!state.audioMuted()"
          title="Toggle Acoustic Tactile Audio Synthesizer"
        >
          <mat-icon class="text-xs">{{ state.audioMuted() ? 'volume_off' : 'volume_up' }}</mat-icon>
          <span class="hidden sm:inline">{{ state.audioMuted() ? 'MUTED' : 'LIVE AUDIO' }}</span>
        </button>

        <!-- Primary Tactile Playback Trigger -->
        <button
          type="button"
          (click)="state.playHapticFeedback()"
          class="flex items-center gap-1.5 px-3 py-1 rounded-sm bg-[#F27D26] hover:bg-[#ff8f3d] text-black font-mono font-black text-[10px] uppercase tracking-widest shadow-sm transition-all active:scale-95 cursor-pointer"
        >
          <mat-icon class="text-xs text-black font-black">play_arrow</mat-icon>
          <span>TRIGGER FEELING</span>
        </button>
      </div>
    </header>
  `,
})
export class HeaderComponent {
  public state = inject(HapticsStateService);

  public onFidelityChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as SimulationFidelity;
    this.state.simulationFidelity.set(val);
  }
}
