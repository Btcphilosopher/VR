import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-optimisation-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Monte Carlo Controls & Statistical Summary -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <!-- Monte Carlo Batch Config -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-base">casino</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Monte Carlo Simulation</h2>
            </div>
            <span class="font-mono text-[10px] text-amber-300 px-1.5 py-0.5 rounded bg-amber-950/60 border border-amber-800/40 font-bold">
              TOLERANCE BATCH
            </span>
          </div>

          <p class="text-slate-400 text-[11px] leading-relaxed">
            Simulate virtual production batch with statistical Gaussian perturbations across chassis mass, spring stiffness, viscous damping, and actuator magnetic flux.
          </p>

          <!-- Run Batch Button -->
          <button
            type="button"
            (click)="runBatch(500)"
            [disabled]="state.isRunningMonteCarlo()"
            class="w-full py-2.5 rounded bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-white font-mono font-bold text-xs shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            <mat-icon class="text-base">{{ state.isRunningMonteCarlo() ? 'hourglass_top' : 'refresh' }}</mat-icon>
            <span>{{ state.isRunningMonteCarlo() ? 'COMPUTING N=500 RUNS...' : 'EXECUTE N=500 BATCH' }}</span>
          </button>

          <!-- Statistical Metrics Grid -->
          @if (state.monteCarloSummary(); as mc) {
            <div class="space-y-2 pt-2 border-t border-slate-800 font-mono text-[11px]">
              <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 flex justify-between items-center">
                <span class="text-slate-400">Production Yield Rate:</span>
                <span class="text-emerald-400 font-extrabold text-sm">{{ mc.yieldPct }}%</span>
              </div>
              <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 flex justify-between items-center">
                <span class="text-slate-400">Mean Resonance f₀:</span>
                <span class="text-slate-200 font-bold">{{ mc.meanResonantFreqHz }} ± {{ mc.stdResonantFreqHz }} Hz</span>
              </div>
              <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 flex justify-between items-center">
                <span class="text-slate-400">Mean Peak Accel:</span>
                <span class="text-cyan-300 font-bold">{{ mc.meanPeakAccG }} ± {{ mc.stdPeakAccG }} G</span>
              </div>
              <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2.5 flex justify-between items-center">
                <span class="text-slate-400">Worst Case Accel:</span>
                <span class="text-amber-300 font-bold">{{ mc.worstCaseAccG }} G</span>
              </div>
            </div>
          }
        </div>

        <!-- Sensitivity Analysis Jacobian Matrix -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-2.5 font-mono text-[11px]">
          <span class="font-bold text-slate-200 uppercase">Parameter Sensitivity (∂R / ∂θ)</span>
          <div class="space-y-2">
            @for (item of state.monteCarloSummary()?.sensitivityRankings; track item.parameter) {
              <div>
                <div class="flex justify-between text-[10px] mb-0.5">
                  <span class="text-slate-300">{{ item.parameter }}</span>
                  <span class="text-amber-400 font-bold">{{ item.sensitivity * 100 | number:'1.0-0' }}%</span>
                </div>
                <div class="w-full bg-[#0b0e14] h-1.5 rounded overflow-hidden">
                  <div class="bg-amber-500 h-full rounded" [style.width.%]="item.sensitivity * 100"></div>
                </div>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Right Column: Histograms & Pareto Multi-Objective Optimization Space -->
      <div class="flex-1 flex flex-col gap-4">
        <!-- Distribution Histogram: Resonant Frequency Variance -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col flex-1 min-h-[260px]">
          <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
            <span class="font-mono font-bold text-xs text-slate-100 uppercase">RESONANT FREQUENCY HISTOGRAM DISTRIBUTION (Hz)</span>
            <span class="font-mono text-[10px] text-amber-300 font-semibold">Nominal f_n: {{ state.deviceTwin().vibration1DOF.naturalFreqHz }} Hz</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 flex items-end gap-1 overflow-hidden relative">
            @for (bin of state.monteCarloSummary()?.distributionFr; track bin.bin) {
              <div class="flex-1 flex flex-col items-center h-full justify-end group">
                <div
                  class="w-full bg-gradient-to-t from-amber-600 to-amber-400 rounded-t transition-all group-hover:from-amber-400 group-hover:to-yellow-300"
                  [style.height.%]="(bin.count / maxFrCount()) * 100"
                ></div>
                <span class="text-[8px] font-mono text-slate-500 mt-1 hidden md:inline">{{ bin.bin }}</span>
              </div>
            }
          </div>
        </div>

        <!-- Distribution Histogram: Peak Acceleration Output G -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col flex-1 min-h-[260px]">
          <div class="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
            <span class="font-mono font-bold text-xs text-slate-100 uppercase">PEAK ACCELERATION HISTOGRAM (G)</span>
            <span class="font-mono text-[10px] text-emerald-400 font-semibold">Pass Threshold: ≥ 0.75 G</span>
          </div>

          <div class="flex-1 bg-[#0b0e14] border border-slate-800/80 rounded-lg p-3 flex items-end gap-1 overflow-hidden relative">
            @for (bin of state.monteCarloSummary()?.distributionAcc; track bin.bin) {
              <div class="flex-1 flex flex-col items-center h-full justify-end group">
                <div
                  class="w-full rounded-t transition-all"
                  [class.bg-gradient-to-t]="true"
                  [class.from-emerald-600]="bin.bin >= 0.8"
                  [class.to-emerald-400]="bin.bin >= 0.8"
                  [class.from-red-600]="bin.bin < 0.8"
                  [class.to-red-400]="bin.bin < 0.8"
                  [style.height.%]="(bin.count / maxAccCount()) * 100"
                ></div>
                <span class="text-[8px] font-mono text-slate-500 mt-1 hidden md:inline">{{ bin.bin }}G</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class OptimisationLabComponent {
  public state = inject(HapticsStateService);

  public runBatch(n = 500): void {
    this.state.runMonteCarlo(n);
  }

  public maxFrCount = computed(() => {
    const dist = this.state.monteCarloSummary()?.distributionFr;
    if (!dist || dist.length === 0) return 1;
    return Math.max(1, ...dist.map((d) => d.count));
  });

  public maxAccCount = computed(() => {
    const dist = this.state.monteCarloSummary()?.distributionAcc;
    if (!dist || dist.length === 0) return 1;
    return Math.max(1, ...dist.map((d) => d.count));
  });
}
