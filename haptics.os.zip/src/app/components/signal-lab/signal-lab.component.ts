import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';
import { EnvelopeCurve, WaveformType } from '../../core/models/haptics.models';

@Component({
  selector: 'app-signal-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-3 p-3 overflow-y-auto bg-[#050505] text-[#E4E3E0] text-xs font-sans">
      <!-- Left Panel: Waveform Synthesizer & ADSR Envelope Controls -->
      <div class="w-full lg:w-96 flex flex-col gap-3 shrink-0">
        <!-- Waveform Generation Panel -->
        <div class="bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between pb-2 border-b border-[#2D2D2D]">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#F27D26] text-sm">graphic_eq</mat-icon>
              <h2 class="font-mono font-bold text-xs text-white uppercase tracking-wider">Signal Generator</h2>
            </div>
            <span class="font-mono text-[9px] text-[#F27D26] px-1.5 py-0.5 rounded-sm bg-[#F27D26]/10 border border-[#F27D26]/30 font-bold uppercase tracking-widest">10 kHz DSP</span>
          </div>

          <!-- Waveform Type Buttons -->
          <div>
            <span class="font-mono text-[10px] text-[#8E9299] block mb-1.5 font-bold uppercase tracking-wider">Waveform Primitive</span>
            <div class="grid grid-cols-3 gap-1">
              @for (wf of waveforms; track wf.id) {
                <button
                  type="button"
                  (click)="onWaveformSelect(wf.id)"
                  class="flex items-center gap-1 px-2 py-1 rounded-sm font-mono text-[9px] font-bold uppercase tracking-wider border transition-all"
                  [class.bg-[#1A1A1A]]="state.activeEvent().waveform === wf.id"
                  [class.text-[#F27D26]]="state.activeEvent().waveform === wf.id"
                  [class.border-[#F27D26]]="state.activeEvent().waveform === wf.id"
                  [class.bg-[#141414]]="state.activeEvent().waveform !== wf.id"
                  [class.text-[#8E9299]]="state.activeEvent().waveform !== wf.id"
                  [class.border-[#2D2D2D]]="state.activeEvent().waveform !== wf.id"
                >
                  <mat-icon class="text-xs">{{ wf.icon }}</mat-icon>
                  <span class="truncate">{{ wf.label }}</span>
                </button>
              }
            </div>
          </div>

          <!-- Parameter Sliders -->
          <div class="space-y-2.5 pt-1">
            <!-- Frequency Slider -->
            <div>
              <div class="flex justify-between font-mono text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Frequency (f₀):</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().frequency }} Hz</span>
              </div>
              <input
                type="range"
                min="10"
                max="600"
                step="1"
                [value]="state.activeEvent().frequency"
                (input)="onFrequencyChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
              <div class="flex justify-between text-[9px] font-mono text-[#8E9299] opacity-60 mt-0.5">
                <span>10 Hz (Meissner)</span>
                <span>250 Hz (Pacinian)</span>
                <span>600 Hz</span>
              </div>
            </div>

            <!-- Amplitude Slider -->
            <div>
              <div class="flex justify-between font-mono text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Amplitude Gain:</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().amplitude | percent }}</span>
              </div>
              <input
                type="range"
                min="0.05"
                max="1.0"
                step="0.01"
                [value]="state.activeEvent().amplitude"
                (input)="onAmplitudeChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            <!-- Duration Slider -->
            <div>
              <div class="flex justify-between font-mono text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Duration:</span>
                <span class="text-[#00FF41] font-bold">{{ state.activeEvent().duration * 1000 | number:'1.0-0' }} ms</span>
              </div>
              <input
                type="range"
                min="10"
                max="800"
                step="5"
                [value]="state.activeEvent().duration * 1000"
                (input)="onDurationChange($event)"
                class="w-full accent-[#00FF41] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            <!-- Phase Offset -->
            <div>
              <div class="flex justify-between font-mono text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Phase Angle (θ):</span>
                <span class="text-[#E4E3E0] font-bold">{{ state.activeEvent().phase || 0 }}°</span>
              </div>
              <input
                type="range"
                min="0"
                max="360"
                step="5"
                [value]="state.activeEvent().phase || 0"
                (input)="onPhaseChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            @if (state.activeEvent().waveform === 'CHIRP' || state.activeEvent().waveform === 'SWEEP') {
              <div>
                <div class="flex justify-between font-mono text-[10px] mb-1">
                  <span class="text-[#8E9299] uppercase">Chirp End Freq:</span>
                  <span class="text-[#F27D26] font-bold">{{ state.activeEvent().chirpEndFreq || 350 }} Hz</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="800"
                  step="5"
                  [value]="state.activeEvent().chirpEndFreq || 350"
                  (input)="onChirpEndFreqChange($event)"
                  class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
                />
              </div>
            }

            @if (state.activeEvent().waveform === 'SQUARE' || state.activeEvent().waveform === 'PULSE') {
              <div>
                <div class="flex justify-between font-mono text-[10px] mb-1">
                  <span class="text-[#8E9299] uppercase">Pulse Width (Duty Cycle):</span>
                  <span class="text-[#F27D26] font-bold">{{ (state.activeEvent().pulseWidth || 0.5) | percent }}</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.95"
                  step="0.05"
                  [value]="state.activeEvent().pulseWidth || 0.5"
                  (input)="onPulseWidthChange($event)"
                  class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
                />
              </div>
            }
          </div>
        </div>

        <!-- ADSR Non-Linear Envelope Sculptor Panel -->
        <div class="bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm p-3 flex flex-col gap-2.5">
          <div class="flex items-center justify-between pb-2 border-b border-[#2D2D2D]">
            <div class="flex items-center gap-2">
              <mat-icon class="text-[#F27D26] text-sm">waves</mat-icon>
              <h2 class="font-mono font-bold text-xs text-white uppercase tracking-wider">ADSR Envelope</h2>
            </div>
            <!-- Curve Selector -->
            <select
              [value]="state.activeEvent().envelope.curve"
              (change)="onCurveChange($event)"
              class="bg-[#141414] border border-[#2D2D2D] text-[#F27D26] font-mono text-[9px] font-bold uppercase rounded-sm px-1.5 py-0.5 focus:outline-none cursor-pointer"
            >
              <option value="SMOOTHSTEP">SMOOTHSTEP (3x²-2x³)</option>
              <option value="EXPONENTIAL">EXPONENTIAL (x^2.5)</option>
              <option value="LOGARITHMIC">LOGARITHMIC (log10)</option>
              <option value="LINEAR">LINEAR (1st Order)</option>
            </select>
          </div>

          <div class="space-y-2 pt-1 font-mono">
            <!-- Attack -->
            <div>
              <div class="flex justify-between text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Attack (t_a):</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().envelope.attack * 1000 | number:'1.1-1' }} ms</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="100"
                step="0.5"
                [value]="state.activeEvent().envelope.attack * 1000"
                (input)="onAttackChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            <!-- Decay -->
            <div>
              <div class="flex justify-between text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Decay (t_d):</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().envelope.decay * 1000 | number:'1.1-1' }} ms</span>
              </div>
              <input
                type="range"
                min="1"
                max="150"
                step="1"
                [value]="state.activeEvent().envelope.decay * 1000"
                (input)="onDecayChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            <!-- Sustain -->
            <div>
              <div class="flex justify-between text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Sustain (L_s):</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().envelope.sustain | percent }}</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                [value]="state.activeEvent().envelope.sustain"
                (input)="onSustainChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>

            <!-- Release -->
            <div>
              <div class="flex justify-between text-[10px] mb-1">
                <span class="text-[#8E9299] uppercase">Release (t_r):</span>
                <span class="text-[#F27D26] font-bold">{{ state.activeEvent().envelope.release * 1000 | number:'1.1-1' }} ms</span>
              </div>
              <input
                type="range"
                min="2"
                max="200"
                step="1"
                [value]="state.activeEvent().envelope.release * 1000"
                (input)="onReleaseChange($event)"
                class="w-full accent-[#F27D26] bg-[#1A1A1A] h-1 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>
      </div>

      <!-- Right Panel: High-Resolution Oscilloscope, FFT Spectrum & Spectrogram Heatmap -->
      <div class="flex-1 flex flex-col gap-3">
        <!-- Display Mode Tabs -->
        <div class="bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm px-3 py-2 flex items-center justify-between">
          <div class="flex items-center gap-1.5">
            <button
              type="button"
              (click)="activeViewTab.set('TIME_DOMAIN')"
              class="px-2.5 py-1 rounded-sm font-mono text-[10px] uppercase font-bold tracking-wider transition-all border"
              [class.bg-[#1A1A1A]]="activeViewTab() === 'TIME_DOMAIN'"
              [class.text-[#F27D26]]="activeViewTab() === 'TIME_DOMAIN'"
              [class.border-[#F27D26]]="activeViewTab() === 'TIME_DOMAIN'"
              [class.text-[#8E9299]]="activeViewTab() !== 'TIME_DOMAIN'"
              [class.border-transparent]="activeViewTab() !== 'TIME_DOMAIN'"
            >
              Time-Domain Scope
            </button>

            <button
              type="button"
              (click)="activeViewTab.set('FFT_SPECTRUM')"
              class="px-2.5 py-1 rounded-sm font-mono text-[10px] uppercase font-bold tracking-wider transition-all border"
              [class.bg-[#1A1A1A]]="activeViewTab() === 'FFT_SPECTRUM'"
              [class.text-[#F27D26]]="activeViewTab() === 'FFT_SPECTRUM'"
              [class.border-[#F27D26]]="activeViewTab() === 'FFT_SPECTRUM'"
              [class.text-[#8E9299]]="activeViewTab() !== 'FFT_SPECTRUM'"
              [class.border-transparent]="activeViewTab() !== 'FFT_SPECTRUM'"
            >
              FFT Power Spectrum (PSD)
            </button>

            <button
              type="button"
              (click)="activeViewTab.set('SPECTROGRAM')"
              class="px-2.5 py-1 rounded-sm font-mono text-[10px] uppercase font-bold tracking-wider transition-all border"
              [class.bg-[#1A1A1A]]="activeViewTab() === 'SPECTROGRAM'"
              [class.text-[#F27D26]]="activeViewTab() === 'SPECTROGRAM'"
              [class.border-[#F27D26]]="activeViewTab() === 'SPECTROGRAM'"
              [class.text-[#8E9299]]="activeViewTab() !== 'SPECTROGRAM'"
              [class.border-transparent]="activeViewTab() !== 'SPECTROGRAM'"
            >
              STFT Spectrogram
            </button>
          </div>

          <!-- DSP Metrics Mini Strip -->
          <div class="hidden xl:flex items-center gap-4 font-mono text-[10px] text-[#8E9299]">
            <div>RMS: <span class="text-white font-bold">{{ state.generatedSignal().metrics.rms }}</span></div>
            <div>CREST: <span class="text-[#F27D26] font-bold">{{ state.generatedSignal().metrics.crestFactor }}</span></div>
            <div>THD: <span class="text-[#F27D26] font-bold">{{ state.generatedSignal().metrics.thd }}%</span></div>
            <div>SNR: <span class="text-[#00FF41] font-bold">{{ state.generatedSignal().metrics.snrDb }} dB</span></div>
          </div>
        </div>

        <!-- Main Visualization Display -->
        <div class="flex-1 bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm p-3 flex flex-col min-h-[350px]">
          @if (activeViewTab() === 'TIME_DOMAIN') {
            <!-- Time-Domain Oscilloscope -->
            <div class="flex-1 flex flex-col">
              <div class="flex justify-between items-center mb-2 font-mono text-[10px] text-[#8E9299]">
                <div class="flex items-center gap-3">
                  <span class="text-[#F27D26] font-bold uppercase tracking-wider">&bull; Command Voltage u(t)</span>
                  <span class="text-[#00FF41] font-bold uppercase tracking-wider">&bull; Measured Accel a(t)</span>
                </div>
                <div class="flex gap-2">
                  <span class="px-1.5 py-0.5 border border-[#2D2D2D] bg-[#0A0A0A]">Sample: 10kHz</span>
                  <span class="px-1.5 py-0.5 border border-[#2D2D2D] bg-[#0A0A0A]">Buffer: 512pt</span>
                </div>
              </div>

              <div class="flex-1 bg-black/50 border border-[#1A1A1A] rounded-sm p-2 relative flex items-center justify-center">
                <svg class="w-full h-full" viewBox="0 0 800 300" preserveAspectRatio="none">
                  <!-- Grid -->
                  @for (y of [50, 100, 150, 200, 250]; track y) {
                    <line x1="0" [attr.y1]="y" x2="800" [attr.y2]="y" stroke="#1A1A1A" stroke-width="1" stroke-dasharray="4" />
                  }
                  @for (x of [100, 200, 300, 400, 500, 600, 700]; track x) {
                    <line [attr.x1]="x" y1="0" [attr.x2]="x" y2="300" stroke="#1A1A1A" stroke-width="1" />
                  }

                  <!-- Drive signal (Orange #F27D26) -->
                  <path [attr.d]="timeDomainDrivePath()" fill="none" stroke="#F27D26" stroke-width="1.8" stroke-linecap="round" />
                  <!-- Acceleration signal (Green #00FF41) -->
                  <path [attr.d]="timeDomainAccPath()" fill="none" stroke="#00FF41" stroke-width="1.5" stroke-linecap="round" />
                </svg>

                <div class="absolute top-2 right-3 font-mono text-[10px] space-y-0.5 text-right">
                  <div class="text-[#F27D26] font-bold">V_peak: {{ state.generatedSignal().metrics.peak }} V</div>
                  <div class="text-[#00FF41] font-bold">A_peak: {{ state.mechSimulation().peakAccelerationG }} G</div>
                </div>
              </div>
            </div>
          } @else if (activeViewTab() === 'FFT_SPECTRUM') {
            <!-- FFT Power Spectrum (PSD) -->
            <div class="flex-1 flex flex-col">
              <div class="flex justify-between items-center mb-2 font-mono text-[10px] text-[#8E9299]">
                <span class="uppercase font-bold tracking-wider">FFT Spectrum (0 Hz to 1000 Hz)</span>
                <span class="text-[#F27D26] font-bold">DOMINANT PEAK: {{ state.fftAnalysis().dominantPeakHz }} Hz</span>
              </div>

              <div class="flex-1 bg-black/50 border border-[#1A1A1A] rounded-sm p-3 relative flex items-center justify-center">
                <svg class="w-full h-full" viewBox="0 0 800 300" preserveAspectRatio="none">
                  <!-- Grid -->
                  @for (db of [0, -20, -40, -60, -80]; track db; let idx = $index) {
                    <line x1="0" [attr.y1]="idx * 60" x2="800" [attr.y2]="idx * 60" stroke="#1A1A1A" stroke-width="1" stroke-dasharray="3" />
                    <text x="8" [attr.y]="idx * 60 + 12" fill="#8E9299" font-family="monospace" font-size="9">{{ db }} dB</text>
                  }

                  <!-- Spectrum Bars/Area -->
                  <path [attr.d]="fftSpectrumPath()" fill="url(#fftGrad)" stroke="#F27D26" stroke-width="1.5" />

                  <defs>
                    <linearGradient id="fftGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stop-color="#F27D26" stop-opacity="0.3" />
                      <stop offset="100%" stop-color="#F27D26" stop-opacity="0.0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
            </div>
          } @else {
            <!-- STFT Spectrogram Heatmap -->
            <div class="flex-1 flex flex-col">
              <div class="flex justify-between items-center mb-2 font-mono text-[10px] text-[#8E9299]">
                <span class="uppercase font-bold tracking-wider">Short-Time Fourier Transform (STFT) Energy Distribution</span>
                <span>Time (0..{{ state.activeEvent().duration * 1000 | number:'1.0-0' }} ms) vs Frequency (0..500 Hz)</span>
              </div>

              <div class="flex-1 bg-black/50 border border-[#1A1A1A] rounded-sm p-2 overflow-hidden flex flex-col justify-end">
                <div class="grid h-full w-full gap-0.5" [style.grid-template-columns]="'repeat(' + spectrogramColumns().length + ', minmax(0, 1fr))'">
                  @for (col of spectrogramColumns(); track $index) {
                    <div class="flex flex-col-reverse h-full gap-0.5">
                      @for (cell of col; track $index) {
                        <div class="flex-1 rounded-[1px] transition-colors" [style.background-color]="cell.color"></div>
                      }
                    </div>
                  }
                </div>
              </div>
            </div>
          }
        </div>

        <!-- Spectral Energy Bands & Numerical Telemetry Matrix -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-2 bg-[#0F0F0F] border border-[#2D2D2D] rounded-sm p-3">
          <div class="bg-black/50 border border-[#1A1A1A] rounded-sm p-2 font-mono">
            <span class="text-[#8E9299] text-[9px] uppercase font-bold block">LOW FREQ (10-100Hz)</span>
            <div class="text-sm font-bold text-[#E4E3E0] mt-0.5">
              {{ state.generatedSignal().metrics.bandEnergyLow | percent }}
            </div>
            <span class="text-[9px] text-[#8E9299] opacity-60">Meissner / Flutter</span>
          </div>

          <div class="bg-black/50 border border-[#1A1A1A] rounded-sm p-2 font-mono">
            <span class="text-[#8E9299] text-[9px] uppercase font-bold block">MID FREQ (100-300Hz)</span>
            <div class="text-sm font-bold text-[#F27D26] mt-0.5">
              {{ state.generatedSignal().metrics.bandEnergyMid | percent }}
            </div>
            <span class="text-[9px] text-[#8E9299] opacity-60">Pacinian / Resonance</span>
          </div>

          <div class="bg-black/50 border border-[#1A1A1A] rounded-sm p-2 font-mono">
            <span class="text-[#8E9299] text-[9px] uppercase font-bold block">HIGH FREQ (300-1000Hz)</span>
            <div class="text-sm font-bold text-[#E4E3E0] mt-0.5">
              {{ state.generatedSignal().metrics.bandEnergyHigh | percent }}
            </div>
            <span class="text-[9px] text-[#8E9299] opacity-60">Acoustic Texture</span>
          </div>

          <div class="bg-black/50 border border-[#1A1A1A] rounded-sm p-2 font-mono">
            <span class="text-[#8E9299] text-[9px] uppercase font-bold block">ZERO CROSSING RATE</span>
            <div class="text-sm font-bold text-[#00FF41] mt-0.5">
              {{ state.generatedSignal().metrics.zeroCrossingRate }} <span class="text-[10px] font-normal text-[#8E9299]">/s</span>
            </div>
            <span class="text-[9px] text-[#8E9299] opacity-60">Transient Density</span>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class SignalLabComponent {
  public state = inject(HapticsStateService);
  public activeViewTab = signal<'TIME_DOMAIN' | 'FFT_SPECTRUM' | 'SPECTROGRAM'>('TIME_DOMAIN');

  public waveforms: { id: WaveformType; label: string; icon: string }[] = [
    { id: 'SINE', label: 'SINE', icon: 'waves' },
    { id: 'COSINE', label: 'COSINE', icon: 'show_chart' },
    { id: 'SQUARE', label: 'SQUARE', icon: 'square' },
    { id: 'TRIANGLE', label: 'TRIANGLE', icon: 'change_history' },
    { id: 'SAW', label: 'SAW', icon: 'timeline' },
    { id: 'PULSE', label: 'PULSE', icon: 'view_week' },
    { id: 'WHITE_NOISE', label: 'WHITE NOISE', icon: 'blur_on' },
    { id: 'PINK_NOISE', label: 'PINK NOISE', icon: 'grain' },
    { id: 'CHIRP', label: 'CHIRP', icon: 'trending_up' },
    { id: 'BURST', label: 'BURST', icon: 'equalizer' },
    { id: 'IMPULSE', label: 'IMPULSE', icon: 'flash_on' },
    { id: 'CUSTOM', label: 'CUSTOM', icon: 'tune' },
  ];

  public onWaveformSelect(wf: WaveformType): void {
    this.state.updateActiveEvent({ waveform: wf });
    this.state.playHapticFeedback();
  }

  public onFrequencyChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ frequency: val });
  }

  public onAmplitudeChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ amplitude: val });
  }

  public onDurationChange(event: Event): void {
    const valMs = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ duration: valMs / 1000 });
  }

  public onPhaseChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ phase: val });
  }

  public onChirpEndFreqChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ chirpEndFreq: val });
  }

  public onPulseWidthChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEvent({ pulseWidth: val });
  }

  public onCurveChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as EnvelopeCurve;
    this.state.updateActiveEnvelope({ curve: val });
  }

  public onAttackChange(event: Event): void {
    const valMs = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEnvelope({ attack: valMs / 1000 });
  }

  public onDecayChange(event: Event): void {
    const valMs = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEnvelope({ decay: valMs / 1000 });
  }

  public onSustainChange(event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEnvelope({ sustain: val });
  }

  public onReleaseChange(event: Event): void {
    const valMs = Number((event.target as HTMLInputElement).value);
    this.state.updateActiveEnvelope({ release: valMs / 1000 });
  }

  public timeDomainDrivePath = computed(() => {
    const samples = this.state.generatedSignal().samples;
    return this.buildSvgPath(samples, 800, 300, 1.0);
  });

  public timeDomainAccPath = computed(() => {
    const samples = this.state.mechSimulation().acceleration;
    const maxVal = Math.max(0.1, this.state.mechSimulation().peakAccelerationG);
    return this.buildSvgPath(samples, 800, 300, maxVal);
  });

  public fftSpectrumPath = computed(() => {
    const fft = this.state.fftAnalysis();
    const mags = fft.magnitudes;
    if (!mags || mags.length === 0) return 'M 0 300';

    const maxMag = Math.max(0.01, fft.peakMagnitude);
    const n = Math.min(256, mags.length);
    const points: string[] = ['M 0 300'];

    for (let i = 0; i < n; i++) {
      const x = (i / (n - 1 || 1)) * 800;
      const normY = mags[i] / maxMag;
      const y = 300 - normY * 260;
      points.push(`L ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    points.push('L 800 300 Z');
    return points.join(' ');
  });

  public spectrogramColumns = computed(() => {
    const spec = this.state.spectrogramAnalysis();
    const matrix = spec.matrix;
    if (!matrix || matrix.length === 0) return [];

    const cols: { color: string }[][] = [];
    const minDb = -80;
    const maxDb = 0;

    for (const row of matrix) {
      const colCells: { color: string }[] = [];
      const binCount = Math.min(24, row.length);

      for (let k = 0; k < binCount; k++) {
        const db = row[k];
        const norm = Math.max(0, Math.min(1, (db - minDb) / (maxDb - minDb)));

        // Color map: Dark Slate -> Deep Indigo -> Cyan -> Amber -> Bright White
        let color = '#0f172a';
        if (norm > 0.8) color = '#fef08a';
        else if (norm > 0.6) color = '#f59e0b';
        else if (norm > 0.35) color = '#06b6d4';
        else if (norm > 0.15) color = '#3b82f6';
        else if (norm > 0.05) color = '#1e1b4b';

        colCells.push({ color });
      }
      cols.push(colCells);
    }
    return cols;
  });

  private buildSvgPath(samples: number[], width: number, height: number, scaleMax: number): string {
    if (!samples || samples.length === 0) return 'M 0 150';
    const n = samples.length;
    const step = Math.max(1, Math.floor(n / width));
    const points: string[] = [];

    const midY = height / 2;
    for (let i = 0; i < n; i += step) {
      const x = (i / (n - 1 || 1)) * width;
      const normalized = samples[i] / (scaleMax || 1);
      const y = midY - normalized * (midY * 0.85);
      points.push(`${points.length === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`);
    }
    return points.join(' ');
  }
}
