import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HapticsStateService } from '../../core/services/haptics-state.service';

@Component({
  selector: 'app-digital-twin-lab',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="h-full flex flex-col lg:flex-row gap-4 p-4 overflow-y-auto bg-[#0b0e14] text-slate-200 text-xs">
      <!-- Left Column: Spatial Vector Panning & Hardware Specifications -->
      <div class="w-full lg:w-96 flex flex-col gap-4 shrink-0">
        <!-- Digital Twin Metadata Panel -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-cyan-400 text-base">view_in_ar</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Digital Twin</h2>
            </div>
            <span class="font-mono text-[10px] text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-950/60 border border-cyan-800/40">
              {{ state.deviceTwin().id }}
            </span>
          </div>

          <div class="space-y-2 font-mono text-[11px]">
            <div class="flex justify-between">
              <span class="text-slate-400">Chassis:</span>
              <span class="text-slate-200 font-semibold">{{ state.deviceTwin().chassisMaterial }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Dimensions:</span>
              <span class="text-cyan-300">{{ state.deviceTwin().dimensionsMm.join(' × ') }} mm</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Total Mass:</span>
              <span class="text-slate-200 font-semibold">{{ state.deviceTwin().totalMassG }} g</span>
            </div>
            <div class="flex justify-between">
              <span class="text-slate-400">Surface Friction:</span>
              <span class="text-amber-300 font-semibold">μ = 0.22 (Oleophobic)</span>
            </div>
          </div>
        </div>

        <!-- Spatial Tactile Phantom Panning (VBAP) -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-3">
          <div class="flex items-center justify-between pb-2 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <mat-icon class="text-indigo-400 text-base">control_camera</mat-icon>
              <h2 class="font-mono font-bold text-sm text-slate-100 uppercase tracking-wide">Spatial Panning</h2>
            </div>
            <span class="font-mono text-[10px] text-indigo-300 px-1.5 py-0.5 rounded bg-indigo-950/60 border border-indigo-800/40">
              VBAP 2D
            </span>
          </div>

          <p class="text-slate-400 text-[11px] leading-relaxed">
            Drag cursor across the device plane to compute real-time Vector Base Amplitude Panning weights across all 4 spatial actuators.
          </p>

          <div class="space-y-2 font-mono text-[11px]">
            <div class="flex justify-between">
              <span class="text-slate-400">Cursor Position (X, Y):</span>
              <span class="text-indigo-300 font-bold">[{{ cursorX() | number:'1.2-2' }}, {{ cursorY() | number:'1.2-2' }}]</span>
            </div>

            <!-- Actuator Energy Weight Bars -->
            <div class="space-y-1.5 pt-2">
              @for (act of state.deviceTwin().actuators; track act.id; let idx = $index) {
                <div>
                  <div class="flex justify-between text-[10px] mb-0.5">
                    <span class="text-slate-300">{{ act.name }}</span>
                    <span class="text-cyan-400 font-bold">{{ actuatorWeights()[idx] | percent }}</span>
                  </div>
                  <div class="w-full bg-[#0b0e14] h-1.5 rounded overflow-hidden">
                    <div
                      class="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded transition-all duration-75"
                      [style.width.%]="actuatorWeights()[idx] * 100"
                    ></div>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Sensor Telemetry Strip -->
        <div class="bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col gap-2.5">
          <span class="font-mono font-bold text-xs text-slate-300 uppercase">Integrated Sensors</span>
          <div class="space-y-1.5">
            @for (sens of state.deviceTwin().sensors; track sens.id) {
              <div class="bg-[#0b0e14] border border-slate-800/80 rounded p-2 flex items-center justify-between font-mono text-[11px]">
                <div class="flex items-center gap-2">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span class="text-slate-300 font-semibold">{{ sens.id }}</span>
                  <span class="text-slate-500 text-[10px]">({{ sens.type }})</span>
                </div>
                <span class="text-emerald-400 font-bold">{{ sens.samplingRateHz / 1000 }} kHz</span>
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Right Column: Interactive 2D/3D Device Surface Coordinate Stage -->
      <div class="flex-1 bg-[#121622] border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center min-h-[460px] relative">
        <div class="w-full flex justify-between items-center mb-3 font-mono text-[11px] text-slate-400">
          <div class="flex items-center gap-3">
            <span class="text-cyan-400 font-bold">SPATIAL TACTILE MATRIX (TOP VIEW)</span>
            <span>&bull; Actuators A1-A4</span>
            <span>&bull; Sensors S1-S4</span>
          </div>
          <button
            type="button"
            (click)="resetCursor()"
            class="px-2 py-1 rounded bg-[#0b0e14] border border-slate-700 text-slate-300 hover:text-white"
          >
            CENTER CURSOR (0,0)
          </button>
        </div>

        <!-- Interactive Virtual Device Surface (Touchscreen) -->
        <div
          tabindex="0"
          role="region"
          aria-label="Interactive haptic touch surface"
          (click)="onDevicePlaneClick($event)"
          (keydown.enter)="resetCursor()"
          (mousemove)="onDevicePlaneMove($event)"
          class="relative w-[300px] h-[520px] bg-gradient-to-b from-[#141926] via-[#0d111a] to-[#141926] rounded-3xl border-2 border-slate-700 shadow-2xl shadow-cyan-950/40 p-4 cursor-crosshair overflow-hidden select-none outline-none focus:border-cyan-500"
        >
          <!-- Surface Texture Simulation Grid -->
          <div class="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]"></div>

          <!-- Actuator Nodes (A1, A2, A3, A4) -->
          <!-- A1 Top-Left -->
          <div class="absolute top-6 left-6 flex flex-col items-center pointer-events-none">
            <div
              class="w-10 h-10 rounded-lg border-2 border-amber-400/80 bg-amber-950/60 flex items-center justify-center shadow-lg transition-transform"
              [style.transform]="'scale(' + (1 + actuatorWeights()[0] * 0.4) + ')'"
            >
              <span class="font-mono text-xs font-bold text-amber-300">A1</span>
            </div>
            <span class="font-mono text-[9px] text-amber-300 mt-1">LRA Top-L</span>
          </div>

          <!-- A2 Top-Right -->
          <div class="absolute top-6 right-6 flex flex-col items-center pointer-events-none">
            <div
              class="w-10 h-10 rounded-lg border-2 border-amber-400/80 bg-amber-950/60 flex items-center justify-center shadow-lg transition-transform"
              [style.transform]="'scale(' + (1 + actuatorWeights()[1] * 0.4) + ')'"
            >
              <span class="font-mono text-xs font-bold text-amber-300">A2</span>
            </div>
            <span class="font-mono text-[9px] text-amber-300 mt-1">LRA Top-R</span>
          </div>

          <!-- A3 Bottom-Left -->
          <div class="absolute bottom-6 left-6 flex flex-col items-center pointer-events-none">
            <div
              class="w-10 h-10 rounded-lg border-2 border-cyan-400/80 bg-cyan-950/60 flex items-center justify-center shadow-lg transition-transform"
              [style.transform]="'scale(' + (1 + actuatorWeights()[2] * 0.4) + ')'"
            >
              <span class="font-mono text-xs font-bold text-cyan-300">A3</span>
            </div>
            <span class="font-mono text-[9px] text-cyan-300 mt-1">VCM Btm-L</span>
          </div>

          <!-- A4 Bottom-Right -->
          <div class="absolute bottom-6 right-6 flex flex-col items-center pointer-events-none">
            <div
              class="w-10 h-10 rounded-lg border-2 border-cyan-400/80 bg-cyan-950/60 flex items-center justify-center shadow-lg transition-transform"
              [style.transform]="'scale(' + (1 + actuatorWeights()[3] * 0.4) + ')'"
            >
              <span class="font-mono text-xs font-bold text-cyan-300">A4</span>
            </div>
            <span class="font-mono text-[9px] text-cyan-300 mt-1">VCM Btm-R</span>
          </div>

          <!-- Sensors (S1, S2, S3, S4) -->
          <!-- S1 Top -->
          <div class="absolute top-16 [left:calc(50%-12px)] w-6 h-6 rounded-full border border-emerald-400 bg-emerald-950/80 flex items-center justify-center font-mono text-[9px] text-emerald-300">
            S1
          </div>
          <!-- S2 Center Force -->
          <div class="absolute top-[248px] [left:calc(50%-14px)] w-7 h-7 rounded-full border border-blue-400 bg-blue-950/80 flex items-center justify-center font-mono text-[9px] text-blue-300 shadow-md">
            S2
          </div>
          <!-- S3 Bottom -->
          <div class="absolute bottom-16 [left:calc(50%-12px)] w-6 h-6 rounded-full border border-emerald-400 bg-emerald-950/80 flex items-center justify-center font-mono text-[9px] text-emerald-300">
            S3
          </div>

          <!-- Interactive Tactile Panning Reticle / Touch Finger -->
          <div
            class="absolute w-12 h-12 -ml-6 -mt-6 rounded-full border-2 border-cyan-400 bg-cyan-500/20 backdrop-blur-sm pointer-events-none flex items-center justify-center transition-all duration-75 shadow-lg shadow-cyan-400/40 animate-pulse"
            [style.left.px]="cursorPixelX()"
            [style.top.px]="cursorPixelY()"
          >
            <div class="w-3 h-3 rounded-full bg-cyan-400"></div>
          </div>
        </div>

        <div class="mt-3 font-mono text-[10px] text-slate-400 text-center">
          Click or drag across the touchscreen glass to simulate tactile touch point &amp; render VBAP spatial feedback
        </div>
      </div>
    </div>
  `,
})
export class DigitalTwinLabComponent {
  public state = inject(HapticsStateService);

  public cursorX = signal<number>(0.0); // [-1 .. 1]
  public cursorY = signal<number>(0.0); // [-1 .. 1]
  public isDragging = signal<boolean>(false);

  public cursorPixelX = computed(() => {
    // Width = 300px, range -1..1 -> 30px to 270px
    return 150 + this.cursorX() * 120;
  });

  public cursorPixelY = computed(() => {
    // Height = 520px, range -1..1 -> 50px to 470px
    return 260 - this.cursorY() * 210;
  });

  public actuatorWeights = computed(() => {
    const x = this.cursorX();
    const y = this.cursorY();

    // 4-Quadrant Bilinear Panning Weights:
    // A1 (Top-Left): x=-1, y=1
    // A2 (Top-Right): x=1, y=1
    // A3 (Bottom-Left): x=-1, y=-1
    // A4 (Bottom-Right): x=1, y=-1
    const w1 = Math.max(0, (1 - x) * (1 + y)) / 4;
    const w2 = Math.max(0, (1 + x) * (1 + y)) / 4;
    const w3 = Math.max(0, (1 - x) * (1 - y)) / 4;
    const w4 = Math.max(0, (1 + x) * (1 - y)) / 4;

    const sum = w1 + w2 + w3 + w4 || 1;
    return [w1 / sum, w2 / sum, w3 / sum, w4 / sum];
  });

  public onDevicePlaneClick(event: MouseEvent): void {
    this.updateCoordinatesFromEvent(event);
    this.state.playHapticFeedback();
  }

  public onDevicePlaneMove(event: MouseEvent): void {
    if (event.buttons === 1) {
      this.updateCoordinatesFromEvent(event);
    }
  }

  public resetCursor(): void {
    this.cursorX.set(0);
    this.cursorY.set(0);
    this.state.playHapticFeedback();
  }

  private updateCoordinatesFromEvent(event: MouseEvent): void {
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const px = event.clientX - rect.left;
    const py = event.clientY - rect.top;

    const normX = Math.max(-1, Math.min(1, (px - 150) / 120));
    const normY = Math.max(-1, Math.min(1, (260 - py) / 210));

    this.cursorX.set(normX);
    this.cursorY.set(normY);
  }
}
