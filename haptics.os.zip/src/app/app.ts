import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { ActiveLabView, HapticsStateService } from './core/services/haptics-state.service';
import { HeaderComponent } from './components/header/header.component';
import { PipelineViewComponent } from './components/pipeline-view/pipeline-view.component';
import { SignalLabComponent } from './components/signal-lab/signal-lab.component';
import { ActuatorLabComponent } from './components/actuator-lab/actuator-lab.component';
import { DigitalTwinLabComponent } from './components/digital-twin-lab/digital-twin-lab.component';
import { PerceptionLabComponent } from './components/perception-lab/perception-lab.component';
import { ControlLabComponent } from './components/control-lab/control-lab.component';
import { OptimisationLabComponent } from './components/optimisation-lab/optimisation-lab.component';
import { LibraryLabComponent } from './components/library-lab/library-lab.component';
import { RConsoleLabComponent } from './components/r-console-lab/r-console-lab.component';
import { AiAdvisorLabComponent } from './components/ai-advisor-lab/ai-advisor-lab.component';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    PipelineViewComponent,
    SignalLabComponent,
    ActuatorLabComponent,
    DigitalTwinLabComponent,
    PerceptionLabComponent,
    ControlLabComponent,
    OptimisationLabComponent,
    LibraryLabComponent,
    RConsoleLabComponent,
    AiAdvisorLabComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public state = inject(HapticsStateService);

  public navItems: { id: ActiveLabView; label: string; icon: string }[] = [
    { id: 'PIPELINE', label: 'PIPELINE', icon: 'account_tree' },
    { id: 'SIGNAL_LAB', label: 'SIGNAL LAB', icon: 'graphic_eq' },
    { id: 'VIBRATION_ACTUATORS', label: 'ACTUATORS & ODE', icon: 'motion_photos_on' },
    { id: 'DIGITAL_TWIN', label: 'DIGITAL TWIN', icon: 'view_in_ar' },
    { id: 'PERCEPTION_PSYCHOPHYSICS', label: 'PERCEPTION', icon: 'fingerprint' },
    { id: 'CONTROL_SYSTEMS', label: 'CONTROL SYSTEMS', icon: 'alt_route' },
    { id: 'OPTIMISATION_MONTE_CARLO', label: 'MONTE CARLO', icon: 'casino' },
    { id: 'DESIGN_LIBRARY', label: 'LIBRARY & MATERIALS', icon: 'texture' },
    { id: 'R_CONSOLE', label: 'R CONSOLE', icon: 'terminal' },
    { id: 'AI_ADVISOR', label: 'AI ADVISOR', icon: 'psychology_alt' },
  ];

  public setView(view: ActiveLabView): void {
    this.state.activeView.set(view);
  }
}
