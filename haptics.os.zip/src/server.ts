import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json({ limit: '10mb' }));

/**
 * Server-Side Gemini Haptics AI Diagnostic Assistant
 */
app.post('/api/haptics/ai-diagnose', async (req, res) => {
  try {
    const { prompt, telemetry } = req.body;
    const apiKey = process.env['GEMINI_API_KEY'];

    if (!apiKey) {
      // Deterministic analytical fallback when key is not provided
      return res.json({
        answer: `[HAPTICS.OS ANALYTICAL CORE] Telemetry Analysis for ${telemetry?.device || 'HAPTIC-01'}:\n\n` +
          `• Resonant Status: Natural frequency at ${telemetry?.resonantFreq || '175.0'} Hz with Q-factor ${telemetry?.qFactor || '6.5'}.\n` +
          `• Mechanical Response: Peak acceleration ${telemetry?.peakAcc || '2.1'} G, Settling time ${telemetry?.settlingTime || '18.4'} ms.\n` +
          `• Recommendation: To minimize ringing, enable Active Braking Feedforward pulse on falling edge or increase damping ratio ζ from ${telemetry?.zeta || '0.077'} to ~0.15.`
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = `You are the Lead Haptic & Vibration Engineering Specialist in HAPTICS.OS.
You provide precise, mathematically grounded, and actionable insights on haptic feedback signals, actuator dynamics (ERM, LRA, Voice Coil, Piezo, Ultrasonic), vibration ODEs, modal resonances, human tactile perception (Pacinian FA II, Meissner FA I), closed-loop PID control, and Monte Carlo manufacturing tolerances.
Ground your response strictly in the provided telemetry context. Be concise, technical, objective, and professional. Avoid fluff.`;

    const contextContent = `CURRENT HAPTIC TELEMETRY CONTEXT:
${JSON.stringify(telemetry || {}, null, 2)}

ENGINEERING QUESTION:
${prompt}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contextContent,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    return res.json({ answer: response.text || 'Diagnostic completed with no warnings.' });
  } catch (err: unknown) {
    console.error('Error in /api/haptics/ai-diagnose:', err);
    const errorMessage = err instanceof Error ? err.message : String(err);
    return res.status(500).json({
      error: 'AI diagnostics failed',
      details: errorMessage,
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
