# IMPACT//VR

A production-structured **Python 3.12+ VR first-person beat-'em-up engine** with a **hardware-independent haptic glove interface**.
You fight with your real hands: strikes, blocks, parries, grabs and dodges are recognised from *tracked hand and head trajectories*
(never from button presses), resolved by a swept-collision physical impact model, and felt through an eight-actuator haptic glove
abstraction that sits behind an independent safety limiter.

The setting is an original, fictional British industrial district at night (brick, railway arches, a loading yard, wet pavement,
sodium street lighting). No cyberpunk neon.

```
REAL HAND -> TRACKING -> SKELETON -> MOTION ANALYSIS -> COMBAT INTERPRETATION -> PHYSICS -> COLLISION -> IMPACT MODEL
          -> GAMEPLAY -> HAPTIC EVENT -> HAPTIC SAFETY -> GLOVE DRIVER -> PLAYER
```

Every arrow is a replaceable, independently testable layer. Hardware lives only behind adapters.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"            # numpy, pydantic, scipy, pygame (+ pytest, hypothesis, ruff, mypy)

impact-vr diagnostics              # environment + dependency + pipeline self-check
impact-vr simulate                 # all 10 scripted combat scenarios, headless
impact-vr run                      # the game (keyboard + mouse drive virtual hands; no headset or glove needed)
impact-vr training                 # training room
impact-vr benchmark                # frame cost + INPUT -> COLLISION -> HAPTIC latency breakdown
impact-vr glove-test --protocol-loopback   # exercise every actuator over the IMPACT-HAPTIC v1 wire protocol
impact-vr calibrate --scripted     # haptic calibration (omit --scripted for the interactive workflow)
impact-vr simulate combo_chain --record out/   # record a replay
impact-vr replay out/combo_chain.jsonl.gz      # re-run it and verify the identical event digest
pytest                             # 112 tests (incl. property-based + protocol fuzzing)
```

Desktop controls (simulation mode): mouse = look; **J / K / H / U / I / O / L / M** = jab / cross / hook / uppercut / palm / hammer
fist / backhand / elbow; **B** hold guard; **P** parry; **G** grab (**T** throw); **F** push; **V** shove; **S** duck; **A / D**
weave; **Q / E** lean; arrows = move / turn sticks; **F3** developer overlay; **F4** digital twin; **F12** haptic emergency stop
(**F5** reset). These keys *trigger scripted hand trajectories* that go through exactly the same recognition pipeline a tracked hand
would.

## What is verified, and what is not (please read)

| Area | Status |
| --- | --- |
| Hand analysis, strike & gesture recognition, collision, impact, damage, enemies, haptic scheduling/safety/protocol, calibration, replay, determinism | **Implemented and tested** (112 tests, ruff clean, mypy clean) with synthetic hands and a simulated glove |
| 8 strike types + block/parry/grab/push/shove/dodge/duck/weave | Recognised from synthetic trajectories with sensor noise; thresholds were tuned on synthetic data only |
| `OpenXRAdapter` (headset, controllers, XR_EXT_hand_tracking) | **Stub, hardware-untested.** Raises `VRUnavailable` and the engine falls back to simulation. The coordinate conversion it must use (`openxr_to_world`) is tested |
| Serial / BLE / HID / WebSocket glove transports | **Hardware-untested** thin adapters over optional packages; they fail cleanly without the package or device |
| UDP + loopback transports, `GenericHapticGlove`, `VirtualGloveFirmware` | Implemented and tested end to end over **IMPACT-HAPTIC v1** (our own documented protocol - *not* a commercial one) |
| Commercial glove SDKs (e.g. HaptX, bHaptics, SenseGlove, ...) | **Not implemented.** `docs/HAPTIC_HARDWARE.md` and `examples/custom_glove_adapter.py` show how to write one against the documented SDK |
| Rendering | A **software (pygame) renderer** for the prototype and a developer digital twin. There is **no stereo/OpenXR renderer and no GPU renderer**. The simulation never imports the renderer |
| Latency numbers | Compute stages are real measurements; scheduler/transport latencies come from the *simulated* glove. They become real once hardware drives the same pipeline |
| Performance | ~4 ms mean / ~7 ms p99 per frame in pure Python for the whole pipeline in the benchmark scenarios on the build machine (budget 11.1 ms at 90 Hz) - see `docs/PERFORMANCE.md` for caveats |
| Safety | The software limiter is defence in depth, **not a certified safety system**. Real gloves need hardware-level limits. See `docs/SAFETY.md` |

## Layout

```
configs/*.toml         typed, validated configuration (vr, haptics, physics, gameplay, graphics, audio)
src/impact_vr/
  engine/              math, events, clock, rng, config, session (the frame pipeline), locomotion, modes, app
  vr/                  device interfaces, runtime (frame timing, play space, hand-source fallback), adapters
  tracking/            runtime-reconfigurable filters (none / EMA / moving average / One Euro / velocity-aware), calibration
  hands/               26-joint skeleton + FK rig, hand analyzer (velocity, acceleration, flexion, fist/point/grip)
  combat/              strike detector, defense (guard/block/parry/gestures), damage, collision+impact system
  physics/             swept shapes, spatial hash, impact model (energy/impulse), props
  enemies/             archetypes, state machine, encounter director (attack tokens)
  haptics/             model, patterns, scheduler, profile, safety limiter, protocol, transports, gloves, pipeline, calibration
  simulation/          synthetic VR, scenarios, deterministic record/replay, benchmark
  telemetry/           structured logging, latency tracker, metrics, diagnostics
  audio/ rendering/ input/ networking/ world/ animation/ tools/
tests/  docs/  examples/
```

See `docs/` for the architecture and every subsystem.
