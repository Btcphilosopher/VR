#!/bin/sh
# Full local check: lint, types, tests.
set -e
ruff check src tests
mypy src/impact_vr
pytest
