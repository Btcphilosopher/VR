"""Skeleton of a vendor-SDK glove adapter. `FakeVendorSDK` stands in for a real SDK so this file runs; replace it with the vendor's
documented API. NOTE: this repository ships no commercial SDK integration."""

from impact_vr.haptics.gloves.base import ConnectionState, HapticGlove
from impact_vr.haptics.model import ACTUATORS, Actuator, HapticCommand
from impact_vr.haptics.pipeline import HapticPipeline
from impact_vr.haptics.model import HapticEvent
from impact_vr.haptics.safety import SafeHapticCommand
from impact_vr.engine.config import HapticsCfg


class FakeVendorSDK:
    """Pretend vendor API: (finger index, 0..255 amplitude, ms)."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, int, int, int]] = []

    def pulse(self, hand: str, zone: int, amplitude: int, ms: int) -> None:
        self.calls.append((hand, zone, amplitude, ms))


class VendorGlove(HapticGlove):
    name = "vendor-example"
    ZONES = {a: i for i, a in enumerate(ACTUATORS[:7])}            # this "vendor" has no forearm actuator

    def __init__(self, hand: str, sdk: FakeVendorSDK) -> None:
        super().__init__(hand)
        self.sdk = sdk

    def connect(self, now_ms: float = 0.0) -> bool:
        self._actuators = set(self.ZONES)
        self._set_state(ConnectionState.CONNECTED, now_ms)
        return True

    def disconnect(self) -> None:
        self._set_state(ConnectionState.DISCONNECTED)

    def update(self, now_ms: float) -> None:
        pass

    def stop_all(self) -> None:
        for a, z in self.ZONES.items():
            self.sdk.pulse(self.hand, z, 0, 0)

    def _transmit(self, cmd: SafeHapticCommand, now_ms: float) -> bool:      # only limiter-approved commands ever arrive here
        self.sdk.pulse(self.hand, self.ZONES[cmd.actuator], int(round(cmd.intensity * 255)), cmd.duration_ms)
        return True


def main() -> list:
    sdk = FakeVendorSDK()
    gloves = {h: VendorGlove(h, sdk) for h in ("left", "right")}
    for g in gloves.values():
        g.connect(0.0)
    pipe = HapticPipeline(HapticsCfg(), gloves)
    pipe.submit(HapticEvent("PARRY", "right", 0.9), 0.0)
    t = 0.0
    while t < 40.0:
        pipe.update(t)
        t += 1.0
    print(f"{len(sdk.calls)} vendor calls, e.g. {sdk.calls[:3]}")
    return sdk.calls


if __name__ == "__main__":
    main()
