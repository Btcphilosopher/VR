"""Define a new enemy archetype and drop it into a designed encounter."""

import dataclasses

from impact_vr.engine.config import load_config
from impact_vr.engine.modes import GameMode
from impact_vr.engine.session import GameSession
from impact_vr.enemies.archetypes import ARCHETYPES, STREET_FIGHTER, AttackDef, _anim
from impact_vr.enemies.director import EncounterDef, SpawnDef
from impact_vr.simulation.synthetic import SyntheticHandTracker, SyntheticHeadset
from impact_vr.vr.adapters import ControllerHandFallback
from impact_vr.vr.device import VRRuntime


def main() -> list[str]:
    stevedore = dataclasses.replace(
        STREET_FIGHTER, id="stevedore", name="Dock Stevedore", health=95, armor=0.1, speed=1.2,
        attacks=(AttackDef("hay_hook", "hook", 0.6, 0.16, 0.7, 1.4, 0.0, 16, "left", anim=_anim("left", (-0.6, 1.4, 0.0), (0.5, 1.4, 0.55), lat=0.25)),))
    ARCHETYPES[stevedore.id] = stevedore
    head = SyntheticHeadset()
    rt = VRRuntime(head, SyntheticHandTracker(head), None, fallback=ControllerHandFallback())
    rt.start()
    session = GameSession(load_config(), rt, mode=GameMode.TRAINING, seed=3)
    session.director.start(EncounterDef("demo", "Dockside", (SpawnDef("stevedore", (0.0, 4.0), 0.2),)), 0.0)
    session.run(8.0)
    names = sorted({e.data["new"] for e in session.events("ENEMY_STATE")})
    print("states visited:", names)
    return names


if __name__ == "__main__":
    main()
