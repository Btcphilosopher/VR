"""Record a session to a replay file, then re-run it with no VR hardware and verify the identical event digest."""

import tempfile
from pathlib import Path

from impact_vr.simulation.replay import ReplayRecorder, verify_replay
from impact_vr.simulation.scenarios import SCENARIOS


def main() -> bool:
    rec = ReplayRecorder("example")
    session, _ = SCENARIOS["combo_chain"].build(recorder=rec)
    session.run(SCENARIOS["combo_chain"].duration)
    path = rec.save(Path(tempfile.mkdtemp()) / "combo.jsonl.gz")
    report = verify_replay(path)
    print(f"{path.name}: {report.frames} frames, live digest {session.event_digest()}, replay digest {report.actual_digest} -> {'IDENTICAL' if report.ok else 'MISMATCH'}")
    return report.ok


if __name__ == "__main__":
    raise SystemExit(0 if main() else 1)
