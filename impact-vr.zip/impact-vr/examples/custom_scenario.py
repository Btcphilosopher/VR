"""Compose a combat scenario from scripted trajectories and run it headlessly through the whole pipeline."""

from impact_vr.simulation.scenarios import SyntheticCombatScenario, _en


def main() -> dict:
    sc = SyntheticCombatScenario("my_combo", "left hook, then a cross", 4.0,
                                 [(1.0, "hook", "left", {}), (2.0, "cross", "right", {})], enemies=[_en(0.92)])
    s = sc.run()
    strikes = [e.data["strike"]["type"] for e in s.events("STRIKE_DETECTED") if e.data["phase"] == "ended"]
    out = {"strikes": strikes, "hits": s.combat.stats.hits, "haptic_commands": s.pipeline.sent_total, "digest": s.event_digest(), "latency": s.latency.breakdown_text()}
    print(out)
    return out


if __name__ == "__main__":
    main()
