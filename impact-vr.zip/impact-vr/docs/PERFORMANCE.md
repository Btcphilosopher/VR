# Benchmarking and performance

`impact-vr benchmark [--scenario combo_chain] [--seconds N] [--repeat N] [--strict]` prints frame time (mean, p99), achieved fps vs
the target, per-stage costs and the **INPUT -> COLLISION -> HAPTIC** latency breakdown:

```
frame ms: mean 3.98  p99 6.83   (251 fps vs 90 target)
tracking 0.53 | gesture 0.52 | collision 0.38 | gameplay 0.09 | haptic_scheduling 2.18 | hardware_transport 5.20
INPUT -> COLLISION -> HAPTIC total: mean 9.25 ms (p95 9.86)
```

(One machine, pure Python + NumPy; your numbers will differ.) Compute stages (tracking, gesture, collision, gameplay) are measured
with `perf_counter_ns`. **Scheduler and transport figures use the simulated glove** (`glove_latency_ms` 6 +/- 1.5 ms by default;
scheduler time is virtual-time quantised to the 2 ms haptic sub-tick plus measured compute) - they describe the pipeline's structure and
become real measurements only when hardware drives it. The synthetic frame source is included in the frame time, so a real run on
tracked data is not directly comparable.

Where the time goes / how to get headroom: per-joint NumPy work in `HandAnalyzer`, the swept collision loops, and enemy updates in
Python. Hot paths are vectorised (`q_rotate`, `q_mul_many`, the quaternion filter bank); further wins would be a native (Rust/C++)
`HandAnalyzer`/collision kernel behind the same interfaces, or lowering `glove_update_hz`.
Fixed-size ring buffers, bounded queues and object pools keep per-frame allocation bounded on the critical path.
