# Haptic architecture

```
gameplay events -> HapticDirector -> HapticEvent -> HapticScheduler -> calibration profile -> HapticSafetyLimiter
                                                                       -> SafeHapticCommand -> glove driver -> device
```

## Actuators and glove interface
Eight named actuators per hand: thumb, index, middle, ring, little, palm, wrist, forearm (optional on real hardware).
`HapticGlove` (haptics/gloves/base.py) is the hardware-independent driver interface:
`connect / disconnect / send(SafeHapticCommand) / detect_actuators / get_actuator_state / get_connection_state / get_latency / get_status`
plus telemetry (command rate, per-actuator utilisation, dropped commands, latency mean/p95, battery, temperature, comm errors).
`HapticCommand` carries hand, actuator, intensity 0..1, duration, frequency, waveform (sine, square, triangle, impact, buzz, pulse train,
ramp, sustain), attack/release, priority and delay; it is validated on construction (NaN, range).

## Patterns (14)
LIGHT_CONTACT, HEAVY_IMPACT, BLOCK, PARRY, GRAB, OBJECT_PICKUP, WALL_CONTACT, METAL_IMPACT, WOOD_IMPACT, FLESH_IMPACT, ELECTRIC_EFFECT,
WARNING, DAMAGE, SUCCESS (`haptics/patterns.py`). Each is a spatio-temporal sequence of steps (which actuators, when, frequency,
waveform, envelope), never "vibrate everything". Examples: PARRY is a crisp 280 Hz square sweep thumb->little across the palm with no
wrist; GRAB ramps on a sustained pressure across thumb and fingers; BLOCK is a forearm/wrist thud; METAL_IMPACT is a high-frequency
buzz with a second ring; WALL_CONTACT is a dull palm/wrist thump; DAMAGE is a wrist/forearm thud followed by a throb. A test asserts that
every pair of patterns differs measurably (minimum pairwise signature distance 0.80, requirement > 0.5).

## Director: physics -> feeling
`intensity_from_energy`: log-compressed, `energy_ref_j` (haptics.toml, 60 J) maps to ~0.95. Material selects the pattern
(metal -> METAL_IMPACT, wood -> WOOD_IMPACT, brick/concrete -> WALL_CONTACT, flesh -> FLESH or HEAVY by strength, < 1.2 J -> LIGHT_CONTACT).
The strike type biases which actuators carry the contact (knuckles for punches, palm + wrist for palm strikes, forearm for elbows, little
finger + palm for hammer fists). Damage direction biases left/right hand for DAMAGE.

## Scheduler (anti-saturation)
Per (hand, actuator) channel: five priorities (ambient, interaction, combat, major impact, critical damage) with higher priority
pre-empting lower; same-priority overlap **combines** (`1 - prod(1 - i)`) instead of stacking; per-priority cooldowns; repetition
decay keyed per *event* (pattern steps are not "repeats"); minimum command interval; a bounded queue that drops the lowest priority first.

## Pipeline timing
The session ticks the pipeline in sub-steps (`glove_update_hz`, default 500 Hz) inside each 90 Hz frame so pattern offsets of a few
milliseconds are preserved. Latency stages: tracking -> gesture -> collision -> gameplay -> haptic scheduling -> hardware transport
(`telemetry/latency.py`), reported as INPUT -> COLLISION -> HAPTIC.

## Protocol (generic gloves)
`haptics/protocol.py` defines **IMPACT-HAPTIC v1**, our own small framing for DIY/generic gloves: `SOF 0xA5 | VER 1 | TYPE | LEN<=32 |
payload | CRC16-CCITT`. Host->device: HAPTIC, STOP, PING, GET_INFO. Device->host: ACK, STATUS, INFO, PONG, ERROR. Device traffic is
**untrusted**: the parser bounds its buffer, validates version/length/CRC/type and resynchronises after garbage; the decoder range
checks battery, temperature, flags, masks and rates; every violation increments the communication-error counter that the safety
limiter watches (a hostile device trips the limiter - tested). The encoder accepts only `SafeHapticCommand`. Property-based tests feed
arbitrary bytes to the parser.
