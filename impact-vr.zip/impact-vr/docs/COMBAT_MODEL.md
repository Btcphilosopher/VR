# Combat model

## Strike recognition (`combat/strikes.py`)
There are no attack buttons. Each hand's fist-centre trajectory (head-relative, in a yaw-only body frame: x right, y up, z forward) is
buffered; a strike **starts** when speed >= 1.6 m/s with acceleration >= 8 m/s^2 (or speed >= 2.4 m/s), is **provisionally
classified** after 3 samples (so a contact mid-swing already knows the strike type; detection latency is reported per event, ~22 ms at
90 Hz in the synthetic runs), **refines** while the motion continues, and **ends** when speed stays below 0.9 m/s. Peak speed must reach
2.0 m/s and travel 0.12 m; recognitions under confidence 0.5 are discarded. A hand retracting to its guard right after a strike is
recognised as *recovery* and ignored.

Classification is a soft scoring model over: forward / lateral / vertical displacement fractions, heading change (arc) and path
curvature, palm-vs-travel alignment, fist vs open hand, and whether the forearm axis opposes travel (elbow leading).

| strike | defining motion |
|--------|-----------------|
| jab / cross | straight forward fist; **jab = lead hand** (stance in `vr.toml`: orthodox = left leads), **cross = rear hand** |
| hook | curved horizontal path, ending across the body |
| uppercut | upward fist travel |
| hammer fist | downward fist travel |
| palm strike | open hand, palm leading forward |
| backhand | open hand, back of the hand leading, lateral outward |
| elbow strike | forearm folding back so the elbow leads |

`StrikeEvent`: hand, type, origin, direction, velocity, acceleration, duration, arc, confidence, contact point/normal, scores, latency.

## Gestures (`combat/defense.py`)
* **block**: a hand near the head, above chest level, moving slowly -> a virtual guard from hand + forearm geometry (`GuardModel`)
* **parry**: a quick lateral open-hand sweep near the guard (speed 1.2-5 m/s); credited if the attack lands while the sweep is in progress or within `parry_window_s` (0.3 s) after it, and the palm is near the attack path
* **grab**: the hand *closes* (it was open within 0.7 s) while the palm is at an object / enemy limb - a closed-fist guard never grabs
* **push / shove**: open forward-facing palm travelling forward (relative to the body); shove = fast or two-handed
* **duck**: head drops > 0.22 m; **weave**: lateral head offset 0.16-0.32 m; **dodge**: > 0.32 m at speed

## Collision and impact
Each hand's striking volume (fist sphere 4.8 cm, palm sphere 5.5 cm, elbow for elbow strikes) is **swept** from last frame's position to
this frame's against enemy hit volumes (head, torso, core, both arms, both legs, raised shield = WEAPON), dynamic props and static
colliders - a fast punch cannot tunnel through a thin limb. The nearest contact wins; a per-(hand, target, region) lockout prevents
re-hits. Regions: HEAD, TORSO, LEFT_ARM, RIGHT_ARM, LEFT_LEG, RIGHT_LEG, CORE, WEAPON, ENVIRONMENT.

`physics/impact.py` computes, from the *relative* velocity along the contact normal (glancing blows are reduced):

    energy  = 0.5 * m_eff * v_n^2
    impulse = m_eff * v_n * (1 + e)

`m_eff` is a *lumped effective mass per attack type* from `physics.toml` - a gameplay-physics abstraction, **not** a biomechanical or
injury model. Moving targets reduce the closing speed (hitting someone who is backing away hurts less).

## Gameplay damage (separate from physics)
`combat/damage.py`: `damage = max_base * E/(E+E_half) * region * combo * confidence * (1-armor) * (1-block*reduction)` - a saturating
curve (`gameplay.toml [damage]`). Stagger and knockback derive from energy/impulse. Changing damage tuning does not change the physical
impact (tested), and haptic intensity is computed from *energy*, never from damage.

## Defending
An enemy attack is resolved when its striking limb sweeps through the player's head/torso hurtboxes. The guard model evaluates
(a) **coverage** - how well forearms/hands shield the line of the attack, (b) **timing** - a guard raised late only stops part of it
(full guard after 0.22 s), (c) **parry**. Blocked fraction reduces damage by up to 85%; a parry cancels it and staggers the attacker. Grabs
(grappler) are unblockable and escaped with a shove/push. Enemy attacks commit their aim 65% through the wind-up, so a duck/dodge
*after* that point makes the strike miss.

## Enemies (`enemies/`)
States: IDLE, PATROL, NOTICE, APPROACH, ATTACK, BLOCK, EVADE, STAGGER, RETREAT, DEFEATED. Archetypes (data only): street fighter,
heavy bruiser (armoured, knockback-resistant), agile attacker, shielded (shield durability, breakable), grappler, ranged (throws
projectiles), boss (phases at 66% / 33% health, combos). Attacks have a readable wind-up (>= 0.28 s, always longer than the strike), an
active window and a recovery. Enemies react to the player's *actual* strikes in flight (block / evade). The `EncounterDirector` grants
**attack tokens** (max 2 simultaneous attackers by default), places enemies on a tactical ring and runs *designed encounters*
(`world/district.py`: Arch Street, Loading Yard, Under the Viaduct, The Foreman), not hordes.
