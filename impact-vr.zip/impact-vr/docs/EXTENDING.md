# Extending the engine

## A new enemy
Add an `Archetype` in `enemies/archetypes.py` (health, speed, preferred distance, armor, `AttackDef`s with wind-up/active/recovery
and a fist `AttackAnim`), register it in `ARCHETYPES`, then use it in a `SpawnDef` inside an `EncounterDef` (`world/district.py`). Keep the
wind-up longer than the active window (a test enforces >= 0.28 s and windup > active).

## A new combat move (strike or gesture)
* **Strike**: add a score in `StrikeDetector._classify` (a soft function of the movement features), add the type to `STRIKE_TYPES`, give it an effective mass in `physics.toml [effective_mass_kg]`, a contact bias in `haptics/director.py: STRIKE_BIAS`, and a synthetic trajectory in `simulation/synthetic.py` + `MOVES`; then add a row to the parametrised test in `tests/test_strikes_gestures.py`.
* **Gesture**: add recognition in `GestureRecognizer`, handle the event in `CombatSystem.on_gesture`.

## A new haptic pattern
Add a `HapticPattern` in `haptics/patterns.py`, map it in `HapticDirector`. The distinctness test will tell you if it is too close to an existing one.

## A new scenario
```python
from impact_vr.simulation.scenarios import SyntheticCombatScenario, _en
sc = SyntheticCombatScenario("my_combo", "left hook then cross", 4.0, [(1.0, "hook", "left", {}), (2.0, "cross", "right", {})], enemies=[_en(0.92)])
session = sc.run()                       # headless; session.events("IMPACT_CALCULATED"), session.event_digest() ...
```
See `examples/`.

## A new material / world prop
`physics.toml [materials.<name>]` (restitution, hardness, haptic pattern) and `world/district.py` (`_solid(level, name, lo, hi, material, palette_key)`).
