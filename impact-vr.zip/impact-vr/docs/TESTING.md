# Testing

`pytest` runs 112 tests (~2 minutes): hand tracking, coordinate transforms (property-based), gesture and strike recognition (all eight
strikes on both hands, noise robustness, no false positives while ducking or moving slowly), swept collision (incl. tunnelling),
impact and damage (monotonicity, glancing blows, physics/damage separation), enemy state machines and tokens, haptic patterns (pairwise
distinctness), scheduler priority/combining/decay/rate limits, safety limiting (clamps, duty cycle, rates, thermal latch, comm
budget, un-forgeable `SafeHapticCommand`, property tests), protocol round-trips, **fuzzing** (`hypothesis` feeds arbitrary bytes
to the parser), hostile-device traffic, glove state machines, calibration (incl. abort without saving), latency measurement,
structured logging, audio spatialisation, locomotion modes, the pygame app, the CLI, and the determinism/replay checks below.

```bash
pytest                         # everything
pytest tests/test_haptics.py   # one area
ruff check src tests && mypy src/impact_vr
```

## Determinism and replay
* `GameSession` reads only the injected `SimClock` and seeded named RNG streams; input frames are quantised to 1e-5.
* `ReplayRecorder` writes JSON-lines (`impact-vr-replay` v1): header (seed, mode, level, encounter, scene setup, config hash), one record per frame (head, controllers, both 26-joint hands, events), footer (event digest).
* `verify_replay` re-runs a recording through a fresh session (no headset, no glove) and compares events frame by frame and the final SHA-256 digest. All ten scenarios replay bit-identically; tampering with the input changes the digest (tested).

## Synthetic simulation mode
`simulation/synthetic.py` scripts hands (all strike/gesture trajectories), the head (duck, weave, dodge keyframes), controllers, sensor
noise and tracking dropouts. `simulation/scenarios.py` composes them with passive/scripted enemies:
`impact-vr simulate --list`. Add your own in a few lines (`examples/custom_scenario.py`).
