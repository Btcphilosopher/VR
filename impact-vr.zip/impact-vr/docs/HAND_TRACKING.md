# Hand tracking and motion analysis

## Skeleton
26 joints per hand in OpenXR `XR_EXT_hand_tracking` order (`hands.skeleton.Joint`: PALM, WRIST, then thumb metacarpal..tip, then
index/middle/ring/little metacarpal..tip). `build_skeleton(hand, wrist_pose, FingerCurls)` is a forward-kinematics rig (MCP 80 deg, PIP
100 deg, DIP 70 deg at full curl) used by the synthetic tracker and by the controller fallback; `finger_bends` / `flexion_from_positions`
invert it (round-trip tested).

## Filtering (runtime-switchable)
`tracking/filters.py`, configured by `vr.toml [filter]` and changeable at runtime with `HandAnalyzer.configure(kind="ema", ...)` (validated):

| kind | behaviour |
|------|-----------|
| `none` | pass-through |
| `ema` | exponential smoothing (`ema_alpha`) |
| `moving_average` | window `ma_window` |
| `one_euro` (default) | Casiez et al.: jitter-free at rest, cutoff grows with speed (`one_euro_min_cutoff`, `one_euro_beta`, `one_euro_d_cutoff`) |
| `velocity_aware` | blends a heavy and a light exponential filter by speed (`va_*`) |

All use the real frame timestamp (irregular dt, dropped frames are safe). Orientations use a vectorised speed-adaptive nlerp. A fast
punch passes through a One Euro filter with far less lag than a heavy EMA with the same rest jitter (tested).

## HandState
Per frame: filtered positions/orientations, per-joint velocity and acceleration (low-passed finite differences, `velocity_cutoff_hz`),
wrist angular velocity, finger flexion (0..1), `openness`, `fist_prob` (needs *every* finger curled, so pointing is not a fist),
`pointing_prob`, `grip_prob`, palm normal / forward / side axes, `fist_center` (knuckle row), `fist_velocity`, estimated elbow.

## Head-relative analysis
The session analyses each hand **relative to the head** (head translation subtracted before filtering, added back afterwards for
world-space use). Ducking, leaning or walking therefore move the hand and head together and produce no strike; a punch thrown while
ducking still carries the head's velocity into the *impact* speed in world space.

## Runtime fallbacks
`VRRuntime` chooses per hand: skeletal tracking if `confidence >= vr.min_hand_confidence`, otherwise a hand synthesised from the
controller. Dropouts are handled at the frame level (`tracked=False` samples are ignored and abort an in-progress strike).

## Tracking calibration
`impact-vr calibrate --tracking` (or the TRACKING CALIBRATION screen): stand still, measure eye height, head and hand jitter (RMS mm),
confidence and controller-fallback share, and get recommended One Euro settings (more jitter -> lower `min_cutoff`). `result.apply(cfg)`
returns an updated validated `Config`.
