# Troubleshooting

| symptom | likely cause / fix |
|---------|--------------------|
| `impact-vr diagnostics` shows `OpenXR runtime: N/A` | expected without pyopenxr and a runtime; simulation mode works. See docs/VR_OPENXR.md |
| no sound / ALSA warnings in a container | `SDL_AUDIODRIVER=dummy` (set automatically for headless CLI commands) or `audio.toml backend = "null"` |
| window does not open on a headless box | `SDL_VIDEODRIVER=dummy`; use `impact-vr simulate` instead of `run` |
| strikes are missed / mis-classified on a real tracker | check `impact-vr calibrate --tracking` for jitter and confidence; tune `strike thresholds` (`StrikeTuning`) and the filter; thresholds were tuned on synthetic data only |
| punches do not register damage | hits below `physics.min_contact_speed` (0.6 m/s) are ignored; follow through - contact at the end of a punch has low speed |
| glove commands "REJECTED by safety/limits" in `glove-test` | per-actuator rate/duty limits or an uncalibrated ceiling (0.5); calibrate, or inspect `limiter.report.rejected` |
| `SAFETY_TRIP` appears | thermal limit, comm-error budget or manual stop; read `limiter.trip_reason`; reset with F5 / `limiter.reset()` only after fixing the cause |
| a generic glove stays `connecting` then `error` | no INFO reply within `handshake_timeout_ms`; check transport and firmware framing (CRC16-CCITT, version 1) |
| replay reports MISMATCH | different config/seed/scene than the recording, or a code change altered behaviour; compare `first_mismatch_frame` |
| frame time above budget | `impact-vr benchmark`; lower `glove_update_hz`, `graphics.resolution`, or run headless |
| settings keep reverting | they are saved under `~/.impact_vr/configs` (`IMPACT_VR_HOME`) - `--config` selects another directory |
