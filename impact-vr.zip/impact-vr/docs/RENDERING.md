# Rendering, audio, digital twin

The simulation (everything the combat depends on) never imports rendering. `rendering/` and `audio/` are consumers of session state and the event bus.

* **Software renderer** (`rendering/software.py`): pygame, painter's-algorithm boxes with per-face shading, fog, sodium/cold lighting from the level's lights. First-person from the head pose; draws the player's tracked hand skeletons. It exists so the prototype is playable and inspectable without a GPU stack.
* **Not provided**: a stereo / OpenXR swapchain renderer and a ModernGL renderer. `rendering.software.Renderer` is the protocol a GPU renderer would implement; this repository does **not** claim one.
* **Developer overlay** (F3): FPS, frame and VR frame time, tracking confidence/source, hand velocities, last gesture/strike/target/impact energy/damage, haptic latency and peak intensity, safety state, enemy state.
* **Digital twin** (F4, `rendering/digital_twin.py`): orbitable inspector of both hands - skeleton, fist/palm/forearm collision volumes, velocity vectors, detected strike with confidence, recent impact vectors, and live per-actuator glove output at the anatomical sites.
* **Glove monitor** (`haptics/monitor.py`): LEFT HAND / RIGHT HAND actuator bars (pygame HUD or text via `impact-vr glove-test`).
* **Audio** (`audio/engine.py`): backend abstraction (null / recording / pygame) with spatialised one-shots synthesised procedurally (no binary assets): punches, blocks, parries, footsteps, enemy swings, impacts by material, object interaction, a quiet haptic-confirmation tick. Each sound also emits an `AUDIO` event for tests/observability.
* **Palette** (`rendering/palette.py`): brick, concrete, steel, timber, wet asphalt; sodium amber and cold arch spill; no neon.
