# Calibration

## Haptic calibration (`haptics/calibration.py`, `impact-vr calibrate`)
1. **CONNECT** each glove (aborts without saving if one cannot connect)
2. **DETECT** actuators (intersection across both hands)
3. **TEST** each actuator with a gentle pulse; any actuator the user does not feel is excluded (max 0)
4. **SET maximum** per actuator: ramp 0.10, 0.15, ... until the first "too strong"; the previous level is the ceiling
5. **SET response curve**: `linear`, `soft` (gentler low end) or `firm`
6. **SET comfort limit** (overall cap)
7. **TEST simultaneous** output at half the comfort limit on all working actuators; "uncomfortable" scales the limit by 0.7
8. **SAVE** the profile (JSON, `~/.impact_vr/haptic_profile_<glove>.json`); a corrupt file is renamed `.corrupt` and defaults are used

Every pulse goes through the pipeline *and the safety limiter*. `ScriptedResponder` provides a deterministic simulated user for
CI (`impact-vr calibrate --scripted`); `ConsoleResponder` is the interactive one.

## Tracking calibration
See docs/HAND_TRACKING.md. Both calibrations are also available from the main menu.
