# Adding glove hardware

Hardware is added **only** by implementing `HapticGlove` (`haptics/gloves/base.py`). Nothing else in the engine changes.

## Option A - your device speaks IMPACT-HAPTIC v1 (DIY / generic)
Use `GenericHapticGlove` with a transport; the thin subclasses `SerialHapticGlove`, `BLEHapticGlove`, `HIDHapticGlove` exist, and
`UDPTransport` / `LoopbackTransport` are fully tested. Firmware needs to answer GET_INFO (actuator mask, max rate, version), PING,
ACK each HAPTIC frame (seq echoed), send STATUS periodically (battery %, temperature, flags, error count, active mask) and honour STOP.
`VirtualGloveFirmware` (`haptics/firmware_sim.py`) is a reference implementation of the device side. **Serial/BLE/HID/WebSocket
transports are hardware-untested.**

```python
from impact_vr.haptics.gloves.generic import GenericHapticGlove
from impact_vr.haptics.transports import UDPTransport
glove = GenericHapticGlove("right", UDPTransport(("192.168.1.50", 9000)))
```

## Option B - a vendor SDK
Subclass `HapticGlove`, translate `SafeHapticCommand` (actuator, intensity 0..1, duration, frequency, waveform, attack/release,
priority) into the vendor's documented API, and populate `self._actuators` (detected actuators), `self._state`, and the telemetry
object (`self.telemetry.on_latency/on_drop/on_error`, battery, temperature). Call `self._notify_applied(cmd.id, latency_ms)` when the
device confirms a command so the INPUT -> COLLISION -> HAPTIC trace completes. `examples/custom_glove_adapter.py` is a worked skeleton.
**This repository does not implement any commercial SDK** - write it against the vendor's own documentation.

## Checklist for a new driver
* `send()` is inherited and enforces `SafeHapticCommand`; implement `_transmit`, `update`, `stop_all`, `connect`, `disconnect`
* map actuators the device lacks to "not present" (commands are dropped and counted, never guessed)
* report real temperature / error counts - the limiter trips on them
* run `impact-vr glove-test` and the calibration workflow against it; add it to `tests/` with a fake transport
