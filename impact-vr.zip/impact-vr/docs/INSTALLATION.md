# Installation

Requires Python 3.12+.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .              # runtime: numpy, pydantic, scipy, pygame
pip install -e ".[dev]"       # + pytest, hypothesis, ruff, mypy
impact-vr diagnostics
```

Optional extras (none are needed for simulation mode):

| Extra | Purpose | Status |
|-------|---------|--------|
| `xr` | `pyopenxr` for a real OpenXR session | adapter is a stub (see `docs/VR_OPENXR.md`) |
| `hw` | `pyserial`, `bleak`, `hidapi`, `websockets` for generic glove transports | transports are hardware-untested |
| `gl` | `moderngl`, `PyOpenGL` | **no GPU renderer is shipped**; reserved for one |
| `cv` | `opencv-python` | not required by the engine |

Headless machines (CI): set `SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy`. The CLI sets these automatically for
`simulate`, `glove-test`, `calibrate`, `benchmark` and `diagnostics`.

Configuration lives in `configs/*.toml` (override with `impact-vr --config DIR ...`); settings changed in the game's SETTINGS screen are
saved to `~/.impact_vr/configs` (override the directory with `IMPACT_VR_HOME`). Haptic calibration profiles are saved to
`~/.impact_vr/haptic_profile_<glove>.json`.
