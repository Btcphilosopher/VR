# Architecture

## The layer chain

| # | Layer | Module(s) | Contract |
|---|-------|-----------|----------|
| 1 | REAL HAND | (the user) | - |
| 2 | TRACKING | `vr/device.py`, `vr/adapters.py`, `tracking/filters.py` | `VRHeadset`, `VRController`, `VRHandTracker` -> `VRFrame` (engine frame, per-hand source: `hand_tracking` / `controller`) |
| 3 | SKELETON | `hands/skeleton.py` | 26 joints in OpenXR `XR_EXT_hand_tracking` order; `build_skeleton` is the forward-kinematics rig used by synthetic input and the controller fallback |
| 4 | MOTION ANALYSIS | `hands/analyzer.py` | `HandAnalyzer` -> `HandState`: filtered positions, velocity, acceleration, angular velocity, finger flexion, openness, fist / pointing / grip probability |
| 5 | COMBAT INTERPRETATION | `combat/strikes.py`, `combat/defense.py` | `StrikeEvent`, `GestureEvent` derived from trajectories |
| 6 | PHYSICS | `physics/*` | swept sphere-vs-capsule/AABB, spatial hash, props |
| 7 | COLLISION | `combat/system.py` | per-hand swept volumes vs enemy hit volumes / props / statics / hazards |
| 8 | IMPACT MODEL | `physics/impact.py` | `PhysicalImpact` (energy, impulse, closing speed) - *physical*, independent of damage |
| 9 | GAMEPLAY | `combat/damage.py`, `enemies/*`, `engine/session.py` | damage, stagger, knockback, guard resolution, encounters, modes |
| 10 | HAPTIC EVENT | `haptics/director.py` | gameplay events -> `HapticEvent(pattern, hand, intensity, priority, bias)` |
| 11 | HAPTIC SAFETY | `haptics/scheduler.py` then `haptics/safety.py` | arbitration, then the independent limiter that alone mints `SafeHapticCommand` |
| 12 | GLOVE DRIVER | `haptics/gloves/*`, `haptics/protocol.py`, `haptics/transports.py` | drivers accept **only** `SafeHapticCommand` |
| 13 | PLAYER | (the glove) | - |

Each layer talks to its neighbours through plain data types. You can replace the tracker (OpenXR instead of synthetic), the glove
(vendor SDK instead of simulated), the renderer, the audio backend or the enemy AI without touching the others.

## The frame (`engine/session.py: GameSession.step`)

1. poll a `VRFrame` from the source (a `VRRuntime`, or a `ReplaySource`); the frame is quantised to 1e-5 so live and replayed runs are bit-identical
2. **tracking**: each hand is analysed *relative to the head* (so ducking, leaning and walking never look like a punch), then shifted back to absolute tracking space
3. locomotion updates the rig (room-scale / smooth / teleport, snap/smooth turn, arena bounds)
4. **gesture**: strike detector (head-relative) and gesture recogniser (guard, parry, grab, push, shove, duck, weave, dodge)
5. **collision**: swept player-hand volumes vs enemies, props, statics, hazards -> `ImpactEvent` + `PhysicalImpact` -> damage -> enemy hit reaction
6. **gameplay**: enemies update (AI, attack tokens), enemy attacks vs the player's hurtboxes, guard/parry/dodge resolution, projectiles, props, mode progression
7. the haptic director converts the frame's gameplay events to haptic events (after gameplay has resolved)
8. haptic sub-ticks (500 Hz default) run scheduler -> calibration profile -> safety limiter -> glove, so multi-millisecond pattern timing survives a 90 Hz frame
9. audio, structured logging, recorder

Two coordinate spaces: **tracking space** (continuous physical motion: used for recognition) and **world space** (tracking space
transformed by the locomotion *rig*: used for collision). Strikes are never confused with locomotion because only the former feeds
the recogniser.

## Conventions

* World frame: x right, y up, **z forward** (left-handed "game" frame). Quaternions are xyzw.
* OpenXR is x right, y up, **-z forward**. `openxr_to_world` mirrors z (and flips the quaternion's x/y); it is applied **only** inside VR adapters and is covered by involution / handedness tests.
* Hand-local frame: +z along the fingers, +y out of the back of the hand, the palm normal is -y; the right hand's radial (thumb) side is -x.
* Units: metres, seconds, kilograms, joules (physics); milliseconds only for the haptics/latency layers.

## Events

Typed names in `engine/events.py` (`VR_FRAME`, `HAND_TRACKED`, `GESTURE_DETECTED`, `STRIKE_DETECTED`, `COLLISION`, `IMPACT_CALCULATED`,
`DAMAGE_APPLIED`, `BLOCK`, `PARRY`, `GRAB`, `ENEMY_*`, `PLAYER_DAMAGED`, `HAPTIC_SCHEDULED`, `HAPTIC_SENT`, `SAFETY_TRIP`, ...). Every event
carries session id, frame id and simulation time, so a hit can be followed from `STRIKE_DETECTED` to `HAPTIC_SENT`.

## Determinism

All simulation code reads the injected `SimClock` and named seeded RNG streams. A recorded input stream replays to the same event
digest (a SHA-256 over canonicalised, rounded events). See `docs/TESTING.md` (record/replay).
