# Haptic safety

**The software limiter is defence in depth, not a certified safety system.** A real glove must also enforce its own hardware limits
(current limiting, thermal cut-off, watchdog). Never assume maximum actuator power is safe or comfortable.

## HapticSafetyLimiter (`haptics/safety.py`)
Independent of gameplay (it imports nothing from combat/enemies/session). Every command passes through `process()`, which returns an
opaque `SafeHapticCommand` or `None`. `SafeHapticCommand` can only be constructed by the limiter, is immutable, and **glove drivers and the
wire encoder reject anything else** - so gameplay, the scheduler, a replay or a malformed device packet cannot reach hardware without
these checks (tested, including attempts to forge a command).

| check | config (`haptics.toml [safety]`) |
|-------|----------------------------------|
| maximum intensity (hard cap, per-actuator calibrated ceiling, comfort limit) | `hard_max_intensity` 0.85 |
| maximum duration | `max_duration_ms` 600 |
| duty cycle per actuator over a sliding window | `max_duty_cycle` 0.5 over `duty_window_ms` 1000 |
| command rate per actuator / global | `max_commands_per_actuator_hz` 60, `max_commands_total_hz` 300 |
| thermal: derate above warn, **latched trip** at the limit | `thermal_warn_c` 38, `thermal_limit_c` 43 |
| connection state | `require_connection` |
| communication error budget | `max_comm_errors` 25 |

A trip stops all gloves, clears the scheduler and latches until `limiter.reset()` (F5 in the game; F12 is a manual emergency stop).
Frequencies are clamped to 20-400 Hz. Uncalibrated gloves are capped at `uncalibrated_max_intensity` (0.5). Thermal state comes from the
glove's own telemetry; the simulated glove has a thermal model so the trip path is tested end to end.

## Comfort
Calibration (docs/CALIBRATION.md) ramps from 0.10 in 0.05 steps and stops at the first "too strong", per actuator, then asks for a
comfort limit and a simultaneous-output check. The saved ceiling can never exceed `hard_max_intensity`. Players can lower
`master_intensity` in SETTINGS at any time.
