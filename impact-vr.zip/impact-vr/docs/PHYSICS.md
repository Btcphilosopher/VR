# Physics

* **Shapes** (`physics/shapes.py`): sphere, capsule, AABB; discrete contact tests and **swept** sphere-vs-capsule/AABB (adaptive sub-sampling with spacing <= the smaller radius, capped by `sweep_substeps_max`), returning the *first* contact with a normal pointing from target to striker.
* **Broadphase**: `SpatialHash` (uniform grid over static AABBs). Tested against brute force (may over-report, never under-report).
* **Props** (`physics/world.py`): point-mass props with optional spring return (the heavy bag), free flight with gravity, ground bounce and reduced drag in flight (thrown crates). Held props follow the hand and inherit its velocity on release; thrown props that exceed 1.8 m/s sweep against enemy hit volumes and deliver a `thrown_object` impact.
* **Impact model** (`physics/impact.py`): see docs/COMBAT_MODEL.md. Materials (`physics.toml`): flesh, metal, wood, brick, concrete, cloth, rubber, each with restitution, hardness and the haptic pattern they imply.
* **Fixed step**: `physics.step_hz` (90). The simulation advances one fixed step per VR frame; `FixedStepper` is used by the pygame app to decouple real time from simulation time.

Everything in `physics/` is pure NumPy with no gameplay imports.
