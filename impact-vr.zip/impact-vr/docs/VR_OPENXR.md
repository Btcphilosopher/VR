# VR / OpenXR setup

**Status: hardware-untested.** There was no headset, runtime or hand-tracking device available when this was written, so
`vr/adapters.py: OpenXRAdapter` is a documented stub that raises `VRUnavailable`. Everything downstream is exercised through the same
interfaces by synthetic devices and recorded replays.

## What the adapter must do

Implement `VRHeadset`, `VRController` and `VRHandTracker` (see `vr/device.py`) on top of pyopenxr:

1. create an instance with `XR_EXT_hand_tracking` (and optionally `XR_FB_hand_tracking_aim`), a session, and a reference space (STAGE or LOCAL)
2. per frame: `xrWaitFrame` -> predicted display time; `xrLocateSpace` for the head and controller aim/grip poses; `xrLocateHandJointsEXT` for each hand (26 joints, same order as `hands.skeleton.Joint`)
3. convert **every** pose with `openxr_to_world(position, orientation)` (z mirror) - `OpenXRAdapter.convert_joints` shows the reference conversion
4. fill `HandSkeleton(positions, orientations, confidence, tracked)`; `confidence` can come from `XrHandJointLocationEXT` validity flags (tracked = position & orientation valid)
5. populate `ControllerState` (trigger, grip, stick, buttons) from the action set

`VRRuntime` handles the rest: play-space recentering (`runtime.recenter()`), frame-time/missed-frame accounting, and per-hand
fallback. If skeletal tracking confidence drops below `vr.min_hand_confidence`, a hand is synthesised from the controller
(`ControllerHandFallback`: grip squeezes middle/ring/little, trigger the index, thumb curls with either), so the game stays
playable with plain controllers.

## Wiring it up

```python
runtime = VRRuntime(MyOpenXRHeadset(), MyOpenXRHands(), MyOpenXRControllers(), target_fps=90, fallback=ControllerHandFallback())
runtime.start(); runtime.recenter()
session = GameSession(cfg, runtime, mode=GameMode.ENCOUNTER)
while running: session.step()          # one call per rendered frame
```

`GameSession` needs only `poll(t) -> VRFrame`, so a real device and a replay are interchangeable.

## Not provided

A stereo renderer. Rendering a view for a headset is out of scope of this repository (see `docs/RENDERING.md`).
