import math

import numpy as np
import pytest
from hypothesis import given
from hypothesis import strategies as st

from impact_vr.engine.mathx import (
    QIDENT, Transform, body_frame, dist_point_segment, openxr_to_world, q_angular_velocity, q_axis_angle, q_conj, q_from_euler, q_from_fwd_up, q_from_yaw, q_mul,
    q_rotate, q_slerp, q_to_yaw, v3, world_to_openxr,
)
from impact_vr.vr.device import PlaySpace
from impact_vr.vr.types import VRPose

f3 = st.floats(-5, 5, allow_nan=False, allow_infinity=False)
angle = st.floats(-math.pi, math.pi, allow_nan=False)


@given(f3, f3, f3, angle, angle, angle)
def test_rotation_preserves_length_and_inverts(x, y, z, a, b, c):
    q, v = q_from_euler(a, b, c), v3(x, y, z)
    r = q_rotate(q, v)
    assert np.linalg.norm(r) == pytest.approx(np.linalg.norm(v), abs=1e-9)
    assert q_rotate(q_conj(q), r) == pytest.approx(v, abs=1e-9)


@given(angle, angle, angle, angle)
def test_quaternion_composition_matches_sequential_rotation(a, b, c, d):
    q1, q2, v = q_from_euler(a, b, 0), q_from_euler(c, d, 0), v3(0.3, -0.7, 1.1)
    assert q_rotate(q_mul(q1, q2), v) == pytest.approx(q_rotate(q1, q_rotate(q2, v)), abs=1e-9)


@given(f3, f3, f3, angle)
def test_transform_inverse_roundtrip_and_compose(x, y, z, yaw):
    t, u, p = Transform(v3(x, y, z), q_from_yaw(yaw)), Transform(v3(1, 2, 3), q_from_yaw(0.4)), v3(0.2, 0.5, -1.0)
    assert t.inverse().apply(t.apply(p)) == pytest.approx(p, abs=1e-9)
    assert t.compose(u).apply(p) == pytest.approx(t.apply(u.apply(p)), abs=1e-9)


@given(f3, f3, f3, angle, angle, angle)
def test_openxr_conversion_is_an_involution_and_preserves_distances(x, y, z, a, b, c):
    p, q = v3(x, y, z), q_from_euler(a, b, c)
    p2, q2 = openxr_to_world(p, q)
    p3, q3 = world_to_openxr(p2, q2)
    assert p3 == pytest.approx(p) and abs(float(q3 @ q)) == pytest.approx(1.0, abs=1e-9)
    assert np.linalg.norm(p2) == pytest.approx(np.linalg.norm(p))


def test_openxr_forward_axis_and_handedness():
    _, q = openxr_to_world(v3(), QIDENT)
    assert q_rotate(q, v3(0, 0, 1)) == pytest.approx(v3(0, 0, 1))                      # OpenXR identity looks down -z; engine +z forward
    assert openxr_to_world(v3(0, 0, -1), QIDENT)[0] == pytest.approx(v3(0, 0, 1))
    _, q_left = openxr_to_world(v3(), q_axis_angle(v3(0, 1, 0), math.radians(30)))      # +30deg about +y turns -z towards -x (left)
    f = q_rotate(q_left, v3(0, 0, 1))
    assert f[0] < 0 and f[2] > 0


def test_yaw_extraction_body_frame_and_fwd_up():
    q = q_from_euler(0.7, 0.3, 0.1)
    assert q_to_yaw(q) == pytest.approx(0.7, abs=1e-9)
    assert body_frame(v3(1, 1.6, 2), q).apply_dir(v3(0, 0, 1)) == pytest.approx(v3(math.sin(0.7), 0, math.cos(0.7)))
    q1 = q_from_fwd_up(v3(1, 0, 0), v3(0, 1, 0))
    assert q_rotate(q1, v3(0, 0, 1)) == pytest.approx(v3(1, 0, 0), abs=1e-9) and q_rotate(q1, v3(0, 1, 0)) == pytest.approx(v3(0, 1, 0), abs=1e-9)
    assert q_rotate(q_from_fwd_up(v3(0, 1, 0), v3(0, 0, -1)), v3(0, 0, 1)) == pytest.approx(v3(0, 1, 0), abs=1e-9)


def test_slerp_angular_velocity_and_point_segment():
    a, b = q_from_yaw(0.0), q_from_yaw(1.0)
    assert q_to_yaw(q_slerp(a, b, 0.5)) == pytest.approx(0.5, abs=1e-6)
    assert q_angular_velocity(a, b, 0.5) == pytest.approx(v3(0, 2.0, 0), abs=1e-6)
    d, t = dist_point_segment(v3(0, 1, 0), v3(-1, 0, 0), v3(1, 0, 0))
    assert d == pytest.approx(1.0) and t == pytest.approx(0.5)


def test_playspace_recenter_moves_head_to_origin_facing_forward():
    ps = PlaySpace()
    head = VRPose(v3(2.0, 1.7, -1.0), q_from_yaw(0.9))
    ps.recenter(head)
    h2 = ps.apply_pose(head)
    assert h2.p == pytest.approx(v3(0, 1.7, 0), abs=1e-9) and q_to_yaw(h2.q) == pytest.approx(0.0, abs=1e-9)
