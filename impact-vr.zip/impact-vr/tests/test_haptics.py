import itertools

import pytest
from hypothesis import given, settings
from hypothesis import strategies as st
from pydantic import ValidationError

from impact_vr.engine.config import HapticsCfg, SafetyCfg, SchedulerCfg
from impact_vr.haptics import protocol as proto
from impact_vr.haptics.calibration import CalibrationSession, ScriptedResponder
from impact_vr.haptics.firmware_sim import VirtualGloveFirmware
from impact_vr.haptics.gloves.base import ConnectionState
from impact_vr.haptics.gloves.generic import GenericHapticGlove, SerialHapticGlove
from impact_vr.haptics.gloves.simulated import SimulatedHapticGlove, make_simulated_pair
from impact_vr.haptics.model import ACTUATORS, Actuator, HapticCommand, HapticEvent, HapticPriority as P, Waveform
from impact_vr.haptics.patterns import PATTERNS, pattern_names, signature_distance
from impact_vr.haptics.pipeline import HapticPipeline
from impact_vr.haptics.profile import CalibrationProfile, ResponseCurve
from impact_vr.haptics.safety import HapticSafetyLimiter, SafeHapticCommand, SafetyViolation, TripReason
from impact_vr.haptics.scheduler import HapticScheduler
from impact_vr.haptics.transports import HIDTransport, LoopbackTransport, TransportUnavailable
from impact_vr.haptics.waveforms import amplitude, envelope


def cmd(actuator="index", intensity=0.6, dur=80, hand="right", prio=P.COMBAT, wf=Waveform.IMPACT, tag="t"):
    return HapticCommand(hand=hand, actuator=actuator, intensity=intensity, duration_ms=dur, waveform=wf, priority=prio, tag=tag)


def test_command_validation():
    for bad in (dict(intensity=1.4), dict(intensity=float("nan"))):
        with pytest.raises(ValidationError):
            HapticCommand(actuator="index", duration_ms=10, **bad)
    with pytest.raises(ValidationError):
        HapticCommand(actuator="index", intensity=0.5, duration_ms=0)
    with pytest.raises(ValidationError):
        HapticCommand(actuator="elbow", intensity=0.5, duration_ms=10)


def test_patterns_exist_distinct_and_designed():
    need = {"LIGHT_CONTACT", "HEAVY_IMPACT", "BLOCK", "PARRY", "GRAB", "OBJECT_PICKUP", "WALL_CONTACT", "METAL_IMPACT", "WOOD_IMPACT", "FLESH_IMPACT", "ELECTRIC_EFFECT", "WARNING", "DAMAGE", "SUCCESS"}
    assert need <= set(pattern_names())
    assert min(signature_distance(PATTERNS[a], PATTERNS[b]) for a, b in itertools.combinations(sorted(need), 2)) > 0.5
    acts = lambda n: {c.actuator for c in PATTERNS[n].expand("right", 1.0)}   # noqa: E731
    assert Actuator.WRIST not in acts("PARRY") and {Actuator.PALM, Actuator.INDEX, Actuator.LITTLE} <= acts("PARRY")
    assert min(c.frequency for c in PATTERNS["PARRY"].expand("right", 1.0)) > 200
    assert acts("GRAB") >= {Actuator.THUMB, Actuator.INDEX, Actuator.MIDDLE} and max(c.duration_ms for c in PATTERNS["GRAB"].expand("right", 1.0)) > 250
    assert PATTERNS["HEAVY_IMPACT"].duration_ms > 3 * PATTERNS["LIGHT_CONTACT"].duration_ms
    assert max(c.frequency for c in PATTERNS["METAL_IMPACT"].expand("right", 1)) > max(c.frequency for c in PATTERNS["FLESH_IMPACT"].expand("right", 1))
    assert len(acts("HEAVY_IMPACT")) > 5 and len(acts("LIGHT_CONTACT")) <= 3
    base = {c.actuator for c in PATTERNS["FLESH_IMPACT"].expand("right", 1.0)}
    assert Actuator.INDEX in base and Actuator.INDEX not in {c.actuator for c in PATTERNS["FLESH_IMPACT"].expand("right", 1.0, bias={Actuator.INDEX: 0.0})}


@given(st.sampled_from(list(Waveform)), st.floats(0, 600), st.floats(5, 500), st.floats(20, 400))
def test_waveforms_are_bounded_and_end(wf, t, dur, f):
    assert 0.0 <= amplitude(wf, t, dur, f, 2, 20) <= 1.0
    assert amplitude(wf, dur + 1, dur, f) == 0.0 and amplitude(wf, -1, dur, f) == 0.0 and envelope(dur / 2, dur, 5, 5) <= 1.0


def tick_all(s, t0, t1, step=2.0):
    out, t = [], t0
    while t <= t1:
        out += [c for c, _ in s.tick(t)]
        t += step
    return out


def test_scheduler_arbitration_priority_combining_decay_and_rate():
    s = HapticScheduler(SchedulerCfg())
    s.submit(HapticEvent("PARRY", "right", 0.9), 0.0)
    acts = [c.actuator for c in tick_all(s, 0.0, 40.0, 1.0)]
    assert acts[0] is Actuator.PALM and acts.index(Actuator.THUMB) < acts.index(Actuator.LITTLE)           # sweep order preserved
    s = HapticScheduler(SchedulerCfg())
    s.submit(HapticEvent("DAMAGE", "right", 1.0), 0.0)
    assert any(c.priority is P.CRITICAL_DAMAGE for c in tick_all(s, 0.0, 5.0))
    s.submit(HapticEvent("WARNING", "right", 0.9), 10.0)
    out = tick_all(s, 10.0, 60.0)
    assert not any(c.tag == "WARNING" and c.actuator in (Actuator.WRIST, Actuator.FOREARM) for c in out) and sum(s.stats.suppressed.values()) > 0
    s = HapticScheduler(SchedulerCfg())
    s.submit(HapticEvent("FLESH_IMPACT", "right", 0.5), 0.0)
    s.submit(HapticEvent("FLESH_IMPACT", "right", 0.5), 0.0)
    idx = [c for c in tick_all(s, 0.0, 4.0) if c.actuator is Actuator.INDEX]
    assert len(idx) == 1 and idx[0].intensity > 0.5 * 0.9 * 0.55 and s.stats.combined >= 1
    s = HapticScheduler(SchedulerCfg())
    ints = []
    for i in range(8):
        s.submit(HapticEvent("FLESH_IMPACT", "right", 0.9), i * 60.0)
        ints += [c.intensity for c in tick_all(s, i * 60.0, i * 60.0 + 3) if c.actuator is Actuator.INDEX]
    assert ints[0] > ints[-1] and min(ints) >= 0.9 * 0.9 * 0.2
    s2, emitted = HapticScheduler(SchedulerCfg()), []
    for i in range(50):                                                      # a 500 Hz storm of identical events over 100 ms
        s2.submit(HapticEvent("LIGHT_CONTACT", "right", 0.9), i * 2.0)
        emitted += [c for c, _ in s2.tick(i * 2.0)]
    per = {}
    for c in emitted:
        per[c.actuator] = per.get(c.actuator, 0) + 1
    assert max(per.values()) <= 100 / SchedulerCfg().cooldown_ms_interaction + 2 and sum(s2.stats.suppressed.values()) > 0


def test_bounded_queue_drops_lowest_priority_first_and_unknown_pattern():
    s = HapticScheduler(SchedulerCfg(queue_capacity=8))
    for _ in range(3):
        s.submit(HapticEvent("WARNING", "right", 0.5), 100.0)
    s.submit(HapticEvent("DAMAGE", "right", 1.0), 100.0)
    assert s.queue_depth <= 8 and s.stats.queue_drops > 0 and any(c.tag == "DAMAGE" for c in tick_all(s, 100.0, 120.0))
    with pytest.raises(KeyError):
        HapticScheduler(SchedulerCfg()).submit(HapticEvent("NOPE", "right", 0.5), 0.0)


def test_limiter_clamps_ceilings_duty_rate_thermal_and_comm_budget():
    lim = HapticSafetyLimiter(SafetyCfg(hard_max_intensity=0.7, max_duration_ms=200))
    s = lim.process(HapticCommand(actuator="index", intensity=1.0, duration_ms=3000, frequency=450), 0.0)
    assert s.intensity == pytest.approx(0.7) and s.duration_ms == 200 and s.frequency == 400 and s.clamped
    prof = CalibrationProfile.uncalibrated(HapticsCfg())
    prof.actuator_max[Actuator.PALM] = 0.2
    lim = HapticSafetyLimiter(SafetyCfg(), prof)
    assert lim.process(cmd("palm", 1.0), 0.0).intensity == pytest.approx(0.2) and lim.process(cmd("index", 1.0), 0.0).intensity == pytest.approx(0.5)
    lim = HapticSafetyLimiter(SafetyCfg(max_duty_cycle=0.3, duty_window_ms=1000, max_commands_per_actuator_hz=1000))
    on = sum((lim.process(cmd("index", 0.5, 100, wf=Waveform.SUSTAIN), i * 20.0) or type("x", (), {"duration_ms": 0})).duration_ms for i in range(40))
    assert on <= 0.3 * 1000 + 100 + 1 and lim.report.rejected["duty_cycle"] > 0
    lim = HapticSafetyLimiter(SafetyCfg(max_commands_per_actuator_hz=50, max_commands_total_hz=100, max_duty_cycle=1.0))
    assert sum(lim.process(cmd("index", 0.3, 5), i * 2.0) is not None for i in range(50)) <= 6 and lim.report.rejected["actuator_rate"] > 0
    lim = HapticSafetyLimiter(SafetyCfg(max_commands_per_actuator_hz=1000, max_commands_total_hz=40, max_duty_cycle=1.0))
    combos = list(itertools.product([x.value for x in ACTUATORS], ["left", "right"])) * 4
    assert sum(lim.process(cmd(a, 0.3, 5, hand=h), k * 0.5) is not None for k, (a, h) in enumerate(combos)) <= 40 and lim.report.rejected["global_rate"] > 0
    lim = HapticSafetyLimiter(SafetyCfg(thermal_warn_c=38, thermal_limit_c=43))
    lim.observe(True, 40.5, 0)
    assert 0.4 <= lim.report.derate < 1.0 and lim.process(cmd(intensity=0.8), 0.0).intensity < 0.8
    lim.observe(True, 43.5, 0)
    assert lim.tripped and lim.trip_reason is TripReason.THERMAL and lim.process(cmd(), 100.0) is None
    lim.observe(True, 30.0, 0)
    assert lim.tripped                                       # latched: cooling alone does not re-enable output
    lim.reset()
    assert lim.process(cmd(), 200.0) is not None
    lim = HapticSafetyLimiter(SafetyCfg(max_comm_errors=5))
    lim.observe(False, None, 0)
    assert lim.process(cmd(), 0.0) is None and lim.report.rejected["disconnected"] == 1
    lim.observe(True, None, 6)
    assert lim.tripped and lim.trip_reason is TripReason.COMM_ERRORS


def test_safe_command_cannot_be_forged_and_drivers_reject_raw_commands():
    raw = cmd()
    with pytest.raises(SafetyViolation):
        SafeHapticCommand(object(), raw, 1.0, 10, 100.0, 0.0, False, 1)
    g = SimulatedHapticGlove("right")
    g.connect(0.0)
    with pytest.raises(SafetyViolation):
        g.send(raw, 0.0)                                     # type: ignore[arg-type]
    with pytest.raises(TypeError):
        proto.encode_haptic(raw)                             # type: ignore[arg-type]
    with pytest.raises(AttributeError):
        HapticSafetyLimiter(SafetyCfg()).process(raw, 0.0).intensity = 1.0


@given(st.floats(0, 1), st.integers(1, 5000), st.floats(20, 500), st.sampled_from(list(Actuator)), st.integers(0, 10_000))
@settings(deadline=None, max_examples=200)
def test_limiter_output_never_exceeds_limits_property(inten, dur, freq, act, t):
    cfgs = SafetyCfg()
    s = HapticSafetyLimiter(cfgs).process(HapticCommand(actuator=act, intensity=inten, duration_ms=dur, frequency=freq), float(t))
    if s is not None:
        assert s.intensity <= cfgs.hard_max_intensity + 1e-9 and s.duration_ms <= cfgs.max_duration_ms and 20 <= s.frequency <= 400


def test_simulated_glove_latency_priority_thermal_and_faults():
    g = SimulatedHapticGlove("right", HapticsCfg(), latency_ms=8.0, jitter_ms=0.0)
    g.connect(0.0)
    lim = HapticSafetyLimiter(SafetyCfg())
    assert g.send(lim.process(cmd("index", 0.6, 100, wf=Waveform.SUSTAIN, prio=P.MAJOR_IMPACT), 0.0), 0.0)
    g.update(4.0)
    assert g.get_actuator_state(4.0)[Actuator.INDEX] == 0.0                  # still in flight
    g.update(10.0)
    assert g.get_actuator_state(10.0)[Actuator.INDEX] > 0.1 and g.get_latency() == pytest.approx(8.0)
    g.send(lim.process(cmd("index", 0.9, 50, prio=P.AMBIENT, tag="x"), 30.0), 30.0)
    g.update(45.0)
    assert g.telemetry.dropped >= 1                                          # device refuses lower priority on a busy actuator
    g.inject_disconnect(50.0)
    assert g.get_connection_state() is ConnectionState.DISCONNECTED and not g.send(lim.process(cmd(), 60.0), 60.0)
    hot = SimulatedHapticGlove("right", HapticsCfg(), latency_ms=0.0, jitter_ms=0.0)
    hot.connect(0.0)
    lim = HapticSafetyLimiter(SafetyCfg(max_duty_cycle=1.0, max_duration_ms=5000, max_commands_per_actuator_hz=1000, max_commands_total_hz=100000))
    t, t0 = 0.0, hot.temperature
    while t < 20000:
        for a in (Actuator.PALM, Actuator.INDEX, Actuator.MIDDLE, Actuator.WRIST):
            s = lim.process(cmd(a.value, 0.85, 400, wf=Waveform.SUSTAIN), t)
            if s:
                hot.send(s, t)
        t += 100.0
        hot.update(t)
    assert hot.temperature > t0 + 2.0


def test_telemetry_surface():
    g = SimulatedHapticGlove("left", HapticsCfg(glove_drop_probability=0.5), seed=2)
    g.connect(0.0)
    lim = HapticSafetyLimiter(SafetyCfg(max_commands_per_actuator_hz=1000))
    for i in range(40):
        s = lim.process(cmd("palm", 0.4, 20, hand="left"), i * 30.0)
        if s:
            g.send(s, i * 30.0)
        g.update(i * 30.0 + 29)
    st_ = g.get_status(1200.0)
    assert st_.connection is ConnectionState.CONNECTED and st_.dropped_commands > 0 and st_.commands_sent > 0 and st_.battery_pct is not None and st_.temperature_c is not None
    assert set(g.get_actuator_state(0.0)) == set(ACTUATORS)


def test_protocol_roundtrip_validation_and_hostile_input():
    s = HapticSafetyLimiter(SafetyCfg()).process(HapticCommand(hand="left", actuator="ring", intensity=0.5, duration_ms=120, frequency=180, waveform="buzz", attack_ms=3, release_ms=30), 0.0)
    h = proto.decode_host_haptic(proto.FrameParser(proto.HOST_TYPES).feed(proto.encode_haptic(s))[0].payload)
    assert h.hand == "left" and h.actuator is Actuator.RING and h.intensity == pytest.approx(0.5, abs=0.01) and h.duration_ms == 120 and h.waveform is Waveform.BUZZ
    d = proto.decode_device(proto.FrameParser(proto.DEVICE_TYPES).feed(proto.encode_status(80, 31.5, 0, 2, 0b101))[0])
    assert d.battery_pct == 80 and d.temperature_c == 31.5 and d.error_count == 2
    for batt, temp in ((130, 25.0), (50, 400.0), (50, -90.0)):
        with pytest.raises(proto.ProtocolError):
            proto.decode_device(proto.FrameParser(proto.DEVICE_TYPES).feed(proto.encode_status(batt & 0xFF, temp, 0, 0, 1))[0])
    p = proto.FrameParser(proto.DEVICE_TYPES)
    good = proto.encode_pong(7)
    corrupt = bytearray(good)
    corrupt[-1] ^= 0xFF
    assert len(p.feed(b"\x00\x13garbage" + bytes(corrupt) + good + bytes([proto.SOF, 1, 0x82, 250]))) == 1 and p.stats.bad_crc >= 1 and p.stats.bad_length >= 1
    p.feed(b"\xa5" * 5000)
    assert len(p.buf) <= proto.MAX_BUFFER and p.stats.overflow >= 1


@given(st.binary(max_size=400))
@settings(deadline=None, max_examples=300)
def test_parser_never_raises_on_arbitrary_bytes(data):
    p = proto.FrameParser(proto.DEVICE_TYPES)
    for f in p.feed(data):
        try:
            proto.decode_device(f)
        except proto.ProtocolError:
            pass
    assert len(p.buf) <= proto.MAX_BUFFER


def pump(g, fw, t, n=10):
    for _ in range(n):
        t += 5
        fw.update(t)
        g.update(t)
    return t


def test_generic_glove_end_to_end_hostile_traffic_and_silence():
    a, b = LoopbackTransport.pair()
    b.open()
    g, fw = GenericHapticGlove("right", a), VirtualGloveFirmware(b)
    g.connect(0.0)
    t = pump(g, fw, 0.0)
    assert g.get_connection_state() is ConnectionState.CONNECTED and len(g.detect_actuators()) == 7
    lim = HapticSafetyLimiter(SafetyCfg(max_comm_errors=10))
    assert g.send(lim.process(cmd("index", 0.7, 100), t), t)
    t = pump(g, fw, t, 12)
    assert fw.received and fw.received[0].actuator is Actuator.INDEX and g.get_latency() > 0 and g.get_status(t).comm_errors == 0
    assert not g.send(lim.process(cmd("forearm", 0.5, 50), t + 50), t + 50)              # actuator the device does not have
    for _ in range(30):
        fw.inject_bad_status(250)
        fw.inject_garbage(40)
        t = pump(g, fw, t, 1)
        st = g.get_status(t)
        lim.observe(True, st.temperature_c, st.comm_errors, t)
    assert g.telemetry.comm_errors > 10 and lim.tripped and lim.process(cmd(), t) is None
    a2, b2 = LoopbackTransport.pair()
    b2.open()
    g2, fw2 = GenericHapticGlove("right", a2, silence_timeout_ms=100.0, ping_interval_ms=1e9), VirtualGloveFirmware(b2)
    g2.connect(0.0)
    pump(g2, fw2, 0.0, 5)
    assert g2.get_connection_state() is ConnectionState.CONNECTED
    g2.update(400.0)                                                                       # firmware stops answering
    assert g2.get_connection_state() is ConnectionState.ERROR


def test_hardware_transports_fail_cleanly():
    assert SerialHapticGlove("right", "/dev/impact-vr-no-such-port").connect(0.0) is False
    with pytest.raises(TransportUnavailable):
        HIDTransport(0x1234, 0x5678).open()


def test_profile_calibration_workflow_and_pipeline(tmp_path, bus):
    p = CalibrationProfile.uncalibrated(HapticsCfg())
    p.actuator_max[Actuator.INDEX] = 0.33
    path = p.save(tmp_path / "p.json")
    assert CalibrationProfile.load(path) == p
    with pytest.raises(ValidationError):
        CalibrationProfile.model_validate({**p.model_dump(mode="json"), "comfort_limit": 1.5})
    with pytest.raises(ValidationError):
        ResponseCurve(kind="points", points=[(0, 0), (0.5, 0.9), (1.0, 0.4)])
    path.write_text("{not json")
    assert not CalibrationProfile.load_or_default(HapticsCfg(), path=path).calibrated and path.with_suffix(".corrupt").exists()
    cfg = HapticsCfg()
    pipe = HapticPipeline(cfg, make_simulated_pair(cfg, 3))
    t = [0.0]

    def adv(ms):
        t[0] += ms
        pipe.update(t[0])
    res = CalibrationSession(pipe, cfg, ScriptedResponder(max_levels={Actuator.INDEX: 0.3, Actuator.PALM: 99.0}, missing={Actuator.FOREARM}, comfort=0.5), lambda: t[0], adv,
                             save_path=tmp_path / "cal.json").run()
    assert res.completed and res.profile.calibrated and (tmp_path / "cal.json").exists()
    assert res.profile.actuator_max[Actuator.INDEX] == pytest.approx(0.25, abs=0.06) and res.profile.actuator_max[Actuator.FOREARM] == 0.0
    assert all(v <= cfg.safety.hard_max_intensity + 1e-9 for v in res.profile.actuator_max.values()) and res.profile.comfort_limit == pytest.approx(0.5)
    a, _ = LoopbackTransport.pair()
    pipe2 = HapticPipeline(cfg, {"right": GenericHapticGlove("right", a, handshake_timeout_ms=20.0), "left": SimulatedHapticGlove("left")})
    t2 = [0.0]
    res2 = CalibrationSession(pipe2, cfg, ScriptedResponder(), lambda: t2[0], lambda ms: t2.__setitem__(0, t2[0] + ms), hands=("right",), save_path=tmp_path / "x.json").run()
    assert not res2.completed and not (tmp_path / "x.json").exists()
    gl = make_simulated_pair(cfg, 1, latency_ms=3.0, jitter_ms=0.0)
    for g in gl.values():
        g.connect(0.0)
    pl = HapticPipeline(cfg, gl, bus)
    pl.submit(HapticEvent("HEAVY_IMPACT", "right", 1.0), 0.0)
    sent, tt = [], 0.0
    while tt < 400:
        sent += pl.update(tt)
        tt += 2.0
    assert sent and all(isinstance(s, SafeHapticCommand) for s in sent) and max(s.intensity for s in sent) <= 0.5 + 1e-9
    assert bus.count("HAPTIC_SCHEDULED") == 1 and bus.count("HAPTIC_SENT") == len(sent)
    pl.emergency_stop()
    pl.submit(HapticEvent("HEAVY_IMPACT", "right", 1.0), 500.0)
    assert not pl.update(502.0) and bus.count("SAFETY_TRIP") == 1
