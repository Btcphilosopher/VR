import runpy
from pathlib import Path

import pytest

EX = Path(__file__).resolve().parents[1] / "examples"


def test_custom_scenario():
    out = runpy.run_path(str(EX / "custom_scenario.py"))["main"]()
    assert "hook" in out["strikes"] and out["haptic_commands"] > 0


def test_record_and_replay():
    assert runpy.run_path(str(EX / "record_and_replay.py"))["main"]() is True


def test_add_enemy():
    names = runpy.run_path(str(EX / "add_enemy.py"))["main"]()
    assert {"APPROACH", "ATTACK"} <= set(names)


def test_custom_glove_adapter_only_receives_safe_commands():
    calls = runpy.run_path(str(EX / "custom_glove_adapter.py"))["main"]()
    assert calls and all(0 <= amp <= 255 and ms > 0 for _, _, amp, ms in calls) and all(amp <= int(0.5 * 255) + 1 for _, _, amp, _ in calls)
