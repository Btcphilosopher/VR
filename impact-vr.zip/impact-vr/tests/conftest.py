import os
import tempfile

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ["IMPACT_VR_HOME"] = tempfile.mkdtemp(prefix="impact_vr_test_home_")

import pytest  # noqa: E402

from impact_vr.engine.config import Config, load_config  # noqa: E402


@pytest.fixture(scope="session")
def cfg() -> Config:
    return load_config()


@pytest.fixture
def bus():
    from impact_vr.engine.events import EventBus

    return EventBus("test")
