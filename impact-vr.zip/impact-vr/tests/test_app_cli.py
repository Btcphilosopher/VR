import json

import pygame
import pytest

from impact_vr.engine.app import App, MENU
from impact_vr.engine.config import Config, dump_toml, load_config, save_config
from impact_vr.engine.modes import GameMode
from impact_vr.networking.interfaces import LoopbackSession
from impact_vr.telemetry.diagnostics import run_diagnostics
from impact_vr.tools.cli import main
from impact_vr.tracking.calibration import run_tracking_calibration
from impact_vr.simulation.scenarios import SCENARIOS


def test_config_roundtrip_validation_and_defaults(tmp_path):
    cfg = Config()
    save_config(cfg, tmp_path)
    assert load_config(tmp_path) == cfg and {p.name for p in tmp_path.iterdir()} == {f"{n}.toml" for n in ("vr", "haptics", "physics", "gameplay", "graphics", "audio")}
    (tmp_path / "haptics.toml").write_text("master_intensity = 3.0\n")
    with pytest.raises(Exception):
        load_config(tmp_path)
    (tmp_path / "haptics.toml").write_text("[safety]\nthermal_warn_c = 50.0\nthermal_limit_c = 40.0\n")
    with pytest.raises(Exception):
        load_config(tmp_path)
    assert load_config() == Config()                         # the shipped configs/*.toml equal the typed defaults
    assert "[nested]" in dump_toml({"a": 1, "nested": {"b": "x"}})


def test_tracking_calibration_applies_to_config(cfg):
    _, rt = SCENARIOS["jab_cross"].build(cfg)
    res = run_tracking_calibration(rt, 0.5)
    assert res.eye_height_m == pytest.approx(1.65, abs=0.01) and res.hand_confidence["right"] == 1.0 and res.controller_fallback_share == 0.0
    assert res.apply(cfg).vr.filter.one_euro_min_cutoff == res.recommended_min_cutoff and "TRACKING CALIBRATION" in res.format()


def test_networking_interfaces_loopback():
    n = LoopbackSession()
    n.send("x", {"a": 1})
    assert n.poll() == []
    n.host("coop")
    n.send("x", {"a": 1})
    assert n.poll() == [("x", {"a": 1})] and n.poll() == []


def test_diagnostics_report(cfg):
    r = run_diagnostics()
    assert r.ok and "pipeline self-check" in r.format() and "READY" in r.format()


def test_cli_subcommands(tmp_path, capsys):
    assert main(["diagnostics", "--fast"]) == 0
    assert main(["simulate", "--list"]) == 0 and "combo_chain" in capsys.readouterr().out
    assert main(["simulate", "jab_cross", "--record", str(tmp_path)]) == 0
    assert main(["replay", str(tmp_path / "jab_cross.jsonl.gz")]) == 0 and "IDENTICAL" in capsys.readouterr().out
    assert main(["glove-test", "--quiet", "--protocol-loopback", "--hand", "right"]) == 0
    assert main(["glove-test", "--quiet", "--intensity", "0.2"]) == 0
    assert main(["calibrate", "--scripted", "--out", str(tmp_path / "p.json")]) == 0 and (tmp_path / "p.json").exists()
    assert main(["calibrate", "--tracking", "--seconds", "0.5"]) == 0
    assert main(["benchmark", "--scenario", "jab_cross", "--seconds", "1"]) == 0
    assert main(["simulate", "nope"]) == 2


def test_app_menu_play_pause_settings_and_screens(cfg):
    app = App(cfg, headless=True)
    key = lambda k: pygame.event.Event(pygame.KEYDOWN, key=k)   # noqa: E731
    app.update(1 / 60)
    app.draw()
    assert [m[0] for m in MENU][:4] == ["TRAINING ROOM", "STORY MODE", "ENCOUNTER MODE", "BOSS ENCOUNTER"]
    app.handle(key(pygame.K_RETURN))                         # TRAINING ROOM
    assert app.state == "play" and app.session.mode is GameMode.TRAINING
    for i in range(120):
        if i == 20:
            app.handle(key(pygame.K_k))
        if i == 60:
            app.handle(key(pygame.K_F4))
        if i == 61:
            app.handle(key(pygame.K_F3))
        app.update(1 / 90)
        app.draw()
    assert app.session.combat.stats.strikes >= 1
    app.handle(key(pygame.K_F12))
    app.update(1 / 90)
    assert app.session.pipeline.limiter.tripped
    app.handle(key(pygame.K_F5))
    assert not app.session.pipeline.limiter.tripped
    app.handle(key(pygame.K_ESCAPE))
    assert app.paused
    app.draw()
    app.handle(key(pygame.K_RETURN))
    assert app.state == "menu"
    app.sel = [m[1] for m in MENU].index(GameMode.SETTINGS)
    app.handle(key(pygame.K_RETURN))
    assert app.state == "settings"
    app.handle(key(pygame.K_RIGHT))
    app.draw()
    app.handle(key(pygame.K_ESCAPE))
    for mode, state in ((GameMode.PERFORMANCE, "perf"), (GameMode.TRACKING_CALIBRATION, "calib_tracking"), (GameMode.HAPTIC_CALIBRATION, "calib_haptic")):
        app.sel = [m[1] for m in MENU].index(mode)
        app.handle(key(pygame.K_RETURN))
        assert app.state == state and app.text_lines
        app.draw()
        app.handle(key(pygame.K_ESCAPE))
    app.shutdown()
