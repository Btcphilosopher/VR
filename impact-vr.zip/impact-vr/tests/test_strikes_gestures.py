from dataclasses import replace

import numpy as np
import pytest

from impact_vr.combat.defense import GestureRecognizer
from impact_vr.combat.strikes import StrikeDetector
from impact_vr.engine.config import FilterCfg, GuardCfg, Stance
from impact_vr.engine.mathx import QIDENT, Transform, v3
from impact_vr.hands.analyzer import HandAnalyzer
from impact_vr.simulation.synthetic import MOVES, HeadKey, SyntheticHandTracker, SyntheticHeadset, block_pose

DT = 1 / 90


def run_strike(move, hand, seconds=3.0, stance=Stance.ORTHODOX, noise_mm=0.0, **kw):
    tr = SyntheticHandTracker(SyntheticHeadset(), noise_mm=noise_mm)
    tr.scripts[hand].add(0.8, MOVES[move](hand, **kw))
    an, det, evs = HandAnalyzer(hand, FilterCfg()), StrikeDetector(stance), []
    for i in range(int(seconds / DT)):
        evs += det.update(hand, an.update(tr.skeleton_at(hand, i * DT)), Transform(v3(), QIDENT))
    return evs


@pytest.mark.parametrize("move,hand", [("jab", "left"), ("cross", "right"), ("hook", "right"), ("hook", "left"), ("uppercut", "right"), ("uppercut", "left"),
                                       ("hammer_fist", "right"), ("palm_strike", "right"), ("palm_strike", "left"), ("backhand", "right"), ("backhand", "left"),
                                       ("elbow_strike", "right"), ("elbow_strike", "left")])
def test_all_strike_types_recognised_from_trajectory(move, hand):
    evs = run_strike(move, hand)
    ended = [e for e in evs if e.phase == "ended"]
    assert len(ended) == 1 and ended[0].type == move and len(evs) == 2, [(e.type, e.phase) for e in evs]
    e = ended[0]
    assert e.confidence > 0.5 and e.velocity > 2.0 and e.acceleration > 5.0 and 0.05 < e.duration < 0.8
    assert np.linalg.norm(e.direction) == pytest.approx(1.0, abs=1e-6)


def test_strike_event_fields():
    e = [x for x in run_strike("cross", "right") if x.phase == "ended"][0]
    assert e.direction[2] > 0.9 and e.arc < 0.3 and e.arc_ratio < 0.2 and e.origin[2] < 0.5
    assert [x for x in run_strike("hook", "right") if x.phase == "ended"][0].arc > 0.8
    assert set(e.to_dict()) >= {"hand", "type", "origin", "direction", "velocity", "acceleration", "duration", "arc", "confidence", "contact_point", "contact_normal"}


def test_lead_vs_rear_hand_changes_straight_punch_name():
    assert [e for e in run_strike("jab", "right", stance=Stance.SOUTHPAW) if e.phase == "ended"][0].type == "jab"
    assert [e for e in run_strike("jab", "right", stance=Stance.ORTHODOX) if e.phase == "ended"][0].type == "cross"


def test_recognition_is_robust_to_sensor_noise():
    assert sum(any(e.type == "cross" and e.phase == "ended" for e in run_strike("cross", "right", noise_mm=1.5)) for _ in range(5)) >= 4


def test_slow_motion_and_ducking_are_not_strikes():
    tr = SyntheticHandTracker(SyntheticHeadset())
    tr.scripts["right"].add(0.5, MOVES["cross"]("right", dur=1.2))
    an, det, evs = HandAnalyzer("right", FilterCfg()), StrikeDetector(), []
    for i in range(int(3 / DT)):
        evs += det.update("right", an.update(tr.skeleton_at("right", i * DT)), Transform(v3(), QIDENT))
    assert not [e for e in evs if e.phase == "ended"]
    head = SyntheticHeadset([HeadKey(0, v3()), HeadKey(0.5, v3()), HeadKey(0.8, v3(0, -0.45, 0.05)), HeadKey(1.6, v3(0, -0.45, 0.05)), HeadKey(1.9, v3())])
    tr = SyntheticHandTracker(head)
    an = {h: HandAnalyzer(h, FilterCfg()) for h in ("left", "right")}
    det, evs = StrikeDetector(), []
    for i in range(int(2.5 / DT)):                      # analysed head-relative, as the session does
        hp = head.get_pose(i * DT).p
        for h in an:
            sk = tr.skeleton_at(h, i * DT)
            evs += det.update(h, an[h].update(replace(sk, positions=sk.positions - hp)), Transform(v3(), QIDENT))
    assert not evs


def gestures(setup, secs=2.5, head_keys=None, grabbables=None):
    head = SyntheticHeadset(head_keys)
    tr = SyntheticHandTracker(head)
    setup(tr)
    an = {h: HandAnalyzer(h, FilterCfg()) for h in ("left", "right")}
    gr, out = GestureRecognizer(GuardCfg()), []
    for i in range(int(secs / DT)):
        t = i * DT
        hp = head.get_pose(t)
        out += gr.update(t, hp.p, hp.q, {h: an[h].update(tr.skeleton_at(h, t)) for h in an}, grabbables)
    return [(g.type, g.hand) for g in out], gr


def test_idle_block_parry_push_shove_grab():
    assert gestures(lambda tr: None, 1.0)[0] == []
    g, gr = gestures(lambda tr: (tr.scripts["left"].add(0.5, block_pose("left")), tr.scripts["right"].add(0.5, block_pose("right"))))
    assert ("block", None) in g and gr.guard.state.active
    assert ("parry", "right") in gestures(lambda tr: tr.scripts["right"].add(0.8, MOVES["parry"]("right")))[0]
    assert ("push", "right") in gestures(lambda tr: tr.scripts["right"].add(0.8, MOVES["push"]("right")))[0]
    assert ("shove", "right") in gestures(lambda tr: tr.scripts["right"].add(0.8, MOVES["shove"]("right")))[0]
    assert ("grab", "right") in gestures(lambda tr: tr.scripts["right"].add(0.8, MOVES["grab"]("right")), grabbables=[("prop", v3(0.12, 1.15, 0.55), 0.2)])[0]


def test_closed_fist_guard_never_triggers_a_grab():
    g, _ = gestures(lambda tr: None, 2.0, grabbables=[("prop", v3(0.17, 1.36, 0.3), 0.3)])
    assert ("grab", "right") not in g and ("grab", "left") not in g


def test_dodge_duck_weave_from_head_motion():
    g, _ = gestures(lambda tr: None, 2.5, [HeadKey(0, v3()), HeadKey(0.8, v3()), HeadKey(1.1, v3(0, -0.4, 0.05)), HeadKey(2.2, v3(0, -0.4, 0.05))])
    assert any(t == "duck" for t, _ in g)
    g, _ = gestures(lambda tr: None, 2.0, [HeadKey(0, v3()), HeadKey(0.8, v3()), HeadKey(1.05, v3(0.22, -0.05, 0)), HeadKey(1.4, v3())])
    assert any(t == "weave" for t, _ in g) and not any(t == "dodge" for t, _ in g)
    g, _ = gestures(lambda tr: None, 2.0, [HeadKey(0, v3()), HeadKey(0.8, v3()), HeadKey(1.0, v3(0.55, 0, 0)), HeadKey(1.6, v3(0.55, 0, 0))])
    assert any(t == "dodge" for t, _ in g)
