import math
import random

import numpy as np
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from impact_vr.combat.damage import base_damage, damage_from_impact
from impact_vr.combat.events import BodyRegion, ImpactEvent
from impact_vr.engine.config import Config, DamageCfg, PhysicsCfg
from impact_vr.engine.mathx import unit, v3
from impact_vr.enemies.archetypes import ARCHETYPES, BOSS
from impact_vr.enemies.director import EncounterDef, EncounterDirector, SpawnDef
from impact_vr.enemies.enemy import Enemy, EnemyState, PlayerBody
from impact_vr.physics.impact import compute_impact
from impact_vr.physics.shapes import AABB, Capsule, Sphere, SpatialHash, sphere_aabb, sphere_capsule, sweep_sphere_aabb, sweep_sphere_capsule
from impact_vr.physics.world import PhysicsWorld, PropBody, StaticCollider

P = PhysicsCfg()


def test_sphere_capsule_and_aabb_contacts():
    cap = Capsule(v3(0, 0, 0), v3(0, 1, 0), 0.1)
    c = sphere_capsule(Sphere(v3(0.15, 0.5, 0), 0.06), cap)
    assert c is not None and c.normal == pytest.approx(v3(1, 0, 0)) and c.depth == pytest.approx(0.01)
    assert sphere_capsule(Sphere(v3(0.3, 0.5, 0), 0.06), cap) is None
    b = AABB(v3(0, 0, 0), v3(1, 1, 1))
    assert sphere_aabb(Sphere(v3(1.04, 0.5, 0.5), 0.05), b).normal == pytest.approx(v3(1, 0, 0))
    assert sphere_aabb(Sphere(v3(0.5, 0.5, 0.5), 0.05), b) is not None


def test_swept_test_catches_tunnelling_that_discrete_test_misses():
    cap = Capsule(v3(0, 1.2, 1.0), v3(0, 1.8, 1.0), 0.04)
    p0, p1 = v3(0, 1.5, 0.0), v3(0, 1.5, 2.0)                           # a 2 m jump in one frame
    assert sphere_capsule(Sphere(p0, 0.05), cap) is None and sphere_capsule(Sphere(p1, 0.05), cap) is None
    c = sweep_sphere_capsule(p0, p1, 0.05, cap)
    assert c is not None and 0.4 < c.t < 0.55 and c.normal == pytest.approx(v3(0, 0, -1), abs=1e-6)
    assert sweep_sphere_aabb(v3(-3, 0.5, 0.5), v3(3, 0.5, 0.5), 0.05, AABB(v3(0, 0, 0), v3(0.02, 1, 1))) is not None


@given(*[st.floats(-2, 2)] * 6)
@settings(deadline=None, max_examples=60)
def test_sweep_never_misses_when_an_endpoint_overlaps(ax, ay, az, bx, by, bz):
    cap, p0, p1 = Capsule(v3(0, 0, 0), v3(0, 1, 0), 0.15), v3(ax, ay, az), v3(bx, by, bz)
    if sphere_capsule(Sphere(p1, 0.05), cap) is not None or sphere_capsule(Sphere(p0, 0.05), cap) is not None:
        assert sweep_sphere_capsule(p0, p1, 0.05, cap) is not None


def test_spatial_hash_matches_bruteforce_and_world_sweeps():
    rng = np.random.default_rng(1)
    h, boxes = SpatialHash(2.0), []
    for i in range(60):
        lo = rng.uniform(-20, 20, 3)
        b = AABB(lo, lo + rng.uniform(0.2, 3, 3))
        h.insert(b, i)
        boxes.append(b)
    qlo, qhi = v3(-5, -5, -5), v3(6, 6, 6)
    assert {i for i, b in enumerate(boxes) if np.all(b.lo <= qhi) and np.all(b.hi >= qlo)} <= {p for _, p in h.query(qlo, qhi)}
    w = PhysicsWorld(P)
    w.add_static(StaticCollider("wall", AABB(v3(-1, 0, 2), v3(1, 3, 2.2)), "brick"))
    w.add_prop(PropBody("drum", v3(0, 0.45, 1.0), 14.0, "metal", 0.28, height=0.9))
    assert w.sweep_statics(v3(0, 1.5, 0), v3(0, 1.5, 3), 0.05)[1].material == "brick"
    assert w.sweep_props(v3(0, 0.5, 0), v3(0, 0.5, 2), 0.05)[1].name == "drum"
    for _ in range(90):
        w.step(1 / 90)


def test_impact_energy_formula_closing_speed_and_attack_types():
    imp = compute_impact("cross", v3(0, 0, 6), v3(), v3(0, 0, -1), "flesh", P)
    m = P.effective_mass_kg["cross"]
    assert imp.energy_j == pytest.approx(0.5 * m * 36) and imp.impulse == pytest.approx(m * 6 * (1 + P.materials["flesh"].restitution))
    assert compute_impact("cross", v3(0, 0, 6), v3(0, 0, 3), v3(0, 0, -1), "flesh", P).energy_j == pytest.approx(0.5 * m * 9)
    assert compute_impact("cross", v3(0, 0, 6), v3(0, 0, -2), v3(0, 0, -1), "flesh", P).energy_j > imp.energy_j
    e = lambda k: compute_impact(k, v3(0, 0, 5), v3(), v3(0, 0, -1), "flesh", P).energy_j   # noqa: E731
    assert e("elbow_strike") > e("cross") > e("jab")
    assert compute_impact("jab", v3(0, 0, -5), v3(), v3(0, 0, -1), "flesh", P).energy_j == 0.0


@given(st.floats(0.0, 12.0), st.floats(0.0, 1.0))
def test_impact_monotonic_and_glancing_reduces(speed, tilt):
    n = v3(0, 0, -1)
    a = compute_impact("jab", v3(0, 0, speed), v3(), n, "flesh", P)
    assert compute_impact("jab", v3(0, 0, speed + 1.0), v3(), n, "flesh", P).energy_j >= a.energy_j >= 0
    d = unit(v3(tilt, 0, 1 - tilt + 1e-6)) * max(speed, 0.1)
    assert compute_impact("jab", d, v3(), n, "flesh", P).energy_j <= compute_impact("jab", v3(0, 0, np.linalg.norm(d)), v3(), n, "flesh", P).energy_j + 1e-9


def test_gameplay_damage_is_separate_saturating_and_regional():
    d = DamageCfg()
    assert base_damage(0, d) == 0 and base_damage(d.energy_half_j, d) == pytest.approx(d.max_base_damage / 2) and base_damage(1e6, d) < d.max_base_damage + 1e-6
    phys = compute_impact("cross", v3(0, 0, 6), v3(), v3(0, 0, -1), "flesh", P)
    head, torso, leg = (damage_from_impact(phys, r, v3(0, 0, -1), d) for r in ("HEAD", "TORSO", "LEFT_LEG"))
    assert head.damage > torso.damage > leg.damage > 0 and head.stagger > torso.stagger
    assert damage_from_impact(phys, "ENVIRONMENT", v3(0, 0, -1), d).damage == 0
    assert damage_from_impact(phys, "TORSO", v3(0, 0, -1), d, armor=0.5).damage == pytest.approx(torso.damage * 0.5)
    combo = damage_from_impact(phys, "TORSO", v3(0, 0, -1), d, combo_hits=5)
    assert combo.damage > torso.damage and combo.knockback @ v3(0, 0, 1) > 0
    assert damage_from_impact(phys, "TORSO", v3(0, 0, -1), DamageCfg(max_base_damage=120.0)).damage > torso.damage     # tuning changes damage, not physics
    ev = ImpactEvent("player", "enemy_03", "TORSO", "punch", 6.8, 12.0, v3(0, 0, -1), v3(0, 1.4, 1), 30.0, "flesh", "right")
    assert ev.to_dict()["body_region"] == "TORSO" and {r.value for r in BodyRegion} >= {"HEAD", "TORSO", "LEFT_ARM", "RIGHT_ARM", "LEFT_LEG", "RIGHT_LEG", "CORE", "WEAPON", "ENVIRONMENT"}


PB = PlayerBody(v3(0, 1.65, 0), v3(), v3(), {}, {})


def mk(arch, pos=(0, 0, 5), seed=1):
    return Enemy("e", ARCHETYPES[arch], v3(*pos), math.pi, random.Random(seed))


def run_enemy(e, secs, pb=PB, token=True):
    seen = []
    for i in range(int(secs * 90)):
        e.update(1 / 90, i / 90, pb, token)
        for n, d in e.drain_events():
            seen.append(d["new"] if n == "state" else "windup:" + d["attack"] if n == "windup" else n)
    return seen


def test_enemy_state_machine_idle_notice_approach_attack():
    seen = run_enemy(mk("street_fighter"), 8)
    order = [s for s in seen if s in {x.value for x in EnemyState}]
    assert order[:2] == ["NOTICE", "APPROACH"] and "ATTACK" in order and any(s.startswith("windup:") for s in seen)


def test_every_archetype_acts_and_telegraphs_before_striking():
    for arch in ARCHETYPES.values():
        if arch.ranged:
            continue
        assert any(s.startswith("windup:") for s in run_enemy(mk(arch.id), 14)), arch.id
        for atk in arch.attacks:
            assert atk.windup >= 0.28 and atk.windup > atk.active


def test_stagger_knockback_and_recovery():
    e = mk("street_fighter", (0, 0, 1.2))
    run_enemy(e, 1.0)
    e.receive_hit("TORSO", 5.0, 30.0, v3(0, 0, 3.0), 1.0)
    assert e.state is EnemyState.STAGGER and e.stagger_time > 0.4
    z0 = zmax = e.pos[2]
    for i in range(180):
        e.update(1 / 90, 1.0 + i / 90, PB, True)
        e.drain_events()
        zmax = max(zmax, e.pos[2])
    assert zmax > z0 + 0.3 and e.state is not EnemyState.STAGGER


def test_windup_interrupt_death_shield_armor():
    e = mk("street_fighter", (0, 0, 1.1))
    for i in range(400):
        e.update(1 / 90, i / 90, PB, True)
        if e.attack is not None and e.attack.phase == "windup":
            break
    assert e.attack is not None
    e.receive_hit("HEAD", 5.0, 20.0, v3(0, 0, 1), 5.0)
    assert e.attack is None and e.state is EnemyState.STAGGER
    e.receive_hit("HEAD", 1e6, 0, v3(), 6.0)
    assert e.state is EnemyState.DEFEATED and not e.alive
    run_enemy(e, 1.0)
    assert e.state is EnemyState.DEFEATED
    sh = mk("shielded", (0, 0, 2))
    h0 = sh.health
    assert sh.receive_hit("WEAPON", 30, 80, v3(0, 0, 1), 1.0).shield_hit and sh.health == h0 and sh.shield_hp < 60
    sh.receive_hit("WEAPON", 30, 200, v3(0, 0, 1), 2.0)
    assert not sh.shield_up
    b = mk("heavy_bruiser")
    b.receive_hit("TORSO", 100.0, 0.0, v3(), 1.0)
    assert b.health == pytest.approx(b.max_health - 100 * (1 - b.arch.armor))


def test_enemies_react_to_incoming_player_strikes():
    reacted = 0
    for seed in range(12):
        e = Enemy("e", ARCHETYPES["agile_attacker"], v3(0, 0, 1.0), math.pi, random.Random(seed))
        e.state = EnemyState.APPROACH
        pb = PlayerBody(v3(0, 1.65, 0), v3(), v3(), {}, {"right": (v3(0, 1.4, 0.3), v3(0, 0, 1), 6.0)})
        seen = run_enemy(e, 0.4, pb)
        reacted += ("EVADE" in seen) or ("BLOCK" in seen)
    assert reacted >= 3


def test_attack_tokens_limit_simultaneous_attackers_and_encounters_are_designed():
    cfg = Config().gameplay.encounter
    d = EncounterDirector(cfg, random.Random(3))
    d.start(EncounterDef("t", "t", tuple(SpawnDef("street_fighter", (x, 4.0), 0.0) for x in (-3, -1, 1, 3))), 0.0)
    peak = 0
    for i in range(90 * 20):
        d.update(i / 90, v3())
        n = 0
        for e in d.enemies.values():
            e.update(1 / 90, i / 90, PB, e.token)
            e.drain_events()
            n += e.attack is not None
        peak = max(peak, n)
    assert 1 <= peak <= cfg.max_simultaneous_attackers and len(d.enemies) <= cfg.max_enemies_alive
    from impact_vr.world.district import build_street
    lvl = build_street(P)
    assert [e.id for e in lvl.encounters] == ["arch_street", "loading_yard", "viaduct", "foreman"] and all(len(e.spawns) + len(e.reinforcements) <= 5 for e in lvl.encounters)
    assert BOSS.phases and len(BOSS.attacks) >= 4 and BOSS.health > 400
