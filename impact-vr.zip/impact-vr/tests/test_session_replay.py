import io
import json
import logging

import numpy as np
import pytest

from impact_vr.audio.engine import AudioEngine, Listener, RecordingAudio, spatialise, synth
from impact_vr.engine import events as E
from impact_vr.engine.config import ComfortCfg, load_config
from impact_vr.engine.events import EventBus
from impact_vr.engine.mathx import q_to_yaw, v3
from impact_vr.engine.modes import GameMode
from impact_vr.engine.session import GameSession
from impact_vr.enemies.enemy import EnemyState
from impact_vr.input.desktop import DesktopInput
from impact_vr.simulation.benchmark import run_benchmark
from impact_vr.simulation.replay import ReplayFormatError, ReplayRecorder, ReplaySource, replay_session, verify_replay
from impact_vr.simulation.scenarios import SCENARIOS, SyntheticCombatScenario, _en
from impact_vr.simulation.synthetic import HeadKey, SyntheticController, SyntheticHandTracker, SyntheticHeadset
from impact_vr.telemetry.latency import STAGES, LatencyTracker
from impact_vr.telemetry.logging import EventLogger, JsonFormatter
from impact_vr.vr.adapters import ControllerHandFallback, OpenXRAdapter
from impact_vr.vr.device import VRRuntime, VRUnavailable
from impact_vr.vr.types import SessionState


def ended(s):
    return [e.data["strike"]["type"] for e in s.events("STRIKE_DETECTED") if e.data.get("phase") == "ended"]


def idle_runtime(cfg):
    head = SyntheticHeadset()
    rt = VRRuntime(head, SyntheticHandTracker(head), None, target_fps=90, fallback=ControllerHandFallback())
    rt.start()
    return rt


@pytest.mark.parametrize("name", list(SCENARIOS))
def test_every_scenario_meets_its_expectations(cfg, name):
    sc = SCENARIOS[name]
    s = sc.run(cfg)
    assert all(x in ended(s) for x in sc.expect_strikes), (name, ended(s))
    assert all(x in {e.name for e in s.bus.history} for x in sc.expect_events), name
    assert not s.pipeline.limiter.tripped


def test_full_chain_hand_to_glove_for_a_punch(cfg):
    s = SCENARIOS["jab_cross"].run(cfg)
    order = [e.name for e in s.bus.history]
    first = lambda n: order.index(n)   # noqa: E731
    assert first("HAND_TRACKED") < first("STRIKE_DETECTED") < first("COLLISION") < first("IMPACT_CALCULATED") < first("DAMAGE_APPLIED") < first("HAPTIC_SCHEDULED") < first("HAPTIC_SENT")
    imp = s.events("IMPACT_CALCULATED")[0].data["impact"]
    assert imp.attacker == "player" and imp.body_region in ("TORSO", "HEAD", "LEFT_ARM", "RIGHT_ARM")
    sent = s.events("HAPTIC_SENT")
    assert sent and all(0 < e.data["intensity"] <= cfg.haptics.safety.hard_max_intensity for e in sent) and any(e.data["hand"] == "left" for e in sent)
    assert s.combat.stats.damage_dealt > 0


def test_harder_hits_feel_harder_and_do_more_damage(cfg):
    en = SCENARIOS["jab_cross"].enemies
    f = SyntheticCombatScenario("fast", "", 3.0, [(1.0, "cross", "right", {"dur": 0.12})], enemies=en).run(cfg)
    s = SyntheticCombatScenario("slow", "", 3.0, [(1.0, "cross", "right", {"dur": 0.26})], enemies=en).run(cfg)
    ef = max(e.data["physical"].energy_j for e in f.events("IMPACT_CALCULATED"))
    es = max((e.data["physical"].energy_j for e in s.events("IMPACT_CALCULATED")), default=0.0)
    assert ef > es and f.combat.stats.damage_dealt > s.combat.stats.damage_dealt
    assert max(e.data["intensity"] for e in f.events("HAPTIC_SENT")) >= max((e.data["intensity"] for e in s.events("HAPTIC_SENT")), default=0)


def test_material_selects_haptic_pattern(cfg):
    s, _ = SyntheticCombatScenario("wall", "", 3.0, [(1.0, "cross", "right", {"reach": 1.4})], level="training").build(cfg)
    from impact_vr.physics.shapes import AABB
    from impact_vr.physics.world import StaticCollider
    s.level.physics.add_static(StaticCollider("plate", AABB(v3(-0.5, 1.0, 1.0), v3(0.5, 2.0, 1.1)), "metal"))
    s.run(3.0)
    assert "METAL_IMPACT" in [e.data["pattern"] for e in s.events("HAPTIC_SCHEDULED")]


def test_block_reduces_damage_and_haptics_fire_on_the_arms(cfg):
    sc = SCENARIOS["block_incoming"]
    guard = sc.run(cfg)
    open_ = SyntheticCombatScenario("open", "", 3.5, [], enemies=sc.enemies).run(cfg)
    assert guard.combat.stats.blocks == 1 and 0 < guard.combat.vitals.damage_taken < open_.combat.vitals.damage_taken
    blocks = [e for e in guard.events("HAPTIC_SENT") if e.data["tag"] == "BLOCK"]
    assert blocks and {e.data["actuator"] for e in blocks} & {"wrist", "forearm"}
    atk = [(e.data["phase"], e.t) for e in guard.events("ENEMY_ATTACK")]
    assert atk[0][0] == "windup" and atk[1][0] == "active" and atk[1][1] - atk[0][1] >= 0.4       # a readable wind-up preceded the strike


def test_parry_negates_damage_and_staggers_attacker(cfg):
    s = SCENARIOS["parry_window"].run(cfg)
    assert s.combat.stats.parries == 1 and s.combat.vitals.damage_taken == 0.0
    assert any(e.data.get("new") == "STAGGER" for e in s.events("ENEMY_STATE")) and any(e.data["tag"] == "PARRY" for e in s.events("HAPTIC_SENT"))


def test_poorly_timed_guard_partially_penetrates(cfg):
    sc = SCENARIOS["block_incoming"]
    late = SyntheticCombatScenario("late", "", 3.5, [(1.62, "block", "left", {}), (1.62, "block", "right", {})], enemies=sc.enemies).run(cfg)
    assert late.combat.vitals.damage_taken > sc.run(cfg).combat.vitals.damage_taken


def test_grab_carry_and_throw_hits_target(cfg):
    s = SCENARIOS["grab_and_throw"].run(cfg)
    assert [e.data["phase"] for e in s.events("GRAB")] == ["start", "end"]
    dummy = s.director.enemies["dummy_0"]
    assert s.combat.stats.thrown_hits >= 1 and dummy.health < dummy.max_health


def test_dodging_after_the_aim_commits_makes_attacks_miss(cfg):
    base = dict(enemies=[_en(1.15, passive=True, attacks=((1.0, "jab"),))])
    stand = SyntheticCombatScenario("stand", "", 3.0, [], **base).run(cfg)
    duck = SyntheticCombatScenario("duck", "", 3.0, [], head=[HeadKey(0, v3()), HeadKey(1.2, v3()), HeadKey(1.5, v3(0, -0.5, 0.05)), HeadKey(2.5, v3(0, -0.5, 0.05))], **base).run(cfg)
    assert stand.combat.vitals.damage_taken > 0 and duck.combat.vitals.damage_taken == 0.0


def test_encounter_mode_can_be_lost_and_won(cfg):
    s = GameSession(cfg, idle_runtime(cfg), mode=GameMode.ENCOUNTER, encounter="arch_street", seed=3)
    s.run(90.0, until_done=True)                                   # a player who never fights back
    assert s.done and not s.result.success and s.result.reason == "player down" and s.combat.vitals.damage_taken > 90
    w = GameSession(cfg, idle_runtime(cfg), mode=GameMode.ENCOUNTER, encounter="arch_street", seed=3)
    w.run(1.0)
    w.director.pending.clear()
    for e in w.director.enemies.values():
        e.receive_hit("HEAD", 1e9, 0.0, v3(), 1.0)
    w.run(1.0, until_done=True)
    assert w.done and w.result.success and w.result.reason == "cleared" and w.defeated >= 1


def test_training_modes_and_story_progression(cfg):
    sc = SyntheticCombatScenario("tour", "", 2.0, [(0.3, "cross", "right", {})], level="training", enemies=[_en(0.95)])
    s, _ = sc.build(cfg)
    s.run(2.0)
    assert s.state.checklist.punches and s.state.checklist.glove_feedback and not s.state.checklist.complete
    story = GameSession(cfg, idle_runtime(cfg), mode=GameMode.STORY, seed=5)
    assert story.director.active.id == "arch_street" and story.state.queue == ["arch_street", "loading_yard", "viaduct", "foreman"]
    assert GameSession(cfg, idle_runtime(cfg), mode=GameMode.BOSS, seed=5).director.active.id == "foreman"
    assert set(GameMode) >= {GameMode.MAIN_MENU, GameMode.TRAINING, GameMode.STORY, GameMode.ENCOUNTER, GameMode.BOSS, GameMode.SETTINGS, GameMode.HAPTIC_CALIBRATION,
                             GameMode.TRACKING_CALIBRATION, GameMode.PERFORMANCE}


def test_boss_changes_phase_as_health_drops(cfg):
    b = GameSession(cfg, idle_runtime(cfg), mode=GameMode.BOSS, seed=5)
    b.run(1.5)
    boss = next(iter(b.director.enemies.values()))
    boss.receive_hit("TORSO", 300, 0, v3(), 2.0)                  # armour 25% -> health < 66%
    b.run(0.2)
    assert boss.phase_idx >= 1 and any(e.data.get("event") == "phase" for e in b.events("ENEMY_STATE"))


def loco_session(cfg, comfort):
    d = DesktopInput()
    rt = VRRuntime(d.headset, d.tracker, d.controllers, target_fps=90, fallback=ControllerHandFallback())
    rt.start()
    c = cfg.model_copy(update={"gameplay": cfg.gameplay.model_copy(update={"comfort": comfort})})
    return GameSession(c, rt, mode=GameMode.TRAINING, level_kind="street", seed=1), d


def test_smooth_locomotion_snap_turn_smooth_turn_room_scale(cfg):
    s, d = loco_session(cfg, ComfortCfg(locomotion="smooth", turn_mode="snap"))
    d.controllers.stick_l = (0.0, 1.0)
    s.run(1.0)
    assert s.head_world[2] > 1.0
    d.controllers.stick_l, d.controllers.stick_r = (0.0, 0.0), (1.0, 0.0)
    s.run(0.1)
    d.controllers.stick_r = (0.0, 0.0)
    s.run(0.1)
    assert s.rig.yaw == pytest.approx(np.radians(30), abs=1e-6)
    s2, d2 = loco_session(cfg, ComfortCfg(locomotion="room_scale", turn_mode="smooth"))
    d2.controllers.stick_r = (1.0, 0.0)
    s2.run(0.5)
    assert 0.2 < s2.rig.yaw < 1.2
    s3, d3 = loco_session(cfg, ComfortCfg(locomotion="room_scale"))
    d3.controllers.stick_l = (0.0, 1.0)
    s3.run(0.5)
    assert s3.rig.pos[2] == pytest.approx(0.0, abs=1e-9)


def test_teleport_and_arena_bounds(cfg):
    s, d = loco_session(cfg, ComfortCfg(locomotion="teleport"))
    d.controllers.stick_l = (0.0, 1.0)
    s.run(0.3)
    assert s.loco.state.teleport_arc and s.loco.state.teleport_target is not None
    d.controllers.stick_l = (0.0, 0.0)
    s.run(0.1)
    assert s.head_world[2] > 1.0 and any(e.data.get("kind") == "teleport" for e in s.events("PLAYER_MOVED"))
    s2, d2 = loco_session(cfg, ComfortCfg(locomotion="smooth"))
    d2.controllers.stick_l = (0.0, 1.0)
    s2.run(25.0)
    x0, z0, x1, z1 = s2.level.bounds
    assert z0 <= s2.head_world[2] <= z1 and x0 <= s2.head_world[0] <= x1


def test_simulation_is_deterministic_and_seed_sensitive(cfg):
    assert SCENARIOS["combo_chain"].run(cfg, seed=7).event_digest() == SCENARIOS["combo_chain"].run(cfg, seed=7).event_digest()

    def enc(seed):
        s = GameSession(cfg, idle_runtime(cfg), mode=GameMode.ENCOUNTER, seed=seed)
        s.run(8.0)
        return s.event_digest()
    assert enc(1) == enc(1) and enc(1) != enc(2)


@pytest.mark.parametrize("name", list(SCENARIOS))
def test_record_replay_is_bit_identical(cfg, tmp_path, name):
    rec = ReplayRecorder(name)
    s, _ = SCENARIOS[name].build(cfg, recorder=rec)
    s.run(SCENARIOS[name].duration)
    rep = verify_replay(rec.save(tmp_path / f"{name}.jsonl.gz"), cfg)
    assert rep.ok and rep.expected_digest == rep.actual_digest == s.event_digest(), rep.detail


def test_replay_format_tamper_detection_and_no_hardware(cfg, tmp_path):
    rec = ReplayRecorder("fmt")
    s, _ = SCENARIOS["jab_cross"].build(cfg, recorder=rec)
    s.run(3.4)
    p = rec.save(tmp_path / "r.jsonl")
    lines = p.read_text().splitlines()
    head, fr = json.loads(lines[0]), json.loads(lines[1])
    assert head["format"] == "impact-vr-replay" and head["version"] == 1 and head["seed"] == 11
    assert {"f", "t", "head", "ctrl", "hands", "ev"} <= set(fr) and len(fr["hands"]["right"]["pos"]) == 26
    assert ReplaySource.load(p).footer["digest"] == s.event_digest()
    sess, src = replay_session(p, cfg)
    assert type(sess.source).__name__ == "ReplaySource"
    while not src.finished:
        sess.step()
    assert sess.combat.stats.hits == s.combat.stats.hits
    bad = tmp_path / "bad.jsonl"
    bad.write_text('{"format":"nope","version":9}\n')
    with pytest.raises(ReplayFormatError):
        ReplaySource.load(bad)
    strike_frames = [i for i, ln in enumerate(lines[1:-1], 1) if any(e["n"] == "STRIKE_DETECTED" for e in json.loads(ln)["ev"])]
    tampered = lines[:]
    for i in range(max(1, strike_frames[0] - 12), strike_frames[0] + 4):       # shift the jabbing hand mid-strike
        d = json.loads(tampered[i])
        d["hands"]["left"]["pos"] = [[x, y, z + 0.4] for x, y, z in d["hands"]["left"]["pos"]]
        tampered[i] = json.dumps(d, sort_keys=True)
    t = tmp_path / "t.jsonl"
    t.write_text("\n".join(tampered) + "\n")
    assert not verify_replay(t, cfg).ok


def test_latency_breakdown_is_measured_and_ordered(cfg):
    s = SCENARIOS["combo_chain"].run(cfg)
    summ = s.latency.summary()
    assert all(summ[k]["n"] > 100 and 0 < summ[k]["mean"] < 20 for k in ("tracking", "gesture", "collision", "gameplay"))
    assert summ["hardware_transport"]["mean"] == pytest.approx(cfg.haptics.glove_latency_ms, abs=cfg.haptics.glove_jitter_ms + 0.5)
    assert summ["haptic_scheduling"]["mean"] < 8.0 and 0 < summ["total"]["mean"] < 40 and "INPUT -> COLLISION -> HAPTIC" in s.latency.breakdown_text()
    tr = s.latency.completed[-1]
    assert set(tr.stages) <= set(STAGES) and tr.total == pytest.approx(sum(tr.stages.values()))
    lt = LatencyTracker()
    lt.new_frame()
    tid = lt.begin_trace()
    lt.stage(tid, "haptic_scheduling", 2.0)
    lt.stage(tid, "haptic_scheduling", 1.0)
    lt.stage(tid, "hardware_transport", 6.0)
    assert lt.finish(tid).stages["haptic_scheduling"] == 2.0
    lt.stage(tid, "gameplay", 100.0)
    assert lt.completed[-1].stages.get("gameplay", 0) != 100.0
    r = run_benchmark("jab_cross", cfg, seconds=1.0)
    assert r.frames > 80 and r.achieved_fps > 0 and set(STAGES) <= set(r.stages_ms) and "INPUT -> COLLISION -> HAPTIC" in r.format()


def test_structured_logging_correlates_by_session_and_frame(cfg):
    buf = io.StringIO()
    log = logging.getLogger("impact_vr.test")
    log.handlers = [logging.StreamHandler(buf)]
    log.handlers[0].setFormatter(JsonFormatter())
    log.setLevel(logging.DEBUG)
    log.propagate = False
    s, _ = SCENARIOS["jab_cross"].build(cfg)
    EventLogger(s.bus, log, level=logging.INFO)
    s.run(2.0)
    rows = [json.loads(x) for x in buf.getvalue().splitlines()]
    assert {"VR_FRAME", "HAND_TRACKED", "STRIKE_DETECTED", "COLLISION", "IMPACT_CALCULATED", "DAMAGE_APPLIED", "HAPTIC_SCHEDULED", "HAPTIC_SENT"} <= {r["event"] for r in rows}
    assert len({r["session"] for r in rows}) == 1 and all("frame" in r for r in rows) and max(r["frame"] for r in rows) > 100


def test_runtime_session_state_recenter_timing_fallback_and_openxr_stub(cfg):
    head = SyntheticHeadset(yaw=0.8)
    tr = SyntheticHandTracker(head)
    rt = VRRuntime(head, tr, SyntheticController(tr), target_fps=90, fallback=ControllerHandFallback())
    assert rt.state is SessionState.IDLE
    rt.start()
    assert rt.state is SessionState.FOCUSED
    rt.recenter(0.0)
    f = rt.poll(0.0)
    assert q_to_yaw(f.head.q) == pytest.approx(0.0, abs=1e-6) and f.hand_source == {"left": "hand_tracking", "right": "hand_tracking"}
    rt.poll(1 / 90)
    assert rt.poll(0.5).missed_frames > 20
    tr.dropouts.append((1.0, 2.0, "right"))
    f3 = rt.poll(1.5)
    assert f3.hand_source["right"] == "controller" and f3.hands["right"] is not None and f3.hand_source["left"] == "hand_tracking"
    rt.stop()
    assert rt.state is SessionState.EXITING
    with pytest.raises(VRUnavailable):
        OpenXRAdapter()
    s, _ = SCENARIOS["jab_cross"].build(cfg, controllers=True)
    s.run(3.4)
    assert "cross" in ended(s) and s.last_frame.hand_source["right"] == "controller"


def test_audio_events_spatialised_and_observable(cfg):
    rec = RecordingAudio()
    s, _ = SCENARIOS["combo_chain"].build(cfg, audio_backend=rec)
    s.run(4.0)
    assert rec.count("punch_flesh") + rec.count("punch_heavy") >= 1 and s.events("AUDIO")
    bus, r2 = EventBus(), RecordingAudio()
    AudioEngine(bus, r2)
    bus.emit(E.ENEMY_ATTACK, pos=v3(10, 0, 0))
    bus.emit(E.ENEMY_DEFEATED, pos=v3(-10, 0, 0))
    (_, l1, r1), (_, l2, rr2) = r2.log
    assert r1 > l1 and l2 > rr2
    for name in ("punch_flesh", "block", "parry", "metal_hit", "wood_hit", "wall_hit", "whoosh", "footstep", "damage", "haptic_confirm", "enemy_down", "success"):
        w = synth(name)
        assert w.size > 100 and abs(w).max() <= 1.0
    assert spatialise(Listener(), v3(0, 0, 3))[0] > spatialise(Listener(), v3(0, 0, 30))[0] and spatialise(Listener(), v3(0, 0, 100))[0] == 0.0


def test_haptic_safety_trip_mid_session_stops_all_output(cfg):
    s, _ = SCENARIOS["combo_chain"].build(cfg)
    s.run(1.6)
    s.gloves["right"].inject_temperature(50.0)
    s.run(3.5)
    assert s.pipeline.limiter.tripped and s.events("SAFETY_TRIP")
    n = s.pipeline.sent_total
    s.run(1.0)
    assert s.pipeline.sent_total == n
