import numpy as np
import pytest
from hypothesis import given
from hypothesis import strategies as st

from impact_vr.engine.config import FilterCfg, FilterKind
from impact_vr.engine.mathx import QIDENT, q_from_yaw, v3
from impact_vr.hands.analyzer import HandAnalyzer, flexion_from_positions
from impact_vr.hands.skeleton import FINGERS, N_JOINTS, FingerCurls, Joint, build_skeleton
from impact_vr.tracking.filters import ExponentialSmoothing, FilterBank, make_filter


def feed(an, curls, n=30, hand="right", dt=1 / 90):
    st = None
    for i in range(n):
        st = an.update(build_skeleton(hand, v3(0.2, 1.2, 0.3), QIDENT, curls, i * dt))
    return st


def test_skeleton_has_26_openxr_joints_in_order_and_hands_mirror():
    s = build_skeleton("right", v3(0, 1, 0), QIDENT, FingerCurls.open())
    assert s.positions.shape == (26, 3) and s.orientations.shape == (26, 4) and N_JOINTS == 26
    assert Joint.PALM == 0 and Joint.WRIST == 1 and Joint.THUMB_TIP == 5 and Joint.LITTLE_TIP == 25
    r = build_skeleton("right", v3(), QIDENT, FingerCurls.open()).positions
    l = build_skeleton("left", v3(), QIDENT, FingerCurls.open()).positions
    assert l[Joint.INDEX_TIP][0] == pytest.approx(-r[Joint.INDEX_TIP][0]) and l[Joint.INDEX_TIP][2] == pytest.approx(r[Joint.INDEX_TIP][2])


@given(st.floats(0.05, 1.0))
def test_flexion_recovers_curl(c):
    fl = flexion_from_positions(build_skeleton("right", v3(), QIDENT, FingerCurls(c, c, c, c, c)).positions)
    for f in FINGERS[1:]:
        assert fl[f] == pytest.approx(c, abs=0.04)


def test_hand_classification_fist_point_open_grip():
    mk = lambda: HandAnalyzer("right", FilterCfg())   # noqa: E731
    fist = feed(mk(), FingerCurls.fist())
    assert fist.fist_prob > 0.9 and fist.openness < 0.1 and fist.grip_prob > 0.9
    point = feed(mk(), FingerCurls.point())
    assert point.pointing_prob > 0.9 and point.fist_prob < 0.5
    op = feed(mk(), FingerCurls.open())
    assert op.openness > 0.9 and op.fist_prob < 0.05 and op.grip_prob < 0.1 and op.pointing_prob < 0.2
    assert feed(mk(), FingerCurls.grip()).grip_prob > 0.7


def test_velocity_acceleration_and_angular_velocity():
    an = HandAnalyzer("right", FilterCfg(kind=FilterKind.NONE, velocity_cutoff_hz=200.0))
    dt = 1 / 90
    for i in range(40):
        st = an.update(build_skeleton("right", v3(0, 1.2, 0.5 * 2.5 * (i * dt) ** 2), QIDENT, FingerCurls.fist(), i * dt))   # constant acceleration 2.5 m/s^2
    assert st.palm_velocity[2] == pytest.approx(2.5 * 39 * dt, rel=0.1) and st.wrist_velocity[2] == pytest.approx(st.palm_velocity[2], rel=0.05)
    an2 = HandAnalyzer("right", FilterCfg(kind=FilterKind.NONE))
    for i in range(10):
        st2 = an2.update(build_skeleton("right", v3(0, 1, 0.3), q_from_yaw(1.0 * i * dt), FingerCurls.open(), i * dt))
    assert st2.angular_velocity[1] == pytest.approx(1.0, rel=0.15)


def test_filters_reduce_jitter_but_follow_motion():
    rng = np.random.default_rng(0)
    for kind in (FilterKind.EMA, FilterKind.MOVING_AVERAGE, FilterKind.ONE_EURO, FilterKind.VELOCITY_AWARE):
        f = make_filter(FilterCfg(kind=kind))
        out = [f.filter(rng.normal(0, 0.003, (1, 3)), i / 90) for i in range(120)]
        assert np.std(np.array(out)[30:]) < 0.003 * 0.85, kind
    oe, ema = make_filter(FilterCfg(kind=FilterKind.ONE_EURO)), ExponentialSmoothing(0.15)
    for i in range(90):
        x = np.array([[i / 90 * 8.0, 0, 0]])
        a, b = oe.filter(x, i / 90), ema.filter(x, i / 90)
    assert abs(x[0, 0] - a[0, 0]) < abs(x[0, 0] - b[0, 0]) * 0.5


def test_filters_runtime_reconfigure_and_irregular_timestamps():
    bank = FilterBank(FilterCfg())
    p = np.zeros((26, 3))
    for i in range(10):
        bank.filter_positions(p + i * 0.01, i / 90)
    bank.configure(kind="ema", ema_alpha=0.3)
    assert bank.filter_positions(p + 0.2, 11 / 90).shape == (26, 3)
    with pytest.raises(Exception):
        bank.configure(ema_alpha=5.0)
    f = make_filter(FilterCfg())
    outs = [float(f.filter(np.array([t * 3.0]), t)[0]) for t in (0.0, 0.011, 0.034, 0.035, 0.100)]
    assert all(np.isfinite(outs)) and outs[-1] > outs[0]
    an = HandAnalyzer("left", FilterCfg())
    feed(an, FingerCurls.fist(), 10, "left")
    an.configure(kind="none")
    assert feed(an, FingerCurls.fist(), 3, "left").tracked
    an.reset()
