"""Tracking calibration: stand still for a couple of seconds and measure what the sensors actually do.

Measures eye height, head and hand jitter (RMS of position about the mean), mean hand-tracking confidence and the share of frames
that fell back to controllers, then recommends filter settings (more jitter -> lower One Euro min cutoff). The result can be
applied to a Config without touching gameplay code.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..engine.config import Config, FilterKind
from ..hands.skeleton import Joint


@dataclass
class TrackingCalibrationResult:
    frames: int
    eye_height_m: float
    head_jitter_mm: float
    hand_jitter_mm: dict[str, float]
    hand_confidence: dict[str, float]
    controller_fallback_share: float
    reach_m: dict[str, float]
    recommended_min_cutoff: float
    recommended_beta: float
    warnings: list[str] = field(default_factory=list)

    def apply(self, cfg: Config) -> Config:
        data = cfg.model_dump(mode="json")
        data["vr"]["standing_eye_height"] = float(min(max(self.eye_height_m, 1.1), 2.1))
        data["vr"]["filter"]["kind"] = FilterKind.ONE_EURO.value
        data["vr"]["filter"]["one_euro_min_cutoff"] = self.recommended_min_cutoff
        data["vr"]["filter"]["one_euro_beta"] = self.recommended_beta
        return Config.model_validate(data)

    def format(self) -> str:
        lines = ["TRACKING CALIBRATION", f"  frames analysed        {self.frames}", f"  eye height             {self.eye_height_m:.3f} m",
                 f"  head jitter (RMS)      {self.head_jitter_mm:.2f} mm"]
        for h in ("left", "right"):
            if h in self.hand_jitter_mm:
                lines.append(f"  {h:<5} hand jitter     {self.hand_jitter_mm[h]:.2f} mm   confidence {self.hand_confidence[h]:.2f}   reach {self.reach_m.get(h, 0):.2f} m")
        lines += [f"  controller fallback    {self.controller_fallback_share * 100:.0f}% of hand samples",
                  f"  recommended One Euro   min_cutoff {self.recommended_min_cutoff:.2f} Hz, beta {self.recommended_beta:.1f}"]
        lines += [f"  warning: {w}" for w in self.warnings]
        return "\n".join(lines)


def run_tracking_calibration(source, seconds: float = 2.0, dt: float = 1.0 / 90.0, t0: float = 0.0) -> TrackingCalibrationResult:
    """`source.poll(t)` -> VRFrame (VRRuntime, ReplaySource, or a synthetic runtime)."""
    n = int(seconds / dt)
    head: list[np.ndarray] = []
    hands: dict[str, list[np.ndarray]] = {"left": [], "right": []}
    conf: dict[str, list[float]] = {"left": [], "right": []}
    fallback = total = 0
    for i in range(n):
        f = source.poll(t0 + i * dt)
        head.append(f.head.p.copy())
        for h in ("left", "right"):
            sk = f.hands.get(h)
            if sk is None:
                continue
            hands[h].append(sk.positions[Joint.WRIST].copy())
            conf[h].append(sk.confidence)
            total += 1
            fallback += f.hand_source.get(h) == "controller"
    hp = np.array(head)
    rms = lambda a: float(np.sqrt(np.mean(np.sum((a - a.mean(axis=0)) ** 2, axis=1)))) * 1000.0 if len(a) else 0.0   # noqa: E731
    head_j = rms(hp)
    hand_j = {h: rms(np.array(v)) for h, v in hands.items() if v}
    reach = {h: float(np.max(np.linalg.norm(np.array(v) - hp[: len(v)], axis=1))) for h, v in hands.items() if v}
    worst = max([head_j, *hand_j.values()])
    min_cutoff = float(np.clip(3.0 / (1.0 + worst / 1.5), 0.6, 3.5))     # more jitter -> heavier smoothing at rest
    warns = []
    if worst > 6.0:
        warns.append("high tracking jitter - check lighting / sensor occlusion")
    if total and fallback / total > 0.5:
        warns.append("most hand samples come from controllers (hand tracking unavailable or low confidence)")
    if hand_j and min(np.mean(c) for c in conf.values() if c) < 0.5:
        warns.append("low hand-tracking confidence")
    return TrackingCalibrationResult(n, float(hp[:, 1].mean()), head_j, hand_j, {h: float(np.mean(c)) for h, c in conf.items() if c},
                                     fallback / total if total else 0.0, reach, round(min_cutoff, 3), 18.0, warns)
