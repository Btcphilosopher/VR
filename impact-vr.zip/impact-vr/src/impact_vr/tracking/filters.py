"""Low-latency signal filters for tracked joint data (vectorised over (N, 3) arrays).

All filters are *timestamp aware* (they use real dt, so they behave at 72/90/120 Hz and survive dropped frames) and can be
reconfigured at runtime via `FilterBank.configure`.
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from collections import deque

import numpy as np

from ..engine.config import FilterCfg, FilterKind


def _alpha(cutoff_hz, dt: float):
    tau = 1.0 / (2.0 * math.pi * np.maximum(cutoff_hz, 1e-6))
    return 1.0 / (1.0 + tau / max(dt, 1e-6))


class SignalFilter(ABC):
    @abstractmethod
    def filter(self, x: np.ndarray, t: float) -> np.ndarray: ...

    @abstractmethod
    def reset(self) -> None: ...


class PassThrough(SignalFilter):
    def filter(self, x: np.ndarray, t: float) -> np.ndarray:
        return x.copy()

    def reset(self) -> None:
        return None


class ExponentialSmoothing(SignalFilter):
    def __init__(self, alpha: float) -> None:
        self.alpha = alpha
        self._y: np.ndarray | None = None

    def filter(self, x: np.ndarray, t: float) -> np.ndarray:
        self._y = x.copy() if self._y is None else self._y + self.alpha * (x - self._y)
        return self._y.copy()

    def reset(self) -> None:
        self._y = None


class MovingAverage(SignalFilter):
    def __init__(self, window: int) -> None:
        self.window = window
        self._buf: deque[np.ndarray] = deque(maxlen=window)

    def filter(self, x: np.ndarray, t: float) -> np.ndarray:
        self._buf.append(x.copy())
        return np.mean(np.stack(self._buf), axis=0)

    def reset(self) -> None:
        self._buf.clear()


class OneEuroFilter(SignalFilter):
    """Casiez et al. 2012. Jitter-free at rest, near-zero lag when moving fast (cutoff grows with speed)."""

    def __init__(self, min_cutoff: float, beta: float, d_cutoff: float) -> None:
        self.min_cutoff, self.beta, self.d_cutoff = min_cutoff, beta, d_cutoff
        self._x: np.ndarray | None = None
        self._dx: np.ndarray = np.zeros(0)
        self._t = 0.0

    def filter(self, x: np.ndarray, t: float) -> np.ndarray:
        if self._x is None:
            self._x, self._dx, self._t = x.copy(), np.zeros_like(x), t
            return x.copy()
        dt = max(t - self._t, 1e-6)
        self._t = t
        dx = (x - self._x) / dt
        a_d = _alpha(self.d_cutoff, dt)
        self._dx = self._dx + a_d * (dx - self._dx)
        speed = np.linalg.norm(self._dx, axis=-1, keepdims=True) if x.ndim > 1 else np.abs(self._dx)
        cutoff = self.min_cutoff + self.beta * speed
        a = _alpha(cutoff, dt)
        self._x = self._x + a * (x - self._x)
        return self._x.copy()

    def reset(self) -> None:
        self._x = None


class VelocityAwareFilter(SignalFilter):
    """Blends between a heavy (slow) and light (fast) exponential filter based on instantaneous speed."""

    def __init__(self, slow_alpha: float, fast_alpha: float, knee: float) -> None:
        self.slow, self.fast, self.knee = slow_alpha, fast_alpha, knee
        self._y: np.ndarray | None = None
        self._t = 0.0

    def filter(self, x: np.ndarray, t: float) -> np.ndarray:
        if self._y is None:
            self._y, self._t = x.copy(), t
            return x.copy()
        dt = max(t - self._t, 1e-6)
        self._t = t
        speed = np.linalg.norm(x - self._y, axis=-1, keepdims=True) / dt if x.ndim > 1 else np.abs(x - self._y) / dt
        k = np.clip(speed / self.knee, 0.0, 1.0)
        k = k * k * (3 - 2 * k)
        a = self.slow + (self.fast - self.slow) * k
        self._y = self._y + a * (x - self._y)
        return self._y.copy()

    def reset(self) -> None:
        self._y = None


def make_filter(cfg: FilterCfg) -> SignalFilter:
    k = cfg.kind
    if k is FilterKind.NONE:
        return PassThrough()
    if k is FilterKind.EMA:
        return ExponentialSmoothing(cfg.ema_alpha)
    if k is FilterKind.MOVING_AVERAGE:
        return MovingAverage(cfg.ma_window)
    if k is FilterKind.VELOCITY_AWARE:
        return VelocityAwareFilter(cfg.va_slow_alpha, cfg.va_fast_alpha, cfg.va_speed_knee)
    return OneEuroFilter(cfg.one_euro_min_cutoff, cfg.one_euro_beta, cfg.one_euro_d_cutoff)


class QuatBank:
    """Vectorised orientation smoothing for all joints at once: nlerp towards the new sample with an alpha that opens up with
    angular speed (heavy filtering at rest, near-zero lag in fast motion)."""

    def __init__(self, enabled: bool, slow_alpha: float = 0.35, fast_alpha: float = 0.95) -> None:
        self.enabled, self.slow, self.fast = enabled, slow_alpha, fast_alpha
        self._q: np.ndarray | None = None

    def filter(self, q: np.ndarray, t: float) -> np.ndarray:
        q = q / np.maximum(np.linalg.norm(q, axis=1, keepdims=True), 1e-9)
        if self._q is None or not self.enabled:
            self._q = q.copy()
            return q
        d = np.sum(self._q * q, axis=1, keepdims=True)
        q = np.where(d < 0.0, -q, q)
        ang = 2.0 * np.arccos(np.minimum(1.0, np.abs(d)))
        k = np.minimum(1.0, ang / 0.25)
        a = self.slow + (self.fast - self.slow) * k
        out = self._q * (1.0 - a) + q * a
        self._q = out / np.maximum(np.linalg.norm(out, axis=1, keepdims=True), 1e-9)
        return self._q.copy()

    def reset(self) -> None:
        self._q = None


class FilterBank:
    """The filters owned by one tracked hand. Reconfigurable at runtime without losing the stream."""

    def __init__(self, cfg: FilterCfg) -> None:
        self.cfg = cfg
        self.pos = make_filter(cfg)
        self.rot = QuatBank(cfg.kind is not FilterKind.NONE)
        self.vel_alpha_hz = cfg.velocity_cutoff_hz

    def configure(self, **overrides: object) -> None:
        """e.g. bank.configure(kind='ema', ema_alpha=0.4). Validated by the pydantic model."""
        data = self.cfg.model_dump()
        data.update(overrides)
        self.cfg = FilterCfg.model_validate(data)
        self.pos = make_filter(self.cfg)
        self.vel_alpha_hz = self.cfg.velocity_cutoff_hz
        self.rot.enabled = self.cfg.kind is not FilterKind.NONE

    def filter_positions(self, p: np.ndarray, t: float) -> np.ndarray:
        return self.pos.filter(p, t)

    def filter_quats(self, q: np.ndarray, t: float) -> np.ndarray:
        return self.rot.filter(q, t)

    def reset(self) -> None:
        self.pos.reset()
        self.rot.reset()


def lowpass_alpha(cutoff_hz: float, dt: float) -> float:
    return float(_alpha(cutoff_hz, dt))


__all__ = ["FilterBank", "QuatBank", "make_filter", "OneEuroFilter", "ExponentialSmoothing", "MovingAverage", "VelocityAwareFilter", "PassThrough", "lowpass_alpha"]
