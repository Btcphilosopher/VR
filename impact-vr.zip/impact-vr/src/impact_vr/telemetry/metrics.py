"""Tiny in-process counters / gauges (exportable as a dict for diagnostics and the benchmark)."""

from __future__ import annotations

from collections import Counter


class Metrics:
    def __init__(self) -> None:
        self.counters: Counter[str] = Counter()
        self.gauges: dict[str, float] = {}

    def inc(self, name: str, n: int = 1) -> None:
        self.counters[name] += n

    def gauge(self, name: str, v: float) -> None:
        self.gauges[name] = v

    def snapshot(self) -> dict[str, object]:
        return {"counters": dict(self.counters), "gauges": dict(self.gauges)}
