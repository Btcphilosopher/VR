"""Latency as a first-class metric: per-stage timing from tracked input to felt haptics.

Stages (ms):  tracking -> gesture -> collision -> gameplay -> haptic_scheduling -> hardware_transport
`INPUT -> COLLISION -> HAPTIC` reports the sum. Compute stages are measured with perf_counter_ns around the real code; the
scheduler / transport stages use the simulated virtual-time latencies, so results are meaningful in simulation and become real
measurements when hardware drives the same pipeline.
"""

from __future__ import annotations

import time
from collections import defaultdict, deque
from contextlib import contextmanager
from dataclasses import dataclass, field

STAGES = ("tracking", "gesture", "collision", "gameplay", "haptic_scheduling", "hardware_transport")


@dataclass
class Trace:
    id: int
    stages: dict[str, float] = field(default_factory=dict)
    done: bool = False

    @property
    def total(self) -> float:
        return sum(self.stages.get(s, 0.0) for s in STAGES)


def _pct(xs: list[float], p: float) -> float:
    if not xs:
        return 0.0
    s = sorted(xs)
    return s[min(len(s) - 1, max(0, int(round(p * (len(s) - 1)))))]


class LatencyTracker:
    def __init__(self, keep: int = 2048) -> None:
        self.samples: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=keep))
        self.traces: dict[int, Trace] = {}
        self.completed: deque[Trace] = deque(maxlen=keep)
        self._frame_stage: dict[str, float] = {}
        self._next = 1

    @contextmanager
    def measure(self, stage: str):
        t0 = time.perf_counter_ns()
        try:
            yield
        finally:
            ms = (time.perf_counter_ns() - t0) / 1e6
            self._frame_stage[stage] = self._frame_stage.get(stage, 0.0) + ms
            self.samples[stage].append(ms)

    def add(self, stage: str, ms: float) -> None:
        self._frame_stage[stage] = self._frame_stage.get(stage, 0.0) + ms
        self.samples[stage].append(ms)

    def new_frame(self) -> None:
        self._frame_stage = {}

    def frame_stages(self) -> dict[str, float]:
        return dict(self._frame_stage)

    def begin_trace(self, extra: dict[str, float] | None = None) -> int:
        tid = self._next
        self._next += 1
        tr = Trace(tid, {k: v for k, v in self._frame_stage.items() if k in STAGES})
        if extra:
            tr.stages.update(extra)
        self.traces[tid] = tr
        if len(self.traces) > 4096:
            self.traces.pop(next(iter(self.traces)))
        return tid

    def stage(self, tid: int, name: str, ms: float) -> None:
        tr = self.traces.get(tid)
        if tr is not None and not tr.done:
            tr.stages[name] = max(tr.stages.get(name, 0.0), ms)       # one haptic event -> many commands: the *first* sets the latency

    def finish(self, tid: int) -> Trace | None:
        tr = self.traces.get(tid)
        if tr is None or tr.done:
            return tr
        tr.done = True
        for k in ("haptic_scheduling", "hardware_transport"):
            if k in tr.stages:
                self.samples[k].append(tr.stages[k])
        self.completed.append(tr)
        self.samples["total"].append(tr.total)
        return tr

    def summary(self) -> dict[str, dict[str, float]]:
        out = {}
        for k in (*STAGES, "total"):
            xs = list(self.samples.get(k, ()))
            out[k] = {"mean": sum(xs) / len(xs) if xs else 0.0, "p95": _pct(xs, 0.95), "max": max(xs) if xs else 0.0, "n": float(len(xs))}
        return out

    def breakdown_text(self) -> str:
        s = self.summary()
        parts = [f"{k}:{s[k]['mean']:.2f}" for k in STAGES]
        return f"INPUT -> COLLISION -> HAPTIC  total {s['total']['mean']:.2f} ms (p95 {s['total']['p95']:.2f})  | " + "  ".join(parts)

    def last_total(self) -> float:
        return self.completed[-1].total if self.completed else 0.0
