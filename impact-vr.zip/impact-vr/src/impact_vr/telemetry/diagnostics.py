"""System diagnostics: environment, optional dependencies, VR/OpenXR availability, glove status, config validity, quick self-check."""

from __future__ import annotations

import importlib
import platform
import sys
import time
from dataclasses import dataclass, field

from ..engine.config import load_config


@dataclass
class Check:
    name: str
    ok: bool
    detail: str = ""
    severity: str = "info"      # info | warn | fail


@dataclass
class DiagnosticsReport:
    checks: list[Check] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not any(c.severity == "fail" and not c.ok for c in self.checks)

    def format(self) -> str:
        out = ["IMPACT//VR diagnostics"]
        for c in self.checks:
            tag = "OK  " if c.ok else ("WARN" if c.severity == "warn" else "N/A " if c.severity == "info" else "FAIL")
            out.append(f"  [{tag}] {c.name:<28} {c.detail}")
        out.append(f"overall: {'READY (simulation mode always available)' if self.ok else 'PROBLEMS FOUND'}")
        return "\n".join(out)


def _opt(mod: str) -> tuple[bool, str]:
    try:
        m = importlib.import_module(mod)
        return True, getattr(m, "__version__", "installed")
    except Exception as e:  # noqa: BLE001
        return False, f"not installed ({type(e).__name__})"


def run_diagnostics(quick_selfcheck: bool = True) -> DiagnosticsReport:
    r = DiagnosticsReport()
    add = r.checks.append
    add(Check("python", sys.version_info >= (3, 12), f"{platform.python_version()} on {platform.system()}", "fail"))
    for mod, sev in (("numpy", "fail"), ("pydantic", "fail"), ("scipy", "warn"), ("pygame", "warn")):
        ok, d = _opt(mod)
        add(Check(f"dependency {mod}", ok, d, sev))
    for mod, what in (("moderngl", "GPU renderer"), ("xr", "OpenXR (pyopenxr)"), ("cv2", "OpenCV debug views"), ("serial", "serial gloves"), ("bleak", "BLE gloves"),
                      ("hid", "HID gloves"), ("websockets", "WebSocket gloves")):
        ok, d = _opt(mod)
        add(Check(f"optional {mod}", ok, f"{what}: {d}", "info"))
    try:
        cfg = load_config()
        add(Check("configuration", True, f"vr/haptics/physics/gameplay/graphics/audio valid; target {cfg.vr.target_fps:.0f} fps, difficulty {cfg.gameplay.difficulty}"))
    except Exception as e:  # noqa: BLE001
        add(Check("configuration", False, str(e)[:160], "fail"))
        return r
    from ..vr.adapters import OpenXRAdapter
    from ..vr.device import VRUnavailable

    try:
        OpenXRAdapter()
        add(Check("OpenXR runtime", True, "available"))
    except VRUnavailable as e:
        add(Check("OpenXR runtime", False, f"{e} -> using synthetic/simulated input", "info"))
    if quick_selfcheck:
        from ..haptics.gloves.simulated import SimulatedHapticGlove
        from ..simulation.scenarios import SCENARIOS

        t0 = time.perf_counter()
        s = SCENARIOS["jab_cross"].run(cfg)
        dt = time.perf_counter() - t0
        strikes = [e.data["strike"]["type"] for e in s.events("STRIKE_DETECTED") if e.data.get("phase") == "ended"]
        add(Check("pipeline self-check", strikes == ["jab", "cross"] and s.pipeline.sent_total > 0, f"strikes {strikes}, {s.pipeline.sent_total} haptic commands, {dt:.2f}s", "fail"))
        rep = s.pipeline.limiter.report
        add(Check("safety limiter", not s.pipeline.limiter.tripped, f"passed {rep.passed}, clamped {rep.clamped}, rejected {sum(rep.rejected.values())}", "fail"))
        g = SimulatedHapticGlove("right")
        add(Check("simulated glove", g.connect(0.0), f"{len(g.detect_actuators())} actuators"))
    return r
