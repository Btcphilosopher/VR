"""Structured (JSON-lines) logging correlated by session id and frame id."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any, TextIO

from ..engine.events import Event, EventBus

LOGGER_NAME = "impact_vr"


def _default(o: Any) -> Any:
    try:
        import numpy as np

        if isinstance(o, np.ndarray):
            return [round(float(x), 4) for x in o.ravel()]
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
    except Exception:  # noqa: BLE001
        pass
    if hasattr(o, "to_dict"):
        return o.to_dict()
    if hasattr(o, "value"):
        return o.value
    return str(o)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {"ts": round(record.created, 6), "level": record.levelname, "logger": record.name, "msg": record.getMessage()}
        extra = getattr(record, "fields", None)
        if extra:
            payload.update(extra)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, sort_keys=True, default=_default)


def configure_logging(stream: TextIO | None = None, level: int = logging.INFO, path: str | None = None) -> logging.Logger:
    log = logging.getLogger(LOGGER_NAME)
    log.setLevel(level)
    for old in list(log.handlers):
        log.removeHandler(old)
    handler: logging.Handler = logging.FileHandler(path) if path else logging.StreamHandler(stream or sys.stderr)
    handler.setFormatter(JsonFormatter())
    log.addHandler(handler)
    log.propagate = False
    return log


def get_logger() -> logging.Logger:
    return logging.getLogger(LOGGER_NAME)


def _scalarise(d: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in d.items():
        if hasattr(v, "to_dict"):
            out[k] = v.to_dict()
        elif isinstance(v, (int, float, str, bool, type(None))):
            out[k] = v
        elif isinstance(v, (list, tuple)) and all(isinstance(x, (int, float, str)) for x in v):
            out[k] = list(v)
        else:
            out[k] = _default(v) if not isinstance(v, (dict, set)) else str(v)[:120]
    return out


class EventLogger:
    """Subscribes to an EventBus and emits one structured log line per event (filterable)."""

    def __init__(self, bus: EventBus, logger: logging.Logger | None = None, names: set[str] | None = None, level: int = logging.DEBUG) -> None:
        self.log = logger or get_logger()
        self.names = names
        self.level = level
        self.count = 0
        bus.subscribe_all(self._on)

    def _on(self, ev: Event) -> None:
        if self.names is not None and ev.name not in self.names:
            return
        if not self.log.isEnabledFor(self.level):
            return
        self.count += 1
        self.log.log(self.level, ev.name, extra={"fields": {"event": ev.name, "session": ev.session, "frame": ev.frame, "t": round(ev.t, 5), **_scalarise(ev.data)}})
