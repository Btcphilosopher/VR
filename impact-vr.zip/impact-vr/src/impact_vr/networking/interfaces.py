"""Networking preparation (co-op sparring / spectating): interfaces only. Snapshots are plain, serialisable data."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class PlayerSnapshot:
    player_id: int
    tick: int
    head: tuple[float, ...]
    left_hand: tuple[float, ...]
    right_hand: tuple[float, ...]
    health: float


@dataclass(frozen=True)
class EnemySnapshot:
    enemy_id: str
    tick: int
    pos: tuple[float, float, float]
    yaw: float
    state: str
    health: float


@dataclass(frozen=True)
class ImpactSnapshot:
    tick: int
    attacker: str
    target: str
    region: str
    energy: float
    position: tuple[float, float, float]


class NetSession(ABC):
    @abstractmethod
    def host(self, mode: str, max_players: int = 2) -> None: ...
    @abstractmethod
    def join(self, address: str) -> None: ...
    @abstractmethod
    def leave(self) -> None: ...
    @abstractmethod
    def send(self, channel: str, payload: dict[str, Any]) -> None: ...
    @abstractmethod
    def poll(self) -> list[tuple[str, dict[str, Any]]]: ...


class StateReplication(ABC):
    @abstractmethod
    def publish_player(self, snap: PlayerSnapshot) -> None: ...
    @abstractmethod
    def publish_enemies(self, snaps: list[EnemySnapshot]) -> None: ...
    @abstractmethod
    def publish_impact(self, snap: ImpactSnapshot) -> None: ...
    @abstractmethod
    def remote_players(self) -> dict[int, PlayerSnapshot]: ...


@dataclass
class LoopbackSession(NetSession):
    _q: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    connected: bool = False

    def host(self, mode: str, max_players: int = 2) -> None:
        self.connected = True

    def join(self, address: str) -> None:
        self.connected = True

    def leave(self) -> None:
        self.connected = False
        self._q.clear()

    def send(self, channel: str, payload: dict[str, Any]) -> None:
        if self.connected:
            self._q.append((channel, dict(payload)))

    def poll(self) -> list[tuple[str, dict[str, Any]]]:
        out, self._q = self._q, []
        return out
