"""Gameplay damage. Takes a *physical* impact and converts it to game values through configurable curves."""

from __future__ import annotations

from dataclasses import dataclass

from ..engine.config import DamageCfg
from ..engine.mathx import Vec, unit
from ..physics.impact import PhysicalImpact


@dataclass(frozen=True)
class DamageResult:
    damage: float
    stagger: float
    knockback: Vec
    region_multiplier: float
    combo_multiplier: float
    blocked_fraction: float = 0.0


def base_damage(energy_j: float, cfg: DamageCfg) -> float:
    """Saturating curve: half of max_base_damage at energy_half_j, asymptote at max_base_damage."""
    return cfg.max_base_damage * energy_j / (energy_j + cfg.energy_half_j) if energy_j > 0 else 0.0


def damage_from_impact(imp: PhysicalImpact, region: str, normal: Vec, cfg: DamageCfg, *, armor: float = 0.0, combo_hits: int = 0,
                       confidence: float = 1.0, blocked_fraction: float = 0.0, knockback_per_impulse: float = 0.08, scale: float = 1.0) -> DamageResult:
    rm = cfg.region_multiplier.get(region, 1.0)
    combo = 1.0 + cfg.combo_bonus_per_hit * min(combo_hits, 8)
    conf = 0.8 + 0.2 * confidence
    raw = base_damage(imp.energy_j, cfg) * rm * combo * conf * scale
    dmg = raw * (1.0 - armor) * (1.0 - blocked_fraction * cfg.block_reduction)
    stagger = imp.energy_j * cfg.stagger_per_joule * (1.3 if region == "HEAD" else 1.0) * (1.0 - 0.5 * blocked_fraction)
    kb = unit(-normal) * imp.impulse * knockback_per_impulse * (1.0 - blocked_fraction * 0.7)
    return DamageResult(max(0.0, dmg), max(0.0, stagger), kb, rm, combo, blocked_fraction)
