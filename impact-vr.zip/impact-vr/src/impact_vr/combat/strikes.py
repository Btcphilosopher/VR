"""Trajectory-based strike recognition.

For each hand we keep a short ring buffer of the fist trajectory (in the fighter's yaw-only body frame). A strike begins when fist
speed and acceleration cross onset thresholds, is *provisionally* classified after a few samples (so a contact that happens
mid-swing already knows what kind of strike it is), and is finalised when the hand decelerates. Classification is a soft scoring
model over movement features, not a rule on button state:

    forward / lateral / vertical fractions of the displacement, heading change (arc), palm-vs-travel alignment, fist/open hand pose,
    and whether the forearm axis opposes travel (elbow leading). Retraction back to the guard position is recognised and rejected.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from ..engine.config import Stance
from ..engine.mathx import Transform, Vec, clamp, norm, sigmoid, unit, v3
from ..hands.analyzer import HandState
from .events import StrikeEvent


@dataclass
class StrikeTuning:
    onset_speed: float = 1.6          # m/s
    onset_accel: float = 8.0          # m/s^2 (or speed above fast_onset)
    fast_onset: float = 2.4
    end_speed: float = 0.9
    min_peak_speed: float = 2.0
    min_travel: float = 0.12          # m
    max_duration: float = 0.75        # s
    detect_samples: int = 3
    buffer: int = 96
    cooldown: float = 0.10            # s between strikes of the same hand
    min_confidence: float = 0.5       # recognitions below this are discarded as noise


def _sig(x: float, thr: float, k: float = 8.0) -> float:
    return sigmoid(k * (x - thr))


@dataclass
class _Sample:
    t: float
    p: Vec
    v: Vec
    speed: float


@dataclass
class _HandTrack:
    buf: deque = field(default_factory=lambda: deque(maxlen=96))
    active: bool = False
    origin_w: Vec | None = None
    origin_b: Vec | None = None
    peak_speed: float = 0.0
    peak_acc: float = 0.0
    low_count: int = 0
    prev_speed: float = 0.0
    prev_t: float | None = None
    last_end_t: float = -9.0
    path: list = field(default_factory=list)       # (t, p_body, speed)
    provisional: StrikeEvent | None = None
    announced: bool = False
    onset_t: float = 0.0
    home: Vec | None = None
    recovery: bool = False


class StrikeDetector:
    def __init__(self, stance: Stance = Stance.ORTHODOX, tuning: StrikeTuning | None = None) -> None:
        self.stance = stance
        self.tuning = tuning or StrikeTuning()
        self._tracks = {"left": _HandTrack(), "right": _HandTrack()}
        self._next_id = 1

    def lead_hand(self) -> str:
        return "left" if self.stance is Stance.ORTHODOX else "right"

    def reset(self) -> None:
        self._tracks = {"left": _HandTrack(), "right": _HandTrack()}

    # ---- queries ------------------------------------------------------------------------------------------------------------
    def active_strike(self, hand: str) -> StrikeEvent | None:
        tr = self._tracks[hand]
        return tr.provisional if tr.active else None

    def is_striking(self, hand: str) -> bool:
        return self._tracks[hand].active

    def consume_on_contact(self, hand: str, point: Vec, normal: Vec) -> StrikeEvent | None:
        """Called by the collision layer on first contact: stamps the contact point/normal on the strike."""
        tr = self._tracks[hand]
        if not tr.active or tr.provisional is None:
            return None
        ev = tr.provisional
        ev.contact_point, ev.contact_normal = point.copy(), normal.copy()
        return ev

    # ---- main --------------------------------------------------------------------------------------------------------------------
    def update(self, hand: str, st: HandState, body: Transform, head_vel: Vec | None = None) -> list[StrikeEvent]:
        """`st` should be head-relative (translation of the body removed); `body` supplies the yaw frame.
        Returns newly *announced* (phase 'active', once per strike) and *ended* strikes."""
        tr = self._tracks[hand]
        tun = self.tuning
        inv = body.inverse()
        p_b = inv.apply(st.fist_center)
        v_b = inv.apply_dir(st.fist_velocity - (head_vel if head_vel is not None else 0.0))
        speed = float(np.linalg.norm(v_b))
        dt = st.dt if st.dt > 0 else 1.0 / 90
        acc_along = (speed - tr.prev_speed) / dt if tr.prev_t is not None else 0.0
        tr.prev_speed, tr.prev_t = speed, st.t
        tr.buf.append(_Sample(st.t, p_b, v_b, speed))
        if speed < 0.4 and not tr.active:      # idle pose = where a retracting hand comes back to
            tr.home = p_b.copy() if tr.home is None else tr.home + 0.04 * (p_b - tr.home)
        out: list[StrikeEvent] = []
        if not st.tracked or st.confidence < 0.2:
            if tr.active:
                self._abort(tr)
            return out
        if not tr.active:
            fast = speed >= tun.fast_onset
            if (speed >= tun.onset_speed and acc_along >= tun.onset_accel or fast) and st.t - tr.last_end_t >= tun.cooldown:
                tr.active = True
                tr.recovery = False
                tr.announced = False
                tr.low_count = 0
                tr.peak_speed = speed
                tr.peak_acc = max(acc_along, 0.0)
                # origin: rewind the buffer to where the motion really started (but not into the slow lead-in)
                start = len(tr.buf) - 1
                while start > 0 and tr.buf[start - 1].speed > 0.5 * tun.onset_speed and len(tr.buf) - start < 14:
                    start -= 1
                tr.path = [(s.t, s.p, s.speed) for s in list(tr.buf)[start:]]
                tr.onset_t = tr.path[0][0]
                tr.origin_b = tr.path[0][1].copy()
                tr.origin_w = body.apply(tr.origin_b)
            else:
                return out
        else:
            tr.path.append((st.t, p_b, speed))
            tr.peak_speed = max(tr.peak_speed, speed)
            tr.peak_acc = max(tr.peak_acc, acc_along)
        tr.low_count = tr.low_count + 1 if speed < tun.end_speed else 0
        dur = st.t - tr.onset_t
        if len(tr.path) >= tun.detect_samples and not tr.recovery:
            ev = self._classify(hand, st, body, tr)
            if ev is not None and ev.confidence >= tun.min_confidence:
                tr.provisional = ev
                if not tr.announced:
                    tr.announced = True
                    ev.detect_latency_ms = (st.t - tr.onset_t) * 1000.0
                    out.append(ev)
        if tr.low_count >= 2 or dur > tun.max_duration:
            ended = self._finish(hand, st, body, tr)
            if ended is not None:
                out.append(ended)
        return out

    # ---- internals -----------------------------------------------------------------------------------------------------------------
    def _abort(self, tr: _HandTrack) -> None:
        tr.active = False
        tr.provisional = None
        tr.path = []

    def _finish(self, hand: str, st: HandState, body: Transform, tr: _HandTrack) -> StrikeEvent | None:
        tun = self.tuning
        ev = tr.provisional
        travel = norm(tr.path[-1][1] - tr.path[0][1]) if tr.path else 0.0
        valid = ev is not None and tr.peak_speed >= tun.min_peak_speed and travel >= tun.min_travel
        out = None
        if valid and ev is not None:
            ev.phase = "ended"
            ev.t_end = st.t
            ev.duration = st.t - ev.t_start
            ev.velocity = tr.peak_speed
            ev.acceleration = tr.peak_acc
            out = ev
        tr.active = False
        tr.last_end_t = st.t
        tr.provisional = None
        tr.path = []
        return out

    def _classify(self, hand: str, st: HandState, body: Transform, tr: _HandTrack) -> StrikeEvent | None:
        pts = np.array([p for _, p, _ in tr.path])
        ts = np.array([t for t, _, _ in tr.path])
        n = len(pts)
        disp = pts[-1] - pts[0]
        chord = norm(disp)
        if chord < 0.02:
            return None
        d_b = disp / chord
        if tr.home is not None and tr.origin_b is not None and not tr.announced and tr.path and tr.path[0][0] - tr.last_end_t < 0.7:
            to_home = tr.home - tr.origin_b
            dh = norm(to_home)
            if dh > 0.15 and float(np.dot(d_b, to_home / dh)) > 0.75:      # right after a strike, heading back to guard: recovery
                tr.recovery = True
                tr.provisional = None
                return None
        seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        path_len = float(seg.sum())
        arc_ratio = max(0.0, path_len / max(chord, 1e-6) - 1.0)
        k = max(2, n // 3)
        h0 = pts[min(k, n - 1)] - pts[0]
        h1 = pts[-1] - pts[max(0, n - 1 - k)]
        a0, a1 = math.atan2(h0[0], h0[2]), math.atan2(h1[0], h1[2])
        arc = abs((a1 - a0 + math.pi) % (2 * math.pi) - math.pi) if norm(h0[[0, 2]]) > 1e-3 and norm(h1[[0, 2]]) > 1e-3 else 0.0
        side_sign = 1.0 if hand == "right" else -1.0
        fwd = float(d_b[2])
        up = float(d_b[1])
        lat_out = float(d_b[0]) * side_sign
        horiz = math.hypot(d_b[0], d_b[2])
        lat_h = abs(d_b[0]) / horiz if horiz > 1e-6 else 0.0
        hh = math.hypot(h1[0], h1[2])
        end_lat_out = float(h1[0]) * side_sign / hh if hh > 1e-6 else 0.0
        inv = body.inverse()
        palm_n = inv.apply_dir(st.palm_normal)
        fwd_axis = inv.apply_dir(st.forward)
        fist, openness = st.fist_prob, st.openness
        palm_dot = float(np.dot(palm_n, d_b))
        axis_dot = float(np.dot(fwd_axis, d_b))
        elbow_v = st.wrist_velocity + np.cross(st.angular_velocity, st.elbow - st.wrist)
        elbow_lead = float(np.linalg.norm(elbow_v)) / max(float(np.linalg.norm(st.wrist_velocity)), 1e-6)
        fist_f = 0.25 + 0.75 * fist
        closed_f = 1.0 - sigmoid(8 * (openness - 0.6))

        palm = _sig(openness, 0.5) * _sig(palm_dot, 0.35) * _sig(fwd, 0.4) * _sig(-abs(up), -0.55)
        backhand = _sig(openness, 0.3) * _sig(-palm_dot, 0.25) * _sig(lat_out, 0.3) * _sig(lat_h, 0.35) * _sig(-abs(up), -0.5)
        elbow = _sig(-axis_dot, 0.35) * _sig(elbow_lead, 0.85, 10) * (0.4 + 0.6 * fist_f)
        hammer = _sig(-up, 0.45) * _sig(fist, 0.4) * (1 - 0.7 * palm)
        upper = _sig(up, 0.38) * fist_f * _sig(fwd, -0.1) * (1 - elbow * 0.7)
        hook = _sig(arc, 0.5) * _sig(-end_lat_out, 0.3) * _sig(-abs(up), -0.55) * fist_f * (1 - 0.8 * elbow) * (1 - 0.6 * hammer)
        straight = _sig(fwd, 0.55) * _sig(-arc, -0.5) * _sig(-arc_ratio, -0.3, 6) * fist_f * closed_f ** 0.5 * (1 - palm) * (1 - elbow)
        lead = self.lead_hand() == hand
        scores = {"jab" if lead else "cross": straight, "hook": hook, "uppercut": upper, "hammer_fist": hammer, "palm_strike": palm,
                  "backhand": backhand, "elbow_strike": elbow}
        ranked = sorted(scores.items(), key=lambda kv: -kv[1])
        best, second = ranked[0], ranked[1]
        margin = best[1] / (best[1] + second[1] + 1e-9)
        conf = clamp(best[1] ** 0.5 * (0.5 + 0.5 * margin) * st.confidence * (0.6 + 0.4 * clamp(tr.peak_speed / 4.0, 0, 1)), 0.0, 1.0)
        prev = tr.provisional
        if prev is not None and prev.id:
            sid = prev.id
        else:
            sid = self._next_id
            self._next_id += 1
        ev = StrikeEvent(
            hand=hand, type=best[0], origin=tr.origin_w.copy() if tr.origin_w is not None else v3(), direction=unit(body.apply_dir(d_b)),
            velocity=tr.peak_speed, acceleration=tr.peak_acc, duration=float(ts[-1] - ts[0]), arc=arc, confidence=conf, t_start=float(ts[0]),
            t_end=float(ts[-1]), phase="active", arc_ratio=arc_ratio, scores={k_: round(v_, 3) for k_, v_ in scores.items()}, id=sid,
        )
        if prev is not None:
            ev.contact_point, ev.contact_normal = prev.contact_point, prev.contact_normal
            ev.detect_latency_ms = prev.detect_latency_ms
        return ev
