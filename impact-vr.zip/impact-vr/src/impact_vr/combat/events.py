"""Combat data types: StrikeEvent, GestureEvent, ImpactEvent and the hit-region vocabulary."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from ..engine.mathx import Vec


class BodyRegion(str, Enum):
    HEAD = "HEAD"
    TORSO = "TORSO"
    LEFT_ARM = "LEFT_ARM"
    RIGHT_ARM = "RIGHT_ARM"
    LEFT_LEG = "LEFT_LEG"
    RIGHT_LEG = "RIGHT_LEG"
    CORE = "CORE"
    WEAPON = "WEAPON"
    ENVIRONMENT = "ENVIRONMENT"


STRIKE_TYPES = ("jab", "cross", "hook", "uppercut", "hammer_fist", "palm_strike", "backhand", "elbow_strike")
GESTURE_TYPES = ("block", "parry", "grab", "push", "shove", "dodge", "duck", "weave")


@dataclass
class StrikeEvent:
    """A recognised strike, derived from the *trajectory* of a tracked hand (never from a button)."""

    hand: str
    type: str
    origin: Vec                       # strike_origin: where the motion started
    direction: Vec                    # strike_direction: unit vector of travel
    velocity: float                   # strike_velocity: peak speed, m/s
    acceleration: float               # strike_acceleration: peak acceleration along the path, m/s^2
    duration: float                   # strike_duration, s
    arc: float                        # strike_arc: heading change over the path, rad
    confidence: float
    t_start: float = 0.0
    t_end: float = 0.0
    contact_point: Vec | None = None
    contact_normal: Vec | None = None
    phase: str = "active"             # active | ended
    arc_ratio: float = 0.0            # path length / chord - 1
    scores: dict[str, float] = field(default_factory=dict)
    detect_latency_ms: float = 0.0    # onset -> recognition
    id: int = 0

    @property
    def strike_type(self) -> str:
        return self.type

    def to_dict(self) -> dict[str, Any]:
        r = lambda v: [round(float(x), 4) for x in v] if v is not None else None  # noqa: E731
        return {"hand": self.hand, "type": self.type, "origin": r(self.origin), "direction": r(self.direction),
                "velocity": round(self.velocity, 3), "acceleration": round(self.acceleration, 2), "duration": round(self.duration, 4),
                "arc": round(self.arc, 3), "confidence": round(self.confidence, 3), "contact_point": r(self.contact_point),
                "contact_normal": r(self.contact_normal), "phase": self.phase}


@dataclass
class GestureEvent:
    type: str
    hand: str | None
    t: float
    confidence: float = 1.0
    direction: Vec | None = None
    magnitude: float = 0.0
    target: str | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "hand": self.hand, "t": round(self.t, 4), "confidence": round(self.confidence, 3),
                "magnitude": round(self.magnitude, 3), "target": self.target}


@dataclass
class ImpactEvent:
    attacker: str
    target: str
    body_region: str
    impact_type: str                  # strike type, "push", "shove", "touch", "thrown_object", "blocked_*", ...
    velocity: float
    impulse: float
    normal: Vec
    position: Vec
    energy: float = 0.0
    material: str = "flesh"
    hand: str | None = None
    t: float = 0.0
    frame: int = 0
    strike_id: int = 0
    confidence: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        r = lambda v: [round(float(x), 4) for x in v]  # noqa: E731
        return {"attacker": self.attacker, "target": self.target, "body_region": self.body_region, "impact_type": self.impact_type,
                "velocity": round(self.velocity, 3), "impulse": round(self.impulse, 3), "energy": round(self.energy, 3), "normal": r(self.normal),
                "position": r(self.position), "material": self.material, "hand": self.hand, "t": round(self.t, 4)}
