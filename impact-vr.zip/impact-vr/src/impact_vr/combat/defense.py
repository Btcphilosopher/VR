"""Defensive recognition: guard model, block, parry, dodge, duck, weave, grab, push, shove.

All of it is derived from tracked motion (hand/forearm position, head displacement, velocities) - no buttons.
"""

from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from ..engine.config import GuardCfg
from ..engine.mathx import Transform, Vec, clamp, norm, q_from_yaw, q_rotate, unit, v3
from ..hands.analyzer import HandState
from ..physics.shapes import closest_on_segment
from .events import GestureEvent


@dataclass
class IncomingAttack:
    """What the guard model needs to know about an enemy attack in flight."""

    attacker: str
    kind: str
    fist_from: Vec            # where the striking limb is now
    fist_to: Vec              # where it is heading (target point on the player)
    t_impact: float           # predicted (or actual) impact time
    power: float = 1.0
    target_region: str = "HEAD"


@dataclass
class BlockResult:
    blocked_fraction: float
    coverage: float
    timing: float
    parried: bool
    hand: str | None
    quality: str              # none | partial | solid | parry


@dataclass
class GuardState:
    active: bool = False
    since: float = -9.0
    hands_up: dict[str, bool] = field(default_factory=lambda: {"left": False, "right": False})
    forearms: dict[str, tuple[Vec, Vec]] = field(default_factory=dict)
    palms: dict[str, Vec] = field(default_factory=dict)
    held: float = 0.0


class GuardModel:
    """Virtual guard from hand position, forearm orientation and head position (spec: PHYSICAL GUARDING)."""

    def __init__(self, cfg: GuardCfg, forearm_radius: float = 0.07) -> None:
        self.cfg = cfg
        self.forearm_radius = forearm_radius
        self.state = GuardState()
        self._parries: deque[tuple[float, float, str, Vec, float]] = deque(maxlen=8)   # (t_start, t_end, hand, direction, magnitude)

    def update(self, t: float, head_p: Vec, head_q: Vec, hands: dict[str, HandState | None], forearm_len: float = 0.27) -> GuardState:
        gs = self.state
        any_up = False
        for h in ("left", "right"):
            st = hands.get(h)
            up = False
            if st is not None and st.tracked:
                fist = st.fist_center
                gs.forearms[h] = (st.wrist, st.wrist - st.forward * forearm_len)
                gs.palms[h] = st.palm
                d_head = norm(fist - head_p)
                pointing_up = st.forward[1] > -0.15 or fist[1] > head_p[1] - 0.35
                slow = st.speed < 1.2
                up = d_head < self.cfg.hands_near_head_m and fist[1] > head_p[1] - 0.38 and pointing_up and slow
            gs.hands_up[h] = up
            any_up = any_up or up
        if any_up and not gs.active:
            gs.active, gs.since = True, t
        elif not any_up:
            gs.active = False
        gs.held = (t - gs.since) if gs.active else 0.0
        return gs

    def note_parry(self, ev: GestureEvent) -> None:
        if ev.hand is not None:
            self._parries.append((float(ev.data.get("t_start", ev.t)), ev.t, ev.hand, ev.direction if ev.direction is not None else v3(), ev.magnitude))

    def coverage(self, frm: Vec, to: Vec) -> tuple[float, str | None]:
        """How well forearms/hands shield the line from the attacker's fist to the target point (0..1)."""
        gs = self.state
        best, hand = 0.0, None
        r = self.cfg.coverage_radius_m
        seg = to - frm
        for h, (a, b) in gs.forearms.items():
            if not gs.hands_up.get(h, False):
                continue
            dmin = 9.0
            for u in (0.55, 0.7, 0.85, 1.0):
                pt = frm + seg * u
                q = closest_on_segment(pt, a, b)
                dmin = min(dmin, norm(pt - q))
            cov = clamp(1.0 - (dmin - self.forearm_radius) / max(r, 1e-6), 0.0, 1.0)
            if cov > best:
                best, hand = cov, h
        return best, hand

    def evaluate(self, atk: IncomingAttack, t_now: float) -> BlockResult:
        gs = self.state
        cov, hand = self.coverage(atk.fist_from, atk.fist_to)
        timing = clamp(gs.held / max(self.cfg.full_guard_s, 1e-6), 0.0, 1.0) if gs.active else 0.0
        parried, phand = False, None
        for t0, t1, h, d, mag in self._parries:
            # the attack must land while the parry sweep is in progress or shortly after it (not before it began)
            if t0 - 0.05 <= atk.t_impact <= t1 + self.cfg.parry_window_s:
                pal = gs.palms.get(h)
                if pal is not None:
                    q = closest_on_segment(pal, atk.fist_from, atk.fist_to)
                    if norm(pal - q) < 0.38:
                        parried, phand = True, h
                        break
        if parried:
            return BlockResult(1.0, max(cov, 0.8), 1.0, True, phand, "parry")
        frac = cov * (0.35 + 0.65 * timing)          # a late guard still stops part of the hit
        quality = "none" if frac < 0.08 else "partial" if frac < 0.6 else "solid"
        return BlockResult(frac, cov, timing, False, hand, quality)


class GestureRecognizer:
    """Recognises block, parry, grab, push, shove, dodge, duck, weave from tracked motion (tracking space)."""

    def __init__(self, guard_cfg: GuardCfg, rest_height: float = 1.65) -> None:
        self.cfg = guard_cfg
        self.guard = GuardModel(guard_cfg)
        self.rest_head = v3(0, rest_height, 0)
        self._rest_init = False
        self._head_hist: deque[tuple[float, Vec]] = deque(maxlen=60)
        self._duck_armed = True
        self._weave_armed = True
        self._dodge_cool = -9.0
        self._block_emitted = False
        self._grab = {"left": False, "right": False}
        self._open_seen = {"left": -9.0, "right": -9.0}
        self._palm_track: dict[str, list] = {"left": [], "right": []}
        self._push_cool = {"left": -9.0, "right": -9.0}
        self._parry_track: dict[str, list] = {"left": [], "right": []}
        self._parry_cool = {"left": -9.0, "right": -9.0}
        self.duck_drop = 0.0
        self.lean = v3()

    def update(self, t: float, head_p: Vec, head_q: Vec, hands: dict[str, HandState | None],
               grabbables: list[tuple[str, Vec, float]] | None = None, striking: dict[str, bool] | None = None) -> list[GestureEvent]:
        events: list[GestureEvent] = []
        striking = striking or {}
        body = Transform(head_p, _yaw_q(head_q))
        inv = body.inverse()
        if not self._rest_init:
            self.rest_head, self._rest_init = head_p.copy(), True
        self._head_hist.append((t, head_p.copy()))
        slow_head = len(self._head_hist) > 3 and norm(self._head_hist[-1][1] - self._head_hist[-4][1]) / max(self._head_hist[-1][0] - self._head_hist[-4][0], 1e-6) < 0.25
        if slow_head:
            self.rest_head = self.rest_head + 0.004 * (head_p - self.rest_head)   # slowly track posture changes
        off = head_p - self.rest_head
        off_b = inv.apply_dir(off)
        self.lean = off_b
        self.duck_drop = float(-off[1])
        hv = self._head_velocity()
        if self.duck_drop > 0.22 and self._duck_armed:
            self._duck_armed = False
            events.append(GestureEvent("duck", None, t, clamp(self.duck_drop / 0.4, 0.3, 1.0), v3(0, -1, 0), self.duck_drop))
        elif self.duck_drop < 0.12:
            self._duck_armed = True
        horiz = float(np.hypot(off_b[0], off_b[2]))
        hspeed = float(np.hypot(hv[0], hv[2]))
        if horiz > 0.32 and hspeed > 1.0 and t - self._dodge_cool > 0.5:
            self._dodge_cool = t
            self._weave_armed = False
            events.append(GestureEvent("dodge", None, t, clamp(horiz / 0.5, 0.3, 1.0), unit(v3(off_b[0], 0, off_b[2])), horiz))
        elif abs(off_b[0]) > 0.16 and horiz <= 0.32 and self._weave_armed and abs(self._lateral_speed(inv)) > 0.45:
            self._weave_armed = False
            events.append(GestureEvent("weave", None, t, clamp(abs(off_b[0]) / 0.3, 0.3, 1.0), v3(math.copysign(1, off_b[0]), 0, 0), abs(off_b[0])))
        elif horiz < 0.07:
            self._weave_armed = True
        gs = self.guard.update(t, head_p, head_q, hands)
        any_striking = any(striking.get(h, False) for h in ("left", "right"))
        if gs.active and gs.held >= self.cfg.hold_min_s and not self._block_emitted and not any_striking:
            self._block_emitted = True
            both = gs.hands_up["left"] and gs.hands_up["right"]
            events.append(GestureEvent("block", None, t, 1.0 if both else 0.7, None, 1.0 if both else 0.5, data={"hands": [h for h, u in gs.hands_up.items() if u]}))
        if not gs.active:
            self._block_emitted = False
        for h in ("left", "right"):
            st = hands.get(h)
            if st is None or not st.tracked:
                continue
            events += self._parry(h, st, t, head_p, inv)
            events += self._grab_push(h, st, t, hands, grabbables or [], striking.get(h, False))
        return events

    # ---- helpers ------------------------------------------------------------------------------------------------------------------
    def _head_velocity(self) -> Vec:
        if len(self._head_hist) < 4:
            return v3()
        (t0, p0), (t1, p1) = self._head_hist[-4], self._head_hist[-1]
        return (p1 - p0) / max(t1 - t0, 1e-6)

    def _lateral_speed(self, inv: Transform) -> float:
        return float(inv.apply_dir(self._head_velocity())[0])

    def _parry(self, h: str, st: HandState, t: float, head_p: Vec, inv: Transform) -> list[GestureEvent]:
        tr = self._parry_track[h]
        v_b = inv.apply_dir(st.palm_velocity - self._head_velocity())
        speed = float(np.linalg.norm(v_b))
        lateral = abs(v_b[0]) / max(speed, 1e-6)
        near_guard = norm(st.palm - head_p) < 0.75 and st.palm[1] > head_p[1] - 0.7
        ok = st.openness > 0.5 and near_guard and self.cfg.parry_min_speed <= speed <= self.cfg.parry_max_speed and lateral > 0.7
        if ok:
            tr.append((t, v_b))
        else:
            if len(tr) >= 3 and t - self._parry_cool[h] > 0.3:
                dur = tr[-1][0] - tr[0][0]
                if 0.03 <= dur <= 0.3:
                    vm = np.mean([x[1] for x in tr], axis=0)
                    ev = GestureEvent("parry", h, tr[-1][0], clamp(float(np.linalg.norm(vm)) / 3.0, 0.4, 1.0), unit(inv.inverse().apply_dir(vm)),
                                      float(np.linalg.norm(vm)), data={"duration": dur, "t_start": tr[0][0]})
                    self._parry_cool[h] = t
                    self.guard.note_parry(ev)
                    tr.clear()
                    return [ev]
            tr.clear()
        return []

    def _grab_push(self, h: str, st: HandState, t: float, hands: dict[str, HandState | None], grabbables: list[tuple[str, Vec, float]],
                   striking: bool) -> list[GestureEvent]:
        out: list[GestureEvent] = []
        gp = st.grip_prob
        if st.openness > 0.55:
            self._open_seen[h] = t
        # grab: the hand *closes* (it was open recently) while the palm is at an object / enemy limb
        if not self._grab[h] and gp > 0.7 and not striking and st.speed < 1.5 and t - self._open_seen[h] < 0.7:
            for name, pos, rad in grabbables:
                if norm(st.palm - pos) <= rad + 0.1:
                    self._grab[h] = True
                    out.append(GestureEvent("grab", h, t, float(gp), None, gp, target=name, data={"phase": "start"}))
                    break
        elif self._grab[h] and gp < 0.4:
            self._grab[h] = False
            out.append(GestureEvent("grab", h, t, 1.0, None, 0.0, data={"phase": "end"}))
        # push / shove: open, forward-facing palm travelling forward (relative to the body)
        v = st.palm_velocity - self._head_velocity()
        fwd_speed = float(np.dot(v, st.palm_normal))
        facing_forward = float(np.dot(st.palm_normal, unit(v3(v[0], 0.0, v[2]))))
        tr = self._palm_track[h]
        ok = st.openness > 0.5 and fwd_speed > 0.6 and facing_forward > 0.5 and not striking
        if ok:
            tr.append((t, st.palm.copy(), fwd_speed))
        else:
            if len(tr) >= 4 and t - self._push_cool[h] > 0.4:
                disp = norm(tr[-1][1] - tr[0][1])
                peak = max(x[2] for x in tr)
                dur = tr[-1][0] - tr[0][0]
                other = hands.get("right" if h == "left" else "left")
                both = other is not None and other.openness > 0.5 and float(np.dot(other.palm_velocity, other.palm_normal)) > 0.5
                if disp > 0.12 and dur >= 0.1:
                    kind = "shove" if (peak >= 1.3 and both) or peak >= 1.55 else "push" if peak >= 0.6 else None
                    if kind:
                        self._push_cool[h] = t
                        out.append(GestureEvent(kind, h, t, clamp(peak / 2.0, 0.3, 1.0), unit(tr[-1][1] - tr[0][1]), peak, data={"both": both}))
            tr.clear()
        return out


def _yaw_q(q: Vec) -> Vec:
    f = q_rotate(q, v3(0, 0, 1))
    return q_from_yaw(math.atan2(f[0], f[2]))
