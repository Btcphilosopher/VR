"""CombatSystem: collision -> impact -> damage for the player's hands, and enemy attacks -> guard -> damage to the player.

TRACK -> INTERPRET -> SIMULATE -> COLLIDE -> IMPACT -> HAPTICS -> FEEDBACK (this module is COLLIDE / IMPACT / damage).
Physical impact (energy, impulse) is computed first; gameplay damage is derived from it separately.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..engine import events as E
from ..engine.config import Config
from ..engine.events import EventBus
from ..engine.mathx import Vec, clamp, norm, unit, v3
from ..engine.rig import Rig
from ..enemies.enemy import Enemy, EnemyState
from ..hands.analyzer import HandState
from ..physics.impact import PhysicalImpact, compute_impact
from ..physics.shapes import Capsule, Contact, Sphere, sweep_sphere_capsule
from ..physics.world import PhysicsWorld, PropBody
from .damage import damage_from_impact
from .defense import GestureRecognizer, GuardModel, IncomingAttack
from .events import BodyRegion, GestureEvent, ImpactEvent, StrikeEvent
from .strikes import StrikeDetector

PALM_STRIKES = {"palm_strike", "backhand", "push", "shove"}


@dataclass
class Projectile:
    pos: Vec
    vel: Vec
    damage: float
    owner: str
    radius: float = 0.07
    alive: bool = True
    age: float = 0.0
    kind: str = "bottle"


@dataclass
class PlayerVitals:
    health: float
    max_health: float
    grabbed_by: str | None = None
    grab_t: float = 0.0
    last_damage_t: float = -9.0
    damage_taken: float = 0.0
    down: bool = False


@dataclass
class CombatStats:
    strikes: int = 0
    hits: int = 0
    blocks: int = 0
    parries: int = 0
    combo: int = 0
    best_combo: int = 0
    last_hit_t: float = -9.0
    damage_dealt: float = 0.0
    score: int = 0
    env_impacts: int = 0
    grabs: int = 0
    thrown_hits: int = 0


class CombatSystem:
    def __init__(self, cfg: Config, bus: EventBus, physics: PhysicsWorld, detector: StrikeDetector, gestures: GestureRecognizer) -> None:
        self.cfg, self.bus, self.physics = cfg, bus, physics
        self.det, self.gest = detector, gestures
        self.vitals = PlayerVitals(cfg.gameplay.player_health, cfg.gameplay.player_health)
        self.stats = CombatStats()
        self._prev: dict[str, dict[str, Vec]] = {}
        self._lockout: dict[tuple[str, str, str], float] = {}
        self.projectiles: list[Projectile] = []
        self.held: dict[str, str] = {}                      # hand -> prop name
        self.held_enemy: dict[str, str] = {}                # hand -> enemy id
        self.dmg_scale = cfg.gameplay.enemy_damage_scale.get(cfg.gameplay.difficulty, 1.0)
        self.hazards: list = []
        self.frame_impacts: list[ImpactEvent] = []

    @staticmethod
    def player_volumes(head: Vec) -> list[tuple[str, object]]:
        return [(BodyRegion.HEAD.value, Sphere(head, 0.13)), (BodyRegion.TORSO.value, Capsule(head - v3(0, 0.22, 0), head - v3(0, 0.78, 0), 0.2))]

    # ---- hands vs world ---------------------------------------------------------------------------------------------------------------
    def update_hands(self, t: float, frame_id: int, hands: dict[str, HandState | None], enemies: dict[str, Enemy], rig: Rig, dt: float) -> list[ImpactEvent]:
        cfg = self.cfg.physics
        out: list[ImpactEvent] = []
        self.frame_impacts = []
        for h, st in hands.items():
            if st is None or not st.tracked:
                continue
            prev = self._prev.get(h)
            strike = self.det.active_strike(h)
            stype = strike.type if strike else ("push" if st.openness > 0.5 and float(np.dot(st.palm_velocity, st.palm_normal)) > 0.6 else "touch")
            use_palm = stype in PALM_STRIKES
            point = st.palm if use_palm else st.fist_center
            if stype == "elbow_strike":
                point = st.elbow
            radius = cfg.palm_radius if use_palm else cfg.fist_radius
            self._prev[h] = {"p": point.copy()}
            if self.held.get(h):
                self._carry(h, st)
                continue
            if prev is None:
                continue
            p0, p1 = prev["p"], point
            v = st.palm_velocity if use_palm else st.fist_velocity
            if stype == "elbow_strike":
                v = st.wrist_velocity + np.cross(st.angular_velocity, st.elbow - st.wrist)
            if norm(v) < 0.25:
                continue
            best: tuple[float, ImpactEvent, str, object] | None = None
            for e in enemies.values():
                if not e.alive:
                    continue
                for region, shape, mat in e.hit_volumes():
                    c = _sweep(p0, p1, radius, shape, cfg.sweep_substeps_max)
                    if c is not None and (best is None or c.t < best[0]):
                        best = (c.t, self._build(h, stype, strike, v, e.velocity_of_region(), c, mat, region, e.id, t, frame_id, st.confidence, e.arch.mass_scale), "enemy", e)
            pc = self.physics.sweep_props(p0, p1, radius)
            if pc is not None and (best is None or pc[0].t < best[0]):
                prop = pc[1]
                best = (pc[0].t, self._build(h, stype, strike, v, prop.v, pc[0], prop.material, BodyRegion.ENVIRONMENT.value, prop.name, t, frame_id, st.confidence, 1.0), "prop", prop)
            sc = self.physics.sweep_statics(p0, p1, radius)
            if sc is not None and (best is None or sc[0].t < best[0]):
                best = (sc[0].t, self._build(h, stype, strike, v, v3(), sc[0], sc[1].material, BodyRegion.ENVIRONMENT.value, sc[1].name, t, frame_id, st.confidence, 1.0), "static", sc[1])
            if best is None:
                continue
            _, imp, kind, obj = best
            min_speed = cfg.min_contact_speed if (strike is not None or kind == "enemy") else 0.3
            if imp.velocity < min_speed:
                continue
            key = (h, imp.target, imp.body_region)
            if t - self._lockout.get(key, -9.0) < cfg.hit_lockout_s * (0.45 if kind != "enemy" or strike is None else 1.0):
                continue
            self._lockout[key] = t
            if strike is not None:
                self.det.consume_on_contact(h, imp.position, imp.normal)
            self._resolve(imp, kind, obj, t)
            out.append(imp)
        for hz in self.hazards:
            for h, st in hands.items():
                if st is None or not st.tracked or t - hz.last_t < hz.cooldown_s:
                    continue
                if _inside(hz.box, st.fist_center, 0.06) or _inside(hz.box, st.palm, 0.06):
                    hz.last_t = t
                    imp = ImpactEvent("player", hz.name, BodyRegion.ENVIRONMENT.value, "touch", 1.0, 1.0, v3(0, 0, -1), st.palm.copy(), 12.0, "metal", h, t, frame_id)
                    phys = PhysicalImpact(12.0, 1.0, 1.0, 1.0, 1.0, "metal", 0.3, 0.9, 0.0)
                    self.bus.emit(E.COLLISION, target=hz.name, hand=h, region="ENVIRONMENT")
                    self.bus.emit(E.IMPACT_CALCULATED, impact=imp, physical=phys, hazard=hz.kind)
                    self.stats.env_impacts += 1
                    out.append(imp)
        self.frame_impacts = out
        return out

    def _build(self, hand: str, stype: str, strike: StrikeEvent | None, v: Vec, tv: Vec, c: Contact, material: str, region: str, target: str,
               t: float, frame: int, conf: float, mass_scale: float) -> ImpactEvent:
        phys = compute_impact(stype, v, tv, c.normal, material, self.cfg.physics, mass_scale if region != BodyRegion.ENVIRONMENT.value else 1.0)
        imp = ImpactEvent("player", target, region, stype, phys.closing_speed, phys.impulse, c.normal.copy(), c.point.copy(), phys.energy_j, material, hand, t,
                          frame, strike.id if strike else 0, strike.confidence if strike else conf)
        imp._phys = phys  # type: ignore[attr-defined]
        return imp

    def _resolve(self, imp: ImpactEvent, kind: str, obj, t: float) -> None:
        phys: PhysicalImpact = imp._phys  # type: ignore[attr-defined]
        gcfg = self.cfg.gameplay
        s = self.stats
        self.bus.emit(E.COLLISION, target=imp.target, hand=imp.hand, region=imp.body_region)
        if kind == "enemy":
            e: Enemy = obj
            if t - s.last_hit_t > gcfg.damage.combo_window_s:
                s.combo = 0
            res = damage_from_impact(phys, imp.body_region, imp.normal, gcfg.damage, armor=e.arch.armor, combo_hits=s.combo, confidence=imp.confidence,
                                     knockback_per_impulse=self.cfg.physics.knockback_per_impulse)
            hit = e.receive_hit(imp.body_region, res.damage, res.stagger, res.knockback, t)
            if imp.body_region != BodyRegion.WEAPON.value and not hit.blocked:
                s.combo += 1
                s.hits += 1
            s.best_combo = max(s.best_combo, s.combo)
            s.last_hit_t = t
            s.damage_dealt += hit.damage_taken
            s.score += int(hit.damage_taken * (1 + 0.1 * s.combo))
            self.bus.emit(E.IMPACT_CALCULATED, impact=imp, physical=phys)
            self.bus.emit(E.DAMAGE_APPLIED, target=imp.target, region=imp.body_region, damage=round(hit.damage_taken, 3), stagger=round(res.stagger, 3),
                          blocked=hit.blocked, shield=hit.shield_hit, health=round(e.health, 3), energy=round(phys.energy_j, 3))
        elif kind == "prop":
            prop: PropBody = obj
            prop.apply_impulse(unit(-imp.normal) * imp.impulse * 1.2)
            s.env_impacts += 1
            self.bus.emit(E.IMPACT_CALCULATED, impact=imp, physical=phys)
        else:
            s.env_impacts += 1
            self.bus.emit(E.IMPACT_CALCULATED, impact=imp, physical=phys)

    # ---- grabbing / carrying / throwing --------------------------------------------------------------------------------------------------
    def grabbables(self, enemies: dict[str, Enemy]) -> list[tuple[str, Vec, float]]:
        out = [(p.name, p.p, p.radius + 0.05) for p in self.physics.props if p.grabbable and p.held_by is None]
        for e in enemies.values():
            if e.alive and e.state in (EnemyState.STAGGER, EnemyState.ATTACK, EnemyState.APPROACH, EnemyState.BLOCK):
                j = e.joints()
                out.append((e.id, j["fist_l"], 0.12))
                out.append((e.id, j["fist_r"], 0.12))
        return out

    def on_gesture(self, g: GestureEvent, hands: dict[str, HandState | None], enemies: dict[str, Enemy], t: float) -> None:
        h = g.hand
        if g.type == "grab" and h and g.data.get("phase") == "start":
            self.stats.grabs += 1
            tgt = g.target or ""
            prop = next((p for p in self.physics.props if p.name == tgt), None)
            if prop is not None and prop.held_by is None:
                prop.held_by = h
                self.held[h] = prop.name
                self.bus.emit(E.GRAB, hand=h, phase="start", grip=g.confidence, object=prop.name)
            elif tgt in enemies:
                self.held_enemy[h] = tgt
                enemies[tgt].force_stagger(max(enemies[tgt].stagger_time, 0.9))
                self.bus.emit(E.GRAB, hand=h, phase="start", grip=g.confidence, enemy=tgt)
        elif g.type == "grab" and h and g.data.get("phase") == "end":
            name = self.held.pop(h, None)
            if name:
                prop = next(p for p in self.physics.props if p.name == name)
                st = hands.get(h)
                prop.held_by = None
                if st is not None:
                    prop.v = st.palm_velocity.copy() * 1.1
                self.bus.emit(E.GRAB, hand=h, phase="end", object=name)
            if h in self.held_enemy:
                self.held_enemy.pop(h)
                self.bus.emit(E.GRAB, hand=h, phase="end")
        elif g.type in ("shove", "push") and self.vitals.grabbed_by:
            self.vitals.grabbed_by = None
            self.bus.emit(E.GESTURE_DETECTED, type="escape_grab", hand=h)

    def _carry(self, h: str, st: HandState) -> None:
        prop = next((p for p in self.physics.props if p.name == self.held.get(h)), None)
        if prop is not None:
            prop.p = st.palm + st.palm_normal * (prop.radius * 0.6)
            prop.v = st.palm_velocity.copy()

    def update_thrown(self, enemies: dict[str, Enemy], t: float, frame_id: int) -> None:
        for p in self.physics.props:
            if p.held_by is not None or p.home is not None:
                continue
            if norm(p.v) < 1.8:
                continue
            for e in enemies.values():
                if not e.alive:
                    continue
                for region, shape, mat in e.hit_volumes():
                    if not isinstance(shape, Capsule):
                        shape = Capsule(shape.c, shape.c, shape.r)       # type: ignore[attr-defined]
                    c = sweep_sphere_capsule(p.p - p.v * (1 / 90), p.p, p.radius, shape, 6)
                    if c is None:
                        continue
                    key = ("prop", p.name + e.id, region)
                    if t - self._lockout.get(key, -9) < 0.6:
                        continue
                    self._lockout[key] = t
                    phys = compute_impact("shove", p.v, e.velocity_of_region(), c.normal, mat, self.cfg.physics, p.mass / 5.0)
                    imp = ImpactEvent("player", e.id, region, "thrown_object", phys.closing_speed, phys.impulse, c.normal, c.point, phys.energy_j, mat, None, t, frame_id)
                    res = damage_from_impact(phys, region, c.normal, self.cfg.gameplay.damage, armor=e.arch.armor, knockback_per_impulse=self.cfg.physics.knockback_per_impulse)
                    hit = e.receive_hit(region, res.damage, res.stagger, res.knockback, t)
                    self.stats.thrown_hits += 1
                    self.stats.damage_dealt += hit.damage_taken
                    self.stats.score += int(hit.damage_taken * 1.5)
                    self.bus.emit(E.COLLISION, target=e.id, hand=None, region=region)
                    self.bus.emit(E.DAMAGE_APPLIED, target=e.id, region=region, damage=round(hit.damage_taken, 3), stagger=round(res.stagger, 3), blocked=hit.blocked,
                                  shield=hit.shield_hit, health=round(e.health, 3), energy=round(phys.energy_j, 3))
                    p.v = p.v * 0.3
                    break

    # ---- enemies vs player ------------------------------------------------------------------------------------------------------------------
    def enemy_attacks(self, t: float, frame_id: int, head: Vec, rig: Rig, enemies: dict[str, Enemy], guard: GuardModel, dt: float) -> None:
        vol = self.player_volumes(head)
        v = self.vitals
        if v.down:
            return
        for e in enemies.values():
            ar = e.active_attack()
            if ar is None or ar.resolved:
                continue
            atk = ar.attack
            if atk.kind == "throw":
                if not ar.hit_fired:
                    ar.hit_fired = True
                    ar.resolved = True
                    self.projectiles.append(Projectile(ar.fist.copy(), unit(head - ar.fist) * atk.projectile_speed + v3(0, 0.6, 0), atk.damage, e.id))
                continue
            p0 = ar.prev_fist if ar.prev_fist is not None else ar.fist
            hit = None
            for region, shape in vol:
                c = _sweep(p0, ar.fist, 0.075, shape, 12)
                if c is not None and (hit is None or c.t < hit[0].t):
                    hit = (c, region)
            if hit is None:
                continue
            ar.resolved = True
            c, region = hit
            self._hit_player(t, frame_id, e, atk.name, atk.kind, atk.damage, c.point, p0, ar.fist, region, rig, guard, head, unblockable=atk.unblockable)
        for pr in self.projectiles:
            if not pr.alive:
                continue
            pr.age += dt
            prev = pr.pos.copy()
            pr.vel = pr.vel + v3(0, -3.0, 0) * dt
            pr.pos = pr.pos + pr.vel * dt
            if pr.age > 3.0 or pr.pos[1] < 0.0:
                pr.alive = False
                continue
            for region, shape in vol:
                c = _sweep(prev, pr.pos, pr.radius, shape, 6)
                if c is not None:
                    pr.alive = False
                    self._hit_player(t, frame_id, enemies.get(pr.owner), "bottle", "throw", pr.damage, c.point, prev, pr.pos, region, rig, guard, head)
                    break
        self.projectiles = [p for p in self.projectiles if p.alive]
        if v.grabbed_by:
            holder = enemies.get(v.grabbed_by)
            if holder is None or not holder.alive or holder.state in (EnemyState.STAGGER, EnemyState.DEFEATED):
                v.grabbed_by = None
            else:
                v.grab_t += dt
                if v.grab_t >= 0.5:
                    v.grab_t = 0.0
                    self._apply_player_damage(t, holder, 4.0 * self.dmg_scale, holder.pos - rig.pos, "TORSO", critical=False)
                holder.attack = None

    def _hit_player(self, t: float, frame_id: int, e: Enemy | None, name: str, kind: str, damage: float, point: Vec, p0: Vec, p1: Vec, region: str,
                    rig: Rig, guard: GuardModel, head: Vec, unblockable: bool = False) -> None:
        dirv = unit(p1 - p0) if norm(p1 - p0) > 1e-6 else v3(0, 0, -1)
        cfg = self.cfg.gameplay
        blocked_frac, parried, bhand, quality = 0.0, False, None, "none"
        if not unblockable:
            inc = IncomingAttack(e.id if e else "thrown", kind, rig.inv_point(p0), rig.inv_point(head if region == "HEAD" else point), t, damage / 25.0, region)
            br = guard.evaluate(inc, t)
            blocked_frac, parried, bhand, quality = br.blocked_fraction, br.parried, br.hand, br.quality
        attacker = e.id if e else "thrown"
        if parried:
            self.stats.parries += 1
            if e is not None:
                e.force_stagger(0.95)
                e.react.kick(-dirv, 2.0)
            self.bus.emit(E.PARRY, hand=bhand, attacker=attacker, power=damage / 25.0)
            self.bus.emit(E.IMPACT_CALCULATED, impact=ImpactEvent(attacker, "player", "LEFT_ARM" if bhand == "left" else "RIGHT_ARM", "parried_" + kind, 0.0, 0.0, -dirv, point, 0.0, "flesh", bhand, t, frame_id),
                          physical=PhysicalImpact(0, 0, 0, 1, 1, "flesh", 0.1, 0.2, 0))
            return
        if blocked_frac >= 0.08:
            self.stats.blocks += 1
            self.bus.emit(E.BLOCK, hands=[bhand] if bhand else ["left", "right"], power=damage / 25.0, quality=quality, fraction=round(blocked_frac, 3), attacker=attacker)
            self.bus.emit(E.IMPACT_CALCULATED, impact=ImpactEvent(attacker, "player", "LEFT_ARM" if bhand == "left" else "RIGHT_ARM", "blocked_" + kind, 0.0, damage, -dirv, point, damage, "flesh", bhand, t, frame_id),
                          physical=PhysicalImpact(damage, damage, 0, 1, 1, "flesh", 0.1, 0.3, 0))
            if e is not None:
                e.react.kick(-dirv, 0.6)
        if kind == "grab" and e is not None and blocked_frac < 0.5:
            self.vitals.grabbed_by = e.id
            self.vitals.grab_t = 0.0
            self.bus.emit(E.GRAB, hand=None, phase="grabbed", enemy=e.id)
        amount = damage * self.dmg_scale * (1.0 - blocked_frac * cfg.damage.block_reduction)
        if amount > 0.05:
            self._apply_player_damage(t, e, amount, (e.pos - rig.pos) if e else -dirv, region, critical=amount > 0.25 * self.vitals.max_health, rig=rig)

    def _apply_player_damage(self, t: float, e: Enemy | None, amount: float, direction: Vec, region: str, critical: bool, rig: Rig | None = None) -> None:
        v = self.vitals
        v.health = max(0.0, v.health - amount)
        v.damage_taken += amount
        v.last_damage_t = t
        d = unit(direction)
        side = clamp(float(d[0]) if rig is None else float(rig.inv_direction(d)[0]), -1.0, 1.0)
        self.bus.emit(E.PLAYER_DAMAGED, amount=round(amount, 3), side=round(side, 3), critical=critical, health=round(v.health, 3), attacker=e.id if e else "", region=region)
        self.stats.combo = 0
        if v.health <= 0 and not v.down:
            v.down = True

    def player_regen(self, dt: float, t: float) -> None:
        v = self.vitals
        if not v.down and v.health < v.max_health and t - v.last_damage_t > 6.0:
            v.health = min(v.max_health, v.health + 3.0 * dt)


def _sweep(p0: Vec, p1: Vec, r: float, shape, substeps: int) -> Contact | None:
    if isinstance(shape, Capsule):
        return sweep_sphere_capsule(p0, p1, r, shape, substeps)
    return sweep_sphere_capsule(p0, p1, r, Capsule(shape.c, shape.c, shape.r), substeps)


def _inside(box, p: Vec, pad: float) -> bool:
    return bool(np.all(p >= box.lo - pad) and np.all(p <= box.hi + pad))
