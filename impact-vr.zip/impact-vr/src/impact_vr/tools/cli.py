"""impact-vr command line: run | training | simulate | replay | glove-test | calibrate | benchmark | diagnostics."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path


def _cfg(args):
    from ..engine.config import load_config

    return load_config(Path(args.config) if getattr(args, "config", None) else None)


def _headless() -> None:
    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    os.environ.setdefault("SDL_AUDIODRIVER", "dummy")


def cmd_run(args) -> int:
    from ..engine.app import App
    from ..engine.modes import GameMode

    app = App(_cfg(args), dev=args.dev, seed=args.seed)
    if getattr(args, "mode", None):
        app.start(GameMode(args.mode))
    app.run()
    return 0


def cmd_training(args) -> int:
    args.mode = "training"
    return cmd_run(args)


def cmd_simulate(args) -> int:
    from ..simulation.replay import ReplayRecorder
    from ..simulation.scenarios import SCENARIOS

    cfg = _cfg(args)
    if args.list:
        for n, sc in SCENARIOS.items():
            print(f"{n:<18} {sc.duration:>4.1f}s  {sc.description}")
        return 0
    names = list(SCENARIOS) if args.scenario in (None, "all") else [args.scenario]
    ok_all, rows = True, []
    for n in names:
        if n not in SCENARIOS:
            print(f"unknown scenario '{n}' (use --list)", file=sys.stderr)
            return 2
        sc = SCENARIOS[n]
        rec = ReplayRecorder(n) if args.record else None
        t0 = time.perf_counter()
        s, _ = sc.build(cfg, args.seed, recorder=rec)
        s.run(args.seconds or sc.duration)
        wall = time.perf_counter() - t0
        strikes = [e.data["strike"]["type"] for e in s.events("STRIKE_DETECTED") if e.data.get("phase") == "ended"]
        names_seen = {e.name for e in s.bus.history}
        ok = all(x in strikes for x in sc.expect_strikes) and all(x in names_seen for x in sc.expect_events)
        ok_all &= ok
        st = s.combat.stats
        rows.append({"scenario": n, "ok": ok, "strikes": strikes, "hits": st.hits, "blocks": st.blocks, "parries": st.parries, "haptic_commands": s.pipeline.sent_total,
                     "digest": s.event_digest(), "wall_s": round(wall, 2), "latency": s.latency.breakdown_text()})
        if rec is not None:
            out = Path(args.record)
            out.mkdir(parents=True, exist_ok=True)
            rec.save(out / f"{n}.jsonl.gz")
    if args.json:
        print(json.dumps(rows, indent=2))
    else:
        for r in rows:
            print(f"[{'PASS' if r['ok'] else 'FAIL'}] {r['scenario']:<18} strikes={r['strikes']} hits={r['hits']} blocks={r['blocks']} parries={r['parries']} haptic={r['haptic_commands']} digest={r['digest']} ({r['wall_s']}s)")
        if args.verbose:
            for r in rows:
                print(f"    {r['scenario']}: {r['latency']}")
    return 0 if ok_all else 1


def cmd_replay(args) -> int:
    from ..simulation.replay import replay_session, verify_replay

    cfg = _cfg(args)
    rep = verify_replay(args.file, cfg)
    print(f"replay {args.file}: {rep.frames} frames  expected {rep.expected_digest}  actual {rep.actual_digest}  -> {'IDENTICAL' if rep.ok else 'MISMATCH ' + rep.detail}")
    if args.play and rep.ok:
        if args.headless:
            _headless()
        import pygame

        from ..engine.app import make_fonts
        from ..rendering.software import SoftwareRenderer, ViewState

        pygame.init()
        scr = pygame.display.set_mode(cfg.graphics.size)
        rend = SoftwareRenderer(make_fonts())
        sess, src = replay_session(args.file, cfg)
        clock = pygame.time.Clock()
        while not src.finished:
            sess.step()
            rend.render(sess, scr, ViewState())
            pygame.display.flip()
            if any(e.type == pygame.QUIT for e in pygame.event.get()):
                break
            clock.tick(cfg.vr.target_fps)
    return 0 if rep.ok else 1


def cmd_glove_test(args) -> int:
    from ..haptics.gloves.base import HapticGlove
    from ..haptics.gloves.generic import GenericHapticGlove
    from ..haptics.gloves.simulated import make_simulated_pair
    from ..haptics.model import ACTUATORS
    from ..haptics.monitor import render_text
    from ..haptics.pipeline import HapticPipeline
    from ..haptics.profile import CalibrationProfile

    cfg = _cfg(args).haptics
    hands = ("left", "right") if args.hand == "both" else (args.hand,)
    fws = []
    if args.protocol_loopback:
        from ..haptics.firmware_sim import VirtualGloveFirmware
        from ..haptics.transports import LoopbackTransport

        gloves: dict[str, HapticGlove] = {}
        for h in hands:
            host_end, dev_end = LoopbackTransport.pair()
            dev_end.open()
            gloves[h] = GenericHapticGlove(h, host_end)
            fws.append(VirtualGloveFirmware(dev_end))
        print("glove driver: GenericHapticGlove over IMPACT-HAPTIC v1 (loopback transport + virtual firmware)")
    else:
        gloves = {h: g for h, g in make_simulated_pair(cfg, 1).items() if h in hands}  # type: ignore[assignment]
        print("glove driver: SimulatedHapticGlove")
    pipe = HapticPipeline(cfg, gloves, profile=CalibrationProfile.uncalibrated(cfg))
    t = 0.0

    def tick(ms: float) -> None:
        nonlocal t
        end = t + ms
        while t < end:
            t += 2.0
            for fw in fws:
                fw.update(t)
            pipe.update(t)
    for g in gloves.values():
        g.connect(t)
    tick(60)
    for h, g in gloves.items():
        print(f"{h}: {g.get_connection_state().value}, actuators {[a.value for a in ACTUATORS if a in g.detect_actuators()]}")
    for h in hands:
        for a in ACTUATORS:
            if a not in gloves[h].detect_actuators():
                continue
            sc = pipe.send_test(h, a, args.intensity, 120, t)
            tick(20)
            if not args.quiet:
                print(f"\n-- {h}.{a.value} @ {args.intensity:.2f}: {'sent' if sc else 'REJECTED by safety/limits'} --")
                print(render_text(pipe.actuator_levels(t)))
            tick(160)
    print("\nSUMMARY")
    for h, g in gloves.items():
        st = g.get_status(t)
        print(f"  {h}: state={st.connection.value} sent={st.commands_sent} dropped={st.dropped_commands} errors={st.comm_errors} latency={st.mean_latency_ms:.1f} ms (p95 {st.p95_latency_ms:.1f}) rate={st.command_rate_hz:.0f}/s")
    rep = pipe.limiter.report
    print(f"  safety: passed={rep.passed} clamped={rep.clamped} rejected={dict(rep.rejected)} tripped={rep.tripped}")
    return 0 if not rep.tripped and all(g.get_status(t).comm_errors == 0 for g in gloves.values()) else 1


def cmd_calibrate(args) -> int:
    from ..haptics.calibration import CalibrationSession, ConsoleResponder, ScriptedResponder
    from ..haptics.gloves.simulated import make_simulated_pair
    from ..haptics.pipeline import HapticPipeline

    cfg = _cfg(args)
    if args.tracking:
        from ..simulation.scenarios import SCENARIOS
        from ..tracking.calibration import run_tracking_calibration

        _, rt = SCENARIOS["jab_cross"].build(cfg)
        print(run_tracking_calibration(rt, args.seconds).format())
        return 0
    hc = cfg.haptics
    pipe = HapticPipeline(hc, make_simulated_pair(hc, 5))
    clock = [0.0]

    def adv(ms: float) -> None:
        clock[0] += ms
        pipe.update(clock[0])
    print("HAPTIC CALIBRATION - never assumes maximum power is comfortable; levels ramp up from 0.10 and stop at the first 'too strong'.")
    res = CalibrationSession(pipe, hc, ScriptedResponder() if args.scripted else ConsoleResponder(), lambda: clock[0], adv, log=print,
                             save_path=Path(args.out) if args.out else None).run()
    print("completed" if res.completed else "ABORTED (nothing saved)")
    return 0 if res.completed else 1


def cmd_benchmark(args) -> int:
    from ..simulation.benchmark import run_benchmark

    rep = run_benchmark(args.scenario, _cfg(args), args.seconds, args.repeat)
    print(rep.format())
    return 0 if rep.meets_target or not args.strict else 1


def cmd_diagnostics(args) -> int:
    from ..telemetry.diagnostics import run_diagnostics

    rep = run_diagnostics(not args.fast)
    print(rep.format())
    return 0 if rep.ok else 1


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="impact-vr", description="IMPACT//VR - VR beat-'em-up platform with a hardware-independent haptic glove interface")
    ap.add_argument("--config", help="directory with vr/haptics/physics/gameplay/graphics/audio .toml (default: ./configs)")
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("run", help="launch the game (desktop / simulation mode)")
    p.add_argument("--mode", choices=["training", "story", "encounter", "boss"])
    p.add_argument("--dev", action="store_true")
    p.add_argument("--seed", type=int)
    p.set_defaults(fn=cmd_run)
    p = sp.add_parser("training", help="launch the training room")
    p.add_argument("--dev", action="store_true")
    p.add_argument("--seed", type=int)
    p.set_defaults(fn=cmd_training)
    p = sp.add_parser("simulate", help="run scripted synthetic combat scenarios headlessly")
    p.add_argument("scenario", nargs="?", default="all")
    p.add_argument("--list", action="store_true")
    p.add_argument("--seed", type=int, default=11)
    p.add_argument("--seconds", type=float)
    p.add_argument("--record", metavar="DIR", help="write a replay file per scenario")
    p.add_argument("--json", action="store_true")
    p.add_argument("-v", "--verbose", action="store_true")
    p.set_defaults(fn=cmd_simulate)
    p = sp.add_parser("replay", help="verify (and optionally play back) a recorded session without VR hardware")
    p.add_argument("file")
    p.add_argument("--play", action="store_true")
    p.add_argument("--headless", action="store_true")
    p.set_defaults(fn=cmd_replay)
    p = sp.add_parser("glove-test", help="exercise every actuator through the safety limiter")
    p.add_argument("--hand", choices=["left", "right", "both"], default="both")
    p.add_argument("--intensity", type=float, default=0.3)
    p.add_argument("--protocol-loopback", action="store_true", help="drive a GenericHapticGlove over IMPACT-HAPTIC v1 against the virtual firmware")
    p.add_argument("--quiet", action="store_true")
    p.set_defaults(fn=cmd_glove_test)
    p = sp.add_parser("calibrate", help="haptic (default) or --tracking calibration")
    p.add_argument("--scripted", action="store_true", help="non-interactive: deterministic simulated user")
    p.add_argument("--tracking", action="store_true")
    p.add_argument("--seconds", type=float, default=1.5)
    p.add_argument("--out")
    p.set_defaults(fn=cmd_calibrate)
    p = sp.add_parser("benchmark", help="frame throughput and INPUT -> COLLISION -> HAPTIC latency breakdown")
    p.add_argument("--scenario", default="combo_chain")
    p.add_argument("--seconds", type=float)
    p.add_argument("--repeat", type=int, default=1)
    p.add_argument("--strict", action="store_true", help="exit non-zero if below the target frame rate")
    p.set_defaults(fn=cmd_benchmark)
    p = sp.add_parser("diagnostics", help="environment, dependencies, OpenXR, config and pipeline self-check")
    p.add_argument("--fast", action="store_true")
    p.set_defaults(fn=cmd_diagnostics)
    args = ap.parse_args(argv)
    if args.cmd in ("simulate", "glove-test", "calibrate", "benchmark", "diagnostics") or getattr(args, "headless", False):
        _headless()
    return int(args.fn(args))


if __name__ == "__main__":
    sys.exit(main())
