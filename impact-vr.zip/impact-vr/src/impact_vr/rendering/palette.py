"""Late-2020s British industrial night palette: brick, concrete, steel, timber, wet asphalt; sodium amber + cold arch spill.
No neon, no purple, no cyberpunk."""

from __future__ import annotations

Color = tuple[int, int, int]

COLORS: dict[str, Color] = {
    "brick": (104, 62, 50), "brick_dark": (78, 48, 42), "concrete": (112, 112, 108), "concrete_floor": (74, 74, 72), "steel": (98, 106, 114),
    "steel_door": (66, 78, 84), "window_dark": (24, 28, 34), "wet_pavement": (36, 38, 42), "tram_rail": (58, 60, 62),
    "viaduct_deck": (58, 56, 54), "arch_void": (14, 16, 20), "timber": (116, 88, 58), "dumpster_green": (46, 78, 62), "fuse_box": (170, 150, 60),
    "foam": (60, 78, 112),
    "enemy_street": (92, 78, 66), "enemy_heavy": (74, 70, 64), "enemy_agile": (62, 82, 92), "enemy_shield": (70, 80, 70), "enemy_grappler": (96, 66, 58),
    "enemy_ranged": (86, 86, 70), "enemy_boss": (118, 74, 50), "skin": (176, 138, 112), "glove": (30, 32, 36),
}
FOG: Color = (10, 12, 15)
SKY_TOP: Color = (8, 10, 14)
SKY_HORIZON: Color = (30, 30, 34)
AMBER: Color = (224, 160, 48)
BLUE: Color = (61, 108, 143)
RED: Color = (192, 57, 43)
UI_TEXT: Color = (214, 214, 206)
UI_DIM: Color = (130, 132, 128)


def color(key: str) -> Color:
    return COLORS.get(key, (100, 100, 100))
