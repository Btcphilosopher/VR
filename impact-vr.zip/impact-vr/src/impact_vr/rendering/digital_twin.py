"""Digital twin of the player's hands + glove: skeleton, collision volumes, velocity vectors, detected gesture, impact vectors and
live actuator output, in an orbitable inspector view. Developer tool for the whole combat pipeline."""

from __future__ import annotations

import math

import numpy as np
import pygame

from ..engine import events as E
from ..engine.mathx import Vec, unit, v3
from ..engine.session import GameSession
from ..hands.skeleton import Joint
from ..haptics.model import Actuator
from . import palette as pal
from .software import _BONES

_SITE = {Actuator.THUMB: Joint.THUMB_TIP, Actuator.INDEX: Joint.INDEX_TIP, Actuator.MIDDLE: Joint.MIDDLE_TIP, Actuator.RING: Joint.RING_TIP, Actuator.LITTLE: Joint.LITTLE_TIP,
         Actuator.PALM: Joint.PALM, Actuator.WRIST: Joint.WRIST, Actuator.FOREARM: Joint.WRIST}


def _view(center: Vec, yaw: float, pitch: float, dist: float, rect: pygame.Rect):
    f = v3(math.sin(yaw) * math.cos(pitch), math.sin(pitch), math.cos(yaw) * math.cos(pitch))
    eye = center - f * dist
    r = unit(np.cross(v3(0, 1, 0), f))
    u = np.cross(f, r)
    focal = rect.height * 1.3

    def proj(p: Vec) -> tuple[float, float] | None:
        d = p - eye
        z = float(d @ f)
        if z < 0.05:
            return None
        return rect.centerx + float(d @ r) / z * focal, rect.centery - float(d @ u) / z * focal
    return proj, focal / max(dist, 0.1)


def draw_digital_twin(surface: pygame.Surface, rect: pygame.Rect, s: GameSession, fonts, orbit: float = 0.6) -> None:
    pygame.draw.rect(surface, (12, 14, 17), rect)
    pygame.draw.rect(surface, (70, 74, 78), rect, 1)
    hands = [(h, st) for h, st in s.world_hands.items() if st is not None]
    tw = fonts["small"]
    if not hands:
        surface.blit(tw.render("no hand data", True, pal.UI_DIM), (rect.x + 10, rect.y + 10))
        return
    proj, scale = _view(np.mean([st.palm for _, st in hands], axis=0), orbit, 0.35, 0.9, rect)
    levels = s.pipeline.actuator_levels(s.clock.now() * 1000.0)
    for h, st in hands:
        pts = [proj(st.positions[i]) for i in range(26)]
        for a, b in _BONES:
            if pts[a] and pts[b]:
                pygame.draw.line(surface, (150, 156, 160), pts[a], pts[b], 2)
        for p in pts:
            if p:
                pygame.draw.circle(surface, (200, 204, 206), (int(p[0]), int(p[1])), 2)
        fc, pc = proj(st.fist_center), proj(st.palm)
        if fc:
            pygame.draw.circle(surface, pal.AMBER, (int(fc[0]), int(fc[1])), max(3, int(s.cfg.physics.fist_radius * scale)), 1)
            tip = proj(st.fist_center + st.fist_velocity * 0.12)            # velocity vector (1 m/s = 12 cm)
            if tip:
                pygame.draw.line(surface, (240, 200, 90), fc, tip, 2)
        if pc:
            pygame.draw.circle(surface, pal.BLUE, (int(pc[0]), int(pc[1])), max(3, int(s.cfg.physics.palm_radius * scale)), 1)
        a, b = proj(st.wrist), proj(st.elbow)
        if a and b:
            pygame.draw.line(surface, pal.BLUE, a, b, 3)
        lv = levels.get(h, {})
        for act, joint in _SITE.items():            # live actuator output at the anatomical sites
            v = lv.get(act, 0.0)
            p = pts[joint]
            if p and v > 0.02:
                pygame.draw.circle(surface, (255, int(190 - 120 * v), 60), (int(p[0]), int(p[1])), 4 + int(10 * v), 2)
        ev = s.detector.active_strike(h)
        label = f"{h.upper()} {'STRIKE ' + ev.type + f' {ev.confidence:.2f}' if ev else ''}  v {st.speed:4.1f} m/s  fist {st.fist_prob:.2f} grip {st.grip_prob:.2f} open {st.openness:.2f}"
        surface.blit(tw.render(label, True, pal.UI_TEXT), (rect.x + 8, rect.y + 6 + (0 if h == "left" else 16)))
    for e in list(s.bus.history)[-80:]:
        if e.name == E.IMPACT_CALCULATED and e.data["impact"].attacker == "player" and s.clock.now() - e.t < 1.5:
            imp = e.data["impact"]
            a, b = proj(imp.position), proj(imp.position + imp.normal * 0.15)
            if a and b:
                pygame.draw.line(surface, (230, 80, 60), a, b, 3)
                pygame.draw.circle(surface, (230, 80, 60), (int(a[0]), int(a[1])), 4)
    surface.blit(tw.render("DIGITAL TWIN  skeleton / collision / velocity / impact / actuators", True, pal.UI_DIM), (rect.x + 8, rect.bottom - 18))
