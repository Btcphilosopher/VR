"""Developer overlay (restrained): FPS, frame/VR frame time, tracking confidence, hand velocities, gesture, target, impact energy,
damage, haptic latency + intensity, enemy state. Off by default; toggle with F3."""

from __future__ import annotations

import numpy as np

from ..engine import events as E
from ..engine.session import GameSession
from . import palette as pal


def overlay_lines(s: GameSession, fps: float, frame_ms: float) -> list[str]:
    f = s.last_frame
    L, R = s.world_hands.get("left"), s.world_hands.get("right")
    conf = min([h.confidence for h in (L, R) if h is not None] or [0.0])

    def vel(h) -> str:
        return f"{float(np.linalg.norm(h.fist_velocity)):4.1f} m/s" if h is not None else " --"
    hist = list(s.bus.history)
    last_strike = next((e for e in reversed(hist) if e.name == E.STRIKE_DETECTED), None)
    last_imp = next((e for e in reversed(hist) if e.name == E.IMPACT_CALCULATED and e.data["impact"].attacker == "player"), None)
    last_dmg = next((e for e in reversed(hist) if e.name == E.DAMAGE_APPLIED), None)
    gest = next((e for e in reversed(hist) if e.name == E.GESTURE_DETECTED), None)
    en = sorted(s.director.alive(), key=lambda e: float(np.linalg.norm(e.pos - s.head_world * np.array([1, 0, 1]))))
    st = s.latency.summary()
    peak = max([v for d in s.pipeline.actuator_levels(s.clock.now() * 1000.0).values() for v in d.values()] or [0.0])
    return [
        f"FPS {fps:5.1f}   FRAME {frame_ms:5.2f} ms   VR FRAME {f.frame_time_ms if f else 0:5.2f} ms   t {s.clock.now():6.2f}s",
        f"TRACKING conf {conf:.2f}   src L:{f.hand_source.get('left', '-') if f else '-'} R:{f.hand_source.get('right', '-') if f else '-'}",
        f"HAND VEL  L {vel(L)}   R {vel(R)}",
        f"GESTURE {gest.data.get('type', '-') if gest else '-':<10} STRIKE {last_strike.data['strike']['type'] if last_strike else '-':<12} conf {last_strike.data['strike']['confidence'] if last_strike else 0:.2f}",
        f"TARGET {last_imp.data['impact'].target if last_imp else '-':<14} region {last_imp.data['impact'].body_region if last_imp else '-':<8} IMPACT {last_imp.data['physical'].energy_j if last_imp else 0:5.1f} J  DAMAGE {last_dmg.data['damage'] if last_dmg else 0:5.1f}",
        f"HAPTIC lat {st['total']['mean']:5.1f} ms (sched {st['haptic_scheduling']['mean']:.1f} + link {st['hardware_transport']['mean']:.1f})  peak {peak:.2f}  sent {s.pipeline.sent_total}  safety {'TRIPPED' if s.pipeline.limiter.tripped else 'ok'}",
        "ENEMY " + (f"{en[0].id} {en[0].state.value} hp {en[0].health:.0f}/{en[0].max_health:.0f} tokens {len(s.director.tokens.holders)}" if en else "-"),
    ]


def draw_overlay(surface, fonts, lines: list[str]) -> None:
    import pygame

    f = fonts["small"]
    bg = pygame.Surface((880, 16 * len(lines) + 12), pygame.SRCALPHA)
    bg.fill((8, 10, 12, 190))
    surface.blit(bg, (8, 8))
    for i, ln in enumerate(lines):
        surface.blit(f.render(ln, True, pal.UI_TEXT), (16, 14 + i * 16))
