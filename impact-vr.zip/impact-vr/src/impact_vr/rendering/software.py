"""Software renderer (pygame): first-person district view, enemies, props and the player's tracked hands.

The simulation never imports this module. It exists so the prototype is *playable and inspectable* without a GPU stack or headset;
a ModernGL stereo renderer would replace it behind the `Renderer` protocol (not implemented here - see docs/RENDERING.md)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Protocol

import numpy as np
import pygame

from ..engine.mathx import Vec, norm, q_rotate, unit, v3
from ..engine.session import GameSession
from . import palette as pal

NEAR = 0.06
_FACES = (("-x", (0, 1, 3, 2)), ("+x", (4, 6, 7, 5)), ("+y", (2, 3, 7, 6)), ("-z", (0, 2, 6, 4)), ("+z", (1, 5, 7, 3)))
_SHADE = {"+y": 1.0, "+z": 0.86, "-z": 0.78, "+x": 0.7, "-x": 0.64}
_BONES = [(1, 0)] + [(1, 2), (2, 3), (3, 4), (4, 5)] + [c for f in ((6, 7, 8, 9, 10), (11, 12, 13, 14, 15), (16, 17, 18, 19, 20), (21, 22, 23, 24, 25)) for c in zip(f, f[1:], strict=False)]


class Renderer(Protocol):
    def render(self, session: GameSession, surface: pygame.Surface, view: ViewState) -> None: ...


@dataclass
class ViewState:
    fov_deg: float = 95.0
    draw_distance: float = 60.0
    show_collision: bool = False
    show_hands: bool = True
    effects: list = field(default_factory=list)       # [(pos, ttl, color, kind)]


@dataclass
class _Cam:
    eye: Vec
    f: Vec
    r: Vec
    u: Vec
    focal: float
    cx: float
    cy: float

    def to_cam(self, p: Vec) -> tuple[float, float, float]:
        d = p - self.eye
        return float(d @ self.r), float(d @ self.u), float(d @ self.f)

    def proj(self, c: tuple[float, float, float]) -> tuple[float, float]:
        return self.cx + c[0] / c[2] * self.focal, self.cy - c[1] / c[2] * self.focal


def make_cam(eye: Vec, q: Vec, fov: float, w: int, h: int) -> _Cam:
    f = q_rotate(q, v3(0, 0, 1))
    r = unit(np.cross(v3(0, 1, 0), f)) if abs(f[1]) < 0.999 else v3(1, 0, 0)
    return _Cam(eye, f, r, np.cross(f, r), (w / 2) / math.tan(math.radians(fov) / 2), w / 2, h / 2)


def _clip(poly):
    out = []
    for i in range(len(poly)):
        a, b = poly[i], poly[(i + 1) % len(poly)]
        ain, bin_ = a[2] >= NEAR, b[2] >= NEAR
        if ain:
            out.append(a)
        if ain != bin_:
            t = (NEAR - a[2]) / (b[2] - a[2])
            out.append((a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR))
    return out


def _shade(c, k):
    return (max(0, min(255, int(c[0] * k))), max(0, min(255, int(c[1] * k))), max(0, min(255, int(c[2] * k))))


class SoftwareRenderer:
    def __init__(self, fonts: dict[str, pygame.font.Font] | None = None) -> None:
        self.fonts = fonts or {}
        self._light_cache: dict[int, tuple[float, float, float]] = {}
        self.stats = {"polys": 0}

    def _light(self, pos: Vec, level, key: int | None = None) -> tuple[float, float, float]:
        if key is not None and key in self._light_cache:
            return self._light_cache[key]
        r = g = b = 0.34
        for L in level.lights:
            d = norm(pos - L.pos)
            if d < L.radius:
                k = (1 - d / L.radius) ** 2 * L.intensity
                r += k * L.color[0] / 255
                g += k * L.color[1] / 255
                b += k * L.color[2] / 255
        res = (min(r, 1.3), min(g, 1.3), min(b, 1.3))
        if key is not None:
            self._light_cache[key] = res
        return res

    def render(self, session: GameSession, surface: pygame.Surface, view: ViewState) -> None:
        w, h = surface.get_size()
        cam = make_cam(session.head_world, session.head_q_world, view.fov_deg, w, h)
        lvl = session.level
        self._bg(surface, cam, w, h)
        polys: list[tuple[float, tuple[int, int, int], list]] = []
        for i, d in enumerate(lvl.decor):
            c = d.box.center
            if norm(c - cam.eye) - norm(d.box.hi - d.box.lo) * 0.6 > view.draw_distance:
                continue
            if d.key in ("wet_pavement", "concrete_floor", "tram_rail"):
                self._ground(surface, cam, d, lvl)
                continue
            self._box(cam, d.box.lo, d.box.hi, pal.color(d.key), self._light(c, lvl, i), polys, emissive=d.emissive)
        for e in session.director.enemies.values():
            self._enemy(cam, e, lvl, polys)
        for p in lvl.physics.props:
            col = pal.color({"metal": "steel", "wood": "timber", "rubber": "enemy_boss"}.get(p.material, "concrete"))
            self._box(cam, p.p - v3(p.radius, p.height / 2, p.radius), p.p + v3(p.radius, p.height / 2, p.radius), col, self._light(p.p, lvl), polys)
        for pr in session.combat.projectiles:
            self._box(cam, pr.pos - 0.06, pr.pos + 0.06, (140, 160, 120), (1, 1, 1), polys, emissive=True)
        polys.sort(key=lambda p: -p[0])
        for _, col, pts in polys:
            if len(pts) >= 3:
                pygame.draw.polygon(surface, col, pts)
        self.stats["polys"] = len(polys)
        for ln in lvl.lights:   # soft sodium glow on lamp heads
            lc = cam.to_cam(ln.pos)
            if lc[2] > 0.5 and ln.pos[1] > 4.0:
                x, y = cam.proj(lc)
                pygame.draw.circle(surface, _shade(ln.color, 0.8), (int(x), int(y)), max(2, int(cam.focal * 0.12 / lc[2])))
        if view.show_hands:
            self._hands(surface, cam, session)
        self._effects(surface, cam, view)

    def _bg(self, surface, cam, w, h):
        horizon = int(cam.cy + (cam.f[1] / max(math.sqrt(max(1e-6, 1 - cam.f[1] ** 2)), 1e-6)) * cam.focal)
        horizon = max(0, min(h, horizon))
        surface.fill(pal.FOG)
        for i in range(10):
            y0, y1 = int(horizon * i / 10), int(horizon * (i + 1) / 10)
            t = i / 9
            pygame.draw.rect(surface, tuple(int(pal.SKY_TOP[k] + (pal.SKY_HORIZON[k] - pal.SKY_TOP[k]) * t) for k in range(3)), (0, y0, w, y1 - y0 + 1))

    def _ground(self, surface, cam, d, lvl):
        lo, hi = d.box.lo, d.box.hi
        poly = _clip([cam.to_cam(c) for c in (v3(lo[0], 0.0, lo[2]), v3(hi[0], 0.0, lo[2]), v3(hi[0], 0.0, hi[2]), v3(lo[0], 0.0, hi[2]))])
        if len(poly) >= 3:
            k = self._light(v3(cam.eye[0], 0.3, cam.eye[2] + 2), lvl)
            pygame.draw.polygon(surface, _shade(pal.color(d.key), 0.6 + 0.8 * k[0]), [cam.proj(c) for c in poly])
        if d.key == "wet_pavement":                      # wet sheen streaks under lamps
            for L in lvl.lights:
                if L.pos[1] > 4.0:
                    c = cam.to_cam(v3(L.pos[0], 0.0, L.pos[2]))
                    if c[2] > 0.5:
                        x, y = cam.proj(c)
                        pygame.draw.line(surface, _shade(L.color, 0.25), (x, y), (x, y + cam.focal * 1.6 / c[2]), max(1, int(cam.focal * 0.04 / c[2])))

    def _box(self, cam, lo, hi, base, light, out, emissive=False):
        cs = [v3(lo[0] if not (i & 4) else hi[0], lo[1] if not (i & 2) else hi[1], lo[2] if not (i & 1) else hi[2]) for i in range(8)]
        cc = [cam.to_cam(c) for c in cs]
        for name, idx in _FACES:
            poly = _clip([cc[i] for i in idx])
            if len(poly) < 3:
                continue
            pts = [cam.proj(c) for c in poly]
            area = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))
            if area > 0:
                continue
            k = _SHADE[name]
            col = base if emissive else (int(base[0] * k * light[0]), int(base[1] * k * light[1]), int(base[2] * k * light[2]))
            dist = sum(c[2] for c in poly) / len(poly)
            f = min(1.0, dist / 70.0) ** 1.3 * 0.8
            out.append((dist, tuple(max(0, min(255, int(col[j] + (pal.FOG[j] - col[j]) * f))) for j in range(3)), pts))

    def _enemy(self, cam, e, lvl, polys) -> None:
        if not e.alive:
            self._box(cam, e.pos + v3(-0.5, 0.0, -0.25), e.pos + v3(0.5, 0.2, 0.25), pal.color("enemy_street"), (0.5, 0.5, 0.5), polys)
            return
        j = e.joints()
        base = pal.color(e.arch.color)
        if e.hit_flash > 0:
            base = (min(255, base[0] + 90), min(255, base[1] + 90), min(255, base[2] + 90))
        telegraph = e.telegraph() is not None
        light = tuple(max(0.35, x) for x in self._light(e.pos + v3(0, 1, 0), lvl))
        s = e.s

        def blk(a, b, rad, col, em=False):
            self._box(cam, np.minimum(a, b) - rad, np.maximum(a, b) + rad, col, light, polys, em)
        blk(j["chest"] + v3(0, 0.1, 0) * s, j["chest"] - v3(0, 0.16, 0) * s, 0.2 * s, base)
        blk(j["hips"] + v3(0, 0.1, 0) * s, j["hips"] - v3(0, 0.04, 0) * s, 0.17 * s, _shade(base, 0.8))
        blk(j["head"], j["head"], 0.11 * s, pal.color("skin"))
        for side in ("l", "r"):
            blk(j[f"shoulder_{side}"], j[f"fist_{side}"], 0.055 * s, _shade(base, 0.9))
            blk(j[f"fist_{side}"], j[f"fist_{side}"], 0.07 * s, (255, 120, 70) if telegraph else pal.color("glove"), telegraph)
            blk(v3(j["hips"][0] + (0.1 if side == "r" else -0.1) * s, 0.5 * s, j["hips"][2]), v3(j[f"foot_{side}"][0], 0.05, j[f"foot_{side}"][2]), 0.07 * s, _shade(base, 0.7))
        if e.shield_up and e.shield_hp > 0:
            c = e.to_world(v3(-0.1, 1.2, 0.5))
            blk(c - v3(0.0, 0.5, 0.0) * s, c + v3(0.0, 0.45, 0.0) * s, 0.22 * s, (96, 112, 120))

    def _hands(self, surface, cam, session) -> None:
        for h, st in session.world_hands.items():
            if st is None:
                continue
            pts = []
            for i in range(26):
                c = cam.to_cam(st.positions[i])
                pts.append(cam.proj(c) if c[2] > NEAR else None)
            col = pal.color("skin") if h == "right" else _shade(pal.color("skin"), 0.9)
            for a, b in _BONES:
                pa, pb = pts[a], pts[b]
                if pa and pb:
                    pygame.draw.line(surface, pal.color("glove"), pa, pb, 7)
                    pygame.draw.line(surface, col, pa, pb, 3)
            c = cam.to_cam(st.fist_center)
            if c[2] > NEAR:
                x, y = cam.proj(c)
                active = session.detector.active_strike(h)
                pygame.draw.circle(surface, pal.AMBER if active else pal.color("glove"), (int(x), int(y)), max(3, min(40, int(cam.focal * 0.035 / c[2]))), 0 if active else 2)

    def _effects(self, surface, cam, view) -> None:
        for pos, ttl, col, kind in view.effects:
            c = cam.to_cam(pos)
            if c[2] < NEAR:
                continue
            x, y = cam.proj(c)
            r = max(3, int(cam.focal * 0.12 / c[2] * (1.2 - min(ttl, 0.3))))
            pygame.draw.circle(surface, col, (int(x), int(y)), r, 2)
            pygame.draw.line(surface, col, (x - r, y), (x + r, y), 1)
            pygame.draw.line(surface, col, (x, y - r), (x, y + r), 1)
