"""SyntheticEnemy + SyntheticCombatScenario: scripted, repeatable combat situations that exercise the whole pipeline."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

import numpy as np

from ..engine.config import Config, load_config
from ..engine.mathx import v3
from ..engine.modes import GameMode
from ..engine.session import GameSession
from ..enemies.archetypes import get_archetype
from ..enemies.enemy import Enemy, EnemyState, PlayerBody
from ..vr.adapters import ControllerHandFallback
from ..vr.device import VRRuntime
from .synthetic import MOVES, HeadKey, SyntheticController, SyntheticHandTracker, SyntheticHeadset


class SyntheticEnemy(Enemy):
    """Passive training/test enemy: holds position, takes hits, optionally throws scheduled attacks (for block/parry tests)."""

    def __init__(self, uid: str, archetype: str, pos, yaw: float = math.pi, passive: bool = True, attacks: tuple[tuple[float, str], ...] = (), seed: int = 5) -> None:
        super().__init__(uid, get_archetype(archetype), np.array(pos, float), yaw, random.Random(seed))
        self.passive = passive
        self.sched = sorted(attacks)
        self.state = EnemyState.APPROACH
        self.group = "synthetic"
        self.guard_z = 0.12 if passive else 0.32

    def update(self, dt: float, t: float, player: PlayerBody, tokens_ok: bool, blocked_fn=None) -> None:
        if not self.passive:
            return super().update(dt, t, player, tokens_ok, blocked_fn)
        self.state_t += dt
        self.hit_flash = max(0.0, self.hit_flash - dt)
        self.react.step(dt)
        self.stagger_meter = max(0.0, self.stagger_meter - dt * 6.0)
        if float(np.linalg.norm(self.knockback)) > 0.02:
            self._move(self.knockback * dt, blocked_fn)
            self.knockback = self.knockback * math.exp(-5.0 * dt)
        if self.state is EnemyState.DEFEATED:
            return
        if self.state is EnemyState.STAGGER:
            if self.state_t >= self.stagger_time:
                self._set(EnemyState.APPROACH)
            return
        to_p = player.floor - self.pos
        if self.state is EnemyState.ATTACK:
            self._attack_update(dt, player, to_p, float(np.linalg.norm(to_p)))
            return
        self._face(to_p, dt, 6.0)
        if self.sched and t >= self.sched[0][0]:
            _, name = self.sched.pop(0)
            self._start_attack(next(a for a in self.arch.attacks if a.name == name), player)


@dataclass
class SyntheticCombatScenario:
    name: str
    description: str
    duration: float
    moves: list[tuple[float, str, str, dict]] = field(default_factory=list)       # (t, move, hand, kwargs)
    head: list[HeadKey] = field(default_factory=list)
    enemies: list[dict] = field(default_factory=list)                                # kwargs for SyntheticEnemy
    level: str = "street"
    expect_strikes: list[str] = field(default_factory=list)
    expect_events: list[str] = field(default_factory=list)
    noise_mm: float = 0.0
    props: dict[str, tuple[float, float, float]] = field(default_factory=dict)

    def build(self, cfg: Config | None = None, seed: int = 11, controllers: bool = False, **kw) -> tuple[GameSession, VRRuntime]:
        cfg = cfg or load_config()
        head = SyntheticHeadset(self.head)
        tracker = SyntheticHandTracker(head, noise_mm=self.noise_mm)
        for t, move, hand, kwargs in self.moves:
            tracker.scripts[hand].add(t, MOVES[move](hand, **kwargs))
        rt = VRRuntime(head, None if controllers else tracker, SyntheticController(tracker), min_confidence=cfg.vr.min_hand_confidence, target_fps=cfg.vr.target_fps,
                       fallback=ControllerHandFallback())
        rt.start()
        sess = GameSession(cfg, rt, mode=GameMode.TRAINING, level_kind=self.level, seed=seed, **kw)
        setup: list[dict] = [{"prop": [pn, list(pos)]} for pn, pos in self.props.items()]
        for i, spec in enumerate(self.enemies):
            setup.append({"enemy": {"uid": f"dummy_{i}", "archetype": spec["archetype"], "pos": list(spec["pos"]), "yaw": spec.get("yaw", math.pi),
                                    "passive": spec.get("passive", True), "attacks": [list(a) for a in spec.get("attacks", ())], "seed": spec.get("seed", 5)}})
        sess.apply_setup(setup)
        return sess, rt

    def run(self, cfg: Config | None = None, seed: int = 11, **kw) -> GameSession:
        sess, _ = self.build(cfg, seed, **kw)
        sess.run(self.duration)
        return sess


def _en(z: float = 0.95, x: float = 0.0, arch: str = "street_fighter", **kw) -> dict:
    return dict(archetype=arch, pos=(x, 0.0, z), **kw)


SCENARIOS: dict[str, SyntheticCombatScenario] = {s.name: s for s in [
    SyntheticCombatScenario("jab_cross", "Orthodox one-two into a stationary opponent.", 3.4,
                            [(1.0, "jab", "left", {}), (2.0, "cross", "right", {})], enemies=[_en(0.95)], expect_strikes=["jab", "cross"]),
    SyntheticCombatScenario("hook_to_head", "Right hook at head height.", 2.6, [(1.0, "hook", "right", {})], enemies=[_en(0.88)], expect_strikes=["hook"]),
    SyntheticCombatScenario("uppercut_body", "Right uppercut under the guard.", 2.6, [(1.0, "uppercut", "right", {})], enemies=[_en(0.95)], expect_strikes=["uppercut"]),
    SyntheticCombatScenario("hammer_fist", "Overhead hammer fist.", 2.6, [(1.0, "hammer_fist", "right", {})], enemies=[_en(0.95)], expect_strikes=["hammer_fist"]),
    SyntheticCombatScenario("palm_and_push", "Palm strike then a push.", 4.0, [(1.0, "palm_strike", "right", {}), (2.5, "push", "left", {})], enemies=[_en(1.0)], expect_strikes=["palm_strike"]),
    SyntheticCombatScenario("block_incoming", "Hold a two-handed guard while an opponent winds up and swings.", 3.5,
                            [(0.2, "block", "left", {}), (0.2, "block", "right", {})], enemies=[_en(1.15, passive=True, attacks=((1.6, "hook"),))], expect_events=["BLOCK"]),
    SyntheticCombatScenario("parry_window", "Open-hand parry timed to an incoming jab.", 3.2,
                            [(0.2, "block", "left", {}), (1.50, "parry", "right", {})], enemies=[_en(1.15, passive=True, attacks=((1.3, "jab"),))], expect_events=["PARRY"]),
    SyntheticCombatScenario("grab_and_throw", "Grab a crate from the floor and hurl it at a dummy.", 5.0,
                            [(1.0, "grab", "right", {"target": v3(0.3, 0.45, 0.6)}), (2.6, "throw", "right", {})], enemies=[_en(2.4, 0.15)], level="training",
                            props={"timber_crate": (0.3, 0.45, 0.6)}, expect_events=["GRAB"]),
    SyntheticCombatScenario("dodge_duck_weave", "Duck under an overhead, then weave and dodge.", 5.0, [],
                            head=[HeadKey(0.0, v3()), HeadKey(1.0, v3()), HeadKey(1.35, v3(0, -0.42, 0.05)), HeadKey(2.0, v3(0, -0.42, 0.05)), HeadKey(2.3, v3()),
                                  HeadKey(3.0, v3()), HeadKey(3.25, v3(0.24, -0.04, 0)), HeadKey(3.6, v3()), HeadKey(4.0, v3()), HeadKey(4.2, v3(0.55, 0, 0))],
                            expect_events=["GESTURE_DETECTED"]),
    SyntheticCombatScenario("combo_chain", "Jab, cross, hook against an enemy that does not move.", 5.2,
                            [(1.0, "jab", "left", {}), (2.0, "cross", "right", {}), (3.2, "hook", "left", {})], enemies=[_en(0.92)], expect_strikes=["jab", "cross", "hook"]),
]}
