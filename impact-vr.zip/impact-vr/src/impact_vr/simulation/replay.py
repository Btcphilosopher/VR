"""Deterministic record / replay.

Recorded per VR frame: head pose, controller states, both hand skeletons, plus every gameplay event (strikes, collisions, impacts,
damage, enemy states, haptic events, player movement). The file is JSON-lines with sorted keys and floats rounded to a fixed
precision, so recordings are stable, diffable and compact enough to commit as fixtures.

Replay feeds the recorded frames into a fresh `GameSession` (no headset, no glove, no wall clock) and compares the event digest
with the one stored in the footer - a strong determinism / regression check for the entire pipeline.
"""

from __future__ import annotations

import gzip
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

from ..engine.config import Config, load_config
from ..engine.events import Event
from ..hands.skeleton import HandSkeleton
from ..vr.types import ControllerState, SessionState, VRFrame, VRPose

FORMAT = "impact-vr-replay"
VERSION = 1
PREC = 5

RECORDED_EVENTS = {"STRIKE_DETECTED", "GESTURE_DETECTED", "COLLISION", "IMPACT_CALCULATED", "DAMAGE_APPLIED", "BLOCK", "PARRY", "GRAB", "PLAYER_DAMAGED",
                   "ENEMY_STATE", "ENEMY_ATTACK", "ENEMY_DEFEATED", "HAPTIC_SCHEDULED", "HAPTIC_SENT", "SAFETY_TRIP", "PLAYER_MOVED", "ENCOUNTER"}


def _r(a: Any) -> Any:
    return np.round(np.asarray(a, dtype=float), PREC).tolist()


def _pose(p: VRPose) -> dict[str, Any]:
    return {"p": _r(p.p), "q": _r(p.q), "v": bool(p.valid)}


def _unpose(d: dict[str, Any]) -> VRPose:
    return VRPose(np.array(d["p"]), np.array(d["q"]), d.get("v", True))


def _ev(e: Event) -> dict[str, Any]:
    from ..engine.session import canon

    return {"n": e.name, "t": round(e.t, 5), "d": json.loads(canon(e))[3]}


def config_hash(cfg: Config) -> str:
    return hashlib.sha256(cfg.model_dump_json().encode()).hexdigest()[:16]


@dataclass
class ReplayHeader:
    seed: int
    mode: str
    level: str
    encounter: str | None
    dt: float
    config_hash: str
    notes: str = ""
    setup: list | None = None


class ReplayRecorder:
    """Attach to a GameSession (`GameSession(..., recorder=rec)`); call `save()` at the end."""

    def __init__(self, notes: str = "") -> None:
        self.frames: list[dict[str, Any]] = []
        self.header: ReplayHeader | None = None
        self.notes = notes
        self.footer: dict[str, Any] = {}

    def record(self, frame: VRFrame, events: list[Event], session) -> None:
        if self.header is None:
            self.header = ReplayHeader(session.seed, session.mode.value, session.level.id, session.director.active.id if session.director.active else None,
                                       session.dt, config_hash(session.cfg), self.notes, list(session.setup))
        hands = {}
        for h in ("left", "right"):
            sk = frame.hands.get(h)
            hands[h] = None if sk is None else {"pos": _r(sk.positions), "ori": _r(sk.orientations), "conf": round(sk.confidence, 4), "tracked": bool(sk.tracked), "src": sk.source}
        ctrls = {h: {"pose": _pose(c.pose), "trigger": round(c.trigger, 4), "grip": round(c.grip, 4), "stick": [round(c.stick[0], 4), round(c.stick[1], 4)],
                     "a": c.a, "b": c.b, "menu": c.menu, "tracked": c.tracked} for h, c in frame.controllers.items()}
        self.frames.append({"f": frame.frame_id, "t": round(frame.t, 5), "dt": round(frame.dt, 6), "head": _pose(frame.head), "ctrl": ctrls, "hands": hands,
                            "src": frame.hand_source, "ev": [_ev(e) for e in events if e.name in RECORDED_EVENTS]})
        self.footer = {"digest": session.event_digest(), "frames": len(self.frames), "events": session.digest_events,
                       "result": None if session.result is None else session.result.__dict__}

    def save(self, path: str | Path) -> Path:
        path = Path(path)
        assert self.header is not None, "nothing recorded"
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "wt") as fh:   # type: ignore[operator]
            fh.write(json.dumps({"format": FORMAT, "version": VERSION, **self.header.__dict__}, sort_keys=True) + "\n")
            for fr in self.frames:
                fh.write(json.dumps(fr, sort_keys=True, separators=(",", ":")) + "\n")
            fh.write(json.dumps({"footer": self.footer}, sort_keys=True, default=str) + "\n")
        return path


class ReplayFormatError(ValueError):
    pass


class ReplaySource:
    """Frame source backed by a recording (implements the same `poll` as VRRuntime). Needs no VR hardware."""

    def __init__(self, header: dict[str, Any], frames: list[dict[str, Any]], footer: dict[str, Any]) -> None:
        self.header, self.raw, self.footer = header, frames, footer
        self.i = 0

    @staticmethod
    def load(path: str | Path) -> ReplaySource:
        path = Path(path)
        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt") as fh:   # type: ignore[operator]
            lines = [ln for ln in fh.read().splitlines() if ln.strip()]
        if not lines:
            raise ReplayFormatError("empty replay")
        head = json.loads(lines[0])
        if head.get("format") != FORMAT or head.get("version") != VERSION:
            raise ReplayFormatError(f"unsupported replay format {head.get('format')} v{head.get('version')}")
        footer = json.loads(lines[-1]).get("footer", {}) if "footer" in lines[-1] else {}
        body = lines[1:-1] if footer else lines[1:]
        return ReplaySource(head, [json.loads(x) for x in body], footer)

    def __len__(self) -> int:
        return len(self.raw)

    @property
    def finished(self) -> bool:
        return self.i >= len(self.raw)

    def poll(self, t: float | None = None) -> VRFrame:
        last = self.i >= len(self.raw)
        if last:
            self.i = len(self.raw) - 1          # hold the last frame
        r = self.raw[self.i]
        if not last:
            self.i += 1
        hands: dict[str, HandSkeleton | None] = {}
        for h in ("left", "right"):
            d = r["hands"].get(h)
            hands[h] = None if d is None else HandSkeleton(h, r["t"], np.array(d["pos"]), np.array(d["ori"]), d["conf"], d.get("src", "replay"), d["tracked"])
        ctrls = {h: ControllerState(_unpose(c["pose"]), c["trigger"], c["grip"], tuple(c["stick"]), c["a"], c["b"], c["menu"], c["tracked"]) for h, c in r["ctrl"].items()}
        return VRFrame(r["f"], r["t"], r["dt"], _unpose(r["head"]), ctrls, hands, SessionState.FOCUSED, r.get("src", {}), r["t"], r["dt"] * 1000.0)

    def expected_events(self) -> list[tuple[int, list[dict[str, Any]]]]:
        return [(fr["f"], fr["ev"]) for fr in self.raw]


@dataclass
class ReplayReport:
    ok: bool
    frames: int
    expected_digest: str
    actual_digest: str
    first_mismatch_frame: int | None = None
    detail: str = ""


def replay_session(path: str | Path, cfg: Config | None = None, **session_kw):
    from ..engine.modes import GameMode
    from ..engine.session import GameSession

    src = ReplaySource.load(path)
    cfg = cfg or load_config()
    h = src.header
    sess = GameSession(cfg, src, mode=GameMode(h["mode"]), level_kind="training" if h["level"] == "training_room" else "street", encounter=h.get("encounter"),
                       seed=h["seed"], **session_kw)
    sess.apply_setup(h.get("setup") or [])
    return sess, src


def verify_replay(path: str | Path, cfg: Config | None = None) -> ReplayReport:
    """Re-run a recording through a fresh session and compare per-frame events and the final digest."""
    sess, src = replay_session(path, cfg)
    exp = src.expected_events()
    mismatch, detail = None, ""
    for i in range(len(src)):
        res = sess.step()
        got = [_ev(e) for e in res.events if e.name in RECORDED_EVENTS]
        if mismatch is None and got != exp[i][1]:
            mismatch, detail = exp[i][0], f"frame {exp[i][0]}: expected {len(exp[i][1])} events, got {len(got)}"
    expected, actual = src.footer.get("digest", ""), sess.event_digest()
    return ReplayReport(mismatch is None and expected == actual, len(src), expected, actual, mismatch, detail)
