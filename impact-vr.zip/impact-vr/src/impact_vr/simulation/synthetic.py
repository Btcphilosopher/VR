"""Synthetic VR: scripted hands, head, controllers and combat trajectories.

Trajectories are authored for the *fist centre* in the fighter's body frame (x right, y up, z forward, origin at the standing floor
point under the head) and converted to full 26-joint skeletons with the rig - so the whole combat pipeline can be exercised
automatically with no hardware. Lead-ins and returns between moves are deliberately slow (below the strike onset speed) so they
never register as strikes.
"""

from __future__ import annotations

import math
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from ..engine.mathx import Transform, Vec, q_from_fwd_up, q_from_yaw, q_rotate, unit, v3
from ..hands.skeleton import FingerCurls, HandSkeleton, build_skeleton
from ..vr.device import VRController, VRHandTracker, VRHeadset
from ..vr.types import ControllerState, VRPose

EYE = 1.65
FIST_OFFSET = 0.11            # wrist -> knuckle-row centre along the hand's forward axis


def min_jerk(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return 10 * u**3 - 15 * u**4 + 6 * u**5


@dataclass
class HandPoseB:
    """Hand pose in the body frame, authored by fist centre."""

    fist: Vec
    fwd: Vec
    back: Vec                     # direction of the back of the hand (palm faces -back)
    curls: FingerCurls = field(default_factory=FingerCurls.fist)

    def lerp(self, o: HandPoseB, k: float) -> HandPoseB:
        return HandPoseB(self.fist + (o.fist - self.fist) * k, unit(self.fwd + (o.fwd - self.fwd) * k), unit(self.back + (o.back - self.back) * k), self.curls.lerp(o.curls, k))


def guard_pose(hand: str, wobble: float = 0.0) -> HandPoseB:
    s = 1.0 if hand == "right" else -1.0
    lead = 0.04 if hand == "left" else 0.0
    return HandPoseB(v3(0.17 * s, 1.36 + wobble, 0.30 + lead), unit(v3(-0.1 * s, 0.35, 0.93)), unit(v3(0.6 * s, 0.75, -0.1)))


@dataclass
class Trajectory:
    name: str
    hand: str
    duration: float
    fn: Callable[[float], HandPoseB]

    def sample(self, tl: float) -> HandPoseB:
        return self.fn(min(1.0, max(0.0, tl / self.duration)))


def _straight(hand: str, name: str, start: Vec, end: Vec, dur: float) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    d = unit(end - start)
    return Trajectory(name, hand, dur, lambda u: HandPoseB(start + (end - start) * min_jerk(u), d, unit(v3(0.25 * s, 1.0, 0.0)), FingerCurls.fist()))


def straight_punch(hand: str = "right", reach: float = 0.9, dur: float = 0.16, height: float = 1.45) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    return _straight(hand, "jab" if hand == "left" else "cross", v3(0.16 * s, height - 0.05, 0.28), v3(0.05 * s, height, reach), dur)


def jab(hand: str = "left", **kw: float) -> Trajectory:
    t = straight_punch(hand, **kw)
    t.name = "jab"
    return t


def cross(hand: str = "right", **kw: float) -> Trajectory:
    t = straight_punch(hand, **kw)
    t.name = "cross"
    return t


def hook(hand: str = "right", dur: float = 0.22, radius: float = 0.62, height: float = 1.42) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    c = v3(0.2 * s, height, 0.15)

    def fn(u: float) -> HandPoseB:
        th = math.radians(78 - 92 * min_jerk(u))               # outward-forward -> across the body
        pos = c + v3(s * radius * math.sin(th), 0.0, radius * math.cos(th))
        vel = v3(s * radius * math.cos(th) * -1.0, 0.0, -radius * math.sin(th) * -1.0)
        return HandPoseB(pos, unit(vel), unit(v3(0.0, 1.0, 0.0) + 0.2 * v3(s, 0, 0)), FingerCurls.fist())
    return Trajectory("hook", hand, dur, fn)


def uppercut(hand: str = "right", dur: float = 0.2) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.12 * s, 0.95, 0.45), v3(0.04 * s, 1.58, 0.90)
    d = unit(b - a)
    return Trajectory("uppercut", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), d, unit(v3(0.2 * s, 0.1, -1.0)), FingerCurls.fist()))


def hammer_fist(hand: str = "right", dur: float = 0.2) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.1 * s, 1.95, 0.50), v3(0.08 * s, 1.25, 0.86)
    d = unit(b - a)
    return Trajectory("hammer_fist", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), d, unit(v3(-1.0 * s, 0.1, 0.0)), FingerCurls.fist()))


def palm_strike(hand: str = "right", dur: float = 0.18) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.14 * s, 1.40, 0.30), v3(0.06 * s, 1.45, 0.88)
    d = unit(b - a)
    fc = FingerCurls(0.1, 0.05, 0.05, 0.05, 0.08)
    return Trajectory("palm_strike", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), v3(0.0, 1.0, 0.0), -d, fc))     # fingers up, palm leads


def backhand(hand: str = "right", dur: float = 0.2) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(-0.25 * s, 1.42, 0.62), v3(0.75 * s, 1.42, 0.66)
    d = unit(b - a)
    fc = FingerCurls(0.1, 0.1, 0.1, 0.1, 0.1)
    return Trajectory("backhand", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), v3(0.0, 0.7, 0.7), d, fc))        # back of hand leads


def elbow_strike(hand: str = "right", dur: float = 0.2) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.22 * s, 1.35, 0.20), v3(0.10 * s, 1.40, 0.78)
    d = unit(b - a)
    return Trajectory("elbow_strike", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), -d, v3(0.0, 1.0, 0.0), FingerCurls.fist()))   # forearm folds back: elbow leads


def block_pose(hand: str, dur: float = 0.25) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a = guard_pose(hand)
    b = HandPoseB(v3(0.10 * s, 1.58, 0.24), unit(v3(-0.05 * s, 0.95, 0.2)), unit(v3(0.9 * s, 0.1, -0.3)), FingerCurls.fist())
    return Trajectory("block", hand, dur, lambda u: a.lerp(b, min_jerk(u)))


def parry(hand: str = "right", dur: float = 0.12, sweep: float = 0.28) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.14 * s, 1.45, 0.36), v3((0.14 - sweep) * s, 1.45, 0.36)
    d = unit(b - a)
    fc = FingerCurls(0.1, 0.1, 0.1, 0.1, 0.1)
    return Trajectory("parry", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), v3(0, 0.3, 1.0), v3(0.0, 0.9, -0.2) + 0.5 * d, fc))


def grab(hand: str = "right", target: Vec | None = None, dur: float = 0.35) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a = guard_pose(hand).fist
    b = target if target is not None else v3(0.12 * s, 1.15, 0.55)
    d = unit(b - a)

    def fn(u: float) -> HandPoseB:
        close = min_jerk(max(0.0, (u - 0.55) / 0.45))
        return HandPoseB(a + (b - a) * min_jerk(u), d, v3(0.0, 1.0, 0.0), FingerCurls.open().lerp(FingerCurls.grip(), close))
    return Trajectory("grab", hand, dur, fn)


def throw(hand: str = "right", dur: float = 0.3, start: Vec | None = None) -> Trajectory:
    """Hurl whatever is in the hand: fast forward-up arc, fingers open at ~55% (release)."""
    s = 1.0 if hand == "right" else -1.0
    a = start if start is not None else v3(0.3 * s, 0.45, 0.6)
    b = v3(0.15 * s, 1.35, 1.9)
    d = unit(b - a)

    def fn(u: float) -> HandPoseB:
        op = min_jerk(max(0.0, (u - 0.5) / 0.15))
        return HandPoseB(a + (b - a) * min_jerk(u), d, v3(0.0, 1.0, 0.0), FingerCurls.grip().lerp(FingerCurls.open(), op))
    return Trajectory("throw", hand, dur, fn)


def push(hand: str = "right", dur: float = 0.45, reach: float = 0.35) -> Trajectory:
    s = 1.0 if hand == "right" else -1.0
    a, b = v3(0.14 * s, 1.35, 0.30), v3(0.10 * s, 1.38, 0.30 + reach)
    d = unit(b - a)
    fc = FingerCurls(0.1, 0.05, 0.05, 0.05, 0.08)
    return Trajectory("push", hand, dur, lambda u: HandPoseB(a + (b - a) * min_jerk(u), v3(0, 1.0, 0.0), -d, fc))


def shove(hand: str = "right", dur: float = 0.16, reach: float = 0.42) -> Trajectory:
    t = push(hand, dur, reach)
    t.name = "shove"
    return t


MOVES: dict[str, Callable[..., Trajectory]] = {
    "jab": jab, "cross": cross, "hook": hook, "uppercut": uppercut, "hammer_fist": hammer_fist, "palm_strike": palm_strike, "backhand": backhand,
    "elbow_strike": elbow_strike, "block": block_pose, "parry": parry, "grab": grab, "throw": throw, "push": push, "shove": shove,
}

# the named scripted trajectories required by the spec
straight_punch_ = straight_punch


@dataclass
class HeadKey:
    t: float
    p: Vec          # body-frame offset from the standing head position
    yaw: float = 0.0


class HandScript:
    """A timeline of trajectories for one hand: slow lead-in -> move -> controlled return to guard. Blocks and grabs are *held*
    until the next item starts."""

    LEAD_SPEED = 0.6          # m/s average - lead-in and return are deliberately slower than the strike onset threshold
    MIN_LEAD = 0.18

    def __init__(self, hand: str, return_time: float = 0.18) -> None:
        self.hand = hand
        self.items: list[tuple[float, Trajectory]] = []
        self.return_time = return_time
        self.hold_pose: HandPoseB | None = None

    def add(self, t0: float, traj: Trajectory) -> HandScript:
        self.items.append((t0, traj))
        self.items.sort(key=lambda x: x[0])
        return self

    def _lead(self, a: HandPoseB, b: HandPoseB) -> float:
        return max(self.MIN_LEAD, float(np.linalg.norm(a.fist - b.fist)) / self.LEAD_SPEED)

    def pose(self, t: float) -> HandPoseB:
        base = self.hold_pose or guard_pose(self.hand)
        cur = base
        for idx, (t0, tr) in enumerate(self.items):
            start = tr.sample(0.0)
            lead = self._lead(cur, start)
            if t < t0 - lead:
                return cur
            if t < t0:
                return cur.lerp(start, min_jerk((t - (t0 - lead)) / lead))
            tl = t - t0
            if tl <= tr.duration:
                return tr.sample(tl)
            end = tr.sample(tr.duration)
            nxt = self.items[idx + 1] if idx + 1 < len(self.items) else None
            if tr.name in ("block", "grab"):
                cur = end
                continue
            back = max(self.return_time, float(np.linalg.norm(end.fist - base.fist)) / self.LEAD_SPEED)
            u = (tl - tr.duration) / back
            if u < 1.0 and (nxt is None or t < nxt[0] - self._lead(base, nxt[1].sample(0.0))):
                return end.lerp(base, min_jerk(u))
            cur = base if u >= 1.0 else end.lerp(base, min_jerk(u))
        return cur


class SyntheticHeadset(VRHeadset):
    name = "synthetic-headset"

    def __init__(self, keys: list[HeadKey] | None = None, eye_height: float = EYE, yaw: float = 0.0) -> None:
        self.keys = sorted(keys or [], key=lambda k: k.t)
        self.eye = eye_height
        self.yaw = yaw
        self.position = v3(0, 0, 0)

    def start(self) -> None: ...
    def stop(self) -> None: ...

    def body_head(self, t: float) -> tuple[Vec, float]:
        off, yaw = v3(), 0.0
        ks = self.keys
        if ks:
            if t <= ks[0].t:
                off, yaw = ks[0].p, ks[0].yaw
            elif t >= ks[-1].t:
                off, yaw = ks[-1].p, ks[-1].yaw
            else:
                for a, b in zip(ks, ks[1:], strict=False):
                    if a.t <= t <= b.t:
                        k = min_jerk((t - a.t) / max(b.t - a.t, 1e-9))
                        off, yaw = a.p + (b.p - a.p) * k, a.yaw + (b.yaw - a.yaw) * k
                        break
        return off, yaw

    def get_pose(self, t: float) -> VRPose:
        off, yaw = self.body_head(t)
        return VRPose(self.position + v3(0, self.eye, 0) + off, q_from_yaw(self.yaw + yaw))


class SyntheticHandTracker(VRHandTracker):
    """Scripted hand tracker. Optional seeded sensor noise, dropout windows and confidence."""

    name = "synthetic-hands"

    def __init__(self, headset: SyntheticHeadset, left: HandScript | None = None, right: HandScript | None = None, noise_mm: float = 0.0, seed: int = 7) -> None:
        self.headset = headset
        self.scripts = {"left": left or HandScript("left"), "right": right or HandScript("right")}
        self.noise = noise_mm / 1000.0
        self.rng = np.random.default_rng(seed)
        self.dropouts: list[tuple[float, float, str]] = []     # (t0, t1, hand)
        self.confidence = 1.0
        self._cache: dict[tuple[str, float], HandSkeleton] = {}

    def start(self) -> None: ...
    def stop(self) -> None: ...

    def body_transform(self, t: float) -> Transform:
        off, yaw = self.headset.body_head(t)
        return Transform(self.headset.position + v3(off[0], off[1], off[2]), q_from_yaw(self.headset.yaw + yaw))

    def skeleton_at(self, hand: str, t: float) -> HandSkeleton:
        key = (hand, t)
        hit = self._cache.get(key)
        if hit is not None:
            return hit.copy()
        sk = self._skeleton_at(hand, t)
        if len(self._cache) > 8:
            self._cache.clear()
        self._cache[key] = sk
        return sk.copy()

    def _skeleton_at(self, hand: str, t: float) -> HandSkeleton:
        bt = self.body_transform(t)
        hp = self.scripts[hand].pose(t)
        q = q_from_fwd_up(bt.apply_dir(hp.fwd), bt.apply_dir(hp.back))
        wrist = bt.apply(hp.fist) - q_rotate(q, v3(0, 0, FIST_OFFSET))
        return build_skeleton(hand, wrist, q, hp.curls, t=t, confidence=self.confidence, source="synthetic")

    def get_hands(self, t: float) -> dict[str, HandSkeleton | None]:
        out: dict[str, HandSkeleton | None] = {}
        for h in ("left", "right"):
            sk = self.skeleton_at(h, t)
            if any(a <= t <= b and hh == h for a, b, hh in self.dropouts):
                sk.tracked, sk.confidence = False, 0.0
            elif self.noise > 0:
                sk.positions = sk.positions + self.rng.normal(0.0, self.noise, sk.positions.shape)
            out[h] = sk
        return out


class SyntheticController(VRController):
    """Controller emulation derived from the same scripts: pose at the wrist, grip/trigger from the finger curls."""

    name = "synthetic-controllers"

    def __init__(self, tracker: SyntheticHandTracker) -> None:
        self.tracker = tracker

    def start(self) -> None: ...
    def stop(self) -> None: ...

    def get_state(self, hand: str, t: float) -> ControllerState:
        from ..hands.analyzer import flexion_from_positions

        sk = self.tracker.skeleton_at(hand, t)
        fl = flexion_from_positions(sk.positions)
        return ControllerState(VRPose(sk.wrist + q_rotate(sk.wrist_q, v3(0, 0, 0.06)), sk.wrist_q), trigger=fl["index"],
                               grip=float(np.mean([fl["middle"], fl["ring"], fl["little"]])))
