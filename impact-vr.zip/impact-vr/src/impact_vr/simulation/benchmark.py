"""Benchmark mode: per-stage compute cost, end-to-end frame throughput, and the INPUT -> COLLISION -> HAPTIC latency breakdown."""

from __future__ import annotations

import time
from dataclasses import dataclass, field

from ..engine.config import Config, load_config
from ..telemetry.latency import STAGES
from .scenarios import SCENARIOS


@dataclass
class BenchmarkReport:
    scenario: str
    frames: int
    wall_s: float
    mean_frame_ms: float
    p99_frame_ms: float
    achieved_fps: float
    target_fps: float
    meets_target: bool
    stages_ms: dict[str, dict[str, float]]
    haptic_commands: int
    traces: int
    impacts: int
    mean_total_latency_ms: float
    p95_total_latency_ms: float
    notes: list[str] = field(default_factory=list)

    def format(self) -> str:
        lines = [f"IMPACT//VR benchmark - scenario '{self.scenario}'",
                 f"  frames {self.frames} in {self.wall_s:.2f}s -> {self.achieved_fps:.0f} fps (target {self.target_fps:.0f}) {'OK' if self.meets_target else 'BELOW TARGET'}",
                 f"  frame ms: mean {self.mean_frame_ms:.2f}  p99 {self.p99_frame_ms:.2f}", "  per-stage compute / latency (ms):"]
        for k in STAGES:
            s = self.stages_ms.get(k, {})
            lines.append(f"    {k:<20} mean {s.get('mean', 0):6.3f}  p95 {s.get('p95', 0):6.3f}  max {s.get('max', 0):6.3f}")
        lines.append(f"  INPUT -> COLLISION -> HAPTIC total: mean {self.mean_total_latency_ms:.2f} ms  p95 {self.p95_total_latency_ms:.2f} ms  ({self.traces} traces, {self.impacts} impacts)")
        lines += [f"  note: {n}" for n in self.notes]
        return "\n".join(lines)


def run_benchmark(scenario: str = "combo_chain", cfg: Config | None = None, seconds: float | None = None, repeat: int = 1, seed: int = 11) -> BenchmarkReport:
    cfg = cfg or load_config()
    sc = SCENARIOS[scenario]
    secs = seconds or sc.duration
    frame_ms: list[float] = []
    sess = None
    t_all = time.perf_counter()
    total = 0
    for r in range(repeat):
        sess, _ = sc.build(cfg, seed + r)
        n = int(round(secs / sess.dt))
        for _ in range(n):
            t0 = time.perf_counter_ns()
            sess.step()
            frame_ms.append((time.perf_counter_ns() - t0) / 1e6)
        total += n
    wall = time.perf_counter() - t_all
    assert sess is not None
    fm = sorted(frame_ms)
    summ = sess.latency.summary()
    mean = sum(fm) / len(fm)
    notes = ["compute stages are measured; scheduler/transport latencies come from the simulated glove (haptics.toml glove_latency_ms)",
             "Python orchestrates; swap native implementations behind the same interfaces for headroom (docs/PERFORMANCE.md)"]
    return BenchmarkReport(scenario, total, wall, mean, fm[min(len(fm) - 1, int(0.99 * len(fm)))], 1000.0 / mean if mean > 0 else 0.0, cfg.vr.target_fps,
                           mean <= 1000.0 / cfg.vr.target_fps, summ, sess.pipeline.sent_total, len(sess.latency.completed), sess.combat.stats.hits,
                           summ["total"]["mean"], summ["total"]["p95"], notes)
