"""Hardware-independent haptic vocabulary: actuators, waveforms, commands, events, patterns.

Nothing here knows about any glove vendor. A 'glove' is just a device exposing up to eight named actuators.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Actuator(str, Enum):
    THUMB = "thumb"
    INDEX = "index"
    MIDDLE = "middle"
    RING = "ring"
    LITTLE = "little"
    PALM = "palm"
    WRIST = "wrist"
    FOREARM = "forearm"          # optional on real hardware


ACTUATORS: tuple[Actuator, ...] = tuple(Actuator)
CORE_ACTUATORS: tuple[Actuator, ...] = ACTUATORS[:7]
FINGERS: tuple[Actuator, ...] = (Actuator.THUMB, Actuator.INDEX, Actuator.MIDDLE, Actuator.RING, Actuator.LITTLE)
ACT_INDEX = {a: i for i, a in enumerate(ACTUATORS)}


class Waveform(str, Enum):
    SINE = "sine"
    SQUARE = "square"
    TRIANGLE = "triangle"
    IMPACT = "impact"            # instant attack, exponential decay
    BUZZ = "buzz"                # sine with fast amplitude modulation (metallic ring)
    PULSE_TRAIN = "pulse_train"  # gated bursts
    RAMP = "ramp"                # linear fall
    SUSTAIN = "sustain"          # steady pressure-like drive


WAVEFORMS: tuple[Waveform, ...] = tuple(Waveform)


class HapticPriority(IntEnum):
    AMBIENT = 0
    INTERACTION = 1
    COMBAT = 2
    MAJOR_IMPACT = 3
    CRITICAL_DAMAGE = 4


Hand = Literal["left", "right"]
_ids = itertools.count(1)


class HapticCommand(BaseModel):
    """One actuator command. Validated on construction; still passes through the safety limiter before any device."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    hand: Hand = "right"
    actuator: Actuator
    intensity: float = Field(ge=0.0, le=1.0)
    duration_ms: int = Field(ge=1, le=5000)
    frequency: float = Field(default=120.0, ge=20.0, le=500.0)
    waveform: Waveform = Waveform.SINE
    attack_ms: int = Field(default=2, ge=0, le=1000)
    release_ms: int = Field(default=20, ge=0, le=2000)
    priority: HapticPriority = HapticPriority.COMBAT
    delay_ms: int = Field(default=0, ge=0, le=5000)
    tag: str = ""
    id: int = Field(default_factory=lambda: next(_ids))

    @field_validator("intensity", "frequency")
    @classmethod
    def _finite(cls, v: float) -> float:
        if v != v or v in (float("inf"), float("-inf")):
            raise ValueError("non-finite value")
        return v


@dataclass
class HapticEvent:
    """What gameplay wants the player to feel (before it becomes actuator commands)."""

    pattern: str
    hand: str                            # left | right | both
    intensity: float
    priority: HapticPriority | None = None      # None -> pattern default
    bias: dict[Actuator, float] = field(default_factory=dict)    # contact-location weighting of the pattern's actuators
    t_ms: float = 0.0
    source: str = ""
    trace_id: int = 0


@dataclass(frozen=True)
class PatternStep:
    actuators: dict[Actuator, float]     # actuator -> weight (relative intensity)
    offset_ms: int
    duration_ms: int
    frequency: float
    waveform: Waveform
    attack_ms: int = 2
    release_ms: int = 20
    intensity: float = 1.0               # step gain


@dataclass(frozen=True)
class HapticPattern:
    name: str
    steps: tuple[PatternStep, ...]
    priority: HapticPriority

    @property
    def duration_ms(self) -> int:
        return max(s.offset_ms + s.duration_ms for s in self.steps)

    def expand(self, hand: str, intensity: float, priority: HapticPriority | None = None, bias: dict[Actuator, float] | None = None) -> list[HapticCommand]:
        """Turn a pattern into per-actuator commands. Weights are multiplied by the contact `bias`; weights below 0.04 are
        dropped (no pointless near-zero commands)."""
        out: list[HapticCommand] = []
        pr = priority if priority is not None else self.priority
        for st in self.steps:
            for act, w in st.actuators.items():
                w2 = w * (bias.get(act, 1.0) if bias else 1.0)
                inten = max(0.0, min(1.0, intensity * st.intensity * w2))
                if inten < 0.04:
                    continue
                out.append(HapticCommand(hand=hand, actuator=act, intensity=inten, duration_ms=st.duration_ms, frequency=st.frequency,   # type: ignore[arg-type]
                                         waveform=st.waveform, attack_ms=st.attack_ms, release_ms=st.release_ms, priority=pr, delay_ms=st.offset_ms, tag=self.name))
        return out


@dataclass(frozen=True)
class HapticChannel:
    """(hand, actuator): the unit of arbitration, rate limiting and safety accounting."""

    hand: str
    actuator: Actuator

    def __str__(self) -> str:
        return f"{self.hand}.{self.actuator.value}"
