"""Per-user, per-glove calibration profile: per-actuator maximum, response curve and comfort limit.

Defaults are deliberately *conservative*: an uncalibrated glove is capped (haptics.toml `uncalibrated_max_intensity`) because
maximum actuator power must never be assumed safe or comfortable."""

from __future__ import annotations

import json
import time
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ..engine.config import HapticsCfg, user_dir
from .model import ACTUATORS, Actuator

PROFILE_VERSION = 1


class ResponseCurve(BaseModel):
    model_config = ConfigDict(extra="forbid")
    kind: str = Field("gamma", pattern="^(gamma|points)$")
    gamma: float = Field(1.0, gt=0.2, le=4.0)
    points: list[tuple[float, float]] = Field(default_factory=lambda: [(0.0, 0.0), (1.0, 1.0)])

    @field_validator("points")
    @classmethod
    def _monotone(cls, pts: list[tuple[float, float]]) -> list[tuple[float, float]]:
        if len(pts) < 2:
            raise ValueError("need >= 2 points")
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        if xs != sorted(xs) or ys != sorted(ys):
            raise ValueError("curve points must be monotonic")
        if any(not (0.0 <= v <= 1.0) for v in xs + ys):
            raise ValueError("curve points must be within [0, 1]")
        return pts

    def apply(self, x: float) -> float:
        x = max(0.0, min(1.0, x))
        if self.kind == "gamma":
            return x ** self.gamma
        pts = self.points
        for (x0, y0), (x1, y1) in zip(pts, pts[1:], strict=False):
            if x0 <= x <= x1:
                return y0 if x1 == x0 else y0 + (y1 - y0) * (x - x0) / (x1 - x0)
        return pts[-1][1]


class CalibrationProfile(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)
    version: int = PROFILE_VERSION
    glove_id: str = "simulated"
    hand: str = Field("both", pattern="^(left|right|both)$")
    calibrated: bool = False
    created: float = Field(default_factory=time.time)
    detected_actuators: list[Actuator] = Field(default_factory=list)
    actuator_max: dict[Actuator, float] = Field(default_factory=dict)
    curve: ResponseCurve = ResponseCurve()
    comfort_limit: float = Field(0.6, gt=0.0, le=1.0)
    master_scale: float = Field(1.0, ge=0.0, le=1.0)
    notes: str = ""

    @field_validator("actuator_max")
    @classmethod
    def _range(cls, v: dict[Actuator, float]) -> dict[Actuator, float]:
        for k, x in v.items():
            if not (0.0 <= x <= 1.0):
                raise ValueError(f"actuator_max[{k.value}] out of range")
        return v

    @staticmethod
    def uncalibrated(cfg: HapticsCfg, glove_id: str = "simulated") -> CalibrationProfile:
        cap = min(cfg.uncalibrated_max_intensity, cfg.safety.hard_max_intensity)
        return CalibrationProfile(glove_id=glove_id, calibrated=False, actuator_max={a: cap for a in ACTUATORS}, comfort_limit=cap,
                                  notes="uncalibrated defaults (conservative)")

    def limit_for(self, a: Actuator, hard_max: float) -> float:
        return max(0.0, min(self.actuator_max.get(a, self.comfort_limit), self.comfort_limit, hard_max))

    def shape(self, a: Actuator, intensity: float, hard_max: float) -> float:
        """curve -> master scale -> clamp to the actuator's calibrated ceiling."""
        return min(self.curve.apply(intensity) * self.master_scale, self.limit_for(a, hard_max))

    def save(self, path: Path | None = None) -> Path:
        p = path or (user_dir() / f"haptic_profile_{self.glove_id}.json")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(json.loads(self.model_dump_json()), indent=2, sort_keys=True))
        return p

    @staticmethod
    def load(path: Path) -> CalibrationProfile:
        return CalibrationProfile.model_validate(json.loads(path.read_text()))

    @staticmethod
    def load_or_default(cfg: HapticsCfg, glove_id: str = "simulated", path: Path | None = None) -> CalibrationProfile:
        p = path or (Path(cfg.profile_dir) if cfg.profile_dir else user_dir()) / f"haptic_profile_{glove_id}.json"
        if p.exists():
            try:
                return CalibrationProfile.load(p)
            except Exception:
                p.rename(p.with_suffix(".corrupt"))
        return CalibrationProfile.uncalibrated(cfg, glove_id)


CURVE_PRESETS = {"linear": ResponseCurve(kind="gamma", gamma=1.0), "soft": ResponseCurve(kind="gamma", gamma=1.6), "firm": ResponseCurve(kind="gamma", gamma=0.7)}
