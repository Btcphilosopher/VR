"""IMPACT-HAPTIC v1: a small, documented, *our own* framing for generic haptic gloves.

This is NOT a commercial protocol. Vendor devices need their own adapter that maps `SafeHapticCommand` onto the vendor's documented
API; this wire format exists so a generic/DIY glove (serial, BLE characteristic, HID report, UDP, WebSocket) can be driven and
*tested* end to end.

    frame := SOF(0xA5) VER(0x01) TYPE(1) LEN(1) PAYLOAD(LEN<=32) CRC16-CCITT(2, big endian over VER..PAYLOAD)

host -> device : 0x01 HAPTIC | 0x02 STOP | 0x03 PING | 0x04 GET_INFO
device -> host : 0x81 ACK | 0x82 STATUS | 0x83 INFO | 0x84 PONG | 0x8F ERROR

Device packets are UNTRUSTED: the parser bounds buffer size and length, verifies version/CRC/type, resynchronises after garbage,
and the decoder range-checks every field. The encoder accepts only `SafeHapticCommand`.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import IntEnum

from .model import ACT_INDEX, ACTUATORS, Actuator, Waveform
from .safety import SafeHapticCommand

SOF = 0xA5
VERSION = 1
MAX_PAYLOAD = 32
MAX_BUFFER = 512
HEADER = 4


class MsgType(IntEnum):
    HAPTIC = 0x01
    STOP = 0x02
    PING = 0x03
    GET_INFO = 0x04
    ACK = 0x81
    STATUS = 0x82
    INFO = 0x83
    PONG = 0x84
    ERROR = 0x8F


HOST_TYPES = {MsgType.HAPTIC, MsgType.STOP, MsgType.PING, MsgType.GET_INFO}
DEVICE_TYPES = {MsgType.ACK, MsgType.STATUS, MsgType.INFO, MsgType.PONG, MsgType.ERROR}
_WAVES = list(Waveform)
_HANDS = {"left": 0, "right": 1}


class ProtocolError(ValueError):
    pass


def crc16_ccitt(data: bytes, init: int = 0xFFFF) -> int:
    crc = init
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def frame(msg: MsgType, payload: bytes = b"") -> bytes:
    if len(payload) > MAX_PAYLOAD:
        raise ProtocolError("payload too long")
    body = bytes([VERSION, int(msg), len(payload)]) + payload
    return bytes([SOF]) + body + struct.pack(">H", crc16_ccitt(body))


def encode_haptic(cmd: SafeHapticCommand) -> bytes:
    """Only limiter-approved commands can be put on the wire. Payload (12 bytes): seq hand actuator intensity(u8) duration(u16)
    frequency(u16) waveform attack(u8) release/2(u8) priority."""
    if not isinstance(cmd, SafeHapticCommand):
        raise TypeError("encode_haptic accepts SafeHapticCommand only")
    payload = struct.pack(">BBBBHHBBBB", cmd.seq & 0xFF, _HANDS[cmd.hand], ACT_INDEX[cmd.actuator], int(round(cmd.intensity * 255)),
                          min(cmd.duration_ms, 65535), int(round(cmd.frequency)), _WAVES.index(cmd.waveform), min(cmd.attack_ms, 255),
                          min(cmd.release_ms // 2, 255), int(cmd.priority))
    return frame(MsgType.HAPTIC, payload)


def encode_stop(hand: str | None = None) -> bytes:
    return frame(MsgType.STOP, bytes([0xFF if hand is None else _HANDS[hand]]))


def encode_ping(token: int) -> bytes:
    return frame(MsgType.PING, struct.pack(">I", token & 0xFFFFFFFF))


def encode_get_info() -> bytes:
    return frame(MsgType.GET_INFO)


@dataclass
class Frame:
    type: MsgType
    payload: bytes


@dataclass
class ParserStats:
    frames: int = 0
    bad_crc: int = 0
    bad_version: int = 0
    bad_length: int = 0
    unknown_type: int = 0
    resyncs: int = 0
    overflow: int = 0

    @property
    def errors(self) -> int:
        return self.bad_crc + self.bad_version + self.bad_length + self.unknown_type + self.overflow


class FrameParser:
    """Stream parser with bounded memory. Never raises on garbage; counts and resynchronises."""

    def __init__(self, accept: set[MsgType]) -> None:
        self.accept = accept
        self.buf = bytearray()
        self.stats = ParserStats()

    def feed(self, data: bytes) -> list[Frame]:
        self.buf += data
        if len(self.buf) > MAX_BUFFER:
            self.stats.overflow += 1
            del self.buf[: len(self.buf) - MAX_BUFFER]
        out: list[Frame] = []
        while True:
            i = self.buf.find(bytes([SOF]))
            if i < 0:
                self.buf.clear()
                break
            if i > 0:
                del self.buf[:i]
                self.stats.resyncs += 1
            if len(self.buf) < HEADER:
                break
            ver, typ, ln = self.buf[1], self.buf[2], self.buf[3]
            if ver != VERSION:
                self.stats.bad_version += 1
                del self.buf[0]
                continue
            if ln > MAX_PAYLOAD:
                self.stats.bad_length += 1
                del self.buf[0]
                continue
            total = HEADER + ln + 2
            if len(self.buf) < total:
                break
            body = bytes(self.buf[1 : HEADER + ln])
            (crc,) = struct.unpack(">H", bytes(self.buf[HEADER + ln : total]))
            if crc != crc16_ccitt(body):
                self.stats.bad_crc += 1
                del self.buf[0]
                continue
            try:
                mt = MsgType(typ)
            except ValueError:
                self.stats.unknown_type += 1
                del self.buf[:total]
                continue
            if mt not in self.accept:
                self.stats.unknown_type += 1
                del self.buf[:total]
                continue
            out.append(Frame(mt, bytes(self.buf[HEADER : HEADER + ln])))
            self.stats.frames += 1
            del self.buf[:total]
        return out


@dataclass
class DeviceStatus:
    battery_pct: int
    temperature_c: float
    flags: int
    error_count: int
    active_mask: int = 0


@dataclass
class DeviceInfo:
    actuators: list[Actuator]
    max_rate_hz: int
    fw: tuple[int, int]


@dataclass
class DeviceAck:
    seq: int
    dropped: bool = False


@dataclass
class DevicePong:
    token: int


@dataclass
class DeviceError:
    code: int


KNOWN_FLAGS = 0b0000_1111          # bit0 charging, bit1 overheat warning, bit2 fault, bit3 low battery


def decode_device(f: Frame):
    """Range-check and decode a device frame; raises ProtocolError on anything out of spec."""
    p = f.payload
    try:
        if f.type is MsgType.STATUS:
            if len(p) != 7:
                raise ProtocolError("status length")
            batt, temp_dc, flags = p[0], struct.unpack(">h", p[1:3])[0], p[3]
            errs, mask = struct.unpack(">H", p[4:6])[0], p[6]
            if batt > 100:
                raise ProtocolError("battery out of range")
            if not (-200 <= temp_dc <= 1200):
                raise ProtocolError("temperature out of range")
            if flags & ~KNOWN_FLAGS:
                raise ProtocolError("unknown status flags")
            return DeviceStatus(batt, temp_dc / 10.0, flags, errs, mask)
        if f.type is MsgType.INFO:
            if len(p) != 6:
                raise ProtocolError("info length")
            mask, rate, fw_maj, fw_min = struct.unpack(">HHBB", p)
            if mask == 0 or mask >> len(ACTUATORS):
                raise ProtocolError("actuator mask invalid")
            if not (1 <= rate <= 2000):
                raise ProtocolError("max rate invalid")
            return DeviceInfo([a for i, a in enumerate(ACTUATORS) if mask >> i & 1], rate, (fw_maj, fw_min))
        if f.type is MsgType.ACK:
            if len(p) not in (1, 2):
                raise ProtocolError("ack length")
            return DeviceAck(p[0], bool(p[1]) if len(p) == 2 else False)
        if f.type is MsgType.PONG:
            if len(p) != 4:
                raise ProtocolError("pong length")
            return DevicePong(struct.unpack(">I", p)[0])
        if f.type is MsgType.ERROR:
            if len(p) != 1:
                raise ProtocolError("error length")
            return DeviceError(p[0])
    except struct.error as e:
        raise ProtocolError(str(e)) from e
    raise ProtocolError(f"unexpected device message {f.type!r}")


def encode_status(batt: int, temp_c: float, flags: int, errs: int, mask: int) -> bytes:
    return frame(MsgType.STATUS, bytes([batt]) + struct.pack(">h", int(round(temp_c * 10))) + bytes([flags]) + struct.pack(">H", errs) + bytes([mask & 0xFF]))


def encode_info(actuators: list[Actuator], max_rate: int = 500, fw: tuple[int, int] = (1, 0)) -> bytes:
    return frame(MsgType.INFO, struct.pack(">HHBB", sum(1 << ACT_INDEX[a] for a in actuators), max_rate, *fw))


def encode_ack(seq: int, dropped: bool = False) -> bytes:
    return frame(MsgType.ACK, bytes([seq & 0xFF, 1 if dropped else 0]))


def encode_pong(token: int) -> bytes:
    return frame(MsgType.PONG, struct.pack(">I", token & 0xFFFFFFFF))


@dataclass
class HostHaptic:
    seq: int
    hand: str
    actuator: Actuator
    intensity: float
    duration_ms: int
    frequency: int
    waveform: Waveform
    attack_ms: int
    release_ms: int
    priority: int


def decode_host_haptic(payload: bytes) -> HostHaptic:
    """Firmware-side decode (used by the virtual firmware and tests)."""
    if len(payload) != 12:
        raise ProtocolError("haptic payload length")
    seq, hand, act, inten, dur, freq, wf, att, rel2, prio = struct.unpack(">BBBBHHBBBB", payload)
    if hand > 1 or act >= len(ACTUATORS) or wf >= len(_WAVES) or dur == 0:
        raise ProtocolError("haptic field out of range")
    return HostHaptic(seq, "left" if hand == 0 else "right", ACTUATORS[act], inten / 255.0, dur, freq, _WAVES[wf], att, rel2 * 2, prio)
