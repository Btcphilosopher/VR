"""The haptic pattern library. Patterns are spatio-temporal: *which* actuators fire, *when*, at what frequency and waveform - they
are never 'vibrate everything at once'."""

from __future__ import annotations

import math

from .model import FINGERS, Actuator as A, HapticPattern, HapticPriority as P, PatternStep as S, Waveform as W

PATTERNS: dict[str, HapticPattern] = {}


def _add(p: HapticPattern) -> None:
    PATTERNS[p.name] = p


# short, low-intensity pulse on the contact fingers
_add(HapticPattern("LIGHT_CONTACT", (S({A.INDEX: 0.7, A.MIDDLE: 0.6, A.PALM: 0.4}, 0, 25, 85, W.SINE, 4, 12, 0.55),), P.INTERACTION))
# rapid strong pulse across knuckles+palm, followed by a decaying wrist/palm tail
_add(HapticPattern("HEAVY_IMPACT", (
    S({A.INDEX: 1.0, A.MIDDLE: 1.0, A.RING: 0.8, A.LITTLE: 0.6, A.THUMB: 0.5, A.PALM: 1.0, A.WRIST: 0.8}, 0, 32, 150, W.IMPACT, 0, 14),
    S({A.PALM: 0.8, A.WRIST: 0.9, A.FOREARM: 0.7}, 28, 220, 70, W.RAMP, 8, 80, 0.7),
), P.MAJOR_IMPACT))
# forearm/wrist thud with a palm snap: the *arm* takes it
_add(HapticPattern("BLOCK", (
    S({A.FOREARM: 1.0, A.WRIST: 1.0, A.PALM: 0.55}, 0, 70, 80, W.IMPACT, 0, 30),
    S({A.FOREARM: 0.5, A.WRIST: 0.6}, 60, 90, 55, W.RAMP, 6, 40, 0.5),
), P.COMBAT))
# brief high-frequency pulse sweeping thumb -> little across the palm: crisp, "clean"
_add(HapticPattern("PARRY", (
    S({A.PALM: 1.0}, 0, 18, 280, W.SQUARE, 0, 4), S({A.THUMB: 0.9}, 3, 14, 280, W.SQUARE, 0, 4), S({A.INDEX: 0.9}, 6, 14, 280, W.SQUARE, 0, 4),
    S({A.MIDDLE: 0.9}, 9, 14, 280, W.SQUARE, 0, 4), S({A.RING: 0.8}, 12, 14, 280, W.SQUARE, 0, 4), S({A.LITTLE: 0.8}, 15, 14, 280, W.SQUARE, 0, 4),
), P.COMBAT))
# sustained pressure on thumb + fingers (ramps on, holds, ramps off) - grip feeling
_add(HapticPattern("GRAB", (
    S({A.THUMB: 0.8, A.INDEX: 0.75, A.MIDDLE: 0.85, A.RING: 0.7, A.LITTLE: 0.55}, 0, 380, 45, W.SUSTAIN, 90, 120, 0.8),
    S({A.PALM: 0.5}, 40, 260, 40, W.SUSTAIN, 80, 100, 0.5),
), P.INTERACTION))
# fingertip tick, then a palm settle
_add(HapticPattern("OBJECT_PICKUP", (S({A.THUMB: 0.7, A.INDEX: 0.7}, 0, 22, 170, W.SINE, 2, 8, 0.7), S({A.PALM: 0.7, A.WRIST: 0.35}, 45, 80, 60, W.SINE, 20, 40, 0.6)), P.INTERACTION))
# dull, broad palm + wrist thump with no fingertip emphasis
_add(HapticPattern("WALL_CONTACT", (S({A.PALM: 1.0, A.WRIST: 0.9, A.FOREARM: 0.5}, 0, 120, 58, W.IMPACT, 3, 60), S({A.WRIST: 0.5}, 100, 80, 48, W.RAMP, 10, 40, 0.4)), P.COMBAT))
# sharp metallic ring: high-frequency buzz on fingers+palm, two decaying "rings"
_add(HapticPattern("METAL_IMPACT", (
    S({A.INDEX: 1.0, A.MIDDLE: 0.9, A.RING: 0.7, A.LITTLE: 0.5, A.THUMB: 0.5, A.PALM: 0.7}, 0, 130, 230, W.BUZZ, 0, 40),
    S({A.INDEX: 0.5, A.MIDDLE: 0.5, A.PALM: 0.4}, 70, 110, 330, W.BUZZ, 0, 50, 0.6),
), P.MAJOR_IMPACT))
# two mid-frequency knocks, palm-led
_add(HapticPattern("WOOD_IMPACT", (S({A.INDEX: 0.85, A.MIDDLE: 0.85, A.PALM: 1.0}, 0, 16, 115, W.IMPACT, 0, 8), S({A.PALM: 0.7, A.WRIST: 0.5}, 38, 18, 105, W.IMPACT, 0, 8, 0.7)), P.COMBAT))
# soft, slower-rising thud with a muffled tail on knuckles + wrist
_add(HapticPattern("FLESH_IMPACT", (S({A.INDEX: 0.9, A.MIDDLE: 0.9, A.PALM: 0.8}, 0, 55, 62, W.SINE, 7, 30), S({A.WRIST: 0.6, A.PALM: 0.4}, 20, 120, 48, W.RAMP, 12, 60, 0.5)), P.COMBAT))
# crackling: fast alternating bursts hopping across fingertips
_add(HapticPattern("ELECTRIC_EFFECT", (
    S({A.INDEX: 0.8}, 0, 28, 210, W.PULSE_TRAIN, 0, 4), S({A.RING: 0.7}, 22, 28, 240, W.PULSE_TRAIN, 0, 4), S({A.THUMB: 0.8}, 44, 28, 200, W.PULSE_TRAIN, 0, 4),
    S({A.MIDDLE: 0.7}, 66, 28, 250, W.PULSE_TRAIN, 0, 4), S({A.LITTLE: 0.8}, 88, 28, 220, W.PULSE_TRAIN, 0, 4), S({A.PALM: 0.5}, 20, 90, 180, W.PULSE_TRAIN, 0, 20, 0.6),
), P.INTERACTION))
# three slow low-frequency wrist/forearm pulses
_add(HapticPattern("WARNING", tuple(S({A.WRIST: 0.9, A.FOREARM: 0.7}, off, 60, 130, W.SINE, 8, 20) for off in (0, 170, 340)), P.AMBIENT))
# heavy thud then a lingering wrist/forearm throb: you were hit
_add(HapticPattern("DAMAGE", (S({A.WRIST: 1.0, A.FOREARM: 1.0, A.PALM: 0.6}, 0, 60, 70, W.IMPACT, 0, 25), S({A.WRIST: 0.8, A.FOREARM: 0.9}, 70, 260, 52, W.RAMP, 10, 100, 0.7)), P.CRITICAL_DAMAGE))
# rising double pulse on the fingertips (reward)
_add(HapticPattern("SUCCESS", (
    S({A.INDEX: 0.7, A.MIDDLE: 0.7, A.THUMB: 0.6}, 0, 45, 120, W.SINE, 6, 20, 0.6),
    S({A.INDEX: 0.9, A.MIDDLE: 0.9, A.RING: 0.8, A.LITTLE: 0.8, A.THUMB: 0.8}, 90, 70, 190, W.SINE, 8, 30, 0.9),
), P.INTERACTION))


def get_pattern(name: str) -> HapticPattern:
    return PATTERNS[name]


def pattern_names() -> list[str]:
    return sorted(PATTERNS)


def signature(p: HapticPattern) -> dict[str, float]:
    """Perceptual-ish descriptor used to prove patterns are physically distinguishable."""
    steps = p.steps
    acts = {a for s in steps for a in s.actuators}
    wsum = sum(w * s.intensity * s.duration_ms for s in steps for w in s.actuators.values()) or 1.0
    mean_f = sum(s.frequency * w * s.intensity * s.duration_ms for s in steps for w in s.actuators.values()) / wsum
    finger = sum(w * s.intensity * s.duration_ms for s in steps for a, w in s.actuators.items() if a in FINGERS) / wsum
    arm = sum(w * s.intensity * s.duration_ms for s in steps for a, w in s.actuators.items() if a in (A.WRIST, A.FOREARM)) / wsum
    return {"duration_ms": float(p.duration_ms), "mean_freq": mean_f, "n_actuators": float(len(acts)), "finger_share": finger, "arm_share": arm,
            "n_steps": float(len(steps)), "peak": max(w * s.intensity for s in steps for w in s.actuators.values()), "waveforms": float(len({s.waveform for s in steps}))}


def signature_distance(a: HapticPattern, b: HapticPattern) -> float:
    sa, sb = signature(a), signature(b)
    d = abs(math.log(sa["duration_ms"] / sb["duration_ms"])) * 0.8 + abs(math.log(sa["mean_freq"] / sb["mean_freq"])) * 1.2
    d += abs(sa["finger_share"] - sb["finger_share"]) * 1.5 + abs(sa["arm_share"] - sb["arm_share"]) * 1.5
    d += abs(sa["n_actuators"] - sb["n_actuators"]) * 0.08 + abs(sa["n_steps"] - sb["n_steps"]) * 0.05
    wa, wb = {s.waveform for s in a.steps}, {s.waveform for s in b.steps}
    return d + 0.35 * (1 - len(wa & wb) / len(wa | wb))
