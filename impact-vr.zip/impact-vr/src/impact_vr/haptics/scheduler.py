"""Haptic scheduler: expands events into commands and arbitrates them per (hand, actuator) channel.

  * priority          - a damage cue is never lost under a flurry of combat ticks
  * combining         - overlapping same-priority cues merge into one stronger command (no stacked drive)
  * ducking/preempt   - a higher-priority command replaces a lower one; lower ones arriving later are dropped
  * cooldowns         - per priority class minimum spacing
  * repetition decay  - the same cue repeated rapidly is attenuated, then suppressed (anti-numbing, anti-spam)
  * rate limiting     - minimum interval between commands to one actuator
  * bounded queue     - hard capacity; the lowest-priority/oldest items are dropped first
The scheduler is gameplay-agnostic and is NOT a safety mechanism - the independent safety limiter follows it.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field

from ..engine.config import SchedulerCfg
from .model import HapticChannel, HapticCommand, HapticEvent, HapticPriority
from .patterns import PATTERNS


@dataclass
class _Active:
    end_ms: float
    priority: int
    intensity: float
    frequency: float
    tag: str


@dataclass
class ScheduledCommand:
    due_ms: float
    cmd: HapticCommand
    submitted_ms: float
    trace_id: int = 0
    event_id: int = 0


@dataclass
class SchedulerStats:
    submitted: int = 0
    emitted: int = 0
    suppressed: Counter = field(default_factory=Counter)
    combined: int = 0
    queue_drops: int = 0


class HapticScheduler:
    def __init__(self, cfg: SchedulerCfg) -> None:
        self.cfg = cfg
        self._queue: list[ScheduledCommand] = []
        self._last_send: dict[HapticChannel, float] = {}
        self._active: dict[HapticChannel, _Active] = {}
        self._repeat: dict[tuple[HapticChannel, str], tuple[float, int, int]] = {}
        self._event_serial = 0
        self.stats = SchedulerStats()
        self._cool = {0: cfg.cooldown_ms_ambient, 1: cfg.cooldown_ms_interaction, 2: cfg.cooldown_ms_combat, 3: cfg.cooldown_ms_major, 4: cfg.cooldown_ms_critical}

    def submit(self, ev: HapticEvent, now_ms: float) -> list[HapticCommand]:
        pat = PATTERNS.get(ev.pattern)
        if pat is None:
            raise KeyError(f"unknown haptic pattern '{ev.pattern}'")
        hands = ("left", "right") if ev.hand == "both" else (ev.hand,)
        self._event_serial += 1
        out: list[HapticCommand] = []
        for h in hands:
            for c in pat.expand(h, max(0.0, min(1.0, ev.intensity)), ev.priority, ev.bias):
                self._enqueue(ScheduledCommand(now_ms + c.delay_ms, c, now_ms, ev.trace_id, self._event_serial))
                out.append(c)
        self.stats.submitted += len(out)
        return out

    def _enqueue(self, sc: ScheduledCommand) -> None:
        if len(self._queue) >= self.cfg.queue_capacity:
            victim = min(range(len(self._queue)), key=lambda i: (self._queue[i].cmd.priority, -self._queue[i].due_ms))
            self.stats.queue_drops += 1
            self.stats.suppressed["queue_full"] += 1
            if self._queue[victim].cmd.priority > sc.cmd.priority:
                return
            self._queue.pop(victim)
        self._queue.append(sc)

    def tick(self, now_ms: float) -> list[tuple[HapticCommand, ScheduledCommand]]:
        """Return the arbitrated commands that are due now (at most one per channel per tick)."""
        due = [s for s in self._queue if s.due_ms <= now_ms]
        self._expire(now_ms)
        if not due:
            return []
        self._queue = [s for s in self._queue if s.due_ms > now_ms]
        by_ch: dict[HapticChannel, list[ScheduledCommand]] = {}
        for s in sorted(due, key=lambda s: (s.due_ms, -int(s.cmd.priority), s.cmd.id)):
            by_ch.setdefault(HapticChannel(s.cmd.hand, s.cmd.actuator), []).append(s)
        out: list[tuple[HapticCommand, ScheduledCommand]] = []
        for ch, items in by_ch.items():
            res = self._arbitrate(ch, items, now_ms)
            if res is not None:
                out.append(res)
        return out

    def _expire(self, now_ms: float) -> None:
        for ch in [c for c, a in self._active.items() if a.end_ms <= now_ms]:
            del self._active[ch]

    def _arbitrate(self, ch: HapticChannel, items: list[ScheduledCommand], now_ms: float) -> tuple[HapticCommand, ScheduledCommand] | None:
        cfg, st = self.cfg, self.stats
        top = max(i.cmd.priority for i in items)
        group = [i for i in items if i.cmd.priority == top]
        st.suppressed["lower_priority_same_tick"] += sum(1 for i in items if i.cmd.priority < top)
        base = max(group, key=lambda i: i.cmd.intensity)
        inten, dur, freq = base.cmd.intensity, base.cmd.duration_ms, base.cmd.frequency
        if len(group) > 1:                                    # overlapping same-priority cues: merge, don't stack
            comb, fsum, wsum = 1.0, 0.0, 0.0
            for g in group:
                comb *= (1.0 - g.cmd.intensity)
                fsum += g.cmd.frequency * g.cmd.intensity
                wsum += g.cmd.intensity
                dur = max(dur, g.cmd.duration_ms)
            inten = 1.0 - comb
            freq = fsum / wsum if wsum > 0 else freq
            st.combined += len(group) - 1
        prio = int(top)
        last = self._last_send.get(ch)
        if last is not None and prio < HapticPriority.CRITICAL_DAMAGE and now_ms - last < self._cool.get(prio, 0):
            st.suppressed["cooldown"] += 1
            return None
        gap = cfg.min_command_interval_ms if prio < HapticPriority.CRITICAL_DAMAGE else min(cfg.min_command_interval_ms, 3)
        if last is not None and now_ms - last < gap:
            st.suppressed["rate_limit"] += 1
            return None
        act = self._active.get(ch)
        if act is not None and act.end_ms > now_ms:
            remaining = act.end_ms - now_ms
            if act.priority > prio and remaining > 12:
                st.suppressed["higher_priority_active"] += 1
                return None
            if act.priority == prio and remaining > 5:
                inten = 1.0 - (1.0 - inten) * (1.0 - act.intensity * 0.6)
                dur = max(dur, int(remaining))
                st.combined += 1
        key = (ch, base.cmd.tag)
        rep = self._repeat.get(key)
        eid = base.event_id
        if rep is not None and now_ms - rep[0] < cfg.repeat_window_ms:
            n = rep[1] + (1 if rep[2] != eid else 0)          # steps of one pattern are not 'repeats'; separate events are
            factor = max(cfg.repeat_floor, cfg.repeat_decay ** n) if (rep[2] != eid or n > 0) else 1.0
            if factor <= cfg.repeat_floor + 1e-9 and prio <= HapticPriority.COMBAT and n > 6:
                st.suppressed["repetition"] += 1
                self._repeat[key] = (now_ms, n, eid)
                return None
            inten *= factor
        else:
            n = 0
        self._repeat[key] = (now_ms, n, eid)
        inten = max(0.0, min(1.0, inten))
        if inten < 0.03:
            st.suppressed["negligible"] += 1
            return None
        cmd = base.cmd.model_copy(update={"intensity": inten, "duration_ms": min(5000, int(dur)), "frequency": freq, "priority": HapticPriority(prio), "delay_ms": 0})
        self._last_send[ch] = now_ms
        self._active[ch] = _Active(now_ms + cmd.duration_ms, prio, inten, freq, cmd.tag)
        st.emitted += 1
        return cmd, base

    @property
    def queue_depth(self) -> int:
        return len(self._queue)

    def reset(self) -> None:
        self._queue.clear()
        self._active.clear()
        self._last_send.clear()
        self._repeat.clear()
