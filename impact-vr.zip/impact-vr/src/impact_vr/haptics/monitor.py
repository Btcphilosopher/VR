"""Virtual glove monitor: LEFT HAND / RIGHT HAND actuator intensity in real time (text for CLI, pygame for the app)."""

from __future__ import annotations

from .gloves.base import GloveStatus
from .model import ACTUATORS, Actuator

_BLOCKS = " ▁▂▃▄▅▆▇█"


def bar(v: float, width: int = 10) -> str:
    v = max(0.0, min(1.0, v))
    full = int(v * width)
    frac = v * width - full
    return "█" * full + (_BLOCKS[int(frac * 8)] if full < width else "") + " " * (width - full - (1 if full < width else 0))


def render_text(levels: dict[str, dict[Actuator, float]], statuses: dict[str, GloveStatus] | None = None) -> str:
    lines = []
    for hand in ("left", "right"):
        lv = levels.get(hand, {})
        lines.append(f"{hand.upper()} HAND")
        for a in ACTUATORS:
            if a in lv:
                lines.append(f"  {a.value:<8}|{bar(lv[a])}| {lv[a]:.2f}")
        st = (statuses or {}).get(hand)
        if st is not None:
            lines.append(f"  [{st.connection.value}] lat {st.mean_latency_ms:.1f} ms  temp {st.temperature_c or 0:.1f}C  batt {st.battery_pct or 0:.0f}%  drops {st.dropped_commands}  err {st.comm_errors}")
    return "\n".join(lines)


def draw_pygame(surface, rect, levels: dict[str, dict[Actuator, float]], font) -> None:
    import pygame

    x0, y0, w, h = rect
    col_w = w // 2
    for i, hand in enumerate(("left", "right")):
        cx = x0 + i * col_w
        surface.blit(font.render(f"{hand.upper()} HAND", True, (214, 214, 206)), (cx + 8, y0 + 4))
        lv = levels.get(hand, {})
        for j, a in enumerate(ACTUATORS):
            yy = y0 + 28 + j * 18
            surface.blit(font.render(a.value, True, (130, 132, 128)), (cx + 8, yy))
            pygame.draw.rect(surface, (30, 32, 34), (cx + 80, yy + 2, col_w - 100, 10))
            v = lv.get(a, 0.0)
            if a in lv:
                pygame.draw.rect(surface, (224, 160, 48) if v < 0.75 else (192, 57, 43), (cx + 80, yy + 2, int((col_w - 100) * min(1.0, v)), 10))
