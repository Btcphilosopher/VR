"""Haptic calibration workflow.

    1 CONNECT -> 2 DETECT actuators -> 3 TEST each actuator -> 4 SET maximum intensity -> 5 SET response curve
    -> 6 SET comfort limit -> 7 TEST simultaneous output -> 8 SAVE profile

Every output during calibration goes through the pipeline *and the safety limiter*; levels ramp up from a conservative start, in
small steps, and stop at the first 'too strong'. The user is always the authority on what is comfortable - the workflow never jumps
to full power, and the saved ceiling can never exceed the hard safety cap.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Protocol

from ..engine.config import HapticsCfg
from .gloves.base import ConnectionState
from .model import ACTUATORS, Actuator
from .pipeline import HapticPipeline
from .profile import CURVE_PRESETS, CalibrationProfile

RAMP_START = 0.10
RAMP_STEP = 0.05
SAFE_STEP_MS = 140


class Step(str, Enum):
    CONNECT = "connect"
    DETECT = "detect"
    TEST_EACH = "test_each"
    SET_MAX = "set_max"
    SET_CURVE = "set_curve"
    SET_COMFORT = "set_comfort"
    TEST_SIMULTANEOUS = "test_simultaneous"
    SAVE = "save"
    DONE = "done"


class Responder(Protocol):
    def felt(self, hand: str, actuator: Actuator) -> bool: ...
    def too_strong(self, hand: str, actuator: Actuator, level: float) -> bool: ...
    def choose_curve(self, presets: list[str]) -> str: ...
    def comfort_limit(self, current: float) -> float: ...
    def simultaneous_ok(self) -> bool: ...


@dataclass
class ScriptedResponder:
    """Deterministic 'user' for tests / CI: becomes uncomfortable at `max_levels[actuator]` (default 0.45)."""

    max_levels: dict[Actuator, float] = field(default_factory=dict)
    default_max: float = 0.45
    missing: set[Actuator] = field(default_factory=set)
    curve: str = "soft"
    comfort: float = 0.5
    simultaneous: bool = True

    def felt(self, hand: str, actuator: Actuator) -> bool:
        return actuator not in self.missing

    def too_strong(self, hand: str, actuator: Actuator, level: float) -> bool:
        return level >= self.max_levels.get(actuator, self.default_max)

    def choose_curve(self, presets: list[str]) -> str:
        return self.curve

    def comfort_limit(self, current: float) -> float:
        return self.comfort

    def simultaneous_ok(self) -> bool:
        return self.simultaneous


class ConsoleResponder:  # pragma: no cover - interactive
    def __init__(self, input_fn: Callable[[str], str] = input, print_fn: Callable[[str], None] = print) -> None:
        self.i, self.p = input_fn, print_fn

    def felt(self, hand: str, actuator: Actuator) -> bool:
        return self.i(f"  [{hand} {actuator.value}] Did you feel that pulse? [Y/n] ").strip().lower() != "n"

    def too_strong(self, hand: str, actuator: Actuator, level: float) -> bool:
        return self.i(f"  [{hand} {actuator.value}] level {level:.2f} - too strong / uncomfortable? [y/N] ").strip().lower() == "y"

    def choose_curve(self, presets: list[str]) -> str:
        c = self.i(f"  Response curve {presets} (soft = gentler low end, firm = stronger low end) [linear]: ").strip().lower()
        return c if c in presets else "linear"

    def comfort_limit(self, current: float) -> float:
        raw = self.i(f"  Overall comfort limit 0.1-1.0 [{current:.2f}]: ").strip()
        try:
            return max(0.1, min(1.0, float(raw)))
        except ValueError:
            return current

    def simultaneous_ok(self) -> bool:
        return self.i("  All actuators pulsed together at your comfort level. Comfortable? [Y/n] ").strip().lower() != "n"


@dataclass
class CalibrationResult:
    profile: CalibrationProfile
    completed: bool
    log: list[str]
    saved_path: str | None = None


class CalibrationSession:
    def __init__(self, pipeline: HapticPipeline, cfg: HapticsCfg, responder: Responder, clock_ms: Callable[[], float], advance: Callable[[float], None],
                 log: Callable[[str], None] | None = None, hands: tuple[str, ...] = ("left", "right"), save_path=None) -> None:
        self.pipe, self.cfg, self.resp = pipeline, cfg, responder
        self.now, self.advance = clock_ms, advance
        self.hands = hands
        self.step = Step.CONNECT
        self.lines: list[str] = []
        self._log = log or (lambda s: None)
        self.profile = CalibrationProfile.uncalibrated(cfg, glove_id="+".join(sorted(pipeline.gloves)))
        self.save_path = save_path
        self.hard = cfg.safety.hard_max_intensity

    def log(self, s: str) -> None:
        self.lines.append(s)
        self._log(s)

    def _pulse(self, hand: str, act: Actuator, level: float, ms: int = SAFE_STEP_MS) -> bool:
        safe = self.pipe.send_test(hand, act, level, ms, self.now(), apply_profile=False)
        self.advance(ms + 120)
        self.pipe.update(self.now())
        return safe is not None

    def run(self) -> CalibrationResult:
        self.step = Step.CONNECT
        for h in self.hands:
            g = self.pipe.gloves[h]
            if g.get_connection_state() is not ConnectionState.CONNECTED:
                ok = g.connect(self.now())
                self.advance(30)
                g.update(self.now())
                if not ok or g.get_connection_state() is not ConnectionState.CONNECTED:
                    self.log(f"FAILED to connect {h} glove - calibration aborted, nothing saved")
                    return CalibrationResult(self.profile, False, self.lines)
            self.log(f"connected {h} glove ({g.name})")
        self.step = Step.DETECT
        for h in self.hands:
            acts = self.pipe.gloves[h].detect_actuators()
            self.log(f"{h}: detected actuators {[a.value for a in ACTUATORS if a in acts]}")
        common = [a for a in ACTUATORS if all(a in self.pipe.gloves[h].detect_actuators() for h in self.hands)]
        self.profile.detected_actuators = common
        self.step = Step.TEST_EACH
        working: list[Actuator] = []
        for a in common:
            felt_all = True
            for h in self.hands:
                self._pulse(h, a, RAMP_START + 0.1)
                if not self.resp.felt(h, a):
                    felt_all = False
                    self.log(f"{h} {a.value}: NOT felt - actuator excluded")
            if felt_all:
                working.append(a)
        self.step = Step.SET_MAX
        for a in common:
            if a not in working:
                self.profile.actuator_max[a] = 0.0
                continue
            ceiling = level = RAMP_START
            while level <= self.hard + 1e-9:
                self._pulse(self.hands[0], a, level)
                if any(self.resp.too_strong(h, a, level) for h in self.hands):
                    break
                ceiling = level
                level = round(level + RAMP_STEP, 4)
            self.profile.actuator_max[a] = round(min(ceiling, self.hard), 3)       # one notch below the first uncomfortable level
            self.log(f"{a.value}: max intensity {self.profile.actuator_max[a]:.2f}")
        self.step = Step.SET_CURVE
        name = self.resp.choose_curve(list(CURVE_PRESETS))
        self.profile.curve = CURVE_PRESETS.get(name, CURVE_PRESETS["linear"])
        self.log(f"response curve: {name}")
        self.step = Step.SET_COMFORT
        self.profile.comfort_limit = max(0.05, min(self.resp.comfort_limit(self.profile.comfort_limit), self.hard))
        self.log(f"comfort limit: {self.profile.comfort_limit:.2f}")
        self.step = Step.TEST_SIMULTANEOUS
        self.pipe.set_profile(self.profile)
        lvl = 0.5 * self.profile.comfort_limit
        for h in self.hands:
            for a in working:
                self.pipe.send_test(h, a, lvl, 220, self.now(), apply_profile=True)
        self.advance(340)
        self.pipe.update(self.now())
        if not self.resp.simultaneous_ok():
            self.profile.comfort_limit = round(self.profile.comfort_limit * 0.7, 3)
            self.profile.notes = "comfort limit reduced after simultaneous test"
            self.log(f"simultaneous output uncomfortable - comfort limit reduced to {self.profile.comfort_limit:.2f}")
        self.step = Step.SAVE
        self.profile.calibrated = True
        self.pipe.set_profile(self.profile)
        path = self.profile.save(self.save_path)
        self.log(f"profile saved: {path}")
        self.step = Step.DONE
        return CalibrationResult(self.profile, True, self.lines, str(path))
