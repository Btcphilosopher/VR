"""SimulatedHapticGlove - a full virtual glove: actuator state, transport latency/jitter/drops, thermal + battery model, fault
injection. Works with no hardware and is the default glove everywhere (tests, sim mode, benchmark)."""

from __future__ import annotations

import random
from dataclasses import dataclass

from ...engine.config import HapticsCfg
from ..model import ACTUATORS, CORE_ACTUATORS, Actuator, HapticPriority
from ..safety import SafeHapticCommand
from ..waveforms import amplitude
from .base import ConnectionState, GloveStatus, HapticGlove


@dataclass
class _Slot:
    cmd: SafeHapticCommand
    start_ms: float
    end_ms: float


class SimulatedHapticGlove(HapticGlove):
    name = "simulated"
    AMBIENT_C = 28.0

    def __init__(self, hand: str, cfg: HapticsCfg | None = None, seed: int = 1, actuators: tuple[Actuator, ...] | None = None,
                 latency_ms: float | None = None, jitter_ms: float | None = None, drop_probability: float | None = None) -> None:
        super().__init__(hand)
        cfg = cfg or HapticsCfg()
        self.latency_ms = cfg.glove_latency_ms if latency_ms is None else latency_ms
        self.jitter_ms = cfg.glove_jitter_ms if jitter_ms is None else jitter_ms
        self.drop_p = cfg.glove_drop_probability if drop_probability is None else drop_probability
        self.rng = random.Random(seed * 7 + (1 if hand == "right" else 0))
        self._avail = tuple(actuators) if actuators is not None else ACTUATORS
        self._pending: list[tuple[float, SafeHapticCommand, float]] = []      # (apply_at_ms, cmd, sent_ms)
        self._slots: dict[Actuator, _Slot] = {}
        self.temperature = self.AMBIENT_C
        self.battery = 100.0
        self._last_update = 0.0
        self.heat_gain = 0.0006      # degC per (drive^2 * ms)
        self.cool_rate = 0.00008     # per ms toward ambient
        self.battery_drain = 0.00002
        self.energy = 0.0
        self.applied_log: list[tuple[float, int, float]] = []    # (apply_ms, cmd id, latency_ms)

    def connect(self, now_ms: float = 0.0) -> bool:
        self._set_state(ConnectionState.CONNECTING, now_ms)
        self._actuators = set(self._avail)
        self._set_state(ConnectionState.CONNECTED, now_ms)
        self._last_update = now_ms
        self.telemetry.battery, self.telemetry.temperature = self.battery, self.temperature
        return True

    def disconnect(self) -> None:
        self._set_state(ConnectionState.DISCONNECTED)
        self._slots.clear()
        self._pending.clear()

    def inject_disconnect(self, now_ms: float = 0.0) -> None:
        self._set_state(ConnectionState.DISCONNECTED, now_ms)
        self._slots.clear()

    def inject_temperature(self, celsius: float) -> None:
        self.temperature = celsius
        self.telemetry.temperature = celsius

    def inject_comm_errors(self, n: int) -> None:
        for _ in range(n):
            self.telemetry.on_error("injected comm error")

    def _transmit(self, cmd: SafeHapticCommand, now_ms: float) -> bool:
        if self.rng.random() < self.drop_p:
            self.telemetry.on_drop("transport drop")
            return False
        lat = max(0.0, self.latency_ms + self.rng.uniform(-self.jitter_ms, self.jitter_ms))
        self._pending.append((now_ms + lat, cmd, now_ms))
        return True

    def stop_all(self) -> None:
        self._slots.clear()
        self._pending.clear()

    def update(self, now_ms: float) -> None:
        if self._state is not ConnectionState.CONNECTED:
            return
        dt = max(0.0, now_ms - self._last_update)
        self._last_update = now_ms
        due = [p for p in self._pending if p[0] <= now_ms]
        if due:
            self._pending = [p for p in self._pending if p[0] > now_ms]
            for at, cmd, sent in sorted(due, key=lambda p: (p[0], p[1].id)):
                cur = self._slots.get(cmd.actuator)
                if cur is not None and cur.end_ms > at and cur.cmd.priority > cmd.priority:
                    self.telemetry.on_drop("device: lower priority while higher active")
                    continue
                self._slots[cmd.actuator] = _Slot(cmd, at, at + cmd.duration_ms)
                self.telemetry.on_latency(at - sent)
                self.applied_log.append((at, cmd.id, at - sent))
                self._notify_applied(cmd.id, at - sent)
        total_drive = 0.0
        for a, s in list(self._slots.items()):
            if s.end_ms <= now_ms:
                del self._slots[a]
            else:
                total_drive += self._drive(a, now_ms) ** 2
        self.temperature += self.heat_gain * total_drive * dt - self.cool_rate * (self.temperature - self.AMBIENT_C) * dt
        self.battery = max(0.0, self.battery - self.battery_drain * dt * (0.2 + total_drive))
        self.energy += total_drive * dt
        self.telemetry.battery, self.telemetry.temperature = self.battery, self.temperature

    def _drive(self, a: Actuator, now_ms: float) -> float:
        s = self._slots.get(a)
        if s is None:
            return 0.0
        c = s.cmd
        return c.intensity * amplitude(c.waveform, now_ms - s.start_ms, c.duration_ms, c.frequency, c.attack_ms, c.release_ms)

    def get_actuator_state(self, now_ms: float = 0.0) -> dict[Actuator, float]:
        return {a: self._drive(a, now_ms) for a in ACTUATORS if a in self._actuators}

    def get_status(self, now_ms: float = 0.0) -> GloveStatus:
        st = super().get_status(now_ms)
        st.battery_pct, st.temperature_c = self.battery, self.temperature
        return st

    @property
    def active_priority(self) -> dict[Actuator, HapticPriority]:
        return {a: s.cmd.priority for a, s in self._slots.items()}


def make_simulated_pair(cfg: HapticsCfg | None = None, seed: int = 1, forearm: bool = True, **kw) -> dict[str, SimulatedHapticGlove]:
    acts = ACTUATORS if forearm else CORE_ACTUATORS
    return {h: SimulatedHapticGlove(h, cfg, seed, acts, **kw) for h in ("left", "right")}
