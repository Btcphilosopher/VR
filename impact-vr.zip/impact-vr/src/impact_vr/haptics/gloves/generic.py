"""GenericHapticGlove: drives any device that speaks IMPACT-HAPTIC v1 over a `Transport`.

Serial / BLE / HID / UDP / WebSocket gloves are this class with a different transport (see the thin subclasses). Vendor SDK gloves
implement `HapticGlove` directly (see docs/HAPTIC_HARDWARE.md). Everything arriving from the device is untrusted: it is parsed by
the bounded `FrameParser`, range-checked by `decode_device`, and any violation increments the communication-error counter that the
safety limiter watches.
"""

from __future__ import annotations

from ..model import ACTUATORS, Actuator
from ..protocol import (
    DEVICE_TYPES, DeviceAck, DeviceError, DeviceInfo, DevicePong, DeviceStatus, FrameParser, ProtocolError, decode_device, encode_get_info, encode_haptic,
    encode_ping, encode_stop,
)
from ..safety import SafeHapticCommand
from ..transports import SerialTransport, Transport, TransportUnavailable
from .base import ConnectionState, GloveStatus, HapticGlove


class GenericHapticGlove(HapticGlove):
    name = "generic"

    def __init__(self, hand: str, transport: Transport, handshake_timeout_ms: float = 250.0, silence_timeout_ms: float = 3000.0,
                 ack_timeout_ms: float = 500.0, ping_interval_ms: float = 500.0) -> None:
        super().__init__(hand)
        self.transport = transport
        self.parser = FrameParser(DEVICE_TYPES)
        self.handshake_timeout = handshake_timeout_ms
        self.silence_timeout = silence_timeout_ms
        self.ack_timeout = ack_timeout_ms
        self.ping_interval = ping_interval_ms
        self._connect_t = self._last_rx = self._last_ping = 0.0
        self._ping_token = 0
        self._ping_sent: dict[int, float] = {}
        self._acks: dict[int, tuple[float, int]] = {}
        self._status: DeviceStatus | None = None
        self.info: DeviceInfo | None = None
        self._parser_errors_seen = 0
        self.rtt_ms: list[float] = []

    def connect(self, now_ms: float = 0.0) -> bool:
        self._set_state(ConnectionState.CONNECTING, now_ms)
        try:
            self.transport.open()
            self.transport.write(encode_get_info())
        except TransportUnavailable as e:
            self.telemetry.on_error(str(e))
            self._set_state(ConnectionState.ERROR, now_ms)
            return False
        self._connect_t = self._last_rx = self._last_ping = now_ms
        return True

    def disconnect(self) -> None:
        try:
            if self.transport.is_open:
                self.transport.write(encode_stop(None))
        except Exception:
            pass
        self.transport.close()
        self._set_state(ConnectionState.DISCONNECTED)

    def stop_all(self) -> None:
        if self.transport.is_open:
            self.transport.write(encode_stop(self.hand))

    def _transmit(self, cmd: SafeHapticCommand, now_ms: float) -> bool:
        try:
            self.transport.write(encode_haptic(cmd))
        except (TransportUnavailable, OSError) as e:
            self.telemetry.on_error(f"write failed: {e}")
            self.telemetry.on_drop("write failed")
            return False
        self._acks[cmd.seq & 0xFF] = (now_ms, cmd.id)
        return True

    def update(self, now_ms: float) -> None:
        if self._state in (ConnectionState.DISCONNECTED, ConnectionState.ERROR) and not self.transport.is_open:
            return
        data = self.transport.read(512)
        if data:
            for f in self.parser.feed(data):
                try:
                    msg = decode_device(f)
                except ProtocolError as e:
                    self.telemetry.on_error(f"bad {f.type.name}: {e}")
                    continue
                self._last_rx = now_ms
                self._handle(msg, now_ms)
        new_err = self.parser.stats.errors - self._parser_errors_seen
        if new_err > 0:
            self._parser_errors_seen = self.parser.stats.errors
            for _ in range(new_err):
                self.telemetry.on_error("malformed frame from device")
        if self._state is ConnectionState.CONNECTING and now_ms - self._connect_t > self.handshake_timeout:
            self.telemetry.on_error("handshake timeout")
            self._set_state(ConnectionState.ERROR, now_ms)
        if self._state is ConnectionState.CONNECTED:
            if now_ms - self._last_rx > self.silence_timeout:
                self.telemetry.on_error("device silent")
                self._set_state(ConnectionState.ERROR, now_ms)
            elif now_ms - self._last_ping >= self.ping_interval:
                self._last_ping = now_ms
                self._ping_token += 1
                self._ping_sent[self._ping_token] = now_ms
                try:
                    self.transport.write(encode_ping(self._ping_token))
                except Exception as e:  # noqa: BLE001
                    self.telemetry.on_error(f"ping failed: {e}")
            for seq, (t0, _cid) in list(self._acks.items()):
                if now_ms - t0 > self.ack_timeout:
                    del self._acks[seq]
                    self.telemetry.on_drop("ack timeout")

    def _handle(self, msg, now_ms: float) -> None:
        if isinstance(msg, DeviceInfo):
            self.info = msg
            self._actuators = set(msg.actuators)
            if self._state is ConnectionState.CONNECTING:
                self._set_state(ConnectionState.CONNECTED, now_ms)
        elif isinstance(msg, DeviceStatus):
            self._status = msg
            self.telemetry.battery = float(msg.battery_pct)
            self.telemetry.temperature = msg.temperature_c
            if msg.flags & 0b100:
                self.telemetry.on_error("device reports fault")
        elif isinstance(msg, DeviceAck):
            ent = self._acks.pop(msg.seq, None)
            if ent is not None:
                t0, cid = ent
                rtt = now_ms - t0
                self.rtt_ms.append(rtt)
                self.telemetry.on_latency(rtt / 2.0)
                self._notify_applied(cid, rtt / 2.0)
            if msg.dropped:
                self.telemetry.on_drop("device dropped command")
        elif isinstance(msg, DevicePong):
            if msg.token in self._ping_sent:
                self.rtt_ms.append(now_ms - self._ping_sent.pop(msg.token))
        elif isinstance(msg, DeviceError):
            self.telemetry.on_error(f"device error code {msg.code}")

    def get_actuator_state(self, now_ms: float = 0.0) -> dict[Actuator, float]:
        mask = self._status.active_mask if self._status else 0
        return {a: (1.0 if mask >> i & 1 else 0.0) for i, a in enumerate(ACTUATORS) if a in self._actuators}

    def get_status(self, now_ms: float = 0.0) -> GloveStatus:
        return super().get_status(now_ms)


class SerialHapticGlove(GenericHapticGlove):
    """Serial/USB-CDC glove speaking IMPACT-HAPTIC v1. HARDWARE-UNTESTED."""

    name = "serial"

    def __init__(self, hand: str, port: str, baud: int = 115200) -> None:
        super().__init__(hand, SerialTransport(port, baud))


class BLEHapticGlove(GenericHapticGlove):
    """BLE glove: pass a `BLETransport` (address + GATT characteristic UUIDs from your device's documentation). HARDWARE-UNTESTED."""

    name = "ble"


class HIDHapticGlove(GenericHapticGlove):
    """USB HID glove: pass an `HIDTransport(vendor_id, product_id)`. HARDWARE-UNTESTED."""

    name = "hid"
