"""Glove driver interface + telemetry. Drivers accept only `SafeHapticCommand`s."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

from ..model import ACTUATORS, Actuator, HapticChannel
from ..safety import SafeHapticCommand, SafetyViolation


class ConnectionState(str, Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class GloveStatus:
    hand: str
    connection: ConnectionState
    battery_pct: float | None = None
    temperature_c: float | None = None
    comm_errors: int = 0
    dropped_commands: int = 0
    commands_sent: int = 0
    command_rate_hz: float = 0.0
    mean_latency_ms: float = 0.0
    p95_latency_ms: float = 0.0
    utilisation: dict[str, float] = field(default_factory=dict)
    last_error: str = ""


class GloveTelemetry:
    """Command frequency, actuator utilisation, drops, latency, battery/thermal, communication errors."""

    def __init__(self, window_ms: float = 1000.0) -> None:
        self.window = window_ms
        self._cmd_t: deque[float] = deque()
        self._busy: dict[HapticChannel, deque[tuple[float, float]]] = {}
        self.lat: deque[float] = deque(maxlen=512)
        self.sent = 0
        self.dropped = 0
        self.comm_errors = 0
        self.battery: float | None = None
        self.temperature: float | None = None
        self.last_error = ""
        self.connection_log: list[tuple[float, str]] = []

    def on_command(self, ch: HapticChannel, cmd: SafeHapticCommand, now_ms: float) -> None:
        self.sent += 1
        self._cmd_t.append(now_ms)
        self._busy.setdefault(ch, deque()).append((now_ms, cmd.duration_ms * cmd.intensity))

    def on_drop(self, reason: str = "") -> None:
        self.dropped += 1
        if reason:
            self.last_error = reason

    def on_error(self, msg: str) -> None:
        self.comm_errors += 1
        self.last_error = msg

    def on_latency(self, ms: float) -> None:
        self.lat.append(ms)

    def on_connection(self, now_ms: float, state: ConnectionState) -> None:
        self.connection_log.append((now_ms, state.value))

    def command_rate(self, now_ms: float) -> float:
        while self._cmd_t and now_ms - self._cmd_t[0] > self.window:
            self._cmd_t.popleft()
        return len(self._cmd_t) * 1000.0 / self.window

    def utilisation(self, now_ms: float) -> dict[str, float]:
        out = {}
        for ch, q in self._busy.items():
            while q and now_ms - q[0][0] > self.window:
                q.popleft()
            out[str(ch)] = min(1.0, sum(x for _, x in q) / self.window)
        return out

    def latency_stats(self) -> tuple[float, float, float]:
        if not self.lat:
            return 0.0, 0.0, 0.0
        s = sorted(self.lat)
        return sum(s) / len(s), s[min(len(s) - 1, int(0.95 * len(s)))], s[-1]


class HapticGlove(ABC):
    """Hardware-independent glove driver (one hand)."""

    name = "glove"

    def __init__(self, hand: str) -> None:
        self.hand = hand
        self.telemetry = GloveTelemetry()
        self._state = ConnectionState.DISCONNECTED
        self._actuators: set[Actuator] = set()
        self.applied_callbacks: list = []      # fn(cmd_id, one_way_latency_ms) when the device confirms/applies a command

    def _notify_applied(self, cmd_id: int, latency_ms: float) -> None:
        for fn in self.applied_callbacks:
            fn(cmd_id, latency_ms)

    @abstractmethod
    def connect(self, now_ms: float = 0.0) -> bool: ...

    @abstractmethod
    def disconnect(self) -> None: ...

    @abstractmethod
    def update(self, now_ms: float) -> None:
        """Pump transport / apply scheduled device effects."""

    @abstractmethod
    def _transmit(self, cmd: SafeHapticCommand, now_ms: float) -> bool: ...

    @abstractmethod
    def stop_all(self) -> None: ...

    def send(self, cmd: SafeHapticCommand, now_ms: float) -> bool:
        if not isinstance(cmd, SafeHapticCommand):
            raise SafetyViolation("glove drivers only accept SafeHapticCommand (must pass the safety limiter)")
        if cmd.hand != self.hand:
            raise ValueError("command addressed to the other hand")
        if self._state is not ConnectionState.CONNECTED:
            self.telemetry.on_drop("not connected")
            return False
        if cmd.actuator not in self._actuators:
            self.telemetry.on_drop(f"actuator {cmd.actuator.value} not present")
            return False
        self.telemetry.on_command(HapticChannel(self.hand, cmd.actuator), cmd, now_ms)
        return self._transmit(cmd, now_ms)

    def detect_actuators(self) -> set[Actuator]:
        return set(self._actuators)

    def get_connection_state(self) -> ConnectionState:
        return self._state

    def get_latency(self) -> float:
        return self.telemetry.latency_stats()[0]

    def get_actuator_state(self, now_ms: float = 0.0) -> dict[Actuator, float]:
        return {a: 0.0 for a in ACTUATORS if a in self._actuators}

    def get_status(self, now_ms: float = 0.0) -> GloveStatus:
        tel = self.telemetry
        mean, p95, _ = tel.latency_stats()
        return GloveStatus(self.hand, self._state, tel.battery, tel.temperature, tel.comm_errors, tel.dropped, tel.sent, tel.command_rate(now_ms), mean, p95,
                           tel.utilisation(now_ms), tel.last_error)

    def _set_state(self, st: ConnectionState, now_ms: float = 0.0) -> None:
        if st is not self._state:
            self._state = st
            self.telemetry.on_connection(now_ms, st)
