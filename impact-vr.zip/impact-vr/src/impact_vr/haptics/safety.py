"""HapticSafetyLimiter - the last gate before any glove driver.

Independent of gameplay (no imports from combat/enemies/engine session). Every command must pass through `process`; glove drivers
only accept the opaque `SafeHapticCommand` type, which can be created by this module alone, so no code path (gameplay, scheduler,
a malformed device packet, a replay file) can reach hardware without these checks.

Checks: maximum intensity (hard cap, per-actuator calibrated cap, comfort limit) - maximum duration - sliding-window duty cycle per
actuator - per-actuator and global command rate - thermal state (derate, then latch off) - connection state - communication error
budget. A trip is latched until explicitly reset.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from enum import Enum

from ..engine.config import SafetyCfg
from .model import HapticChannel, HapticCommand
from .profile import CalibrationProfile

_MINT = object()


class SafetyViolation(RuntimeError):
    pass


class TripReason(str, Enum):
    THERMAL = "thermal_limit"
    COMM_ERRORS = "comm_error_budget"
    MANUAL = "manual"
    DEVICE_FAULT = "device_fault"


class SafeHapticCommand:
    """A command that has passed the limiter. Cannot be constructed outside this module."""

    __slots__ = ("hand", "actuator", "intensity", "duration_ms", "frequency", "waveform", "attack_ms", "release_ms", "priority", "id", "t_ms", "clamped", "seq")

    def __init__(self, token: object, cmd: HapticCommand, intensity: float, duration_ms: int, frequency: float, t_ms: float, clamped: bool, seq: int) -> None:
        if token is not _MINT:
            raise SafetyViolation("SafeHapticCommand can only be created by HapticSafetyLimiter")
        self.hand, self.actuator, self.intensity = cmd.hand, cmd.actuator, intensity
        self.duration_ms, self.frequency, self.waveform = duration_ms, frequency, cmd.waveform
        self.attack_ms, self.release_ms, self.priority = min(cmd.attack_ms, duration_ms), min(cmd.release_ms, duration_ms), cmd.priority
        self.id, self.t_ms, self.clamped, self.seq = cmd.id, t_ms, clamped, seq

    def __setattr__(self, k: str, v: object) -> None:
        if hasattr(self, k) and k in self.__slots__:
            raise AttributeError("SafeHapticCommand is immutable")
        object.__setattr__(self, k, v)

    @property
    def channel(self) -> HapticChannel:
        return HapticChannel(self.hand, self.actuator)

    def __repr__(self) -> str:
        return f"Safe({self.hand}.{self.actuator.value} {self.intensity:.2f} {self.duration_ms}ms {self.frequency:.0f}Hz {self.waveform.value})"


@dataclass
class SafetyReport:
    passed: int = 0
    clamped: int = 0
    rejected: Counter = field(default_factory=Counter)
    tripped: bool = False
    trip_reason: str = ""
    trips: int = 0
    derate: float = 1.0


class HapticSafetyLimiter:
    def __init__(self, cfg: SafetyCfg, profile: CalibrationProfile | None = None) -> None:
        self.cfg = cfg
        self.profile = profile
        self.report = SafetyReport()
        self._on: dict[HapticChannel, deque[tuple[float, float]]] = {}      # (t_ms, on_ms) accounting entries
        self._last_cmd: dict[HapticChannel, float] = {}
        self._global: deque[float] = deque()
        self._seq = 0
        self.connection_ok = True
        self.temperature_c: float | None = None
        self.comm_errors = 0
        self._tripped = False
        self.trip_reason: TripReason | None = None
        self.listeners: list = []

    # ---- state feed (from glove telemetry, not from gameplay) ------------------------------------------------------------------
    def observe(self, connected: bool, temperature_c: float | None, comm_errors: int, now_ms: float = 0.0) -> None:
        self.connection_ok = connected
        self.temperature_c = temperature_c
        self.comm_errors = comm_errors
        if comm_errors > self.cfg.max_comm_errors:
            self.trip(TripReason.COMM_ERRORS, now_ms)
        if temperature_c is not None and temperature_c >= self.cfg.thermal_limit_c:
            self.trip(TripReason.THERMAL, now_ms)
        t = temperature_c
        if t is not None and t > self.cfg.thermal_warn_c:
            span = max(self.cfg.thermal_limit_c - self.cfg.thermal_warn_c, 1e-6)
            self.report.derate = max(0.4, 1.0 - 0.6 * (t - self.cfg.thermal_warn_c) / span)
        else:
            self.report.derate = 1.0
        if self._tripped and not self.cfg.latch_on_trip and self.trip_reason is TripReason.THERMAL and (t is None or t < self.cfg.thermal_warn_c):
            self.reset()

    def trip(self, reason: TripReason, now_ms: float = 0.0) -> None:
        if not self._tripped:
            self.report.trips += 1
            for fn in self.listeners:
                fn(reason, now_ms)
        self._tripped = True
        self.trip_reason = reason
        self.report.tripped, self.report.trip_reason = True, reason.value

    def reset(self, authorized: bool = True) -> None:
        if not authorized:
            raise SafetyViolation("reset requires explicit authorisation")
        self._tripped = False
        self.trip_reason = None
        self.report.tripped, self.report.trip_reason = False, ""
        self._on.clear()
        self._global.clear()

    @property
    def tripped(self) -> bool:
        return self._tripped

    def set_profile(self, p: CalibrationProfile | None) -> None:
        self.profile = p

    # ---- the gate ------------------------------------------------------------------------------------------------------------------
    def process(self, cmd: HapticCommand, now_ms: float) -> SafeHapticCommand | None:
        cfg, rep = self.cfg, self.report
        if self._tripped:
            rep.rejected["tripped"] += 1
            return None
        if cfg.require_connection and not self.connection_ok:
            rep.rejected["disconnected"] += 1
            return None
        ch = HapticChannel(cmd.hand, cmd.actuator)
        while self._global and now_ms - self._global[0] > 1000.0:
            self._global.popleft()
        if len(self._global) >= cfg.max_commands_total_hz:
            rep.rejected["global_rate"] += 1
            return None
        last = self._last_cmd.get(ch)
        if last is not None and now_ms - last < 1000.0 / cfg.max_commands_per_actuator_hz:
            rep.rejected["actuator_rate"] += 1
            return None
        ceiling = cfg.hard_max_intensity
        if self.profile is not None:
            ceiling = min(ceiling, self.profile.limit_for(cmd.actuator, cfg.hard_max_intensity))
        ceiling *= rep.derate
        inten = min(cmd.intensity, ceiling)
        clamped = inten < cmd.intensity - 1e-9
        dur = cmd.duration_ms
        if dur > cfg.max_duration_ms:
            dur, clamped = cfg.max_duration_ms, True
        freq = max(20.0, min(400.0, cmd.frequency))
        if freq != cmd.frequency:
            clamped = True
        win = float(cfg.duty_window_ms)
        q = self._on.setdefault(ch, deque())
        while q and now_ms - q[0][0] > win:
            q.popleft()
        budget = cfg.max_duty_cycle * win - sum(on for _, on in q)
        if inten > 0.04:
            if budget <= 1.0:
                rep.rejected["duty_cycle"] += 1
                return None
            if dur > budget:
                dur, clamped = int(budget), True
            q.append((now_ms, float(dur)))
        if inten < 0.02:
            rep.rejected["negligible"] += 1
            return None
        self._last_cmd[ch] = now_ms
        self._global.append(now_ms)
        self._seq = (self._seq + 1) & 0xFF
        rep.passed += 1
        if clamped:
            rep.clamped += 1
        return SafeHapticCommand(_MINT, cmd, inten, max(1, int(dur)), freq, now_ms, clamped, self._seq)

    def duty_used(self, ch: HapticChannel, now_ms: float) -> float:
        return sum(on for t, on in self._on.get(ch, ()) if now_ms - t <= self.cfg.duty_window_ms) / self.cfg.duty_window_ms
