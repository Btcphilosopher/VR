"""VirtualGloveFirmware: the *device side* of IMPACT-HAPTIC v1, for end-to-end tests of generic gloves and for fuzzing the host parser
with hostile / malformed device traffic."""

from __future__ import annotations

import random

from .model import ACTUATORS, Actuator
from .protocol import HOST_TYPES, FrameParser, MsgType, ProtocolError, decode_host_haptic, encode_ack, encode_info, encode_pong, encode_status, frame
from .transports import Transport
from .waveforms import amplitude


class VirtualGloveFirmware:
    def __init__(self, transport: Transport, actuators: tuple[Actuator, ...] = ACTUATORS[:7], seed: int = 3, status_interval_ms: float = 100.0) -> None:
        self.t = transport
        self.actuators = actuators
        self.parser = FrameParser(HOST_TYPES)
        self.slots: dict[Actuator, tuple[float, object]] = {}
        self.battery = 90
        self.temp_c = 29.0
        self.errors = 0
        self.rng = random.Random(seed)
        self.received: list = []
        self.status_interval = status_interval_ms
        self._last_status = -1e9
        self.drop_next = False
        self.rejected = 0

    def update(self, now_ms: float) -> None:
        data = self.t.read(512)
        for f in self.parser.feed(data) if data else []:
            if f.type is MsgType.GET_INFO:
                self.t.write(encode_info(list(self.actuators)))
            elif f.type is MsgType.PING:
                self.t.write(encode_pong(int.from_bytes(f.payload[:4].ljust(4, b"\0"), "big")))
            elif f.type is MsgType.STOP:
                self.slots.clear()
            elif f.type is MsgType.HAPTIC:
                try:
                    h = decode_host_haptic(f.payload)
                except ProtocolError:
                    self.rejected += 1
                    continue
                dropped = self.drop_next
                self.drop_next = False
                if not dropped and h.actuator in self.actuators:
                    self.slots[h.actuator] = (now_ms, h)
                    self.received.append(h)
                self.t.write(encode_ack(h.seq, dropped))
        for a in [a for a, (t0, h) in self.slots.items() if now_ms - t0 > h.duration_ms]:  # type: ignore[attr-defined]
            del self.slots[a]
        if now_ms - self._last_status >= self.status_interval:
            self._last_status = now_ms
            mask = sum(1 << i for i, a in enumerate(ACTUATORS) if a in self.slots)
            self.t.write(encode_status(self.battery, self.temp_c, 0, self.errors, mask & 0xFF))

    def drive(self, a: Actuator, now_ms: float) -> float:
        s = self.slots.get(a)
        if s is None:
            return 0.0
        t0, h = s
        return h.intensity * amplitude(h.waveform, now_ms - t0, h.duration_ms, h.frequency, h.attack_ms, h.release_ms)  # type: ignore[attr-defined]

    def inject_garbage(self, n: int = 64) -> None:
        self.t.write(bytes(self.rng.randrange(256) for _ in range(n)))

    def inject_bad_status(self, battery: int = 250, temp_dc: int = 0) -> None:
        self.t.write(frame(MsgType.STATUS, bytes([battery]) + temp_dc.to_bytes(2, "big", signed=True) + bytes([0]) + (0).to_bytes(2, "big") + bytes([0])))
