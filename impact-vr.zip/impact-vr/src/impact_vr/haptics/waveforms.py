"""Waveform / envelope sampling used by simulated hardware and by tests (pure functions, bounded outputs)."""

from __future__ import annotations

import math

from .model import Waveform


def envelope(t_ms: float, duration_ms: float, attack_ms: float, release_ms: float) -> float:
    """Trapezoidal gain envelope in [0, 1]."""
    if t_ms < 0 or t_ms >= duration_ms or duration_ms <= 0:
        return 0.0
    a = 1.0 if attack_ms <= 0 else min(1.0, t_ms / attack_ms)
    rel = min(release_ms, duration_ms)
    r = 1.0 if rel <= 0 else min(1.0, (duration_ms - t_ms) / rel)
    return max(0.0, min(1.0, min(a, r)))


def amplitude(wf: Waveform, t_ms: float, duration_ms: float, freq: float, attack_ms: float = 2.0, release_ms: float = 20.0) -> float:
    """Drive amplitude (0..1, rectified 'strength') at time t after the command started."""
    env = envelope(t_ms, duration_ms, attack_ms, release_ms)
    if env <= 0.0:
        return 0.0
    u = t_ms / duration_ms
    ph = (t_ms / 1000.0) * freq
    if wf is Waveform.SINE:
        k = abs(math.sin(2 * math.pi * ph))
    elif wf is Waveform.SQUARE:
        k = 1.0 if (ph % 1.0) < 0.5 else 0.0
    elif wf is Waveform.TRIANGLE:
        k = abs(2 * (ph % 1.0) - 1.0)
    elif wf is Waveform.IMPACT:
        k = math.exp(-5.0 * u) * (0.6 + 0.4 * abs(math.sin(2 * math.pi * ph)))
    elif wf is Waveform.BUZZ:
        k = abs(math.sin(2 * math.pi * ph)) * (0.55 + 0.45 * abs(math.sin(2 * math.pi * ph * 0.1))) * math.exp(-2.5 * u)
    elif wf is Waveform.PULSE_TRAIN:
        k = 1.0 if (ph * 0.25 % 1.0) < 0.4 else 0.0
    elif wf is Waveform.RAMP:
        k = 1.0 - u
    else:  # SUSTAIN
        k = 1.0
    return max(0.0, min(1.0, env * k))
