"""HapticPipeline: events -> scheduler -> calibration profile -> SAFETY LIMITER -> glove drivers.

The limiter is the only producer of `SafeHapticCommand`, and drivers accept nothing else, so this ordering cannot be bypassed by
gameplay code."""

from __future__ import annotations

import time

from collections.abc import Mapping

from ..engine.config import HapticsCfg
from ..engine.events import HAPTIC_SCHEDULED, HAPTIC_SENT, HAPTIC_SUPPRESSED, SAFETY_CLAMP, SAFETY_TRIP, EventBus
from ..telemetry.latency import LatencyTracker
from .gloves.base import ConnectionState, HapticGlove
from .model import Actuator, HapticCommand, HapticEvent, HapticPriority, Waveform
from .profile import CalibrationProfile
from .safety import HapticSafetyLimiter, SafeHapticCommand, TripReason
from .scheduler import HapticScheduler


class HapticPipeline:
    def __init__(self, cfg: HapticsCfg, gloves: Mapping[str, HapticGlove], bus: EventBus | None = None, profile: CalibrationProfile | None = None,
                 latency: LatencyTracker | None = None) -> None:
        self.cfg = cfg
        self.gloves = gloves
        self.bus = bus
        self.profile = profile or CalibrationProfile.uncalibrated(cfg)
        self.scheduler = HapticScheduler(cfg.scheduler)
        self.limiter = HapticSafetyLimiter(cfg.safety, self.profile)
        self.latency = latency
        self.enabled = cfg.enabled
        self.sent: list[SafeHapticCommand] = []
        self.sent_total = 0
        self._cmd_trace: dict[int, int] = {}
        self._cmd_sched_t: dict[int, float] = {}
        self.keep_sent = 2048
        for g in gloves.values():
            g.applied_callbacks.append(self._on_applied)
        self.limiter.listeners.append(self._on_trip)

    def set_profile(self, profile: CalibrationProfile) -> None:
        self.profile = profile
        self.limiter.set_profile(profile)

    def submit(self, ev: HapticEvent, now_ms: float) -> int:
        if not self.enabled:
            return 0
        ev = HapticEvent(ev.pattern, ev.hand, ev.intensity * self.cfg.master_intensity, ev.priority, ev.bias, now_ms, ev.source, ev.trace_id)
        cmds = self.scheduler.submit(ev, now_ms)
        for c in cmds:
            if ev.trace_id:
                self._cmd_trace[c.id] = ev.trace_id
            self._cmd_sched_t[c.id] = now_ms + c.delay_ms        # intended due time: pattern offsets are design, not latency
        if self.bus is not None:
            self.bus.emit(HAPTIC_SCHEDULED, pattern=ev.pattern, hand=ev.hand, intensity=round(ev.intensity, 3), commands=len(cmds),
                          priority=int(ev.priority) if ev.priority is not None else -1)
        return len(cmds)

    def update(self, now_ms: float) -> list[SafeHapticCommand]:
        for gl in self.gloves.values():
            gl.update(now_ms)
            st = gl.get_status(now_ms)
            self.limiter.observe(st.connection is ConnectionState.CONNECTED, st.temperature_c, st.comm_errors, now_ms)
        out: list[SafeHapticCommand] = []
        if not self.enabled:
            self.scheduler.reset()
            return out
        sup_before = sum(self.scheduler.stats.suppressed.values())
        t0 = time.perf_counter_ns()
        for cmd, _sc in self.scheduler.tick(now_ms):
            shaped = self.profile.shape(cmd.actuator, cmd.intensity, self.cfg.safety.hard_max_intensity)
            if shaped < 0.02:
                continue
            safe = self.limiter.process(cmd.model_copy(update={"intensity": min(1.0, shaped)}), now_ms)
            if safe is None:
                continue
            g = self.gloves.get(safe.hand)
            if g is None:
                continue
            if safe.clamped and self.bus is not None:
                self.bus.emit(SAFETY_CLAMP, actuator=safe.actuator.value, hand=safe.hand)
            if g.send(safe, now_ms):
                out.append(safe)
                self.sent_total += 1
                if self.bus is not None:
                    self.bus.emit(HAPTIC_SENT, hand=safe.hand, actuator=safe.actuator.value, intensity=round(safe.intensity, 3), duration_ms=safe.duration_ms,
                                  frequency=safe.frequency, waveform=safe.waveform.value, tag=cmd.tag)
                tid = self._cmd_trace.get(cmd.id)
                if tid is not None:
                    if self.latency is not None:
                        self.latency.stage(tid, "haptic_scheduling", max(0.0, now_ms - self._cmd_sched_t.get(cmd.id, now_ms)) + (time.perf_counter_ns() - t0) / 1e6)
                    self._cmd_trace[safe.id] = tid
        self.sent.extend(out)
        if len(self.sent) > self.keep_sent:
            del self.sent[: len(self.sent) - self.keep_sent]
        if self.bus is not None:
            n = sum(self.scheduler.stats.suppressed.values()) - sup_before
            if n > 0:
                self.bus.emit(HAPTIC_SUPPRESSED, count=n)
        for gl in self.gloves.values():
            gl.update(now_ms)
        return out

    def _on_applied(self, cmd_id: int, latency_ms: float) -> None:
        tid = self._cmd_trace.pop(cmd_id, None)
        if tid and self.latency is not None:
            self.latency.stage(tid, "hardware_transport", latency_ms)
            self.latency.finish(tid)

    def _on_trip(self, reason: TripReason, now_ms: float) -> None:
        for g in self.gloves.values():
            try:
                g.stop_all()
            except Exception:  # noqa: BLE001
                pass
        self.scheduler.reset()
        if self.bus is not None:
            self.bus.emit(SAFETY_TRIP, reason=reason.value)

    def emergency_stop(self) -> None:
        self.limiter.trip(TripReason.MANUAL)

    def send_test(self, hand: str, actuator: Actuator, intensity: float, duration_ms: int, now_ms: float, frequency: float = 120.0,
                  waveform: Waveform = Waveform.SINE, apply_profile: bool = True) -> SafeHapticCommand | None:
        """Direct test output (glove-test / calibration). Still passes the safety limiter."""
        inten = self.profile.shape(actuator, intensity, self.cfg.safety.hard_max_intensity) if apply_profile else intensity
        cmd = HapticCommand(hand=hand, actuator=actuator, intensity=max(0.0, min(1.0, inten)), duration_ms=duration_ms, frequency=frequency,  # type: ignore[arg-type]
                            waveform=waveform, attack_ms=5, release_ms=min(40, duration_ms // 2), priority=HapticPriority.MAJOR_IMPACT, tag="test")
        safe = self.limiter.process(cmd, now_ms)
        g = self.gloves.get(hand)
        if safe is None or g is None:
            return None
        return safe if g.send(safe, now_ms) else None

    def actuator_levels(self, now_ms: float) -> dict[str, dict[Actuator, float]]:
        return {h: g.get_actuator_state(now_ms) for h, g in self.gloves.items()}
