"""Byte transports for generic gloves.

`LoopbackTransport` and `UDPTransport` are fully testable here. Serial/BLE/HID/WebSocket transports are thin, guarded adapters over
optional third-party packages: HARDWARE-UNTESTED in this repository (no devices available); they fail cleanly
(`TransportUnavailable`) when the package or device is missing.
"""

from __future__ import annotations

import queue
import socket
import threading
from abc import ABC, abstractmethod
from collections import deque


class TransportUnavailable(RuntimeError):
    pass


class Transport(ABC):
    name = "transport"

    @abstractmethod
    def open(self) -> None: ...

    @abstractmethod
    def close(self) -> None: ...

    @abstractmethod
    def write(self, data: bytes) -> int: ...

    @abstractmethod
    def read(self, max_bytes: int = 256) -> bytes: ...

    @property
    @abstractmethod
    def is_open(self) -> bool: ...


class LoopbackTransport(Transport):
    """In-memory duplex pair: what one end writes the other reads."""

    name = "loopback"

    def __init__(self) -> None:
        self._rx: deque[bytes] = deque()
        self.peer: LoopbackTransport | None = None
        self._open = False
        self.bytes_written = 0

    @staticmethod
    def pair() -> tuple[LoopbackTransport, LoopbackTransport]:
        a, b = LoopbackTransport(), LoopbackTransport()
        a.peer, b.peer = b, a
        return a, b

    def open(self) -> None:
        self._open = True

    def close(self) -> None:
        self._open = False

    @property
    def is_open(self) -> bool:
        return self._open

    def write(self, data: bytes) -> int:
        if not self._open or self.peer is None:
            raise TransportUnavailable("loopback not open")
        self.bytes_written += len(data)
        self.peer._rx.append(bytes(data))
        return len(data)

    def read(self, max_bytes: int = 256) -> bytes:
        out = bytearray()
        while self._rx and len(out) < max_bytes:
            chunk = self._rx.popleft()
            take = chunk[: max_bytes - len(out)]
            out += take
            if len(take) < len(chunk):
                self._rx.appendleft(chunk[len(take):])
                break
        return bytes(out)


class UDPTransport(Transport):
    name = "udp"

    def __init__(self, remote: tuple[str, int], local: tuple[str, int] = ("127.0.0.1", 0)) -> None:
        self.remote, self.local = remote, local
        self._sock: socket.socket | None = None

    def open(self) -> None:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setblocking(False)
        s.bind(self.local)
        self._sock = s

    @property
    def local_address(self) -> tuple[str, int]:
        assert self._sock is not None
        return self._sock.getsockname()

    def close(self) -> None:
        if self._sock:
            self._sock.close()
            self._sock = None

    @property
    def is_open(self) -> bool:
        return self._sock is not None

    def write(self, data: bytes) -> int:
        if self._sock is None:
            raise TransportUnavailable("udp not open")
        return self._sock.sendto(data, self.remote)

    def read(self, max_bytes: int = 256) -> bytes:
        if self._sock is None:
            return b""
        try:
            data, _ = self._sock.recvfrom(max(max_bytes, 512))
            return data[:max_bytes]
        except (BlockingIOError, OSError):
            return b""


class SerialTransport(Transport):  # pragma: no cover - hardware
    name = "serial"

    def __init__(self, port: str, baud: int = 115200) -> None:
        self.port, self.baud = port, baud
        self._s = None

    def open(self) -> None:
        try:
            import serial
        except Exception as e:
            raise TransportUnavailable(f"pyserial not installed: {e}") from e
        try:
            self._s = serial.Serial(self.port, self.baud, timeout=0, write_timeout=0.05)
        except Exception as e:
            raise TransportUnavailable(f"cannot open {self.port}: {e}") from e

    def close(self) -> None:
        if self._s:
            self._s.close()
            self._s = None

    @property
    def is_open(self) -> bool:
        return self._s is not None

    def write(self, data: bytes) -> int:
        return int(self._s.write(data)) if self._s else 0

    def read(self, max_bytes: int = 256) -> bytes:
        return bytes(self._s.read(max_bytes)) if self._s else b""


class HIDTransport(Transport):  # pragma: no cover - hardware
    name = "hid"

    def __init__(self, vendor_id: int, product_id: int, report_size: int = 64) -> None:
        self.vid, self.pid, self.rs = vendor_id, product_id, report_size
        self._d = None

    def open(self) -> None:
        try:
            import hid
        except Exception as e:
            raise TransportUnavailable(f"hidapi not installed: {e}") from e
        d = hid.device()
        try:
            d.open(self.vid, self.pid)
            d.set_nonblocking(1)
        except Exception as e:
            raise TransportUnavailable(f"cannot open HID {self.vid:04x}:{self.pid:04x}: {e}") from e
        self._d = d

    def close(self) -> None:
        if self._d:
            self._d.close()
            self._d = None

    @property
    def is_open(self) -> bool:
        return self._d is not None

    def write(self, data: bytes) -> int:
        return int(self._d.write(b"\x00" + data.ljust(self.rs, b"\x00"))) if self._d else 0

    def read(self, max_bytes: int = 256) -> bytes:
        if not self._d:
            return b""
        r = self._d.read(self.rs)
        return bytes(r)[:max_bytes] if r else b""


class BLETransport(Transport):  # pragma: no cover - hardware
    """BLE GATT bridge: a worker thread owns an asyncio loop (bleak). Characteristic UUIDs come from your device's documentation."""

    name = "ble"

    def __init__(self, address: str, write_uuid: str, notify_uuid: str) -> None:
        self.address, self.write_uuid, self.notify_uuid = address, write_uuid, notify_uuid
        self._rx: queue.Queue[bytes] = queue.Queue(maxsize=256)
        self._tx: queue.Queue[bytes] = queue.Queue(maxsize=256)
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._open = False

    def open(self) -> None:
        try:
            import bleak  # noqa: F401
        except Exception as e:
            raise TransportUnavailable(f"bleak not installed: {e}") from e
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        self._open = True

    def _run(self) -> None:
        import asyncio

        from bleak import BleakClient

        async def main() -> None:
            async with BleakClient(self.address) as c:
                await c.start_notify(self.notify_uuid, lambda _, d: self._rx.put_nowait(bytes(d)) if not self._rx.full() else None)
                while not self._stop.is_set():
                    try:
                        await c.write_gatt_char(self.write_uuid, self._tx.get_nowait(), response=False)
                    except queue.Empty:
                        await asyncio.sleep(0.002)

        try:
            asyncio.run(main())
        except Exception:
            self._open = False

    def close(self) -> None:
        self._stop.set()
        self._open = False

    @property
    def is_open(self) -> bool:
        return self._open

    def write(self, data: bytes) -> int:
        try:
            self._tx.put_nowait(data)
            return len(data)
        except queue.Full:
            return 0

    def read(self, max_bytes: int = 256) -> bytes:
        out = b""
        while len(out) < max_bytes:
            try:
                out += self._rx.get_nowait()
            except queue.Empty:
                break
        return out[:max_bytes]


class WebSocketTransport(Transport):  # pragma: no cover - hardware / network
    name = "websocket"

    def __init__(self, url: str) -> None:
        self.url = url
        self._ws = None

    def open(self) -> None:
        try:
            from websockets.sync.client import connect
        except Exception as e:
            raise TransportUnavailable(f"websockets not installed: {e}") from e
        try:
            self._ws = connect(self.url, open_timeout=2)
        except Exception as e:
            raise TransportUnavailable(f"cannot connect {self.url}: {e}") from e

    def close(self) -> None:
        if self._ws:
            self._ws.close()
            self._ws = None

    @property
    def is_open(self) -> bool:
        return self._ws is not None

    def write(self, data: bytes) -> int:
        if self._ws:
            self._ws.send(data)
            return len(data)
        return 0

    def read(self, max_bytes: int = 256) -> bytes:
        if not self._ws:
            return b""
        try:
            m = self._ws.recv(timeout=0)
            return bytes(m)[:max_bytes] if isinstance(m, (bytes, bytearray)) else b""
        except Exception:
            return b""
