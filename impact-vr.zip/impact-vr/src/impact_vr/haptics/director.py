"""HapticDirector: translates gameplay events (impacts, blocks, damage, grabs...) into `HapticEvent`s.

It knows gameplay vocabulary; it knows nothing about devices, limits or protocols. Impact *physics* (energy) -> haptic *intensity*,
never gameplay damage, so cinematic damage tuning cannot make the glove stronger. Gameplay events are queued and converted by
`flush()` after the gameplay stage has resolved (IMPACT -> GAMEPLAY -> HAPTIC EVENT)."""

from __future__ import annotations

import math

from ..engine.config import HapticsCfg
from ..engine.events import BLOCK, ENEMY_ATTACK, ENEMY_DEFEATED, GRAB, IMPACT_CALCULATED, PARRY, PLAYER_DAMAGED, Event, EventBus
from .model import Actuator as A, HapticEvent, HapticPriority as P

_KNUCKLE = {A.INDEX: 1.0, A.MIDDLE: 1.0, A.RING: 0.75, A.LITTLE: 0.45, A.THUMB: 0.35, A.PALM: 0.8, A.WRIST: 0.7, A.FOREARM: 0.5}
STRIKE_BIAS: dict[str, dict[A, float]] = {
    "jab": _KNUCKLE, "cross": _KNUCKLE, "hook": {**_KNUCKLE, A.LITTLE: 0.7, A.RING: 0.9},
    "uppercut": {**_KNUCKLE, A.PALM: 0.95, A.WRIST: 0.85},
    "hammer_fist": {A.LITTLE: 1.0, A.RING: 0.8, A.PALM: 1.0, A.WRIST: 1.0, A.FOREARM: 0.8, A.INDEX: 0.35, A.MIDDLE: 0.45, A.THUMB: 0.3},
    "palm_strike": {A.PALM: 1.0, A.WRIST: 1.0, A.FOREARM: 0.7, A.INDEX: 0.45, A.MIDDLE: 0.5, A.RING: 0.45, A.LITTLE: 0.4, A.THUMB: 0.4},
    "backhand": {A.WRIST: 1.0, A.FOREARM: 0.8, A.PALM: 0.3, A.INDEX: 0.6, A.MIDDLE: 0.5, A.RING: 0.4, A.LITTLE: 0.4, A.THUMB: 0.5},
    "elbow_strike": {A.FOREARM: 1.0, A.WRIST: 0.8, A.PALM: 0.25, A.INDEX: 0.1, A.MIDDLE: 0.1, A.RING: 0.1, A.LITTLE: 0.1, A.THUMB: 0.1},
    "push": {A.PALM: 1.0, A.INDEX: 0.8, A.MIDDLE: 0.8, A.RING: 0.7, A.LITTLE: 0.6, A.THUMB: 0.7, A.WRIST: 0.6},
    "shove": {A.PALM: 1.0, A.INDEX: 0.85, A.MIDDLE: 0.85, A.RING: 0.75, A.LITTLE: 0.65, A.THUMB: 0.75, A.WRIST: 0.8, A.FOREARM: 0.5},
}


def intensity_from_energy(energy_j: float, e_ref: float, hardness: float = 0.5) -> float:
    """Log-compressed: perceived strength grows ~logarithmically with energy. e_ref maps to ~0.95."""
    if energy_j <= 0:
        return 0.0
    e0 = 2.0
    i = math.log1p(energy_j / e0) / math.log1p(e_ref / e0) * 0.95
    return max(0.0, min(1.0, i * (0.9 + 0.2 * hardness)))


class HapticDirector:
    def __init__(self, bus: EventBus, pipeline, cfg: HapticsCfg, now_ms=lambda: 0.0, latency=None) -> None:
        self.bus, self.pipeline, self.cfg = bus, pipeline, cfg
        self.now_ms = now_ms
        self.latency = latency
        self.player_health_max = 100.0
        self._pending: list = []
        for name, fn in ((IMPACT_CALCULATED, self._impact), (BLOCK, self._block), (PARRY, self._parry), (GRAB, self._grab), (PLAYER_DAMAGED, self._damaged),
                         (ENEMY_ATTACK, self._warning), (ENEMY_DEFEATED, self._success)):
            bus.subscribe(name, self._defer(fn))

    def _defer(self, fn):
        def handler(e: Event) -> None:
            self._pending.append((fn, e))
        return handler

    def flush(self) -> int:
        """Convert queued gameplay events into haptic events (call once per frame, after gameplay resolution)."""
        n = 0
        while self._pending:
            batch, self._pending = self._pending, []
            for fn, e in batch:
                fn(e)
                n += 1
        return n

    def _emit(self, pattern: str, hand: str, intensity: float, priority: P | None = None, bias: dict[A, float] | None = None, source: str = "") -> None:
        if intensity <= 0.02:
            return
        tid = self.latency.begin_trace() if self.latency is not None else 0
        self.pipeline.submit(HapticEvent(pattern, hand, intensity, priority, bias or {}, self.now_ms(), source, tid), self.now_ms())

    def trigger(self, pattern: str, hand: str = "both", intensity: float = 0.7, priority: P | None = None) -> None:
        self._emit(pattern, hand, intensity, priority, None, "manual")

    def _impact(self, e: Event) -> None:
        imp, phys = e.data["impact"], e.data["physical"]
        if imp.attacker != "player" or imp.hand is None:
            return
        i = intensity_from_energy(phys.energy_j, self.cfg.energy_ref_j, phys.hardness)
        if phys.energy_j < 1.2:
            pat = "LIGHT_CONTACT"
        elif phys.material == "metal":
            pat = "METAL_IMPACT"
        elif phys.material == "wood":
            pat = "WOOD_IMPACT"
        elif phys.material in ("brick", "concrete"):
            pat = "WALL_CONTACT"
        elif phys.material in ("flesh", "rubber") and i > 0.55:
            pat = "HEAVY_IMPACT"
        elif phys.material == "cloth":
            pat = "LIGHT_CONTACT"
        else:
            pat = "FLESH_IMPACT"
        self._emit(pat, imp.hand, i, P.MAJOR_IMPACT if i > 0.6 else P.COMBAT, STRIKE_BIAS.get(imp.impact_type), "impact")
        if e.data.get("hazard") == "electric":
            self._emit("ELECTRIC_EFFECT", imp.hand, max(0.4, i), P.INTERACTION, None, "hazard")

    def _block(self, e: Event) -> None:
        gain = {"solid": 1.0, "partial": 0.8, "none": 0.0}.get(e.data.get("quality", "solid"), 0.8)
        for h in e.data.get("hands", ()):
            self._emit("BLOCK", h, min(1.0, 0.25 + 0.75 * float(e.data.get("power", 0.6))) * gain, P.COMBAT, None, "block")

    def _parry(self, e: Event) -> None:
        self._emit("PARRY", e.data["hand"], 0.8, P.COMBAT, None, "parry")

    def _grab(self, e: Event) -> None:
        h = e.data.get("hand")
        if h is None or e.data.get("phase") != "start":
            return
        kind = "OBJECT_PICKUP" if e.data.get("object") else "GRAB"
        self._emit(kind, h, 0.45 + 0.5 * float(e.data.get("grip", 0.8)), P.INTERACTION, None, "grab")
        if kind == "OBJECT_PICKUP":
            self._emit("GRAB", h, 0.5, P.INTERACTION, None, "grab")

    def _damaged(self, e: Event) -> None:
        amount = float(e.data.get("amount", 10.0))
        frac = amount / max(self.player_health_max, 1.0)
        side = float(e.data.get("side", 0.0))          # -1 hit from left .. +1 from right (relative to head yaw)
        crit = frac >= 0.25 or bool(e.data.get("critical"))
        base = min(1.0, 0.35 + 1.6 * frac)
        for hand, w in (("right", 0.55 + 0.45 * max(0.0, side)), ("left", 0.55 + 0.45 * max(0.0, -side))):
            self._emit("DAMAGE", hand, base * w, P.CRITICAL_DAMAGE if crit else P.MAJOR_IMPACT, None, "damage")

    def _warning(self, e: Event) -> None:
        d = float(e.data.get("distance", 9.0))
        if d < 2.6 and e.data.get("phase", "windup") == "windup":
            self._emit("WARNING", "both", 0.35 + 0.25 * (1 - d / 2.6), P.AMBIENT, None, "warning")

    def _success(self, e: Event) -> None:
        self._emit("SUCCESS", "both", 0.7, P.INTERACTION, None, "success")
