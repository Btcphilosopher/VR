"""Procedural animation: readable enemy attack wind-ups and hit-reaction springs (no skeletal asset dependency)."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..engine.mathx import Vec, lerp, unit, v3


def ease_out(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return 1 - (1 - u) ** 3


def ease_in(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return u**2.2


def ease_inout(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return u * u * (3 - 2 * u)


@dataclass(frozen=True)
class AttackAnim:
    """Fist path of one attack in the enemy's local frame (x right, y up, z forward). Windup = the telegraph."""

    guard: Vec
    windup: Vec
    strike_end: Vec
    arc_lateral: float = 0.0        # extra sideways bulge during the strike (hooks)
    arc_vertical: float = 0.0       # extra vertical bulge (overheads)


def attack_fist_local(anim: AttackAnim, phase: str, u: float) -> Vec:
    if phase == "windup":
        return lerp(anim.guard, anim.windup, ease_out(u))
    if phase == "active":
        k = ease_in(u)
        p = lerp(anim.windup, anim.strike_end, k)
        bulge = math.sin(math.pi * k)
        return p + v3(anim.arc_lateral * bulge, anim.arc_vertical * bulge, 0.0)
    return lerp(anim.strike_end, anim.guard, ease_inout(u))     # recovery


@dataclass
class HitReaction:
    """Spring giving torso/head recoil after a hit."""

    offset: Vec = field(default_factory=lambda: v3())
    vel: Vec = field(default_factory=lambda: v3())
    stiffness: float = 140.0
    damping: float = 14.0

    def kick(self, direction: Vec, strength: float) -> None:
        self.vel = self.vel + unit(direction) * strength

    def step(self, dt: float) -> None:
        acc = -self.stiffness * self.offset - self.damping * self.vel
        self.vel = self.vel + acc * dt
        self.offset = self.offset + self.vel * dt

    @property
    def magnitude(self) -> float:
        return float(np.linalg.norm(self.offset))
