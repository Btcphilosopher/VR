"""Desktop input -> synthetic VR devices, so the game is playable with a keyboard and mouse (simulation / development mode).

Keys trigger *trajectories* for the synthetic hands (the pipeline still recognises them from motion, exactly as it would from a
tracked hand): J jab, K cross, H hook, U uppercut, I palm, O hammer fist, L backhand, M elbow, B hold block, P parry, G grab (hold)
/ T throw, F push, V shove; S duck, A/D weave left/right, Q/E lean; arrows = sticks (move / turn); mouse = look.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..engine.mathx import Vec, q_from_euler, v3
from ..simulation.synthetic import MOVES, SyntheticController, SyntheticHandTracker, SyntheticHeadset
from ..vr.types import ControllerState, VRPose

KEYMAP = {"j": ("jab", "left"), "k": ("cross", "right"), "h": ("hook", "right"), "u": ("uppercut", "right"), "i": ("palm_strike", "right"),
          "o": ("hammer_fist", "right"), "l": ("backhand", "right"), "m": ("elbow_strike", "right"), "p": ("parry", "right"), "t": ("throw", "right"),
          "f": ("push", "left"), "v": ("shove", "right")}


class LiveHeadset(SyntheticHeadset):
    """Head driven live: target offset eased critically-damped, yaw/pitch from the mouse."""

    name = "desktop-headset"

    def __init__(self) -> None:
        super().__init__()
        self.target = v3()
        self.cur = v3()
        self.pitch = 0.0
        self._t = 0.0

    def tick(self, t: float) -> None:
        dt = max(t - self._t, 0.0)
        self._t = t
        self.cur = self.cur + (self.target - self.cur) * (1.0 - math.exp(-dt / 0.07))

    def body_head(self, t: float) -> tuple[Vec, float]:
        return self.cur.copy(), 0.0

    def get_pose(self, t: float) -> VRPose:
        return VRPose(self.position + v3(0, self.eye, 0) + self.cur, q_from_euler(self.yaw, self.pitch, 0.0))


class LiveHands(SyntheticHandTracker):
    def trigger(self, hand: str, move: str, now: float, **kw) -> None:
        sc = self.scripts[hand]
        traj = MOVES[move](hand, **kw)
        lead = sc._lead(sc.pose(now), traj.sample(0.0))
        sc.items = [(t0, tr) for t0, tr in sc.items if t0 + tr.duration + 1.0 > now or tr.name in ("block", "grab")][-6:]
        sc.add(now + lead, traj)

    def hold_guard(self, hand: str, now: float, on: bool) -> None:
        sc = self.scripts[hand]
        holding = any(tr.name == "block" for _, tr in sc.items[-1:])
        if on and not holding:
            self.trigger(hand, "block", now)
        elif not on and holding:
            sc.items = []
            sc.hold_pose = None


class DesktopController(SyntheticController):
    name = "desktop-controllers"

    def __init__(self, tracker: SyntheticHandTracker) -> None:
        super().__init__(tracker)
        self.stick_l = (0.0, 0.0)
        self.stick_r = (0.0, 0.0)

    def get_state(self, hand: str, t: float) -> ControllerState:
        st = super().get_state(hand, t)
        st.stick = self.stick_l if hand == "left" else self.stick_r
        return st


@dataclass
class DesktopInput:
    """Holds the live devices and translates keyboard/mouse state each frame."""

    headset: LiveHeadset = field(default_factory=LiveHeadset)
    tracker: LiveHands = field(init=False)
    controllers: DesktopController = field(init=False)
    sens: float = 0.0028

    def __post_init__(self) -> None:
        self.tracker = LiveHands(self.headset)
        self.controllers = DesktopController(self.tracker)

    def key_down(self, key: str, now: float) -> None:
        mv = KEYMAP.get(key)
        if mv:
            self.tracker.trigger(mv[1], mv[0], now)
        if key == "g":
            self.tracker.trigger("right", "grab", now)

    def update(self, keys: set[str], mouse_rel: tuple[int, int], now: float) -> None:
        self.headset.yaw += mouse_rel[0] * self.sens
        self.headset.pitch = float(np.clip(self.headset.pitch - mouse_rel[1] * self.sens, -1.0, 1.0))
        tgt = v3()
        if "s" in keys:
            tgt = tgt + v3(0, -0.42, 0.05)
        if "a" in keys:
            tgt = tgt + v3(-0.22, -0.03, 0)
        if "d" in keys:
            tgt = tgt + v3(0.22, -0.03, 0)
        if "q" in keys:
            tgt = tgt + v3(-0.12, 0, 0.1)
        if "e" in keys:
            tgt = tgt + v3(0.12, 0, 0.1)
        self.headset.target = tgt
        self.headset.tick(now)
        self.tracker.hold_guard("left", now, "b" in keys)
        self.tracker.hold_guard("right", now, "b" in keys)
        self.controllers.stick_l = (0.0, (1.0 if "up" in keys else 0.0) - (1.0 if "down" in keys else 0.0))
        self.controllers.stick_r = ((1.0 if "right" in keys else 0.0) - (1.0 if "left" in keys else 0.0), 0.0)
