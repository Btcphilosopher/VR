"""Typed event names and an in-process bus. Every event is stamped with session id + frame id for correlation."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

VR_FRAME = "VR_FRAME"
HAND_TRACKED = "HAND_TRACKED"
GESTURE_DETECTED = "GESTURE_DETECTED"
STRIKE_DETECTED = "STRIKE_DETECTED"
COLLISION = "COLLISION"
IMPACT_CALCULATED = "IMPACT_CALCULATED"
DAMAGE_APPLIED = "DAMAGE_APPLIED"
BLOCK = "BLOCK"
PARRY = "PARRY"
ENEMY_STATE = "ENEMY_STATE"
ENEMY_ATTACK = "ENEMY_ATTACK"
ENEMY_DEFEATED = "ENEMY_DEFEATED"
PLAYER_DAMAGED = "PLAYER_DAMAGED"
HAPTIC_SCHEDULED = "HAPTIC_SCHEDULED"
HAPTIC_SENT = "HAPTIC_SENT"
HAPTIC_SUPPRESSED = "HAPTIC_SUPPRESSED"
SAFETY_TRIP = "SAFETY_TRIP"
SAFETY_CLAMP = "SAFETY_CLAMP"
AUDIO = "AUDIO"
PLAYER_MOVED = "PLAYER_MOVED"
ENCOUNTER = "ENCOUNTER"
GRAB = "GRAB"
GLOVE_STATE = "GLOVE_STATE"


@dataclass(slots=True)
class Event:
    name: str
    t: float
    frame: int
    session: str
    data: dict[str, Any] = field(default_factory=dict)


Handler = Callable[[Event], None]


class EventBus:
    def __init__(self, session_id: str = "s0", history: int = 4096) -> None:
        self.session_id = session_id
        self.frame = 0
        self.time = 0.0
        self.history: deque[Event] = deque(maxlen=history)
        self._subs: dict[str, list[Handler]] = {}
        self._all: list[Handler] = []

    def subscribe(self, name: str, fn: Handler) -> None:
        self._subs.setdefault(name, []).append(fn)

    def subscribe_all(self, fn: Handler) -> None:
        self._all.append(fn)

    def emit(self, name: str, **data: Any) -> Event:
        ev = Event(name, self.time, self.frame, self.session_id, data)
        self.history.append(ev)
        for fn in self._subs.get(name, ()):
            fn(ev)
        for fn in self._all:
            fn(ev)
        return ev

    def of(self, name: str) -> list[Event]:
        return [e for e in self.history if e.name == name]

    def count(self, name: str) -> int:
        return sum(1 for e in self.history if e.name == name)
