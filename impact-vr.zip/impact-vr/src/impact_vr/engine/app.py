"""Pygame application: main menu, training room, story / encounter / boss modes, settings, calibrations, performance monitor.

Runs entirely on the synthetic VR stack (keyboard + mouse drive virtual hands through the same recognition pipeline), so the full
game is playable with no headset and no glove. See input/desktop.py for the key map."""

from __future__ import annotations

import time
from dataclasses import dataclass

import pygame

from ..audio.engine import NullAudio, PygameAudio
from ..haptics import monitor as glove_monitor
from ..haptics.calibration import CalibrationSession, ScriptedResponder
from ..haptics.gloves.simulated import make_simulated_pair
from ..haptics.pipeline import HapticPipeline
from ..haptics.profile import CalibrationProfile
from ..input.desktop import DesktopInput
from ..rendering import palette as pal
from ..rendering.digital_twin import draw_digital_twin
from ..rendering.overlay import draw_overlay, overlay_lines
from ..rendering.software import SoftwareRenderer, ViewState
from ..simulation.benchmark import run_benchmark
from ..tracking.calibration import run_tracking_calibration
from ..vr.adapters import ControllerHandFallback
from ..vr.device import VRRuntime
from . import events as E
from .clock import FixedStepper, FrameTimer
from .config import Config, save_config, user_dir
from .modes import GameMode
from .session import GameSession

MENU = [("TRAINING ROOM", GameMode.TRAINING), ("STORY MODE", GameMode.STORY), ("ENCOUNTER MODE", GameMode.ENCOUNTER), ("BOSS ENCOUNTER", GameMode.BOSS),
        ("SETTINGS", GameMode.SETTINGS), ("HAPTIC CALIBRATION", GameMode.HAPTIC_CALIBRATION), ("TRACKING CALIBRATION", GameMode.TRACKING_CALIBRATION),
        ("PERFORMANCE MONITOR", GameMode.PERFORMANCE), ("QUIT", None)]


def make_fonts() -> dict[str, pygame.font.Font]:
    pygame.font.init()
    n = "dejavusansmono,liberationmono,consolas,couriernew,monospace"
    f = lambda s, b=False: pygame.font.SysFont(n, s, bold=b)   # noqa: E731
    return {"small": f(13), "body": f(16), "title": f(22, True), "huge": f(48, True)}


@dataclass
class App:
    cfg: Config
    headless: bool = False
    dev: bool = False
    seed: int | None = None

    SETTINGS = ["difficulty", "locomotion", "turn_mode", "master_intensity", "filter", "overlay"]

    def __post_init__(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode(self.cfg.graphics.size)
        pygame.display.set_caption("IMPACT//VR")
        self.fonts = make_fonts()
        self.renderer = SoftwareRenderer(self.fonts)
        self.clock = pygame.time.Clock()
        self.timer = FrameTimer()
        self.audio = NullAudio() if self.headless or self.cfg.audio.backend == "null" else PygameAudio(self.cfg.audio.max_voices)
        self.state = "menu"
        self.sel = 0
        self.sel2 = 0
        self.session: GameSession | None = None
        self.inp: DesktopInput | None = None
        self.keys: set[str] = set()
        self.effects: list[list] = []
        self.show_overlay = self.cfg.graphics.show_overlay or self.dev
        self.show_twin = False
        self.paused = False
        self.running = True
        self.stepper = FixedStepper(1.0 / self.cfg.physics.step_hz)
        self.text_lines: list[str] = []
        self.profile = CalibrationProfile.load_or_default(self.cfg.haptics)
        self.message = ""
        self.orbit = 0.6

    # ---- flow ------------------------------------------------------------------------------------------------------------------------
    def start(self, mode: GameMode) -> None:
        self.inp = DesktopInput()
        rt = VRRuntime(self.inp.headset, self.inp.tracker, self.inp.controllers, min_confidence=self.cfg.vr.min_hand_confidence, target_fps=self.cfg.vr.target_fps,
                       fallback=ControllerHandFallback())
        rt.start()
        self.session = GameSession(self.cfg, rt, mode=mode, seed=self.seed, profile=self.profile, audio_backend=self.audio)
        self.effects.clear()
        self.session.bus.subscribe(E.IMPACT_CALCULATED, self._fx)
        self.state, self.paused = "play", False
        pygame.mouse.set_visible(self.headless)
        if not self.headless:
            pygame.event.set_grab(True)

    def _fx(self, ev) -> None:
        imp = ev.data["impact"]
        if imp.attacker == "player":
            col = {"metal": (255, 230, 150), "wood": (200, 160, 100), "brick": (200, 190, 180), "concrete": (200, 190, 180)}.get(imp.material, (255, 120, 90))
            self.effects.append([imp.position.copy(), 0.35, col, "hit"])

    def back_to_menu(self) -> None:
        self.state, self.session = "menu", None
        pygame.mouse.set_visible(True)
        pygame.event.set_grab(False)

    # ---- events --------------------------------------------------------------------------------------------------------------------------
    def handle(self, e: pygame.event.Event) -> None:
        if e.type == pygame.QUIT:
            self.running = False
        elif e.type == pygame.KEYDOWN:
            name = pygame.key.name(e.key)
            if e.key == pygame.K_F3:
                self.show_overlay = not self.show_overlay
            elif e.key == pygame.K_F4:
                self.show_twin = not self.show_twin
            elif e.key == pygame.K_F5 and self.session:
                self.session.pipeline.limiter.reset()
                self.message = ""
            if self.state == "menu":
                self._menu_key(e)
            elif self.state == "play":
                if e.key == pygame.K_ESCAPE:
                    self.paused = not self.paused
                elif e.key == pygame.K_F12 and self.session:
                    self.session.pipeline.emergency_stop()
                    self.message = "HAPTICS EMERGENCY STOP (F5 to reset)"
                elif self.paused and e.key == pygame.K_RETURN:
                    self.back_to_menu()
                elif not self.paused and self.inp and self.session:
                    self.keys.add(name)
                    self.inp.key_down(name, self.session.clock.now())
            elif self.state in ("results", "settings", "perf", "calib_tracking", "calib_haptic"):
                if e.key in (pygame.K_ESCAPE, pygame.K_RETURN):
                    self.back_to_menu()
                elif self.state == "settings":
                    self._settings_key(e)
        elif e.type == pygame.KEYUP:
            self.keys.discard(pygame.key.name(e.key))

    def _menu_key(self, e: pygame.event.Event) -> None:
        if e.key in (pygame.K_UP, pygame.K_w):
            self.sel = (self.sel - 1) % len(MENU)
        elif e.key in (pygame.K_DOWN, pygame.K_s):
            self.sel = (self.sel + 1) % len(MENU)
        elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
            _, mode = MENU[self.sel]
            if mode is None:
                self.running = False
            elif mode in (GameMode.TRAINING, GameMode.STORY, GameMode.ENCOUNTER, GameMode.BOSS):
                self.start(mode)
            elif mode is GameMode.SETTINGS:
                self.state, self.sel2 = "settings", 0
            elif mode is GameMode.PERFORMANCE:
                self.text_lines, self.state = run_benchmark("combo_chain", self.cfg, seconds=2.0).format().splitlines(), "perf"
            elif mode is GameMode.TRACKING_CALIBRATION:
                self.text_lines, self.state = self._tracking_cal().splitlines(), "calib_tracking"
            elif mode is GameMode.HAPTIC_CALIBRATION:
                self.text_lines, self.state = self._haptic_cal().splitlines(), "calib_haptic"

    def _settings_key(self, e: pygame.event.Event) -> None:
        if e.key in (pygame.K_UP, pygame.K_w):
            self.sel2 = (self.sel2 - 1) % len(self.SETTINGS)
        elif e.key in (pygame.K_DOWN, pygame.K_s):
            self.sel2 = (self.sel2 + 1) % len(self.SETTINGS)
        elif e.key in (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_a, pygame.K_d, pygame.K_SPACE):
            d = -1 if e.key in (pygame.K_LEFT, pygame.K_a) else 1
            name = self.SETTINGS[self.sel2]
            data = self.cfg.model_dump(mode="json")
            cyc = lambda cur, opts: opts[(opts.index(cur) + d) % len(opts)]   # noqa: E731
            if name == "difficulty":
                data["gameplay"]["difficulty"] = cyc(data["gameplay"]["difficulty"], ["easy", "normal", "hard"])
            elif name == "locomotion":
                data["gameplay"]["comfort"]["locomotion"] = cyc(data["gameplay"]["comfort"]["locomotion"], ["room_scale", "smooth", "teleport"])
            elif name == "turn_mode":
                data["gameplay"]["comfort"]["turn_mode"] = cyc(data["gameplay"]["comfort"]["turn_mode"], ["snap", "smooth"])
            elif name == "master_intensity":
                data["haptics"]["master_intensity"] = round(min(1.0, max(0.0, data["haptics"]["master_intensity"] + 0.1 * d)), 2)
            elif name == "filter":
                data["vr"]["filter"]["kind"] = cyc(data["vr"]["filter"]["kind"], ["one_euro", "ema", "moving_average", "velocity_aware", "none"])
            elif name == "overlay":
                self.show_overlay = not self.show_overlay
            self.cfg = Config.model_validate(data)
            save_config(self.cfg, user_dir() / "configs")

    def _tracking_cal(self) -> str:
        from ..simulation.scenarios import SCENARIOS

        _, rt = SCENARIOS["jab_cross"].build(self.cfg)
        res = run_tracking_calibration(rt, 1.0)
        self.cfg = res.apply(self.cfg)
        return res.format() + "\n\n(applied to this session; Enter to return)"

    def _haptic_cal(self) -> str:
        cfg = self.cfg.haptics
        pipe = HapticPipeline(cfg, make_simulated_pair(cfg, 3))
        t = [0.0]

        def adv(ms: float) -> None:
            t[0] += ms
            pipe.update(t[0])
        res = CalibrationSession(pipe, cfg, ScriptedResponder(), lambda: t[0], adv).run()
        self.profile = res.profile
        return "HAPTIC CALIBRATION (simulated glove, scripted comfort answers)\n" + "\n".join(res.log) + "\n\nUse `impact-vr calibrate` in a terminal for the interactive workflow. Enter to return."

    # ---- frame ----------------------------------------------------------------------------------------------------------------------------
    def update(self, real_dt: float) -> None:
        self.timer.add(real_dt)
        s = self.session
        if self.state != "play" or s is None or self.paused or self.inp is None:
            return
        rel = pygame.mouse.get_rel() if not self.headless else (0, 0)
        for _ in range(self.stepper.steps(real_dt)):
            self.inp.update(self.keys, rel, s.clock.now())
            rel = (0, 0)
            s.step()
            if s.done:
                self.state = "results"
                pygame.mouse.set_visible(True)
                pygame.event.set_grab(False)
                break
        self.effects = [[p, ttl - real_dt, c, k] for p, ttl, c, k in self.effects if ttl - real_dt > 0]

    def draw(self) -> None:
        scr, f = self.screen, self.fonts
        w, h = scr.get_size()
        if self.state == "menu":
            scr.fill((12, 14, 17))
            for i in range(0, h, 4):
                pygame.draw.line(scr, (15, 17, 20), (0, i), (w, i))
            scr.blit(f["huge"].render("IMPACT//VR", True, pal.UI_TEXT), (80, 60))
            pygame.draw.line(scr, pal.AMBER, (80, 122), (200, 122), 3)
            scr.blit(f["small"].render("VR beat-'em-up platform  -  haptic glove interface  -  simulation mode (no hardware needed)", True, pal.UI_DIM), (80, 132))
            for i, (label, _) in enumerate(MENU):
                scr.blit(f["title"].render(("> " if i == self.sel else "  ") + label, True, pal.AMBER if i == self.sel else pal.UI_TEXT), (90, 190 + i * 38))
            scr.blit(f["small"].render("W/S + Enter.  In-game: mouse look, J K H U jabs/hooks, B guard, P parry, G grab, T throw, F push, V shove, S duck, A/D weave,"
                                       " arrows move/turn, F3 overlay, F4 digital twin, F12 haptic e-stop", True, pal.UI_DIM), (40, h - 30))
        elif self.state in ("play", "results") and self.session is not None:
            self._draw_world()
        elif self.state == "settings":
            scr.fill((12, 14, 17))
            scr.blit(f["title"].render("SETTINGS", True, pal.UI_TEXT), (80, 50))
            vals = {"difficulty": self.cfg.gameplay.difficulty, "locomotion": self.cfg.gameplay.comfort.locomotion, "turn_mode": self.cfg.gameplay.comfort.turn_mode,
                    "master_intensity": f"{self.cfg.haptics.master_intensity:.1f}", "filter": self.cfg.vr.filter.kind.value, "overlay": "on" if self.show_overlay else "off"}
            for i, k in enumerate(self.SETTINGS):
                scr.blit(f["body"].render(f"{k:<18}< {vals[k]} >", True, pal.AMBER if i == self.sel2 else pal.UI_TEXT), (90, 120 + i * 32))
            scr.blit(f["small"].render("Left/Right change - saved to your user config - Esc back", True, pal.UI_DIM), (90, h - 50))
        else:
            scr.fill((12, 14, 17))
            for i, ln in enumerate(self.text_lines[:30]):
                scr.blit(f["small"].render(ln, True, pal.UI_TEXT), (50, 40 + i * 18))
            scr.blit(f["small"].render("Enter / Esc: back", True, pal.UI_DIM), (50, h - 36))

    def _draw_world(self) -> None:
        s, scr, f = self.session, self.screen, self.fonts
        assert s is not None
        w, h = scr.get_size()
        self.renderer.render(s, scr, ViewState(self.cfg.graphics.fov_degrees, self.cfg.graphics.draw_distance, effects=[tuple(x) for x in self.effects]))
        v, st = s.combat.vitals, s.combat.stats
        pygame.draw.rect(scr, (30, 32, 34), (24, h - 38, 220, 10))
        pygame.draw.rect(scr, pal.RED if v.health < 30 else pal.AMBER, (24, h - 38, int(220 * v.health / v.max_health), 10))
        scr.blit(f["small"].render(f"{s.mode.value.upper()}  combo x{st.combo}  score {st.score}  defeated {s.defeated}  strikes {st.strikes}  blocks {st.blocks}  parries {st.parries}", True, pal.UI_TEXT), (24, h - 62))
        if s.director.active is not None:
            scr.blit(f["title"].render(s.director.active.title.upper(), True, pal.UI_TEXT), (w // 2 - 120, 18))
        if s.mode is GameMode.TRAINING:
            for i, (label, ok) in enumerate(s.state.checklist.items()):
                scr.blit(f["small"].render(("[x] " if ok else "[ ] ") + label, True, pal.AMBER if ok else pal.UI_DIM), (w - 250, 18 + i * 17))
        glove_monitor.draw_pygame(scr, (w - 300, h - 220, 290, 210), s.pipeline.actuator_levels(s.clock.now() * 1000.0), f["small"])
        if s.pipeline.limiter.tripped:
            scr.blit(f["title"].render("HAPTIC SAFETY TRIPPED (F5 to reset)", True, pal.RED), (24, 60))
        if self.message:
            scr.blit(f["small"].render(self.message, True, pal.AMBER), (24, 90))
        if self.show_twin:
            draw_digital_twin(scr, pygame.Rect(w - 480, 120, 470, 330), s, f, self.orbit)
        if self.show_overlay:
            draw_overlay(scr, f, overlay_lines(s, self.timer.fps, self.timer.mean_ms))
        if self.paused:
            scr.blit(f["huge"].render("PAUSED", True, pal.UI_TEXT), (w // 2 - 110, h // 2 - 40))
            scr.blit(f["small"].render("Esc resume - Enter quit to menu", True, pal.UI_DIM), (w // 2 - 120, h // 2 + 20))
        if self.state == "results" and s.result is not None:
            r = s.result
            ov = pygame.Surface((w, h), pygame.SRCALPHA)
            ov.fill((8, 10, 12, 200))
            scr.blit(ov, (0, 0))
            scr.blit(f["huge"].render("VICTORY" if r.success else "DEFEAT", True, pal.UI_TEXT if r.success else pal.RED), (w // 2 - 130, 120))
            for i, ln in enumerate([f"mode {r.mode}   time {r.time_s:.1f}s   grade {r.grade}   score {r.score}", f"enemies defeated {r.enemies_defeated}   damage taken {r.damage_taken:.0f}",
                                    f"strikes {r.strikes}  hits {r.hits}  accuracy {r.accuracy * 100:.0f}%  best combo {r.best_combo}  blocks {r.blocks}  parries {r.parries}", "Enter: back to menu"]):
                scr.blit(f["body"].render(ln, True, pal.UI_TEXT), (w // 2 - 330, 220 + i * 30))

    def run(self) -> None:
        last = time.perf_counter()
        while self.running:
            now = time.perf_counter()
            dt, last = now - last, now
            for e in pygame.event.get():
                self.handle(e)
            self.update(dt)
            self.draw()
            pygame.display.flip()
            self.clock.tick(self.cfg.graphics.fps_cap)
        self.shutdown()

    def shutdown(self) -> None:
        self.audio.shutdown()
        pygame.quit()
