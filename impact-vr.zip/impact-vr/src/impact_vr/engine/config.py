"""Typed configuration (pydantic) loaded from `configs/*.toml`. No magic numbers outside this file and the TOMLs."""

from __future__ import annotations

import os
import tomllib
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class _M(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


# ------------------------------------------------------------------------------------------------- vr.toml
class FilterKind(str, Enum):
    NONE = "none"
    EMA = "ema"
    MOVING_AVERAGE = "moving_average"
    ONE_EURO = "one_euro"
    VELOCITY_AWARE = "velocity_aware"


class Stance(str, Enum):
    ORTHODOX = "orthodox"   # left hand leads (jab), right hand is the rear (cross)
    SOUTHPAW = "southpaw"


class FilterCfg(_M):
    kind: FilterKind = FilterKind.ONE_EURO
    ema_alpha: float = Field(0.55, gt=0.0, le=1.0)
    ma_window: int = Field(3, ge=1, le=16)
    one_euro_min_cutoff: float = Field(2.0, gt=0.0)      # Hz: jitter suppression at rest
    one_euro_beta: float = Field(18.0, ge=0.0)           # speed coefficient: lag removal in fast motion
    one_euro_d_cutoff: float = Field(8.0, gt=0.0)
    va_slow_alpha: float = Field(0.25, gt=0.0, le=1.0)
    va_fast_alpha: float = Field(0.95, gt=0.0, le=1.0)
    va_speed_knee: float = Field(1.5, gt=0.0)            # m/s where the filter opens up
    velocity_cutoff_hz: float = Field(20.0, gt=0.0)


class VRCfg(_M):
    target_fps: float = Field(90.0, gt=10.0, le=240.0)
    play_space_width: float = Field(2.5, gt=0.5)
    play_space_depth: float = Field(2.5, gt=0.5)
    standing_eye_height: float = Field(1.65, gt=1.0, lt=2.2)
    min_hand_confidence: float = Field(0.35, ge=0.0, le=1.0)
    prefer_hand_tracking: bool = True
    stance: Stance = Stance.ORTHODOX
    dominant_hand: str = Field("right", pattern="^(left|right)$")
    filter: FilterCfg = FilterCfg()


# ------------------------------------------------------------------------------------------------- haptics.toml
class SafetyCfg(_M):
    hard_max_intensity: float = Field(0.85, gt=0.0, le=1.0)
    max_duration_ms: int = Field(600, ge=1, le=5000)
    duty_window_ms: int = Field(1000, ge=100)
    max_duty_cycle: float = Field(0.5, gt=0.0, le=1.0)
    max_commands_per_actuator_hz: float = Field(60.0, gt=0.0)
    max_commands_total_hz: float = Field(300.0, gt=0.0)
    thermal_warn_c: float = Field(38.0, gt=20.0)
    thermal_limit_c: float = Field(43.0, gt=20.0)
    max_comm_errors: int = Field(25, ge=1)
    require_connection: bool = True
    latch_on_trip: bool = True

    @model_validator(mode="after")
    def _order(self) -> SafetyCfg:
        if self.thermal_warn_c >= self.thermal_limit_c:
            raise ValueError("thermal_warn_c must be below thermal_limit_c")
        return self


class SchedulerCfg(_M):
    queue_capacity: int = Field(256, ge=8)
    cooldown_ms_critical: int = 0
    cooldown_ms_major: int = 25
    cooldown_ms_combat: int = 40
    cooldown_ms_interaction: int = 80
    cooldown_ms_ambient: int = 250
    repeat_window_ms: int = 220
    repeat_decay: float = Field(0.65, gt=0.0, le=1.0)
    repeat_floor: float = Field(0.25, ge=0.0, le=1.0)
    duck_factor: float = Field(0.35, ge=0.0, le=1.0)
    combine_window_ms: int = 12
    min_command_interval_ms: int = 8


class HapticsCfg(_M):
    enabled: bool = True
    master_intensity: float = Field(0.8, ge=0.0, le=1.0)
    uncalibrated_max_intensity: float = Field(0.5, gt=0.0, le=1.0)
    profile_dir: str = ""
    energy_ref_j: float = Field(60.0, gt=0.0)       # impact energy that maps to full-scale haptic intensity
    glove_latency_ms: float = Field(6.0, ge=0.0)    # simulated transport latency
    glove_jitter_ms: float = Field(1.5, ge=0.0)
    glove_drop_probability: float = Field(0.0, ge=0.0, le=1.0)
    glove_update_hz: float = Field(500.0, gt=0.0)
    safety: SafetyCfg = SafetyCfg()
    scheduler: SchedulerCfg = SchedulerCfg()


# ------------------------------------------------------------------------------------------------- physics.toml
class MaterialCfg(_M):
    restitution: float = Field(0.2, ge=0.0, le=1.0)
    hardness: float = Field(0.5, ge=0.0, le=1.0)    # 0 = soft, 1 = rigid
    impact_pattern: str = "LIGHT_CONTACT"


class PhysicsCfg(_M):
    step_hz: float = Field(90.0, gt=10.0)
    effective_mass_kg: dict[str, float] = Field(
        default_factory=lambda: {"jab": 1.6, "cross": 2.4, "hook": 2.6, "uppercut": 2.3, "hammer_fist": 2.8,
                                 "palm_strike": 2.2, "backhand": 1.7, "elbow_strike": 3.4, "push": 5.0, "shove": 6.0,
                                 "grab": 1.0, "touch": 0.8}
    )
    materials: dict[str, MaterialCfg] = Field(
        default_factory=lambda: {
            "flesh": MaterialCfg(restitution=0.15, hardness=0.25, impact_pattern="FLESH_IMPACT"),
            "metal": MaterialCfg(restitution=0.35, hardness=0.95, impact_pattern="METAL_IMPACT"),
            "wood": MaterialCfg(restitution=0.3, hardness=0.6, impact_pattern="WOOD_IMPACT"),
            "brick": MaterialCfg(restitution=0.1, hardness=0.9, impact_pattern="WALL_CONTACT"),
            "concrete": MaterialCfg(restitution=0.08, hardness=1.0, impact_pattern="WALL_CONTACT"),
            "cloth": MaterialCfg(restitution=0.1, hardness=0.1, impact_pattern="LIGHT_CONTACT"),
            "rubber": MaterialCfg(restitution=0.5, hardness=0.35, impact_pattern="HEAVY_IMPACT"),
        }
    )
    glancing_exponent: float = Field(1.5, gt=0.0)
    min_contact_speed: float = Field(0.6, gt=0.0)
    hit_lockout_s: float = Field(0.35, ge=0.0)
    fist_radius: float = Field(0.048, gt=0.0)
    palm_radius: float = Field(0.055, gt=0.0)
    forearm_radius: float = Field(0.045, gt=0.0)
    forearm_length: float = Field(0.27, gt=0.0)
    sweep_substeps_max: int = Field(24, ge=1)
    knockback_per_impulse: float = Field(0.08, ge=0.0)
    gravity: float = 9.81


# ------------------------------------------------------------------------------------------------- gameplay.toml
class DamageCfg(_M):
    energy_half_j: float = Field(25.0, gt=0.0)       # energy giving half of max base damage (saturating curve)
    max_base_damage: float = Field(60.0, gt=0.0)
    region_multiplier: dict[str, float] = Field(
        default_factory=lambda: {"HEAD": 1.6, "TORSO": 1.0, "CORE": 1.25, "LEFT_ARM": 0.5, "RIGHT_ARM": 0.5,
                                 "LEFT_LEG": 0.6, "RIGHT_LEG": 0.6, "WEAPON": 0.1, "ENVIRONMENT": 0.0}
    )
    stagger_per_joule: float = Field(1.1, ge=0.0)
    block_reduction: float = Field(0.85, ge=0.0, le=1.0)
    combo_window_s: float = Field(1.2, gt=0.0)
    combo_bonus_per_hit: float = Field(0.06, ge=0.0)


class GuardCfg(_M):
    hands_near_head_m: float = Field(0.38, gt=0.0)
    hold_min_s: float = Field(0.08, ge=0.0)
    full_guard_s: float = Field(0.22, gt=0.0)        # raising earlier than this before impact = timing penalty
    coverage_radius_m: float = Field(0.16, gt=0.0)
    parry_window_s: float = Field(0.3, gt=0.0)
    parry_min_speed: float = Field(1.2, gt=0.0)
    parry_max_speed: float = Field(5.0, gt=0.0)


class ComfortCfg(_M):
    locomotion: str = Field("room_scale", pattern="^(room_scale|smooth|teleport)$")
    turn_mode: str = Field("snap", pattern="^(snap|smooth)$")
    snap_degrees: float = Field(30.0, gt=0.0, le=90.0)
    smooth_turn_dps: float = Field(100.0, gt=0.0)
    move_speed: float = Field(1.6, gt=0.0)
    vignette: float = Field(0.4, ge=0.0, le=1.0)
    seated: bool = False
    teleport_range: float = Field(4.0, gt=0.0)


class EncounterCfg(_M):
    max_simultaneous_attackers: int = Field(2, ge=1)
    attack_token_cooldown_s: float = Field(0.9, ge=0.0)
    ring_radius_m: float = Field(2.4, gt=0.5)
    max_enemies_alive: int = Field(4, ge=1)


class GameplayCfg(_M):
    seed: int = 20260101
    player_health: float = Field(100.0, gt=0.0)
    damage: DamageCfg = DamageCfg()
    guard: GuardCfg = GuardCfg()
    comfort: ComfortCfg = ComfortCfg()
    encounter: EncounterCfg = EncounterCfg()
    difficulty: str = Field("normal", pattern="^(easy|normal|hard)$")
    enemy_damage_scale: dict[str, float] = Field(default_factory=lambda: {"easy": 0.6, "normal": 1.0, "hard": 1.4})


# ------------------------------------------------------------------------------------------------- graphics / audio
class GraphicsCfg(_M):
    backend: str = Field("software", pattern="^(software|moderngl)$")
    resolution: str = Field("1280x720", pattern=r"^\d{3,5}x\d{3,5}$")
    fov_degrees: float = Field(95.0, ge=50.0, le=130.0)
    draw_distance: float = Field(60.0, gt=5.0)
    fps_cap: int = Field(90, ge=15, le=240)
    show_overlay: bool = False

    @property
    def size(self) -> tuple[int, int]:
        w, _, h = self.resolution.partition("x")
        return int(w), int(h)


class AudioCfg(_M):
    backend: str = Field("pygame", pattern="^(pygame|null)$")
    master: float = Field(0.8, ge=0.0, le=1.0)
    spatial: bool = True
    max_voices: int = Field(24, ge=1)


class Config(_M):
    vr: VRCfg = VRCfg()
    haptics: HapticsCfg = HapticsCfg()
    physics: PhysicsCfg = PhysicsCfg()
    gameplay: GameplayCfg = GameplayCfg()
    graphics: GraphicsCfg = GraphicsCfg()
    audio: AudioCfg = AudioCfg()


FILES = ("vr", "haptics", "physics", "gameplay", "graphics", "audio")


def repo_root() -> Path:
    env = os.environ.get("IMPACT_VR_ROOT")
    if env:
        return Path(env)
    for p in Path(__file__).resolve().parents:
        if (p / "configs" / "vr.toml").exists():
            return p
    return Path.cwd()


def user_dir() -> Path:
    p = Path(os.environ.get("IMPACT_VR_HOME", str(Path.home() / ".impact_vr")))
    p.mkdir(parents=True, exist_ok=True)
    return p


def load_config(directory: Path | None = None) -> Config:
    d = directory or (repo_root() / "configs")
    raw: dict[str, Any] = {}
    for name in FILES:
        f = d / f"{name}.toml"
        if f.exists():
            raw[name] = tomllib.loads(f.read_text())
    return Config.model_validate(raw)


def _toml_value(v: Any) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, str):
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_toml_value(x) for x in v) + "]"
    raise TypeError(type(v))


def dump_toml(data: dict[str, Any], prefix: str = "") -> str:
    """Minimal TOML writer (scalars, lists, nested tables) - enough for our config schema."""
    lines: list[str] = []
    tables: list[tuple[str, dict[str, Any]]] = []
    for k, v in data.items():
        if isinstance(v, dict):
            tables.append((k, v))
        else:
            lines.append(f"{k} = {_toml_value(v)}")
    out = "\n".join(lines)
    for k, v in tables:
        name = f"{prefix}.{k}" if prefix else k
        body = dump_toml(v, name)
        out += f"\n\n[{name}]\n{body}" if body.strip() else ""
    return out.strip() + "\n"


def save_config(cfg: Config, directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    dump = cfg.model_dump(mode="json")
    for name in FILES:
        (directory / f"{name}.toml").write_text(dump_toml(dump[name]))
