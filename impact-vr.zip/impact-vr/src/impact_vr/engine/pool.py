"""Object pool and bounded queue (no unbounded growth on the critical path)."""

from __future__ import annotations

from collections import deque
from collections.abc import Callable, Iterator
from typing import Generic, TypeVar

T = TypeVar("T")


class ObjectPool(Generic[T]):
    def __init__(self, factory: Callable[[], T], reset: Callable[[T], None], size: int = 64) -> None:
        self._factory, self._reset = factory, reset
        self._free: list[T] = [factory() for _ in range(size)]
        self.created = size

    def acquire(self) -> T:
        if self._free:
            return self._free.pop()
        self.created += 1
        return self._factory()

    def release(self, obj: T) -> None:
        self._reset(obj)
        self._free.append(obj)

    @property
    def available(self) -> int:
        return len(self._free)


class BoundedQueue(Generic[T]):
    """FIFO with a hard capacity; `push` returns False (and counts a drop) when full."""

    def __init__(self, capacity: int) -> None:
        self.capacity = capacity
        self._q: deque[T] = deque()
        self.dropped = 0

    def push(self, item: T) -> bool:
        if len(self._q) >= self.capacity:
            self.dropped += 1
            return False
        self._q.append(item)
        return True

    def pop(self) -> T | None:
        return self._q.popleft() if self._q else None

    def __len__(self) -> int:
        return len(self._q)

    def __iter__(self) -> Iterator[T]:
        return iter(self._q)
