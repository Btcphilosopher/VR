"""Game modes and progression: MAIN MENU / TRAINING ROOM / STORY / ENCOUNTER / BOSS / SETTINGS / calibrations / performance."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class GameMode(str, Enum):
    MAIN_MENU = "main_menu"
    TRAINING = "training"
    STORY = "story"
    ENCOUNTER = "encounter"
    BOSS = "boss"
    SETTINGS = "settings"
    HAPTIC_CALIBRATION = "haptic_calibration"
    TRACKING_CALIBRATION = "tracking_calibration"
    PERFORMANCE = "performance"


GAMEPLAY_MODES = (GameMode.TRAINING, GameMode.STORY, GameMode.ENCOUNTER, GameMode.BOSS)
STORY_ORDER = ["arch_street", "loading_yard", "viaduct", "foreman"]


@dataclass
class TrainingChecklist:
    """What the player has demonstrated in the training room."""

    punches: bool = False
    blocks: bool = False
    grabs: bool = False
    environment_impacts: bool = False
    glove_feedback: bool = False
    parries: bool = False

    @property
    def complete(self) -> bool:
        return all((self.punches, self.blocks, self.grabs, self.environment_impacts, self.glove_feedback))

    def items(self) -> list[tuple[str, bool]]:
        return [("Throw punches", self.punches), ("Raise a guard", self.blocks), ("Grab an object", self.grabs), ("Hit the environment", self.environment_impacts),
                ("Feel glove feedback", self.glove_feedback), ("Parry (bonus)", self.parries)]


@dataclass
class SessionResult:
    success: bool
    mode: str
    time_s: float
    enemies_defeated: int
    damage_taken: float
    strikes: int
    hits: int
    accuracy: float
    best_combo: int
    blocks: int
    parries: int
    score: int
    grade: str
    reason: str = ""


def grade(score: int, damage: float, accuracy: float) -> str:
    s = score / 100.0 + accuracy * 4 - damage / 40.0
    return "S" if s >= 10 else "A" if s >= 7 else "B" if s >= 4 else "C" if s >= 2 else "D"


@dataclass
class ModeState:
    mode: GameMode
    chapter: int = 0
    queue: list[str] = field(default_factory=list)
    finished: bool = False
    success: bool = False
    checklist: TrainingChecklist = field(default_factory=TrainingChecklist)
