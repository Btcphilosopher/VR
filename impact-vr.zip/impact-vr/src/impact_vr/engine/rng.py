"""Named deterministic random streams."""

from __future__ import annotations

import hashlib
import random


class Rng:
    def __init__(self, seed: int = 1) -> None:
        self.seed = seed
        self._s: dict[str, random.Random] = {}

    def stream(self, name: str) -> random.Random:
        r = self._s.get(name)
        if r is None:
            h = hashlib.sha256(f"{self.seed}:{name}".encode()).digest()
            r = random.Random(int.from_bytes(h[:8], "little"))
            self._s[name] = r
        return r
