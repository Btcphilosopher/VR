"""Vector / quaternion / transform helpers (NumPy).

World convention for the whole engine: **x right, y up, z forward** (left-handed 'game' frame). Quaternions are (x, y, z, w).
OpenXR uses x right, y up, -z forward; the conversion lives in `openxr_to_world` and is applied only inside VR adapters, so
no other subsystem ever sees an OpenXR frame.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

Vec = np.ndarray
EPS = 1e-9


def v3(x: float = 0.0, y: float = 0.0, z: float = 0.0) -> Vec:
    return np.array([x, y, z], dtype=np.float64)


def norm(v: Vec) -> float:
    return float(np.sqrt(np.dot(v, v)))


def unit(v: Vec) -> Vec:
    n = norm(v)
    return v / n if n > EPS else np.zeros(3)


def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


def lerp(a, b, t: float):
    return a + (b - a) * t


def smoothstep(e0: float, e1: float, x: float) -> float:
    t = clamp((x - e0) / (e1 - e0), 0.0, 1.0) if e1 != e0 else float(x >= e1)
    return t * t * (3.0 - 2.0 * t)


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-60.0, min(60.0, x))))


def wrap_pi(a: float) -> float:
    return (a + math.pi) % (2 * math.pi) - math.pi


# ---- quaternions ---------------------------------------------------------------------------------------------
QIDENT = np.array([0.0, 0.0, 0.0, 1.0])


def q_norm(q: Vec) -> Vec:
    n = float(np.sqrt(np.dot(q, q)))
    return q / n if n > EPS else QIDENT.copy()


def q_mul(a: Vec, b: Vec) -> Vec:
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return np.array(
        [
            aw * bx + ax * bw + ay * bz - az * by,
            aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw,
            aw * bw - ax * bx - ay * by - az * bz,
        ]
    )


def q_conj(q: Vec) -> Vec:
    return np.array([-q[0], -q[1], -q[2], q[3]])


def q_axis_angle(axis: Vec, angle: float) -> Vec:
    a = unit(axis)
    s = math.sin(angle / 2)
    return np.array([a[0] * s, a[1] * s, a[2] * s, math.cos(angle / 2)])


def q_rotate(q: Vec, v: Vec) -> Vec:
    """Rotate v by unit quaternion q (works on (3,) and (N, 3) arrays) without np.cross overhead."""
    x, y, z, w = float(q[0]), float(q[1]), float(q[2]), float(q[3])
    vv = np.asarray(v, dtype=np.float64)
    vx, vy, vz = vv[..., 0], vv[..., 1], vv[..., 2]
    tx = 2.0 * (y * vz - z * vy)
    ty = 2.0 * (z * vx - x * vz)
    tz = 2.0 * (x * vy - y * vx)
    rx = vx + w * tx + (y * tz - z * ty)
    ry = vy + w * ty + (z * tx - x * tz)
    rz = vz + w * tz + (x * ty - y * tx)
    return np.stack([rx, ry, rz], axis=-1)


def q_mul_many(q: Vec, Q: np.ndarray) -> np.ndarray:
    """q * Q[i] for every row of Q (N, 4), normalised."""
    ax, ay, az, aw = (float(q[0]), float(q[1]), float(q[2]), float(q[3]))
    bx, by, bz, bw = Q[:, 0], Q[:, 1], Q[:, 2], Q[:, 3]
    out = np.stack([aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx,
                    aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz], axis=1)
    return out / np.maximum(np.linalg.norm(out, axis=1, keepdims=True), EPS)


def q_from_yaw(yaw: float) -> Vec:
    return q_axis_angle(v3(0, 1, 0), yaw)


def q_from_euler(yaw: float, pitch: float, roll: float) -> Vec:
    """Yaw about +y, pitch about +x, roll about +z, applied roll->pitch->yaw."""
    return q_mul(q_from_yaw(yaw), q_mul(q_axis_angle(v3(1, 0, 0), pitch), q_axis_angle(v3(0, 0, 1), roll)))


def q_to_yaw(q: Vec) -> float:
    f = q_rotate(q, v3(0, 0, 1))
    return math.atan2(f[0], f[2])


def q_slerp(a: Vec, b: Vec, t: float) -> Vec:
    d = float(np.dot(a, b))
    if d < 0.0:
        b, d = -b, -d
    if d > 0.9995:
        return q_norm(a + (b - a) * t)
    th = math.acos(clamp(d, -1.0, 1.0))
    s = math.sin(th)
    return q_norm(a * (math.sin((1 - t) * th) / s) + b * (math.sin(t * th) / s))


def q_angle_between(a: Vec, b: Vec) -> float:
    d = abs(float(np.dot(a, b)))
    return 2.0 * math.acos(clamp(d, 0.0, 1.0))


def q_angular_velocity(q0: Vec, q1: Vec, dt: float) -> Vec:
    """World-frame angular velocity (rad/s) taking q0 -> q1 over dt."""
    if dt <= 0:
        return np.zeros(3)
    dq = q_mul(q1, q_conj(q0))
    if dq[3] < 0:
        dq = -dq
    s = norm(dq[:3])
    if s < EPS:
        return np.zeros(3)
    ang = 2.0 * math.atan2(s, dq[3])
    return dq[:3] / s * (ang / dt)


def q_from_fwd_up(fwd: Vec, up: Vec) -> Vec:
    """Quaternion whose local +z maps to `fwd` and local +y to (the component of) `up` orthogonal to it."""
    z = unit(fwd)
    x = unit(np.cross(up, z))
    if norm(x) < EPS:
        x = unit(np.cross(v3(1, 0, 0) if abs(z[0]) < 0.9 else v3(0, 0, 1), z))
    y = np.cross(z, x)
    m = np.stack([x, y, z], axis=1)
    t = m[0, 0] + m[1, 1] + m[2, 2]
    if t > 0:
        s = math.sqrt(t + 1.0) * 2
        q = np.array([(m[2, 1] - m[1, 2]) / s, (m[0, 2] - m[2, 0]) / s, (m[1, 0] - m[0, 1]) / s, 0.25 * s])
    elif m[0, 0] > m[1, 1] and m[0, 0] > m[2, 2]:
        s = math.sqrt(1.0 + m[0, 0] - m[1, 1] - m[2, 2]) * 2
        q = np.array([0.25 * s, (m[0, 1] + m[1, 0]) / s, (m[0, 2] + m[2, 0]) / s, (m[2, 1] - m[1, 2]) / s])
    elif m[1, 1] > m[2, 2]:
        s = math.sqrt(1.0 + m[1, 1] - m[0, 0] - m[2, 2]) * 2
        q = np.array([(m[0, 1] + m[1, 0]) / s, 0.25 * s, (m[1, 2] + m[2, 1]) / s, (m[0, 2] - m[2, 0]) / s])
    else:
        s = math.sqrt(1.0 + m[2, 2] - m[0, 0] - m[1, 1]) * 2
        q = np.array([(m[0, 2] + m[2, 0]) / s, (m[1, 2] + m[2, 1]) / s, 0.25 * s, (m[1, 0] - m[0, 1]) / s])
    return q_norm(q)


# ---- transforms -----------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Transform:
    """Rigid transform: world = rotate(q, local) + p."""

    p: Vec
    q: Vec

    @staticmethod
    def identity() -> Transform:
        return Transform(np.zeros(3), QIDENT.copy())

    def apply(self, pts: Vec) -> Vec:
        return q_rotate(self.q, pts) + self.p

    def apply_dir(self, d: Vec) -> Vec:
        return q_rotate(self.q, d)

    def inverse(self) -> Transform:
        qi = q_conj(self.q)
        return Transform(-q_rotate(qi, self.p), qi)

    def compose(self, other: Transform) -> Transform:
        """self * other (other applied first)."""
        return Transform(self.apply(other.p), q_norm(q_mul(self.q, other.q)))


def openxr_to_world(p: Vec, q: Vec) -> tuple[Vec, Vec]:
    """OpenXR (x right, y up, -z fwd) -> engine (x right, y up, +z fwd): mirror z.

    A reflection flips handedness, so the quaternion's x/y components change sign along with z.
    """
    pw = np.array([p[0], p[1], -p[2]])
    qw = np.array([-q[0], -q[1], q[2], q[3]])
    return pw, qw


def world_to_openxr(p: Vec, q: Vec) -> tuple[Vec, Vec]:
    return openxr_to_world(p, q)  # the mirror is an involution


def body_frame(head_p: Vec, head_q: Vec) -> Transform:
    """Yaw-only frame at the head: x right, y up, z forward. Used to describe strikes relative to the fighter."""
    f = q_rotate(head_q, v3(0, 0, 1))
    yaw = math.atan2(f[0], f[2])
    return Transform(head_p.copy(), q_from_yaw(yaw))


def dist_point_segment(p: Vec, a: Vec, b: Vec) -> tuple[float, float]:
    ab = b - a
    t = float(np.dot(p - a, ab) / max(float(np.dot(ab, ab)), EPS))
    t = clamp(t, 0.0, 1.0)
    return norm(p - (a + ab * t)), t
