"""Player locomotion & comfort: room-scale, smooth, teleport, snap/smooth turning, crouch/lean readouts, vignette.

The rig (locomotion offset) is separate from physical movement: walking around your play area moves your head in tracking space
(room-scale); the rig only moves for stick locomotion / teleport / turning."""

from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from ..vr.types import VRFrame
from . import events as E
from .config import ComfortCfg
from .events import EventBus
from .mathx import Vec, clamp, norm, q_to_yaw, unit, v3, wrap_pi
from .rig import Rig


@dataclass
class LocoState:
    vignette: float = 0.0
    teleport_arc: list[Vec] = field(default_factory=list)
    teleport_target: Vec | None = None
    crouch: float = 0.0           # metres below standing height
    lean: Vec = field(default_factory=lambda: v3())
    moved: float = 0.0
    turned: float = 0.0


class LocomotionController:
    def __init__(self, cfg: ComfortCfg, bus: EventBus, physics, bounds, standing_height: float = 1.65) -> None:
        self.cfg, self.bus, self.physics, self.bounds = cfg, bus, physics, bounds
        self.state = LocoState()
        self._snap_armed = True
        self._tp_aim = False
        self._tp_target: Vec | None = None
        self.standing = standing_height
        self._moved_acc = 0.0

    def update(self, frame: VRFrame, rig: Rig, dt: float) -> LocoState:
        st = self.state
        st.moved = st.turned = 0.0
        head = frame.head
        left, right = frame.controllers.get("left"), frame.controllers.get("right")
        head_yaw = q_to_yaw(head.q)
        st.crouch = max(0.0, self.standing - float(head.p[1]))
        # turning (right stick) ---------------------------------------------------------------------------------------------------
        tx = right.stick[0] if right else 0.0
        dyaw = 0.0
        if self.cfg.turn_mode == "snap":
            if abs(tx) > 0.7 and self._snap_armed:
                dyaw = math.copysign(math.radians(self.cfg.snap_degrees), tx)
                self._snap_armed = False
            elif abs(tx) < 0.3:
                self._snap_armed = True
        elif abs(tx) > 0.15:
            dyaw = math.radians(self.cfg.smooth_turn_dps) * tx * dt * (0.6 if self.cfg.vignette > 0 else 1.0)
        if dyaw:
            hp_before = rig.point(v3(head.p[0], 0.0, head.p[2]))
            rig.yaw = wrap_pi(rig.yaw + dyaw)
            hp_after = rig.point(v3(head.p[0], 0.0, head.p[2]))
            rig.pos = rig.pos + (hp_before - hp_after)          # rotate about the head, not the play-space origin
            st.turned = dyaw
        # translation -------------------------------------------------------------------------------------------------------------
        rig.vel = v3()
        ls = left.stick if left else (0.0, 0.0)
        mode = self.cfg.locomotion
        st.teleport_arc, st.teleport_target = [], None
        if mode == "smooth" and norm(np.array(ls)) > 0.12:
            fwd = v3(math.sin(rig.yaw + head_yaw), 0.0, math.cos(rig.yaw + head_yaw))
            side = v3(fwd[2], 0.0, -fwd[0])
            vel = (fwd * ls[1] + side * ls[0]) * self.cfg.move_speed
            new = rig.pos + vel * dt
            if not self.physics.blocked(rig.point(v3(head.p[0], 0.0, head.p[2])) + vel * dt, 0.3):
                st.moved = norm(new - rig.pos)
                rig.pos, rig.vel = new, vel
        elif mode == "teleport":
            if ls[1] > 0.6 and left is not None:
                self._tp_aim = True
                arc, tgt = self._arc(left, rig)
                st.teleport_arc = arc
                self._tp_target = tgt if (tgt is not None and self._valid(tgt, rig, head)) else None
                st.teleport_target = self._tp_target
            elif self._tp_aim:
                self._tp_aim = False
                if self._tp_target is not None:
                    hp = rig.point(v3(head.p[0], 0.0, head.p[2]))
                    st.moved = norm(self._tp_target - hp)
                    rig.pos = rig.pos + (self._tp_target - hp)
                    self.bus.emit(E.PLAYER_MOVED, kind="teleport", x=round(float(self._tp_target[0]), 3), z=round(float(self._tp_target[2]), 3))
                self._tp_target = None
        # keep the head inside the arena --------------------------------------------------------------------------------------------
        hw = rig.point(v3(head.p[0], 0.0, head.p[2]))
        x0, z0, x1, z1 = self.bounds
        cx, cz = min(max(hw[0], x0 + 0.4), x1 - 0.4), min(max(hw[2], z0 + 0.4), z1 - 0.4)
        if abs(cx - hw[0]) > 1e-9 or abs(cz - hw[2]) > 1e-9:
            rig.pos = rig.pos + v3(cx - hw[0], 0.0, cz - hw[2])
        self._moved_acc += st.moved
        if self._moved_acc > 0.5:
            self._moved_acc = 0.0
            self.bus.emit(E.PLAYER_MOVED, kind="locomotion", x=round(float(rig.pos[0]), 3), z=round(float(rig.pos[2]), 3), yaw=round(rig.yaw, 3))
        speed = norm(rig.vel)
        st.vignette = clamp(self.cfg.vignette * (speed / max(self.cfg.move_speed, 1e-6) + abs(st.turned) / math.radians(60) * (0.5 if self.cfg.turn_mode == "snap" else 1.0)), 0.0, 1.0)
        return st

    def _arc(self, c, rig: Rig) -> tuple[list[Vec], Vec | None]:
        origin = rig.point(c.pose.p)
        v = unit(rig.direction(c.pose.forward())) * 4.2 + v3(0, 1.5, 0)
        p = origin.copy()
        pts = []
        for _ in range(40):
            pts.append(p.copy())
            v = v + v3(0, -9.81 * 0.05, 0)
            p = p + v * 0.05
            if p[1] <= 0.0:
                land = v3(p[0], 0.0, p[2])
                pts.append(land)
                return pts, land
        return pts, None

    def _valid(self, tgt: Vec, rig: Rig, head) -> bool:
        hp = rig.point(v3(head.p[0], 0.0, head.p[2]))
        if norm(tgt - hp) > self.cfg.teleport_range:
            return False
        x0, z0, x1, z1 = self.bounds
        if not (x0 + 0.4 <= tgt[0] <= x1 - 0.4 and z0 + 0.4 <= tgt[2] <= z1 - 0.4):
            return False
        return not self.physics.blocked(tgt, 0.3)
