"""Rig (locomotion) transform: tracking space (play space, continuous physical motion) -> world."""

from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np

from .mathx import Vec, q_conj, q_from_yaw, q_mul_many, q_rotate, v3


@dataclass
class Rig:
    pos: Vec = field(default_factory=lambda: v3())
    yaw: float = 0.0
    vel: Vec = field(default_factory=lambda: v3())          # linear velocity from locomotion (not physical walking)

    @property
    def q(self) -> Vec:
        return q_from_yaw(self.yaw)

    def point(self, p: Vec) -> Vec:
        return q_rotate(self.q, p) + self.pos

    def points(self, p: np.ndarray) -> np.ndarray:
        return q_rotate(self.q, p) + self.pos

    def direction(self, d: Vec) -> Vec:
        return q_rotate(self.q, d)

    def inv_point(self, p: Vec) -> Vec:
        return q_rotate(q_conj(self.q), p - self.pos)

    def inv_direction(self, d: Vec) -> Vec:
        return q_rotate(q_conj(self.q), d)


def hand_to_world(st, rig: Rig):
    """HandState (tracking space) -> HandState (world). Velocities are rotated and rig motion is added."""
    q = rig.q
    pos = rig.points(st.positions)
    ori = q_mul_many(q, st.orientations)
    vel = q_rotate(q, st.velocities) + rig.vel
    return replace(st, positions=pos, orientations=ori, velocities=vel, accelerations=q_rotate(q, st.accelerations),
                   palm_velocity=q_rotate(q, st.palm_velocity) + rig.vel, wrist_velocity=q_rotate(q, st.wrist_velocity) + rig.vel,
                   angular_velocity=q_rotate(q, st.angular_velocity), palm_normal=q_rotate(q, st.palm_normal),
                   forward=q_rotate(q, st.forward), side=q_rotate(q, st.side))


def shift_state(st, head_p: Vec, head_vel: Vec):
    """Head-relative HandState -> absolute tracking-space HandState (adds the head's translation and velocity)."""
    return replace(st, positions=st.positions + head_p, velocities=st.velocities + head_vel,
                   palm_velocity=st.palm_velocity + head_vel, wrist_velocity=st.wrist_velocity + head_vel)
