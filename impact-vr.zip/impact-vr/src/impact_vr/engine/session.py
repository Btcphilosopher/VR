"""GameSession: the whole IMPACT//VR simulation as one deterministic, headless pipeline.

    VR frame -> tracking/skeleton analysis -> locomotion -> gesture + strike recognition -> collision/impact/damage
             -> enemy AI/attacks/guard -> haptic events -> scheduler -> profile -> SAFETY -> glove drivers -> audio/log/record

Everything reads an injected clock and seeded RNG streams, so a recorded VR stream replays to a bit-identical event digest (see
simulation/replay.py). Rendering, audio output and UI are consumers of the event bus.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, replace
from typing import Any, Protocol

import numpy as np

from ..audio.engine import AudioBackend, AudioEngine, NullAudio
from ..combat.defense import GestureRecognizer
from ..combat.events import GestureEvent, ImpactEvent, StrikeEvent
from ..combat.strikes import StrikeDetector
from ..combat.system import CombatSystem
from ..enemies.director import EncounterDirector
from ..enemies.enemy import Enemy, EnemyState, PlayerBody
from ..hands.analyzer import HandAnalyzer, HandState
from ..haptics.director import HapticDirector
from ..haptics.gloves.base import ConnectionState, HapticGlove
from ..haptics.gloves.simulated import make_simulated_pair
from ..haptics.pipeline import HapticPipeline
from ..haptics.profile import CalibrationProfile
from ..telemetry.latency import LatencyTracker
from ..telemetry.logging import EventLogger
from ..telemetry.metrics import Metrics
from ..vr.types import VRFrame, quantize_frame
from ..world.district import Level, build_district
from . import events as E
from .clock import SimClock
from .config import Config
from .events import Event, EventBus
from .locomotion import LocomotionController
from .mathx import Transform, body_frame, norm, q_mul, q_to_yaw, unit, v3
from .modes import STORY_ORDER, GameMode, ModeState, SessionResult, grade
from .rig import Rig, hand_to_world, shift_state
from .rng import Rng

DIGEST_EVENTS = {E.STRIKE_DETECTED, E.GESTURE_DETECTED, E.IMPACT_CALCULATED, E.DAMAGE_APPLIED, E.BLOCK, E.PARRY, E.GRAB, E.PLAYER_DAMAGED, E.ENEMY_STATE,
                 E.ENEMY_ATTACK, E.ENEMY_DEFEATED, E.HAPTIC_SENT, E.HAPTIC_SCHEDULED, E.SAFETY_TRIP, E.PLAYER_MOVED, E.ENCOUNTER}


class FrameSource(Protocol):
    def poll(self, t: float | None = None) -> VRFrame: ...


def canon(ev: Event) -> str:
    """Canonical, rounded, key-sorted JSON of an event (used for the determinism digest and replay comparison)."""

    def conv(v: Any) -> Any:
        if hasattr(v, "to_dict"):
            return conv(v.to_dict())
        if isinstance(v, float):
            return round(v, 4)
        if isinstance(v, dict):
            return {str(k): conv(x) for k, x in sorted(v.items(), key=lambda kv: str(kv[0]))}
        if isinstance(v, (list, tuple)):
            return [conv(x) for x in v]
        if isinstance(v, np.ndarray):
            return [round(float(x), 4) for x in v.ravel()]
        if hasattr(v, "value"):
            return conv(v.value)
        if isinstance(v, (np.floating, np.integer)):
            return conv(v.item())
        return v

    d = {k: conv(v) for k, v in ev.data.items() if k not in ("physical",)}
    return json.dumps([ev.name, ev.frame, round(ev.t, 5), d], sort_keys=True, default=str)


@dataclass
class FrameResult:
    frame: int
    t: float
    events: list[Event]
    stages_ms: dict[str, float]
    strikes: list[StrikeEvent] = field(default_factory=list)
    gestures: list[GestureEvent] = field(default_factory=list)
    impacts: list[ImpactEvent] = field(default_factory=list)
    haptic_commands: int = 0


class GameSession:
    def __init__(self, cfg: Config, source: FrameSource, *, mode: GameMode | str = GameMode.ENCOUNTER, level_kind: str | None = None, encounter: str | None = None,
                 seed: int | None = None, gloves: dict[str, HapticGlove] | None = None, profile: CalibrationProfile | None = None,
                 audio_backend: AudioBackend | None = None, recorder=None, log_events: bool = False) -> None:
        self.cfg = cfg
        self.source = source
        self.mode = GameMode(mode)
        self.seed = cfg.gameplay.seed if seed is None else seed
        self.rng = Rng(self.seed)
        self.clock = SimClock()
        self.dt = 1.0 / cfg.physics.step_hz
        self.bus = EventBus(session_id=f"s{self.seed:x}")
        self.latency = LatencyTracker()
        self.metrics = Metrics()
        kind = level_kind or ("training" if self.mode is GameMode.TRAINING else "street")
        self.level: Level = build_district(cfg.physics, kind)
        hs = {"easy": 0.75, "normal": 1.0, "hard": 1.3}[cfg.gameplay.difficulty]
        self.director = EncounterDirector(cfg.gameplay.encounter, self.rng.stream("enemies"), hs)
        self.analyzers = {h: HandAnalyzer(h, cfg.vr.filter) for h in ("left", "right")}
        self.detector = StrikeDetector(cfg.vr.stance)
        self.gestures = GestureRecognizer(cfg.gameplay.guard, cfg.vr.standing_eye_height)
        self.combat = CombatSystem(cfg, self.bus, self.level.physics, self.detector, self.gestures)
        self.combat.hazards = self.level.hazards
        self.rig = Rig(pos=self.level.player_start.copy())
        self.loco = LocomotionController(cfg.gameplay.comfort, self.bus, self.level.physics, self.level.bounds, cfg.vr.standing_eye_height)
        # haptics: events -> scheduler -> profile -> safety limiter -> glove driver
        self.gloves: dict[str, HapticGlove] = gloves if gloves is not None else dict(make_simulated_pair(cfg.haptics, self.seed))
        for g in self.gloves.values():
            if g.get_connection_state() is not ConnectionState.CONNECTED:
                g.connect(0.0)
        self.profile = profile or CalibrationProfile.uncalibrated(cfg.haptics)
        self.pipeline = HapticPipeline(cfg.haptics, self.gloves, self.bus, self.profile, self.latency)
        self.hdirector = HapticDirector(self.bus, self.pipeline, cfg.haptics, now_ms=lambda: self.clock.now() * 1000.0, latency=self.latency)
        self.hdirector.player_health_max = cfg.gameplay.player_health
        self.audio = AudioEngine(self.bus, audio_backend or NullAudio(), cfg.audio.master, cfg.audio.spatial)
        self.recorder = recorder
        self.logger = EventLogger(self.bus) if log_events else None
        self.digest = hashlib.sha256()
        self.digest_events = 0
        self.bus.subscribe_all(self._digest)
        self.hands: dict[str, HandState | None] = {"left": None, "right": None}
        self.world_hands: dict[str, HandState | None] = {"left": None, "right": None}
        self.head_world = v3(0, cfg.vr.standing_eye_height, 0)
        self.head_q_world = np.array([0.0, 0.0, 0.0, 1.0])
        self.state = ModeState(self.mode)
        self.result: SessionResult | None = None
        self.frame_count = 0
        self.setup: list[dict] = []           # scene setup log (synthetic enemies / props) so replays can rebuild the scene
        self.last_frame: VRFrame | None = None
        self._head_prev: tuple[float, np.ndarray] | None = None
        self._head_vel = v3()
        self.last: FrameResult | None = None
        self.defeated = 0
        self.bus.subscribe(E.ENEMY_DEFEATED, lambda e: setattr(self, "defeated", self.defeated + 1))
        self._start_mode(encounter)

    # ---- modes ------------------------------------------------------------------------------------------------------------------
    def _start_mode(self, encounter: str | None) -> None:
        enc = {e.id: e for e in self.level.encounters}
        if self.mode is GameMode.STORY:
            self.state.queue = [i for i in STORY_ORDER if i in enc]
            self._begin_encounter(enc[self.state.queue[0]])
        elif self.mode is GameMode.BOSS:
            self._begin_encounter(enc["foreman"])
        elif self.mode is GameMode.ENCOUNTER:
            self._begin_encounter(enc[encounter or "arch_street"])
        elif self.mode is GameMode.TRAINING and encounter:
            self._begin_encounter(enc[encounter])

    def _begin_encounter(self, enc) -> None:
        self.director.reset()
        self.director.start(enc, self.clock.now())
        self.bus.emit(E.ENCOUNTER, id=enc.id, title=enc.title, phase="start", intro=enc.intro)

    def start_encounter(self, enc_id: str) -> None:
        self._begin_encounter({e.id: e for e in self.level.encounters}[enc_id])

    def add_enemy(self, e: Enemy, spec: dict | None = None) -> Enemy:
        self.director.enemies[e.id] = e
        if spec is not None:
            self.setup.append({"enemy": spec})
        return e

    def place_prop(self, name: str, pos) -> None:
        pr = next(p for p in self.level.physics.props if p.name == name)
        pr.p = v3(*[float(x) for x in pos])
        self.setup.append({"prop": [name, [float(x) for x in pos]]})

    def apply_setup(self, setup: list[dict]) -> None:
        from ..simulation.scenarios import SyntheticEnemy

        for item in setup:
            if "enemy" in item:
                spec = dict(item["enemy"])
                uid = spec.pop("uid")
                kw = {**spec, "pos": tuple(spec["pos"]), "attacks": tuple(tuple(a) for a in spec.get("attacks", ()))}
                self.add_enemy(SyntheticEnemy(uid, **kw), {"uid": uid, **item["enemy"]})
            elif "prop" in item:
                self.place_prop(item["prop"][0], item["prop"][1])

    # ---- determinism digest ----------------------------------------------------------------------------------------------------------
    def _digest(self, ev: Event) -> None:
        if ev.name in DIGEST_EVENTS:
            self.digest.update(canon(ev).encode())
            self.digest.update(b"\n")
            self.digest_events += 1

    def event_digest(self) -> str:
        return self.digest.copy().hexdigest()[:24]

    # ---- the frame ---------------------------------------------------------------------------------------------------------------------
    def step(self) -> FrameResult:
        lat = self.latency
        lat.new_frame()
        t = self.clock.now()
        self.bus.time = t
        self.bus.frame = self.frame_count + 1
        n_before = len(self.bus.history)
        frame = quantize_frame(self.source.poll(t))
        self.last_frame = frame
        self.bus.emit(E.VR_FRAME, frame_id=frame.frame_id, frame_ms=round(frame.frame_time_ms, 3), state=frame.state.value,
                      src_left=frame.hand_source.get("left", "none"), src_right=frame.hand_source.get("right", "none"))
        # ---- TRACK / SKELETON: hands are analysed *relative to the head* so ducking, leaning and walking never look like a punch ---------
        with lat.measure("tracking"):
            if self._head_prev is not None:
                dtt = max(frame.t - self._head_prev[0], 1e-4)
                self._head_vel = self._head_vel + 0.6 * ((frame.head.p - self._head_prev[1]) / dtt - self._head_vel)
            self._head_prev = (frame.t, frame.head.p.copy())
            rel_states: dict[str, HandState | None] = {}
            tracking: dict[str, HandState | None] = {}
            for h in ("left", "right"):
                sk = frame.hands.get(h)
                if sk is None:
                    rel_states[h] = tracking[h] = None
                    continue
                st_rel = self.analyzers[h].update(replace(sk, positions=sk.positions - frame.head.p))
                rel_states[h] = st_rel
                tracking[h] = shift_state(st_rel, frame.head.p, self._head_vel)
                self.bus.emit(E.HAND_TRACKED, hand=h, conf=round(st_rel.confidence, 3), source=sk.source, speed=round(st_rel.speed, 3), fist=round(st_rel.fist_prob, 3),
                              grip=round(st_rel.grip_prob, 3), openness=round(st_rel.openness, 3))
        # ---- locomotion ------------------------------------------------------------------------------------------------------------------
        self.loco.update(frame, self.rig, self.dt)
        self.head_world = self.rig.point(frame.head.p)
        self.head_q_world = q_mul(self.rig.q, frame.head.q)
        world = {h: (hand_to_world(st, self.rig) if st is not None else None) for h, st in tracking.items()}
        self.hands, self.world_hands = tracking, world
        # ---- INTERPRET: strikes + gestures (tracking space: physical body motion only) -------------------------------------------------------
        strikes_out: list[StrikeEvent] = []
        gest_out: list[GestureEvent] = []
        with lat.measure("gesture"):
            body_t = Transform(v3(), body_frame(frame.head.p, frame.head.q).q)       # rotation only: states are head-relative
            for h in ("left", "right"):
                st = rel_states[h]
                if st is None or h in self.combat.held:
                    continue
                for ev in self.detector.update(h, st, body_t):
                    if ev.phase == "active":
                        self.bus.emit(E.STRIKE_DETECTED, strike=self._world_strike(ev), phase="active", latency_ms=round(ev.detect_latency_ms, 2))
                        self.combat.stats.strikes += 1
                    else:
                        self.bus.emit(E.STRIKE_DETECTED, strike=self._world_strike(ev), phase="ended", latency_ms=round(ev.detect_latency_ms, 2))
                    strikes_out.append(ev)
            striking = {h: self.detector.is_striking(h) for h in ("left", "right")}
            grabbables = [(n, self.rig.inv_point(p), r) for n, p, r in self.combat.grabbables(self.director.enemies)]
            for g in self.gestures.update(t, frame.head.p, frame.head.q, tracking, grabbables, striking):
                gest_out.append(g)
                self.bus.emit(E.GESTURE_DETECTED, type=g.type, hand=g.hand, conf=round(g.confidence, 3), mag=round(g.magnitude, 3), target=g.target or "")
                self.combat.on_gesture(g, world, self.director.enemies, t)
        # ---- COLLIDE / IMPACT -----------------------------------------------------------------------------------------------------------------
        with lat.measure("collision"):
            impacts = self.combat.update_hands(t, frame.frame_id, world, self.director.enemies, self.rig, self.dt)
            self.combat.update_thrown(self.director.enemies, t, frame.frame_id)
        # ---- GAMEPLAY: enemies, attacks, guard, physics ------------------------------------------------------------------------------------------
        with lat.measure("gameplay"):
            self._gameplay(t, frame)
        self.hdirector.flush()
        # ---- HAPTICS (scheduler -> profile -> safety -> glove); sub-ticks give ms-level pattern timing -----------------------------------------------
        t_ms0 = t * 1000.0
        n_sub = max(1, int(round(self.dt * self.cfg.haptics.glove_update_hz)))
        sent = 0
        for k in range(n_sub):
            sent += len(self.pipeline.update(t_ms0 + (k + 1) * self.dt * 1000.0 / n_sub))
        self.audio.listener.pos, self.audio.listener.yaw = self.head_world, q_to_yaw(self.head_q_world)
        self._update_mode()
        self.frame_count += 1
        self.clock.advance(self.dt)
        evs = list(self.bus.history)[n_before:] if len(self.bus.history) >= n_before else []
        res = FrameResult(frame.frame_id, t, evs, lat.frame_stages(), strikes_out, gest_out, impacts, sent)
        self.last = res
        if self.recorder is not None:
            self.recorder.record(frame, evs, self)
        return res

    # ---- helpers ----------------------------------------------------------------------------------------------------------------------------------
    def _world_strike(self, ev: StrikeEvent) -> dict:
        d = ev.to_dict()
        hp = self.last_frame.head.p if self.last_frame is not None else v3()
        d["origin"] = [round(float(x), 4) for x in self.rig.point(ev.origin + hp)]
        d["direction"] = [round(float(x), 4) for x in self.rig.direction(ev.direction)]
        return d

    def player_body(self) -> PlayerBody:
        fists, strikes = {}, {}
        for h, st in self.world_hands.items():
            if st is None:
                continue
            fists[h] = st.fist_center
            if self.detector.active_strike(h) is not None:
                strikes[h] = (st.fist_center, unit(st.fist_velocity), st.speed)
        crouch = self.cfg.vr.standing_eye_height - float(self.head_world[1])
        return PlayerBody(self.head_world.copy(), v3(self.head_world[0], 0, self.head_world[2]), self.rig.vel.copy(), fists, strikes, self.combat.vitals.health, crouch > 0.3)

    def _gameplay(self, t: float, frame: VRFrame) -> None:
        pb = self.player_body()
        self.director.update(t, pb.floor)
        blocked = lambda p: self.level.physics.blocked(p, 0.3)   # noqa: E731
        for e in list(self.director.enemies.values()):
            e.update(self.dt, t, pb, e.token, blocked)
            e.pos = self.level.clamp_to_bounds(e.pos, 0.5)
            for name, data in e.drain_events():
                if name == "state":
                    self.bus.emit(E.ENEMY_STATE, enemy=e.id, old=data["old"], new=data["new"], arch=e.arch.id)
                elif name == "windup":
                    self.bus.emit(E.ENEMY_ATTACK, enemy=e.id, attack=data["attack"], kind=data["kind"], phase="windup", distance=round(norm(e.pos - pb.floor), 3),
                                  duration=data["duration"], pos=e.pos.copy())
                elif name == "attack_active":
                    self.bus.emit(E.ENEMY_ATTACK, enemy=e.id, attack=data["attack"], kind=data["kind"], phase="active", distance=round(norm(e.pos - pb.floor), 3), pos=e.pos.copy())
                elif name == "defeated":
                    self.bus.emit(E.ENEMY_DEFEATED, enemy=e.id, arch=e.arch.id, pos=e.pos.copy())
                elif name in ("staggered", "shield_broken", "phase", "evade", "block", "notice", "brace"):
                    self.bus.emit(E.ENEMY_STATE, enemy=e.id, old=e.state.value, new=e.state.value, event=name, arch=e.arch.id)
        for e in self.director.enemies.values():          # soft separation from the player (enemies do not walk through you)
            if e.alive:
                d = e.pos - pb.floor
                dist = norm(d)
                if 1e-6 < dist < 0.55:
                    e.pos = e.pos + unit(d) * (0.55 - dist)
        self.combat.enemy_attacks(t, frame.frame_id, self.head_world, self.rig, self.director.enemies, self.gestures.guard, self.dt)
        self.level.physics.step(self.dt)
        self.combat.player_regen(self.dt, t)

    def _update_mode(self) -> None:
        st, c = self.state, self.combat
        if self.result is not None:
            return
        if self.mode is GameMode.TRAINING:
            ck = st.checklist
            ck.punches = ck.punches or c.stats.strikes > 0
            ck.blocks = ck.blocks or any(e.name == E.BLOCK for e in self.bus.history) or self.gestures.guard.state.active
            ck.grabs = ck.grabs or c.stats.grabs > 0
            ck.environment_impacts = ck.environment_impacts or c.stats.env_impacts > 0
            ck.glove_feedback = ck.glove_feedback or self.pipeline.sent_total > 0
            ck.parries = ck.parries or c.stats.parries > 0
            if ck.complete and not st.finished:
                self._finish(True, "training complete")
            return
        if c.vitals.down:
            self._finish(False, "player down")
            return
        if self.director.finished and self.director.active is not None:
            enc = self.director.active
            self.bus.emit(E.ENCOUNTER, id=enc.id, title=enc.title, phase="cleared")
            if self.mode is GameMode.STORY and st.chapter + 1 < len(st.queue):
                st.chapter += 1
                nxt = {e.id: e for e in self.level.encounters}[st.queue[st.chapter]]
                self.director.finished = False
                self.director.active = None
                self._begin_encounter(nxt)
                c.vitals.health = min(c.vitals.max_health, c.vitals.health + 25.0)
            else:
                self._finish(True, "cleared")

    def _finish(self, success: bool, reason: str) -> None:
        s = self.combat.stats
        acc = min(1.0, s.hits / max(s.strikes, 1))
        self.result = SessionResult(success, self.mode.value, self.clock.now(), self.defeated, self.combat.vitals.damage_taken, s.strikes, s.hits, acc, s.best_combo,
                                    s.blocks, s.parries, s.score + (500 if success else 0), grade(s.score, self.combat.vitals.damage_taken, acc), reason)
        self.state.finished, self.state.success = True, success

    @property
    def done(self) -> bool:
        return self.result is not None

    def run(self, seconds: float, until_done: bool = False) -> int:
        n = int(round(seconds / self.dt))
        for i in range(n):
            self.step()
            if until_done and self.done:
                return i + 1
        return n

    def events(self, name: str) -> list[Event]:
        return self.bus.of(name)
