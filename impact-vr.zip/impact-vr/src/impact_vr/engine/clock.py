"""Clocks. The simulation only ever reads an injected clock, which keeps it deterministic and testable."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol


class Clock(Protocol):
    def now(self) -> float: ...


@dataclass
class SimClock:
    t: float = 0.0

    def now(self) -> float:
        return self.t

    def advance(self, dt: float) -> float:
        self.t += dt
        return self.t


class WallClock:
    def now(self) -> float:
        return time.perf_counter()


@dataclass
class FixedStepper:
    """Accumulates real time and yields fixed simulation steps (physics at a constant rate)."""

    dt: float
    max_steps: int = 5
    _acc: float = 0.0

    def steps(self, real_dt: float) -> int:
        self._acc += min(real_dt, self.dt * self.max_steps)
        n = 0
        while self._acc >= self.dt and n < self.max_steps:
            self._acc -= self.dt
            n += 1
        return n


@dataclass
class FrameTimer:
    window: int = 180
    samples: list[float] = field(default_factory=list)

    def add(self, dt: float) -> None:
        self.samples.append(dt)
        if len(self.samples) > self.window:
            self.samples.pop(0)

    @property
    def fps(self) -> float:
        s = sum(self.samples)
        return len(self.samples) / s if s > 0 else 0.0

    @property
    def mean_ms(self) -> float:
        return 1000.0 * sum(self.samples) / len(self.samples) if self.samples else 0.0

    @property
    def p99_ms(self) -> float:
        if not self.samples:
            return 0.0
        s = sorted(self.samples)
        return 1000.0 * s[min(len(s) - 1, int(0.99 * len(s)))]
