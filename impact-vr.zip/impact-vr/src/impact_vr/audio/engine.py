"""Spatial audio abstraction. Gameplay never touches an audio backend: it emits events; `AudioEngine` maps them to sounds and a
backend (null / recording / pygame) plays them. Sounds are synthesised, so the repo ships no binary audio."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Protocol

import numpy as np

from ..engine import events as E
from ..engine.events import Event, EventBus
from ..engine.mathx import Vec, norm, v3

SAMPLE_RATE = 22050


def _env(n: int, attack: float, decay: float) -> np.ndarray:
    t = np.arange(n) / SAMPLE_RATE
    return np.minimum(t / max(attack, 1e-4), 1.0) * np.exp(-t / decay)


def synth(sound: str) -> np.ndarray:
    rng = np.random.default_rng(sum(map(ord, sound)))

    def noise(d: float) -> np.ndarray:
        return rng.uniform(-1, 1, int(SAMPLE_RATE * d)).astype(np.float32)

    def tone(f: float, d: float, sweep: float = 0.0) -> np.ndarray:
        t = np.arange(int(SAMPLE_RATE * d)) / SAMPLE_RATE
        return np.sin(2 * math.pi * np.cumsum(f * (1 - sweep * t / d)) / SAMPLE_RATE).astype(np.float32)

    def lp(x: np.ndarray, k: int) -> np.ndarray:
        return np.convolve(x, np.ones(k) / k, mode="same").astype(np.float32)

    if sound in ("punch_flesh", "punch_heavy"):
        d = 0.18 if sound == "punch_flesh" else 0.28
        n = noise(d)
        out = lp(n, 14) * _env(len(n), 0.001, 0.04 if sound == "punch_flesh" else 0.07) * 1.8 + tone(70 if sound == "punch_heavy" else 95, d, 0.5) * _env(len(n), 0.001, 0.06)
    elif sound == "block":
        n = noise(0.2)
        out = lp(n, 6) * _env(len(n), 0.001, 0.05) + tone(120, 0.2, 0.4) * _env(len(n), 0.001, 0.07) * 0.9
    elif sound == "parry":
        out = (tone(1500, 0.12) + tone(2300, 0.12) * 0.6) * _env(int(SAMPLE_RATE * 0.12), 0.0005, 0.03)
    elif sound == "metal_hit":
        out = (tone(620, 0.4) + tone(1130, 0.4) * 0.6 + tone(1730, 0.4) * 0.35) * _env(int(SAMPLE_RATE * 0.4), 0.0005, 0.12)
    elif sound == "wood_hit":
        out = (tone(240, 0.16) * 0.8 + noise(0.16) * 0.3) * _env(int(SAMPLE_RATE * 0.16), 0.0005, 0.03)
    elif sound == "wall_hit":
        n = noise(0.22)
        out = lp(n, 20) * _env(len(n), 0.002, 0.07) * 2.2 + tone(55, 0.22, 0.3) * _env(len(n), 0.002, 0.08)
    elif sound in ("whoosh", "enemy_swing"):
        n = lp(noise(0.28), 30)
        out = n * np.sin(np.linspace(0, math.pi, len(n))).astype(np.float32) * (2.0 if sound == "whoosh" else 3.0)
    elif sound == "footstep":
        n = lp(noise(0.1), 10)
        out = n * _env(len(n), 0.003, 0.025) * 1.8
    elif sound in ("grab", "pickup"):
        out = (tone(300 if sound == "grab" else 520, 0.1) + noise(0.1) * 0.2) * _env(int(SAMPLE_RATE * 0.1), 0.005, 0.03)
    elif sound == "damage":
        n = noise(0.3)
        out = lp(n, 10) * _env(len(n), 0.001, 0.06) * 1.3 + tone(60, 0.3, 0.4) * _env(len(n), 0.001, 0.1)
    elif sound == "haptic_confirm":
        out = tone(1900, 0.03) * _env(int(SAMPLE_RATE * 0.03), 0.0005, 0.008) * 0.5
    elif sound in ("enemy_down", "shield_break"):
        n = noise(0.4)
        out = lp(n, 8) * _env(len(n), 0.002, 0.12) + tone(80 if sound == "enemy_down" else 400, 0.4, 0.6) * _env(len(n), 0.002, 0.15)
    elif sound == "success":
        out = np.concatenate([tone(f, 0.12) * _env(int(SAMPLE_RATE * 0.12), 0.004, 0.07) * 0.5 for f in (520, 660, 780)])
    else:
        out = tone(440, 0.05) * 0.2
    out = np.asarray(out, dtype=np.float32)
    return out / max(float(np.max(np.abs(out))), 1e-6) * 0.9


@dataclass
class Listener:
    pos: Vec = field(default_factory=lambda: v3())
    yaw: float = 0.0


def spatialise(l: Listener, src: Vec, ref: float = 3.0, max_dist: float = 40.0) -> tuple[float, float]:
    """(gain, pan[-1..1]). Inverse-distance attenuation; pan from the source bearing relative to the listener's yaw."""
    d = src - l.pos
    dist = norm(d)
    if dist >= max_dist:
        return 0.0, 0.0
    gain = 1.0 if dist < 0.4 else min(1.0, ref / (ref + (dist - 0.4) * 0.9))
    right = v3(math.cos(l.yaw), 0.0, -math.sin(l.yaw))
    h = v3(d[0], 0.0, d[2])
    pan = float(np.dot(h / norm(h), right)) * 0.95 if norm(h) > 0.3 else 0.0
    return gain, pan


class AudioBackend(Protocol):
    def play(self, sound: str, left: float, right: float) -> None: ...
    def shutdown(self) -> None: ...


class NullAudio:
    def play(self, sound: str, left: float, right: float) -> None: ...
    def shutdown(self) -> None: ...


@dataclass
class RecordingAudio:
    log: list[tuple[str, float, float]] = field(default_factory=list)

    def play(self, sound: str, left: float, right: float) -> None:
        self.log.append((sound, left, right))

    def shutdown(self) -> None: ...

    def count(self, sound: str) -> int:
        return sum(1 for s, _, _ in self.log if s == sound)


class PygameAudio:
    def __init__(self, voices: int = 24) -> None:
        import pygame

        self.pg, self.ok = pygame, False
        self.cache: dict[str, pygame.mixer.Sound] = {}
        try:
            pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=2, buffer=512)
            pygame.mixer.set_num_channels(voices)
            self.ok = True
        except Exception:  # noqa: BLE001
            self.ok = False

    def play(self, sound: str, left: float, right: float) -> None:
        if not self.ok:
            return
        ch = self.pg.mixer.find_channel()
        if ch is None:
            return
        if sound not in self.cache:
            pcm = (synth(sound) * 32767).astype(np.int16)
            self.cache[sound] = self.pg.sndarray.make_sound(np.ascontiguousarray(np.stack([pcm, pcm], axis=1)))
        ch.set_volume(min(1.0, left), min(1.0, right))
        ch.play(self.cache[sound])

    def shutdown(self) -> None:
        if self.ok:
            self.pg.mixer.quit()


class AudioEngine:
    """Subscribes to gameplay events -> spatialised one-shots. Emits an AUDIO event per sound (observability/tests)."""

    def __init__(self, bus: EventBus, backend: AudioBackend, master: float = 0.8, spatial: bool = True, emit: bool = True) -> None:
        self.bus, self.backend, self.master, self.spatial, self.emit = bus, backend, master, spatial, emit
        self.listener = Listener()
        self._last: dict[str, float] = {}
        bus.subscribe(E.IMPACT_CALCULATED, self._impact)
        bus.subscribe(E.BLOCK, lambda e: self.play("block", self.listener.pos + v3(0, 0, 0.3)))
        bus.subscribe(E.PARRY, lambda e: self.play("parry", self.listener.pos + v3(0, 0, 0.3)))
        bus.subscribe(E.ENEMY_ATTACK, lambda e: self.play("enemy_swing", e.data.get("pos")))
        bus.subscribe(E.ENEMY_DEFEATED, lambda e: self.play("enemy_down", e.data.get("pos")))
        bus.subscribe(E.PLAYER_DAMAGED, lambda e: self.play("damage", None))
        bus.subscribe(E.GRAB, lambda e: self.play("grab", None) if e.data.get("phase") == "start" else None)
        bus.subscribe(E.PLAYER_MOVED, lambda e: self.play("footstep", None))
        bus.subscribe(E.HAPTIC_SENT, self._haptic)
        bus.subscribe(E.GESTURE_DETECTED, lambda e: self.play("whoosh", None) if e.data.get("type") in ("push", "shove") else None)

    def _impact(self, e: Event) -> None:
        imp, phys = e.data["impact"], e.data["physical"]
        if imp.attacker != "player" or (imp.impact_type or "").startswith(("blocked", "parried")):
            return
        m = imp.material
        s = "metal_hit" if m == "metal" else "wood_hit" if m == "wood" else "wall_hit" if m in ("brick", "concrete") else ("punch_heavy" if phys.energy_j > 18 else "punch_flesh")
        self.play(s, imp.position, gain=min(1.0, 0.35 + phys.energy_j / 40.0))

    def _haptic(self, e: Event) -> None:
        if e.data.get("intensity", 0) > 0.55 and e.data.get("hand") == "right":
            self.play("haptic_confirm", None, gain=0.35)

    def play(self, sound: str, pos: Vec | None, gain: float = 1.0) -> None:
        t = self.bus.time
        if t - self._last.get(sound, -9.0) < 0.02:
            return
        self._last[sound] = t
        if pos is None or not self.spatial:
            l = r = self.master * gain
        else:
            g, pan = spatialise(self.listener, pos)
            if g <= 0.01:
                return
            l = self.master * gain * g * math.sqrt(0.5 * (1 - pan)) * 1.4
            r = self.master * gain * g * math.sqrt(0.5 * (1 + pan)) * 1.4
        self.backend.play(sound, l, r)
        if self.emit:
            self.bus.emit(E.AUDIO, sound=sound, left=round(l, 3), right=round(r, 3))
