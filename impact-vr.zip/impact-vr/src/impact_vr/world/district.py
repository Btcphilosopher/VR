"""Original environment: a compact fictional British industrial district at night.

Brick warehouse frontage, railway-arch viaduct piers, a loading yard behind a steel roller door, wet pavement, sodium street
lighting with cold spill from the arches. Restrained palette, real materials (brick, concrete, steel, timber), no neon.
Everything is generated procedurally from AABBs, so it is deterministic and cheap to collide against.

Coordinates: x right, y up, z forward; the player starts near the origin looking +z down the street.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..engine.config import PhysicsCfg
from ..engine.mathx import v3
from ..enemies.director import EncounterDef, SpawnDef
from ..physics.shapes import AABB
from ..physics.world import PhysicsWorld, PropBody, StaticCollider


@dataclass
class Decor:
    box: AABB
    key: str                    # palette key
    emissive: bool = False


@dataclass
class Light:
    pos: np.ndarray
    color: tuple[int, int, int]
    radius: float
    intensity: float = 1.0


@dataclass
class Hazard:
    name: str
    box: AABB
    kind: str                   # electric
    cooldown_s: float = 2.0
    last_t: float = -9.0


@dataclass
class Level:
    id: str
    name: str
    physics: PhysicsWorld
    decor: list[Decor] = field(default_factory=list)
    lights: list[Light] = field(default_factory=list)
    hazards: list[Hazard] = field(default_factory=list)
    encounters: list[EncounterDef] = field(default_factory=list)
    player_start: np.ndarray = field(default_factory=lambda: v3(0, 0, 0))
    bounds: tuple[float, float, float, float] = (-9.0, -5.0, 9.0, 16.0)     # min_x, min_z, max_x, max_z
    spawn_points: dict[str, tuple[float, float]] = field(default_factory=dict)
    grabbables: list[str] = field(default_factory=list)

    def clamp_to_bounds(self, p: np.ndarray, margin: float = 0.4) -> np.ndarray:
        x0, z0, x1, z1 = self.bounds
        return v3(min(max(p[0], x0 + margin), x1 - margin), p[1], min(max(p[2], z0 + margin), z1 - margin))


def _solid(level: Level, name: str, lo, hi, material: str, key: str) -> None:
    box = AABB(np.array(lo, float), np.array(hi, float))
    level.physics.add_static(StaticCollider(name, box, material, "ENVIRONMENT"))
    level.decor.append(Decor(box, key))


def _decor(level: Level, lo, hi, key: str, emissive: bool = False) -> None:
    level.decor.append(Decor(AABB(np.array(lo, float), np.array(hi, float)), key, emissive))


def build_district(cfg: PhysicsCfg, kind: str = "street") -> Level:
    return build_training_room(cfg) if kind == "training" else build_street(cfg)


def build_street(cfg: PhysicsCfg) -> Level:
    L = Level("arch_street", "Halloran Arches - Night", PhysicsWorld(cfg))
    L.player_start = v3(0.0, 0.0, 0.0)
    _decor(L, (-9, -0.05, -5), (9, 0.0, 16), "wet_pavement")
    _decor(L, (-1.4, -0.04, -5), (1.4, 0.001, 16), "tram_rail")
    _solid(L, "warehouse_front", (-9.6, 0, -5), (-9.0, 7.0, 16), "brick", "brick")
    _decor(L, (-9.0, 0.0, 3.0), (-8.9, 3.2, 5.6), "steel_door")
    _decor(L, (-9.0, 4.2, 0.0), (-8.9, 5.0, 12.0), "window_dark")
    for i, z in enumerate((1.5, 6.0, 10.5)):
        _solid(L, f"arch_pier_{i}", (8.4, 0, z - 0.6), (9.6, 5.5, z + 0.6), "brick", "brick_dark")
        _decor(L, (8.4, 5.5, z - 0.6), (9.6, 6.1, z + 3.0), "brick_dark")
    _decor(L, (8.4, 6.1, -5), (9.6, 7.6, 16), "viaduct_deck")
    for z in (3.75, 8.25):
        _decor(L, (8.6, 0.0, z - 1.6), (9.5, 4.2, z + 1.6), "arch_void")
    _solid(L, "yard_wall_l", (-9.0, 0, 15.5), (-3.2, 4.5, 16.2), "concrete", "concrete")
    _solid(L, "yard_wall_r", (3.2, 0, 15.5), (9.0, 4.5, 16.2), "concrete", "concrete")
    _solid(L, "roller_door", (-3.2, 0, 15.8), (3.2, 3.6, 16.1), "metal", "steel_door")
    for i, x in enumerate((-4.2, -2.6, 2.6, 4.2)):
        _solid(L, f"bollard_{i}", (x - 0.12, 0, -4.5), (x + 0.12, 0.95, -4.26), "metal", "steel")
    _solid(L, "jersey_barrier", (4.8, 0, 7.5), (6.6, 0.85, 8.4), "concrete", "concrete")
    _solid(L, "dumpster", (-8.4, 0, 8.5), (-6.6, 1.5, 10.1), "metal", "dumpster_green")
    _solid(L, "pallet_stack", (-8.4, 0, 12.0), (-7.0, 1.3, 13.4), "wood", "timber")
    _solid(L, "lamp_post_l", (-6.55, 0, 4.0), (-6.45, 5.4, 4.1), "metal", "steel")
    _solid(L, "lamp_post_r", (6.45, 0, 11.0), (6.55, 5.4, 11.1), "metal", "steel")
    L.physics.add_prop(PropBody("oil_drum_a", v3(-5.5, 0.45, 6.0), 14.0, "metal", 0.28, height=0.9, damping=2.0))
    L.physics.add_prop(PropBody("oil_drum_b", v3(5.0, 0.45, 3.0), 14.0, "metal", 0.28, height=0.9, damping=2.0))
    L.physics.add_prop(PropBody("timber_crate", v3(-3.0, 0.3, 2.5), 6.0, "wood", 0.3, height=0.6, damping=2.5))
    L.grabbables = ["timber_crate", "oil_drum_a", "oil_drum_b"]
    L.hazards.append(Hazard("fuse_box", AABB(np.array([-9.0, 1.1, 6.8]), np.array([-8.7, 1.9, 7.6])), "electric"))
    _decor(L, (-9.0, 1.1, 6.8), (-8.7, 1.9, 7.6), "fuse_box")
    L.lights += [Light(v3(-6.5, 5.2, 4.0), (255, 190, 110), 10.0, 0.9), Light(v3(6.5, 5.2, 11.0), (255, 190, 110), 10.0, 0.9),
                 Light(v3(8.0, 3.0, 3.75), (150, 175, 215), 6.0, 0.5), Light(v3(8.0, 3.0, 8.25), (150, 175, 215), 6.0, 0.5),
                 Light(v3(0.0, 3.6, 14.8), (230, 150, 80), 7.0, 0.6)]
    sp = L.spawn_points = {"street_far": (0.0, 11.0), "street_l": (-4.0, 9.0), "street_r": (4.5, 9.5), "yard": (0.0, 13.5), "arch": (7.0, 4.0)}
    L.encounters = [
        EncounterDef("arch_street", "Arch Street", (SpawnDef("street_fighter", sp["street_far"], 0.5), SpawnDef("street_fighter", sp["street_l"], 3.5),
                                                     SpawnDef("agile_attacker", sp["street_r"], 7.0)), intro="Two locals want to talk. A third is circling."),
        EncounterDef("loading_yard", "Loading Yard", (SpawnDef("heavy_bruiser", sp["yard"], 0.5), SpawnDef("ranged", sp["street_r"], 2.0),
                                                       SpawnDef("shielded", sp["street_l"], 6.0)), intro="Heavy and unhurried. Mind the bottles."),
        EncounterDef("viaduct", "Under the Viaduct", (SpawnDef("grappler", sp["arch"], 0.5), SpawnDef("street_fighter", sp["street_far"], 3.0)),
                     reinforce_when_alive_leq=1, reinforcements=(SpawnDef("agile_attacker", sp["street_l"], 1.0), SpawnDef("street_fighter", sp["street_r"], 2.0)),
                     intro="Keep your hands up. Shove the big one off you."),
        EncounterDef("foreman", "The Foreman", (SpawnDef("boss", sp["yard"], 1.0),), intro="He runs this yard."),
    ]
    return L


def build_training_room(cfg: PhysicsCfg) -> Level:
    L = Level("training_room", "Calibration Hall - Training", PhysicsWorld(cfg), bounds=(-5.0, -3.0, 5.0, 8.0))
    L.player_start = v3(0.0, 0.0, 0.0)
    _decor(L, (-5, -0.05, -3), (5, 0.0, 8), "concrete_floor")
    _solid(L, "back_wall_brick", (-5, 0, 7.8), (5, 4.0, 8.2), "brick", "brick")
    _solid(L, "left_wall", (-5.2, 0, -3), (-4.8, 4.0, 8), "concrete", "concrete")
    _solid(L, "right_wall", (4.8, 0, -3), (5.2, 4.0, 8), "concrete", "concrete")
    _solid(L, "steel_plate", (2.4, 0.8, 7.5), (3.6, 2.0, 7.65), "metal", "steel")
    _solid(L, "timber_board", (-3.6, 0.8, 7.5), (-2.4, 2.0, 7.65), "wood", "timber")
    _solid(L, "foam_pad", (-0.6, 0.8, 7.6), (0.6, 2.0, 7.8), "cloth", "foam")
    L.physics.add_prop(PropBody("heavy_bag", v3(1.0, 1.0, 2.4), 32.0, "rubber", 0.18, home=v3(1.0, 1.0, 2.4), spring_k=95.0, damping=0.9, height=1.2, grabbable=False))
    L.physics.add_prop(PropBody("timber_crate", v3(-1.4, 0.3, 2.2), 6.0, "wood", 0.3, height=0.6, damping=2.5))
    L.physics.add_prop(PropBody("oil_drum", v3(-2.6, 0.45, 3.4), 14.0, "metal", 0.28, height=0.9, damping=2.0))
    L.grabbables = ["timber_crate", "oil_drum"]
    L.hazards.append(Hazard("test_fuse_box", AABB(np.array([-4.8, 1.0, 3.0]), np.array([-4.6, 1.8, 3.8])), "electric"))
    _decor(L, (-4.8, 1.0, 3.0), (-4.6, 1.8, 3.8), "fuse_box")
    L.lights += [Light(v3(0.0, 3.6, 2.0), (235, 235, 225), 9.0, 0.9), Light(v3(0.0, 3.6, 6.0), (235, 235, 225), 7.0, 0.8)]
    L.spawn_points = {"target": (0.0, 3.2)}
    L.encounters = [EncounterDef("sparring", "Sparring Dummy", (SpawnDef("street_fighter", (0.0, 4.0), 0.5, "IDLE"),), intro="Training dummy: stationary, hits back slowly.")]
    return L
