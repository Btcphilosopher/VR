"""Enemy entity: spatial body, state machine (IDLE .. DEFEATED), readable attacks, hit reactions, stagger, knockback."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from ..animation.clips import HitReaction, attack_fist_local, ease_inout
from ..combat.events import BodyRegion
from ..engine.mathx import Vec, clamp, norm, q_from_yaw, q_rotate, unit, v3, wrap_pi
from ..physics.shapes import Capsule, Sphere
from .archetypes import Archetype, AttackDef


class EnemyState(str, Enum):
    IDLE = "IDLE"
    PATROL = "PATROL"
    NOTICE = "NOTICE"
    APPROACH = "APPROACH"
    ATTACK = "ATTACK"
    BLOCK = "BLOCK"
    EVADE = "EVADE"
    STAGGER = "STAGGER"
    RETREAT = "RETREAT"
    DEFEATED = "DEFEATED"


@dataclass
class PlayerBody:
    """What the enemies perceive of the player (world space)."""

    head: Vec
    floor: Vec                     # (x, 0, z) under the head
    velocity: Vec
    fists: dict[str, Vec]          # current fist centres
    strikes: dict[str, tuple[Vec, Vec, float]]   # hand -> (position, direction, speed) for strikes in progress
    health: float = 100.0
    ducking: bool = False

    @property
    def torso_center(self) -> Vec:
        return v3(self.head[0], self.head[1] - 0.38, self.head[2])


@dataclass
class EnemyHit:
    region: str
    damage_taken: float
    blocked: bool = False
    shield_hit: bool = False


@dataclass
class AttackRuntime:
    attack: AttackDef
    phase: str = "windup"
    t: float = 0.0
    target: Vec = field(default_factory=lambda: v3())
    prev_fist: Vec | None = None
    fist: Vec = field(default_factory=lambda: v3())
    resolved: bool = False
    hit_fired: bool = False
    locked: bool = False          # aim point committed (late in the wind-up): moving after this point dodges the attack


def _default_anim():
    from .archetypes import _anim

    return _anim("right", (0.2, 1.4, 0.0), (0.0, 1.4, 0.8))


class Enemy:
    def __init__(self, uid: str, arch: Archetype, pos: Vec, yaw: float, rng: random.Random, health_scale: float = 1.0) -> None:
        self.id = uid
        self.arch = arch
        self.pos = pos.astype(float).copy()
        self.pos[1] = 0.0
        self.yaw = yaw
        self.vel = v3()
        self.rng = rng
        self.max_health = arch.health * health_scale
        self.health = self.max_health
        self.state = EnemyState.IDLE
        self.state_t = 0.0
        self.stagger_meter = 0.0
        self.stagger_time = 0.0
        self.attack: AttackRuntime | None = None
        self.token = False
        self.slot_angle = 0.0
        reaches = [a.reach for a in arch.attacks if a.kind != "throw"]
        self.slot_dist = arch.preferred_distance if arch.ranged or not reaches else max(0.9, min(arch.preferred_distance, min(reaches) - 0.35))
        self.route: list[Vec] = []
        self.route_i = 0
        self.react = HitReaction()
        self.shield_hp = arch.shield_durability
        self.shield_up = arch.shield
        self.block_t = 0.0
        self.evade_dir = v3()
        self.cooldown = rng.uniform(0.2, 0.8)
        self.noticed_t = -9.0
        self.phase_idx = 0
        self.combo_left = 0
        self.last_hit_t = -9.0
        self.hit_flash = 0.0
        self.grab_active = False
        self.strafe_dir = rng.choice([-1.0, 1.0])
        self.strafe_t = 0.0
        self.knockback = v3()
        self.guard_z = 0.32
        self.group = ""
        self.events: list[tuple[str, dict]] = []     # drained by the session each frame

    # ---- geometry -------------------------------------------------------------------------------------------------------------
    @property
    def alive(self) -> bool:
        return self.state is not EnemyState.DEFEATED

    @property
    def s(self) -> float:
        return self.arch.scale

    @property
    def forward(self) -> Vec:
        return v3(math.sin(self.yaw), 0.0, math.cos(self.yaw))

    def to_world(self, local: Vec) -> Vec:
        return self.pos + q_rotate(q_from_yaw(self.yaw), local * self.s)

    def fist_world(self, hand: str) -> Vec:
        a = self.attack
        if a is not None and (a.attack.hand == hand or a.attack.hand == "both") and norm(a.fist) > 0:
            return a.fist
        g = v3(0.22 if hand == "right" else -0.22, 1.28, self.guard_z)
        if self.state is EnemyState.BLOCK:
            g = v3(0.14 if hand == "right" else -0.14, 1.52, 0.35)
        return self.to_world(g) + self.react.offset

    def joints(self) -> dict[str, Vec]:
        r = self.react.offset
        return {
            "head": self.to_world(v3(0.0, 1.62, 0.04)) + r * 1.3,
            "chest": self.to_world(v3(0.0, 1.32, 0.0)) + r,
            "hips": self.to_world(v3(0.0, 0.95, 0.0)),
            "shoulder_l": self.to_world(v3(-0.21, 1.42, 0.0)) + r,
            "shoulder_r": self.to_world(v3(0.21, 1.42, 0.0)) + r,
            "foot_l": self.to_world(v3(-0.13, 0.0, 0.0)),
            "foot_r": self.to_world(v3(0.13, 0.0, 0.0)),
            "fist_l": self.fist_world("left"),
            "fist_r": self.fist_world("right"),
        }

    def hit_volumes(self) -> list[tuple[str, object, str]]:
        """(region, shape, material). A raised shield is a WEAPON-region slab in front."""
        if not self.alive:
            return []
        j = self.joints()
        s = self.s
        vols: list[tuple[str, object, str]] = [
            (BodyRegion.HEAD.value, Sphere(j["head"], 0.115 * s), "flesh"),
            (BodyRegion.TORSO.value, Capsule(j["chest"] + v3(0, 0.12 * s, 0), j["chest"] - v3(0, 0.16 * s, 0), 0.19 * s), "flesh"),
            (BodyRegion.CORE.value, Capsule(j["hips"] + v3(0, 0.12 * s, 0), j["hips"] - v3(0, 0.05 * s, 0), 0.17 * s), "flesh"),
            (BodyRegion.LEFT_ARM.value, Capsule(j["shoulder_l"], j["fist_l"], 0.065 * s), "flesh"),
            (BodyRegion.RIGHT_ARM.value, Capsule(j["shoulder_r"], j["fist_r"], 0.065 * s), "flesh"),
            (BodyRegion.LEFT_LEG.value, Capsule(j["hips"] + self.to_world(v3(-0.1, 0, 0)) - self.pos, j["foot_l"], 0.09 * s), "flesh"),
            (BodyRegion.RIGHT_LEG.value, Capsule(j["hips"] + self.to_world(v3(0.1, 0, 0)) - self.pos, j["foot_r"], 0.09 * s), "flesh"),
        ]
        if self.shield_up and self.shield_hp > 0:
            c = self.to_world(v3(-0.1, 1.2, 0.5))
            vols.append((BodyRegion.WEAPON.value, Capsule(c - v3(0, 0.45 * s, 0), c + v3(0, 0.4 * s, 0), 0.2 * s), "metal"))
        return vols

    def velocity_of_region(self) -> Vec:
        return self.vel + self.knockback

    # ---- damage ----------------------------------------------------------------------------------------------------------------
    def receive_hit(self, region: str, damage: float, stagger: float, knockback: Vec, t: float, *, blocking_fraction: float = 0.0) -> EnemyHit:
        if region == BodyRegion.WEAPON.value:
            self.shield_hp -= stagger * 1.0 + damage * 0.5
            if self.shield_hp <= 0:
                self.shield_up = False
                self.events.append(("shield_broken", {}))
            self.react.kick(knockback, 0.4)
            return EnemyHit(region, 0.0, True, True)
        blocked = self.state is EnemyState.BLOCK
        if blocked:
            damage *= 0.35
            stagger *= 0.4
        damage *= (1.0 - self.arch.armor)
        self.health = max(0.0, self.health - damage)
        self.last_hit_t = t
        self.hit_flash = 0.15
        kb = knockback * (1.0 - self.arch.knockback_resist) / max(self.arch.mass_scale, 0.5)
        self.knockback = self.knockback + kb
        self.react.kick(knockback + v3(0, 0.1, 0), 1.0 + min(damage / 12.0, 3.0))
        if self.health <= 0:
            self._set(EnemyState.DEFEATED)
            self.events.append(("defeated", {}))
        else:
            self.stagger_meter += stagger
            if self.attack is not None and self.attack.phase == "windup" and stagger > self.arch.stagger_threshold * 0.5:
                self.attack = None                       # interrupt a wind-up
                self._set(EnemyState.STAGGER)
                self.stagger_time = 0.35
            if self.stagger_meter >= self.arch.stagger_threshold and self.state is not EnemyState.STAGGER:
                self._set(EnemyState.STAGGER)
                self.stagger_time = clamp(0.45 + 0.02 * self.stagger_meter, 0.45, 1.4)
                self.stagger_meter = 0.0
                self.attack = None
                self.events.append(("staggered", {"duration": self.stagger_time}))
        return EnemyHit(region, damage, blocked, False)

    def force_stagger(self, duration: float) -> None:
        self.attack = None
        self._set(EnemyState.STAGGER)
        self.stagger_time = duration

    def _set(self, st: EnemyState) -> None:
        if st is self.state:
            return
        old = self.state
        self.state = st
        self.state_t = 0.0
        self.events.append(("state", {"old": old.value, "new": st.value}))

    # ---- update ------------------------------------------------------------------------------------------------------------------
    def update(self, dt: float, t: float, player: PlayerBody, tokens_ok: bool, blocked_fn=None) -> None:
        self.state_t += dt
        self.hit_flash = max(0.0, self.hit_flash - dt)
        self.react.step(dt)
        self.cooldown = max(0.0, self.cooldown - dt)
        self.stagger_meter = max(0.0, self.stagger_meter - dt * 6.0)
        if norm(self.knockback) > 0.02:
            self._move(self.knockback * dt, blocked_fn)
            self.knockback = self.knockback * math.exp(-5.0 * dt)
        if self.state is EnemyState.DEFEATED:
            return
        self._update_phase()
        to_p = player.floor - self.pos
        to_p[1] = 0.0
        dist = norm(to_p)
        st = self.state
        if st is EnemyState.STAGGER:
            if self.state_t >= self.stagger_time:
                self._set(EnemyState.RETREAT if self.rng.random() < 0.4 else EnemyState.APPROACH)
            return
        if st in (EnemyState.IDLE, EnemyState.PATROL):
            if st is EnemyState.PATROL and self.route:
                self._walk_to(self.route[self.route_i], dt, 0.45, blocked_fn)
                if norm(self.route[self.route_i] - self.pos) < 0.4:
                    self.route_i = (self.route_i + 1) % len(self.route)
            if dist < self.arch.notice_range and self._facing_ok(to_p, 140.0 if dist > 3 else 360.0):
                self._set(EnemyState.NOTICE)
                self.noticed_t = t
                self.events.append(("notice", {}))
            elif st is EnemyState.IDLE and self.route and self.state_t > 2.0:
                self._set(EnemyState.PATROL)
            return
        if st is EnemyState.NOTICE:
            self._face(to_p, dt, 6.0)
            if self.state_t >= self.arch.notice_delay:
                self._set(EnemyState.APPROACH)
            return
        if st is not EnemyState.ATTACK:
            self._face(to_p, dt, 7.0 if st is not EnemyState.EVADE else 2.0)
        if st in (EnemyState.APPROACH, EnemyState.RETREAT, EnemyState.BLOCK) and self._react_to_player(player, dt, dist):
            return
        if st is EnemyState.APPROACH:
            self._approach(dt, player, to_p, dist, tokens_ok, blocked_fn, t)
        elif st is EnemyState.ATTACK:
            self._attack_update(dt, player, to_p, dist)
        elif st is EnemyState.BLOCK:
            self.block_t -= dt
            if self.block_t <= 0:
                self._set(EnemyState.APPROACH)
        elif st is EnemyState.EVADE:
            self._move(self.evade_dir * self.arch.speed * 2.4 * dt, blocked_fn)
            if self.state_t >= 0.32:
                self._set(EnemyState.APPROACH)
        elif st is EnemyState.RETREAT:
            self._move(-unit(to_p) * self.arch.speed * 0.9 * dt, blocked_fn)
            if self.state_t >= 0.9 or dist > self.arch.preferred_distance + 1.2:
                self._set(EnemyState.APPROACH)

    # ---- behaviours -----------------------------------------------------------------------------------------------------------------
    def _update_phase(self) -> None:
        if not self.arch.phases:
            return
        frac = self.health / self.max_health
        idx = sum(1 for p in self.arch.phases if frac <= p)
        if idx > self.phase_idx:
            self.phase_idx = idx
            self.events.append(("phase", {"phase": idx + 1}))

    def _facing_ok(self, to_p: Vec, fov_deg: float) -> bool:
        if norm(to_p) < 1e-6:
            return True
        return abs(wrap_pi(math.atan2(to_p[0], to_p[2]) - self.yaw)) <= math.radians(fov_deg) / 2

    def _face(self, to_p: Vec, dt: float, rate: float) -> None:
        if norm(to_p) < 1e-6:
            return
        d = wrap_pi(math.atan2(to_p[0], to_p[2]) - self.yaw)
        self.yaw = wrap_pi(self.yaw + clamp(d, -rate * dt, rate * dt))

    def _move(self, delta: Vec, blocked_fn) -> None:
        new = self.pos + delta
        if blocked_fn is None or not blocked_fn(new):
            self.pos = new
        elif blocked_fn(self.pos + v3(delta[0], 0, 0)) is False:
            self.pos = self.pos + v3(delta[0], 0, 0)
        elif blocked_fn(self.pos + v3(0, 0, delta[2])) is False:
            self.pos = self.pos + v3(0, 0, delta[2])
        self.pos[1] = 0.0

    def _walk_to(self, target: Vec, dt: float, speed_scale: float, blocked_fn) -> None:
        d = target - self.pos
        d[1] = 0
        if norm(d) < 1e-3:
            return
        self._face(d, dt, 5.0)
        self._move(unit(d) * self.arch.speed * speed_scale * dt, blocked_fn)

    def _react_to_player(self, player: PlayerBody, dt: float, dist: float) -> bool:
        """Spatial awareness of the player's *actual* attacks: block or evade a strike that is heading for us."""
        for hand, (p, d, speed) in player.strikes.items():
            to_me = self.joints()["head"] - p
            dd = norm(to_me)
            if dd > 1.6 or speed < 1.5:
                continue
            if float(np.dot(unit(to_me), d)) < 0.75:
                continue
            t_hit = dd / max(speed, 0.1)
            if t_hit > 0.28 or self.state in (EnemyState.BLOCK, EnemyState.EVADE):
                continue
            if self.arch.shield and self.shield_up:
                self.events.append(("brace", {}))
                return False
            r = self.rng.random()
            if r < self.arch.evade_chance:
                side = np.cross(v3(0, 1, 0), unit(to_me))
                self.evade_dir = unit(side) * self.strafe_dir if norm(side) > 1e-6 else v3(1, 0, 0)
                self._set(EnemyState.EVADE)
                self.attack = None
                self.events.append(("evade", {}))
                return True
            if r < self.arch.evade_chance + self.arch.block_chance:
                self._set(EnemyState.BLOCK)
                self.block_t = 0.55
                self.attack = None
                self.events.append(("block", {}))
                return True
        return False

    def _approach(self, dt: float, player: PlayerBody, to_p: Vec, dist: float, tokens_ok: bool, blocked_fn, t: float) -> None:
        a = self.arch
        pref = self.slot_dist
        slot = player.floor + v3(math.sin(self.slot_angle), 0, math.cos(self.slot_angle)) * pref
        to_slot = slot - self.pos
        to_slot[1] = 0
        move = v3()
        if dist > pref + 0.15:
            move = unit(to_slot if norm(to_slot) > 0.3 else to_p)
        elif dist < pref - 0.35:
            move = -unit(to_p) * 0.7
        else:                                   # hold distance: gentle strafing so the ring feels alive
            self.strafe_t -= dt
            if self.strafe_t <= 0:
                self.strafe_t = self.rng.uniform(0.8, 1.8)
                self.strafe_dir = self.rng.choice([-1.0, 1.0])
            move = unit(np.cross(v3(0, 1, 0), to_p)) * self.strafe_dir * 0.35
        self._move(move * a.speed * dt, blocked_fn)
        if self.cooldown <= 0 and tokens_ok and (self.token or not a.ranged):
            choices = [x for x in a.attacks if x.min_range <= dist <= x.reach]
            if self.phase_idx >= 1 and a.id == "boss":
                choices = choices or list(a.attacks)
            if choices and self._facing_ok(to_p, 70.0):
                self._start_attack(self._pick(choices), player)

    def _pick(self, choices: list[AttackDef]) -> AttackDef:
        return self.rng.choices(choices, weights=[c.weight for c in choices], k=1)[0]

    def _start_attack(self, atk: AttackDef, player: PlayerBody) -> None:
        self.attack = AttackRuntime(atk)
        self.attack.fist = self._fist_for(atk, "windup", 0.0, player)
        self._set(EnemyState.ATTACK)
        self.events.append(("windup", {"attack": atk.name, "kind": atk.kind, "duration": atk.windup, "hand": atk.hand}))
        self.combo_left = (2 if self.phase_idx >= 1 else 1) if self.arch.id == "boss" and atk.name.startswith("combo") else 0

    def _fist_for(self, atk: AttackDef, phase: str, u: float, player: PlayerBody) -> Vec:
        anim = atk.anim or _default_anim()
        local = attack_fist_local(anim, phase, u)
        if phase == "active":
            tgt = self.attack.target if self.attack is not None and norm(self.attack.target) > 0 else player.head
            wind = self.to_world(anim.windup)
            shoulder = self.to_world(v3(0.21 if atk.hand != "left" else -0.21, 1.42, 0.0))
            ray = tgt - shoulder
            max_reach = (0.95 if atk.kind != "kick" else 1.15) * self.s
            end_w = tgt if atk.kind == "throw" else shoulder + unit(ray) * min(norm(ray), max_reach)
            k = u ** 2.2
            p = wind + (end_w - wind) * k
            bulge = math.sin(math.pi * k)
            side = q_rotate(q_from_yaw(self.yaw), v3(1, 0, 0))
            return p + side * anim.arc_lateral * bulge * self.s + v3(0, anim.arc_vertical * bulge, 0)
        if phase == "recovery" and self.attack is not None:
            end_w = self.attack.prev_fist if self.attack.prev_fist is not None else self.to_world(anim.strike_end)
            return end_w + (self.to_world(anim.guard) - end_w) * ease_inout(u)
        return self.to_world(local) + self.react.offset

    def _attack_update(self, dt: float, player: PlayerBody, to_p: Vec, dist: float) -> None:
        ar = self.attack
        if ar is None:
            self._set(EnemyState.APPROACH)
            return
        atk = ar.attack
        ar.t += dt
        if ar.phase == "windup":
            self._face(to_p, dt, 3.0)
            if not ar.locked:
                ar.target = player.head if atk.kind != "grab" else player.torso_center
                if ar.t >= 0.65 * atk.windup:
                    ar.locked = True          # commit: the strike goes where the head *was* - a duck/dodge after this point makes it miss
            ar.fist = self._fist_for(atk, "windup", ar.t / atk.windup, player)
            if atk.kind != "throw" and dist > 1.0 * self.s:
                self._move(unit(to_p) * min(self.arch.speed * 0.9, 1.4) * dt, None)       # step in while winding up
            if ar.t >= atk.windup:
                ar.phase, ar.t = "active", 0.0
                ar.target = ar.target + player.velocity * 0.06
                self.events.append(("attack_active", {"attack": atk.name, "kind": atk.kind}))
        elif ar.phase == "active":
            ar.prev_fist = ar.fist.copy()
            if atk.kind != "throw" and dist > 0.9 * self.s:
                self._move(unit(to_p) * min(dist - 0.9 * self.s, self.arch.speed * 2.5 * dt), None)    # lunge into range
            ar.fist = self._fist_for(atk, "active", min(1.0, ar.t / atk.active), player)
            if ar.t >= atk.active:
                ar.phase, ar.t = "recovery", 0.0
                ar.prev_fist = ar.fist.copy()
        else:
            ar.fist = self._fist_for(atk, "recovery", min(1.0, ar.t / atk.recovery), player)
            if ar.t >= atk.recovery:
                self.attack = None
                self.cooldown = self.rng.uniform(0.25, 0.6) * (0.6 if self.phase_idx >= 2 else 1.0)
                if self.combo_left > 0 and dist < 2.0:
                    self.combo_left -= 1
                    nxt = [x for x in self.arch.attacks if x.name.startswith("combo")]
                    if nxt:
                        self._start_attack(self._pick(nxt), player)
                        return
                self.events.append(("attack_end", {}))
                self._set(EnemyState.RETREAT if self.rng.random() < 0.3 and not self.arch.ranged else EnemyState.APPROACH)

    # ---- queries for combat ---------------------------------------------------------------------------------------------------------
    def active_attack(self) -> AttackRuntime | None:
        a = self.attack
        return a if a is not None and a.phase == "active" else None

    def telegraph(self) -> AttackRuntime | None:
        a = self.attack
        return a if a is not None and a.phase == "windup" else None

    def drain_events(self) -> list[tuple[str, dict]]:
        ev, self.events = self.events, []
        return ev
