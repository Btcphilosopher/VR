"""Original fictional enemy archetypes. Data only - behaviour is shared and parameterised."""

from __future__ import annotations

from dataclasses import dataclass

from ..animation.clips import AttackAnim
from ..engine.mathx import v3


@dataclass(frozen=True)
class AttackDef:
    name: str
    kind: str                   # jab | hook | overhead | kick | grab | throw
    windup: float               # readable telegraph, s
    active: float
    recovery: float
    reach: float                # max distance from enemy root to the *target* for the attack to be chosen
    min_range: float
    damage: float
    hand: str = "right"
    unblockable: bool = False
    anim: AttackAnim | None = None
    weight: float = 1.0
    projectile_speed: float = 0.0


_G_R = v3(0.22, 1.30, 0.28)
_G_L = v3(-0.22, 1.30, 0.28)


def _anim(hand: str, wind: tuple[float, float, float], end: tuple[float, float, float], lat: float = 0.0, vert: float = 0.0) -> AttackAnim:
    s = 1.0 if hand == "right" else -1.0
    g = _G_R if hand == "right" else _G_L
    return AttackAnim(g, v3(wind[0] * s, wind[1], wind[2]), v3(end[0] * s, end[1], end[2]), lat * s, vert)


@dataclass(frozen=True)
class Archetype:
    id: str
    name: str
    health: float
    speed: float
    preferred_distance: float
    attacks: tuple[AttackDef, ...]
    stagger_threshold: float = 14.0
    armor: float = 0.0
    scale: float = 1.0
    mass_scale: float = 1.0
    knockback_resist: float = 0.0
    block_chance: float = 0.15
    evade_chance: float = 0.1
    notice_range: float = 9.0
    notice_delay: float = 0.5
    shield: bool = False
    shield_durability: float = 0.0
    ranged: bool = False
    grappler: bool = False
    token_cost: int = 1
    reaction_time: float = 0.25
    color: str = "enemy_street"
    phases: tuple[float, ...] = ()


STREET_FIGHTER = Archetype(
    "street_fighter", "Arches Brawler", 70, 1.5, 1.45,
    (
        AttackDef("jab", "jab", 0.42, 0.12, 0.45, 1.45, 0.0, 9, "right", anim=_anim("right", (0.18, 1.34, -0.05), (0.04, 1.48, 0.82)), weight=1.3),
        AttackDef("hook", "hook", 0.55, 0.16, 0.6, 1.4, 0.0, 14, "left", anim=_anim("left", (-0.55, 1.4, 0.0), (0.5, 1.4, 0.55), lat=0.25), weight=1.0),
    ),
    stagger_threshold=12, block_chance=0.2, evade_chance=0.1, color="enemy_street",
)
HEAVY_BRUISER = Archetype(
    "heavy_bruiser", "Yard Bruiser", 190, 0.95, 1.6,
    (
        AttackDef("overhead", "overhead", 0.85, 0.18, 0.95, 1.55, 0.0, 26, "right", anim=_anim("right", (0.25, 2.1, -0.1), (0.05, 1.2, 0.9), vert=0.1)),
        AttackDef("haymaker", "hook", 0.75, 0.2, 0.85, 1.55, 0.0, 22, "left", anim=_anim("left", (-0.75, 1.5, -0.1), (0.6, 1.4, 0.6), lat=0.3), weight=0.8),
    ),
    stagger_threshold=40, armor=0.3, scale=1.18, mass_scale=1.6, knockback_resist=0.7, block_chance=0.05, evade_chance=0.0,
    token_cost=2, reaction_time=0.4, color="enemy_heavy",
)
AGILE_ATTACKER = Archetype(
    "agile_attacker", "Viaduct Runner", 52, 2.6, 1.75,
    (
        AttackDef("flurry_jab", "jab", 0.28, 0.1, 0.3, 1.5, 0.0, 6, "left", anim=_anim("left", (-0.1, 1.38, 0.0), (-0.02, 1.46, 0.85)), weight=1.5),
        AttackDef("lunge_kick", "kick", 0.4, 0.14, 0.55, 1.9, 0.9, 12, "right", anim=_anim("right", (0.2, 0.7, -0.2), (0.0, 1.0, 1.05)), weight=0.8),
    ),
    stagger_threshold=9, block_chance=0.05, evade_chance=0.45, notice_delay=0.35, reaction_time=0.15, color="enemy_agile",
)
SHIELDED = Archetype(
    "shielded", "Riot Shield Warden", 110, 1.1, 1.55,
    (
        AttackDef("shield_bash", "overhead", 0.7, 0.16, 0.8, 1.35, 0.0, 15, "left", anim=_anim("left", (-0.3, 1.25, -0.25), (-0.05, 1.3, 0.8))),
        AttackDef("baton", "jab", 0.5, 0.12, 0.6, 1.5, 0.0, 12, "right", anim=_anim("right", (0.25, 1.5, -0.1), (0.1, 1.4, 0.9)), weight=1.2),
    ),
    stagger_threshold=26, armor=0.15, mass_scale=1.3, knockback_resist=0.5, shield=True, shield_durability=60.0,
    block_chance=0.6, reaction_time=0.3, color="enemy_shield",
)
GRAPPLER = Archetype(
    "grappler", "Dockside Grappler", 120, 1.3, 1.1,
    (
        AttackDef("bear_grab", "grab", 0.6, 0.2, 0.9, 1.15, 0.0, 6, "both", unblockable=True, anim=_anim("right", (0.5, 1.4, 0.05), (0.0, 1.25, 0.8), lat=-0.2)),
        AttackDef("hook", "hook", 0.6, 0.16, 0.7, 1.4, 0.0, 12, "left", anim=_anim("left", (-0.6, 1.4, 0.0), (0.5, 1.4, 0.55), lat=0.25), weight=0.7),
    ),
    stagger_threshold=22, armor=0.1, mass_scale=1.4, knockback_resist=0.4, grappler=True, block_chance=0.1, color="enemy_grappler",
)
RANGED = Archetype(
    "ranged", "Gantry Thrower", 48, 1.6, 4.5,
    (AttackDef("bottle_throw", "throw", 0.65, 0.1, 0.9, 7.5, 3.0, 8, "right", anim=_anim("right", (0.3, 1.9, -0.2), (0.1, 1.5, 0.5)), projectile_speed=7.5),),
    stagger_threshold=10, block_chance=0.0, evade_chance=0.25, notice_range=12.0, ranged=True, color="enemy_ranged",
)
BOSS = Archetype(
    "boss", "The Foreman", 520, 1.35, 1.7,
    (
        AttackDef("combo_jab", "jab", 0.35, 0.1, 0.25, 1.6, 0.0, 12, "left", anim=_anim("left", (-0.1, 1.4, 0.0), (-0.02, 1.48, 0.9)), weight=1.3),
        AttackDef("combo_cross", "jab", 0.4, 0.12, 0.35, 1.6, 0.0, 17, "right", anim=_anim("right", (0.25, 1.4, -0.1), (0.05, 1.46, 0.95)), weight=1.2),
        AttackDef("sledge_overhead", "overhead", 0.8, 0.18, 0.9, 1.7, 0.0, 30, "right", anim=_anim("right", (0.3, 2.2, -0.1), (0.05, 1.1, 0.95), vert=0.1), weight=0.9),
        AttackDef("lunge_hook", "hook", 0.5, 0.16, 0.6, 2.4, 1.2, 20, "left", anim=_anim("left", (-0.8, 1.4, -0.1), (0.6, 1.4, 0.6), lat=0.3), weight=0.8),
    ),
    stagger_threshold=60, armor=0.25, scale=1.22, mass_scale=2.0, knockback_resist=0.85, block_chance=0.25, evade_chance=0.1,
    token_cost=2, reaction_time=0.2, color="enemy_boss", phases=(0.66, 0.33),
)

ARCHETYPES: dict[str, Archetype] = {a.id: a for a in (STREET_FIGHTER, HEAVY_BRUISER, AGILE_ATTACKER, SHIELDED, GRAPPLER, RANGED, BOSS)}


def get_archetype(aid: str) -> Archetype:
    return ARCHETYPES[aid]
