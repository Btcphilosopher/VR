"""Encounter director: attack tokens, tactical ring positioning, designed (scripted) encounters rather than hordes."""

from __future__ import annotations

import math
import random
from dataclasses import dataclass

from ..engine.config import EncounterCfg
from ..engine.mathx import Vec, norm, v3
from .archetypes import get_archetype
from .enemy import Enemy, EnemyState


@dataclass(frozen=True)
class SpawnDef:
    archetype: str
    pos: tuple[float, float]
    delay: float = 0.0
    state: str = "APPROACH"          # IDLE | PATROL | APPROACH
    route: tuple[tuple[float, float], ...] = ()


@dataclass(frozen=True)
class EncounterDef:
    id: str
    title: str
    spawns: tuple[SpawnDef, ...]
    reinforce_when_alive_leq: int = 0
    reinforcements: tuple[SpawnDef, ...] = ()
    intro: str = ""


class AttackTokens:
    """At most N enemies may be in an attack at once (token cost per archetype). Keeps fights readable and fair."""

    def __init__(self, cfg: EncounterCfg) -> None:
        self.cfg = cfg
        self.holders: dict[str, float] = {}      # enemy id -> time acquired
        self.next_grant = 0.0

    def used(self, enemies: dict[str, Enemy]) -> int:
        return sum(enemies[i].arch.token_cost for i in self.holders if i in enemies)

    def update(self, t: float, enemies: dict[str, Enemy], player_floor: Vec) -> None:
        for eid in list(self.holders):
            e = enemies.get(eid)
            if e is None or not e.alive or (e.attack is None and e.state not in (EnemyState.ATTACK, EnemyState.APPROACH)):
                del self.holders[eid]
            elif e.attack is None and t - self.holders[eid] > 3.0:
                del self.holders[eid]            # a token held without attacking is revoked
        free = self.cfg.max_simultaneous_attackers - self.used(enemies)
        if free <= 0 or t < self.next_grant:
            for e in enemies.values():
                e.token = e.id in self.holders
            return
        cands = [e for e in enemies.values() if e.alive and e.state is EnemyState.APPROACH and e.id not in self.holders and e.cooldown <= 0]
        cands.sort(key=lambda e: (norm(e.pos - player_floor), e.id))
        for e in cands:
            if e.arch.token_cost <= free:
                self.holders[e.id] = t
                free -= e.arch.token_cost
                self.next_grant = t + self.cfg.attack_token_cooldown_s * 0.5
                break
        for e in enemies.values():
            e.token = e.id in self.holders


class EncounterDirector:
    def __init__(self, cfg: EncounterCfg, rng: random.Random, health_scale: float = 1.0) -> None:
        self.cfg = cfg
        self.rng = rng
        self.tokens = AttackTokens(cfg)
        self.enemies: dict[str, Enemy] = {}
        self.pending: list[tuple[float, SpawnDef]] = []
        self.active: EncounterDef | None = None
        self.t0 = 0.0
        self._n = 0
        self.health_scale = health_scale
        self.finished = False
        self._reinforced = False

    def start(self, enc: EncounterDef, t: float, origin: Vec | None = None) -> None:
        self.active, self.t0, self.finished, self._reinforced = enc, t, False, False
        self.pending = [(t + s.delay, s) for s in enc.spawns]

    def _spawn(self, s: SpawnDef, player_floor: Vec) -> Enemy:
        self._n += 1
        arch = get_archetype(s.archetype)
        pos = v3(s.pos[0], 0.0, s.pos[1])
        yaw = math.atan2(player_floor[0] - pos[0], player_floor[2] - pos[2])
        e = Enemy(f"{s.archetype}_{self._n:02d}", arch, pos, yaw, random.Random(self.rng.randrange(1 << 30)), self.health_scale)
        if s.route:
            e.route = [v3(x, 0.0, z) for x, z in s.route]
        e.state = EnemyState[s.state]
        e.group = self.active.id if self.active else ""
        self.enemies[e.id] = e
        return e

    def alive(self) -> list[Enemy]:
        return [e for e in self.enemies.values() if e.alive]

    def update(self, t: float, player_floor: Vec) -> None:
        for due, s in list(self.pending):
            if t >= due and len(self.alive()) < self.cfg.max_enemies_alive:
                self.pending.remove((due, s))
                self._spawn(s, player_floor)
        enc = self.active
        if enc and enc.reinforcements and not self._reinforced and len(self.alive()) <= enc.reinforce_when_alive_leq and not self.pending:
            self._reinforced = True
            self.pending += [(t + s.delay, s) for s in enc.reinforcements]
        alive = self.alive()
        awake = [e for e in alive if e.state not in (EnemyState.IDLE, EnemyState.PATROL, EnemyState.DEFEATED)]
        if awake:
            awake.sort(key=lambda e: math.atan2(e.pos[0] - player_floor[0], e.pos[2] - player_floor[2]))
            n = len(awake)
            base = math.atan2(awake[0].pos[0] - player_floor[0], awake[0].pos[2] - player_floor[2])
            spread = min(math.radians(70), math.radians(35) * max(n - 1, 0))
            for i, e in enumerate(awake):
                e.slot_angle = base + (-spread / 2 + (spread * i / (n - 1) if n > 1 else 0.0))
        self.tokens.update(t, self.enemies, player_floor)
        if enc and not self.pending and not alive and self.enemies:
            self.finished = True

    def reset(self) -> None:
        self.enemies.clear()
        self.pending.clear()
        self.tokens = AttackTokens(self.cfg)
        self.active = None
        self.finished = False
        self._n = 0
