"""Per-hand motion analysis: filtering, kinematics (velocity, acceleration, angular velocity) and pose classification
(finger flexion, openness, fist / pointing / grip probabilities)."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..engine.config import FilterCfg
from ..engine.mathx import QIDENT, Vec, q_angular_velocity, q_rotate, sigmoid, unit, v3
from ..tracking.filters import FilterBank, lowpass_alpha
from .skeleton import FINGER_BEND_MAX, FINGERS, KNUCKLES, N_JOINTS, THUMB_BEND_MAX, FingerCurls, HandSkeleton, Joint, build_skeleton, finger_bends


def _baseline() -> dict[str, float]:
    p = build_skeleton("right", np.zeros(3), QIDENT, FingerCurls.open()).positions
    return {f: sum(finger_bends(p, f)) for f in FINGERS}


_BASE = _baseline()
_MAX = {f: (THUMB_BEND_MAX if f == "thumb" else FINGER_BEND_MAX) for f in FINGERS}


def flexion_from_positions(positions: np.ndarray) -> dict[str, float]:
    out = {}
    for f in FINGERS:
        s = sum(finger_bends(positions, f))
        out[f] = float(min(1.0, max(0.0, (s - _BASE[f]) / max(_MAX[f] - _BASE[f], 1e-6))))
    return out


@dataclass
class HandState:
    """Filtered kinematic + semantic state of one hand for one frame."""

    hand: str
    t: float
    dt: float
    positions: np.ndarray                    # (26, 3) filtered
    orientations: np.ndarray                 # (26, 4)
    velocities: np.ndarray                   # (26, 3)
    accelerations: np.ndarray                # (26, 3)
    flexion: dict[str, float]
    openness: float
    fist_prob: float
    pointing_prob: float
    grip_prob: float
    palm_velocity: Vec
    wrist_velocity: Vec
    angular_velocity: Vec
    confidence: float
    tracked: bool
    palm_normal: Vec = field(default_factory=lambda: v3(0, -1, 0))
    forward: Vec = field(default_factory=lambda: v3(0, 0, 1))
    side: Vec = field(default_factory=lambda: v3(1, 0, 0))

    @property
    def wrist(self) -> Vec:
        return self.positions[Joint.WRIST]

    @property
    def palm(self) -> Vec:
        return self.positions[Joint.PALM]

    @property
    def fist_center(self) -> Vec:
        """Centre of the striking surface: the knuckle row, pushed slightly forward."""
        k = np.mean([self.positions[j] for j in KNUCKLES], axis=0)
        return k + self.forward * 0.015

    @property
    def fist_velocity(self) -> Vec:
        return np.mean([self.velocities[j] for j in KNUCKLES], axis=0)

    @property
    def speed(self) -> float:
        return float(np.linalg.norm(self.fist_velocity))

    @property
    def elbow(self) -> Vec:
        """Estimated elbow: along the forearm axis behind the wrist."""
        return self.wrist - self.forward * 0.27

    def mean_flexion4(self) -> float:
        return float(np.mean([self.flexion[f] for f in FINGERS[1:]]))


class HandAnalyzer:
    """Stateful analyser for one hand. Feed raw skeleton samples, get `HandState`."""

    def __init__(self, hand: str, cfg: FilterCfg) -> None:
        self.hand = hand
        self.bank = FilterBank(cfg)
        self._prev_pos: np.ndarray | None = None
        self._prev_vel = np.zeros((N_JOINTS, 3))
        self._prev_wq = QIDENT.copy()
        self._prev_t: float | None = None
        self._vel = np.zeros((N_JOINTS, 3))
        self._acc = np.zeros((N_JOINTS, 3))
        self.last: HandState | None = None

    def configure(self, **overrides: object) -> None:
        self.bank.configure(**overrides)

    def reset(self) -> None:
        self.bank.reset()
        self._prev_pos = None
        self._prev_t = None
        self._vel[:] = 0
        self._acc[:] = 0

    def update(self, skel: HandSkeleton) -> HandState:
        t = skel.t
        pos = self.bank.filter_positions(skel.positions, t)
        ori = self.bank.filter_quats(skel.orientations, t)
        if self._prev_pos is None or self._prev_t is None:
            dt = 0.0
            vel = np.zeros_like(pos)
            acc = np.zeros_like(pos)
            wv = np.zeros(3)
        else:
            dt = max(t - self._prev_t, 1e-4)
            raw_v = (pos - self._prev_pos) / dt
            a = lowpass_alpha(self.bank.vel_alpha_hz, dt)
            vel = self._vel + a * (raw_v - self._vel)
            raw_a = (vel - self._prev_vel) / dt
            acc = self._acc + a * (raw_a - self._acc)
            wv = q_angular_velocity(self._prev_wq, ori[Joint.WRIST], dt)
        self._prev_pos, self._prev_t, self._prev_vel = pos, t, vel.copy()
        self._prev_wq = ori[Joint.WRIST].copy()
        self._vel, self._acc = vel, acc
        flex = flexion_from_positions(pos)
        m4 = float(np.mean([flex[f] for f in FINGERS[1:]]))
        thumb = flex["thumb"]
        openness = float(max(0.0, min(1.0, 1.0 - (0.8 * m4 + 0.2 * thumb))))
        min4 = float(min(flex[f] for f in FINGERS[1:]))      # a fist needs *every* finger curled (pointing is not a fist)
        fist = sigmoid(14 * (min4 - 0.62)) * (0.55 + 0.45 * sigmoid(10 * (thumb - 0.25)))
        point = sigmoid(12 * (0.30 - flex["index"])) * sigmoid(12 * (float(np.mean([flex["middle"], flex["ring"], flex["little"]])) - 0.55))
        grip = sigmoid(10 * (m4 - 0.42)) * (0.5 + 0.5 * sigmoid(10 * (thumb - 0.18)))
        q = ori[Joint.WRIST]
        fwd = unit(q_rotate(q, v3(0, 0, 1)))
        back = unit(q_rotate(q, v3(0, 1, 0)))
        side = unit(q_rotate(q, v3(1, 0, 0)))
        st = HandState(
            hand=self.hand, t=t, dt=dt, positions=pos, orientations=ori, velocities=vel, accelerations=acc, flexion=flex, openness=openness,
            fist_prob=float(fist), pointing_prob=float(point), grip_prob=float(grip), palm_velocity=vel[Joint.PALM].copy(), wrist_velocity=vel[Joint.WRIST].copy(),
            angular_velocity=wv, confidence=skel.confidence, tracked=skel.tracked, palm_normal=-back, forward=fwd, side=side,
        )
        self.last = st
        return st
