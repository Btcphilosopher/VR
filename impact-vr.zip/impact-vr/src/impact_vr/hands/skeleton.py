"""Hand skeleton (26 joints, OpenXR XR_EXT_hand_tracking ordering) and a forward-kinematics rig.

The rig is used by the synthetic tracker and by the controller fallback to turn (wrist pose + finger curls) into a full
skeleton, so every downstream subsystem sees the same data whether it comes from a camera-tracked hand, a glove, a controller
or a script.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import IntEnum

import numpy as np

from ..engine.mathx import QIDENT, Vec, q_axis_angle, q_mul, q_norm, q_rotate, unit, v3


class Joint(IntEnum):
    PALM = 0
    WRIST = 1
    THUMB_METACARPAL = 2
    THUMB_PROXIMAL = 3
    THUMB_DISTAL = 4
    THUMB_TIP = 5
    INDEX_METACARPAL = 6
    INDEX_PROXIMAL = 7
    INDEX_INTERMEDIATE = 8
    INDEX_DISTAL = 9
    INDEX_TIP = 10
    MIDDLE_METACARPAL = 11
    MIDDLE_PROXIMAL = 12
    MIDDLE_INTERMEDIATE = 13
    MIDDLE_DISTAL = 14
    MIDDLE_TIP = 15
    RING_METACARPAL = 16
    RING_PROXIMAL = 17
    RING_INTERMEDIATE = 18
    RING_DISTAL = 19
    RING_TIP = 20
    LITTLE_METACARPAL = 21
    LITTLE_PROXIMAL = 22
    LITTLE_INTERMEDIATE = 23
    LITTLE_DISTAL = 24
    LITTLE_TIP = 25


N_JOINTS = 26
FINGERS = ("thumb", "index", "middle", "ring", "little")
FINGER_JOINTS: dict[str, tuple[int, ...]] = {
    "thumb": (2, 3, 4, 5),
    "index": (6, 7, 8, 9, 10),
    "middle": (11, 12, 13, 14, 15),
    "ring": (16, 17, 18, 19, 20),
    "little": (21, 22, 23, 24, 25),
}
KNUCKLES = (Joint.INDEX_PROXIMAL, Joint.MIDDLE_PROXIMAL, Joint.RING_PROXIMAL, Joint.LITTLE_PROXIMAL)
TIPS = (Joint.THUMB_TIP, Joint.INDEX_TIP, Joint.MIDDLE_TIP, Joint.RING_TIP, Joint.LITTLE_TIP)


@dataclass
class HandSkeleton:
    """A (possibly noisy) hand sample in world space."""

    hand: str                       # "left" | "right"
    t: float
    positions: np.ndarray           # (26, 3)
    orientations: np.ndarray        # (26, 4) xyzw
    confidence: float = 1.0
    source: str = "synthetic"       # synthetic | hand_tracking | controller | glove | replay
    tracked: bool = True

    @property
    def wrist(self) -> Vec:
        return self.positions[Joint.WRIST]

    @property
    def wrist_q(self) -> Vec:
        return self.orientations[Joint.WRIST]

    def copy(self) -> HandSkeleton:
        return HandSkeleton(self.hand, self.t, self.positions.copy(), self.orientations.copy(), self.confidence, self.source, self.tracked)


@dataclass
class FingerCurls:
    """0 = fully extended, 1 = fully flexed."""

    thumb: float = 0.0
    index: float = 0.0
    middle: float = 0.0
    ring: float = 0.0
    little: float = 0.0

    @staticmethod
    def open() -> FingerCurls:
        return FingerCurls()

    @staticmethod
    def fist() -> FingerCurls:
        return FingerCurls(0.85, 1.0, 1.0, 1.0, 1.0)

    @staticmethod
    def point() -> FingerCurls:
        return FingerCurls(0.8, 0.0, 1.0, 1.0, 1.0)

    @staticmethod
    def grip() -> FingerCurls:
        return FingerCurls(0.6, 0.62, 0.65, 0.68, 0.7)

    def as_dict(self) -> dict[str, float]:
        return {f: getattr(self, f) for f in FINGERS}

    def lerp(self, other: FingerCurls, k: float) -> FingerCurls:
        return FingerCurls(*(getattr(self, f) + (getattr(other, f) - getattr(self, f)) * k for f in FINGERS))


# hand-local frame: +z along fingers, +y out of the back of the hand, right-hand radial (thumb) side = -x
_FINGER_X = {"index": 0.022, "middle": 0.007, "ring": -0.009, "little": -0.025}
_PHALANGES = {"index": (0.040, 0.025, 0.020), "middle": (0.045, 0.028, 0.022), "ring": (0.041, 0.026, 0.020), "little": (0.032, 0.020, 0.018)}
_MCP_MAX, _PIP_MAX, _DIP_MAX = math.radians(80), math.radians(100), math.radians(70)
FINGER_BEND_MAX = _MCP_MAX + _PIP_MAX + _DIP_MAX
_KNUCKLE_Z = 0.095
_META_Z = 0.02
_THUMB_SEG = (0.045, 0.032, 0.028)
_CURL_W = (0.4, 0.8, 1.0)


def _thumb_dirs(side: float, curl: float) -> list[np.ndarray]:
    radial = -side
    d0 = unit(v3(radial * 0.55, -0.15, 0.8))
    d1 = unit(v3(-radial * 0.6, -0.6, 0.4))
    return [unit(d0 * (1 - curl * w) + d1 * (curl * w)) for w in _CURL_W]


def build_skeleton(hand: str, wrist_p: Vec, wrist_q: Vec, curls: FingerCurls, t: float = 0.0, confidence: float = 1.0,
                   source: str = "synthetic") -> HandSkeleton:
    """Forward kinematics: wrist pose + finger curls -> 26 world-space joints."""
    side = 1.0 if hand == "right" else -1.0
    local = np.zeros((N_JOINTS, 3))
    ori = np.tile(QIDENT, (N_JOINTS, 1))
    local[Joint.PALM] = v3(0, 0, 0.045)
    for name in ("index", "middle", "ring", "little"):
        j = FINGER_JOINTS[name]
        x = -side * _FINGER_X[name]
        c = getattr(curls, name)
        phi = np.cumsum([c * _MCP_MAX, c * _PIP_MAX, c * _DIP_MAX])
        local[j[0]] = v3(x * 0.7, 0.0, _META_Z)
        local[j[1]] = v3(x, 0.0, _KNUCKLE_Z)
        pos = local[j[1]].copy()
        angles = [0.0, *phi]
        for k, (seg, ang) in enumerate(zip(_PHALANGES[name], phi, strict=True)):
            d = v3(0.0, -math.sin(ang), math.cos(ang))
            pos = pos + d * seg
            local[j[2 + k]] = pos
        ori[j[0]] = QIDENT
        for k in range(1, 5):
            ori[j[k]] = q_axis_angle(v3(1, 0, 0), angles[min(k - 1, 3)])
    tj = FINGER_JOINTS["thumb"]
    local[tj[0]] = v3(-side * 0.020, -0.005, 0.02)
    dirs = _thumb_dirs(side, curls.thumb)
    pos = local[tj[0]].copy()
    for k in range(3):
        pos = pos + dirs[k] * _THUMB_SEG[k]
        local[tj[1 + k]] = pos
    positions = q_rotate(wrist_q, local) + wrist_p
    orientations = np.array([q_norm(q_mul(wrist_q, o)) for o in ori])
    orientations[Joint.WRIST] = wrist_q
    orientations[Joint.PALM] = wrist_q
    return HandSkeleton(hand, t, positions, orientations, confidence, source)


def finger_bends(positions: np.ndarray, finger: str) -> list[float]:
    """Bend angle (rad) at each interior joint of a finger chain."""
    j = FINGER_JOINTS[finger]
    segs = [positions[j[k + 1]] - positions[j[k]] for k in range(len(j) - 1)]
    out = []
    for a, b in zip(segs, segs[1:], strict=False):
        na, nb = np.linalg.norm(a), np.linalg.norm(b)
        if na < 1e-9 or nb < 1e-9:
            out.append(0.0)
            continue
        out.append(float(math.acos(max(-1.0, min(1.0, float(np.dot(a, b) / (na * nb)))))))
    return out


def _thumb_bend_max() -> float:
    p = build_skeleton("right", np.zeros(3), QIDENT, FingerCurls(thumb=1.0)).positions
    return sum(finger_bends(p, "thumb"))


THUMB_BEND_MAX = _thumb_bend_max()


@dataclass
class HandPose:
    wrist_p: Vec
    wrist_q: Vec
    curls: FingerCurls = field(default_factory=FingerCurls.open)
