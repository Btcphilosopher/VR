"""Hardware adapters.

* `ControllerHandFallback`  - controller -> synthetic hand (grip/trigger -> finger curls). Always available.
* `OpenXRAdapter`           - skeleton of a pyopenxr-backed runtime (HMD + controllers + XR_EXT_hand_tracking).

HARDWARE-UNTESTED: `OpenXRAdapter` requires pyopenxr and a running OpenXR runtime; in every other case it raises `VRUnavailable`
and callers fall back to simulation. OpenXR joint order == our `Joint` enum order (26 joints), and `openxr_to_world` converts
the coordinate frame at the boundary.
"""

from __future__ import annotations

import numpy as np

from ..engine.mathx import q_rotate, v3
from ..hands.skeleton import FingerCurls, HandSkeleton, build_skeleton
from .device import VRUnavailable
from .types import ControllerState


class ControllerHandFallback:
    """Fabricates a plausible hand from a controller: grip squeezes the little/ring/middle fingers, trigger the index, thumb curls
    when either is down. The wrist is offset from the controller pose so the virtual fist sits where a gripped hand would be."""

    def __init__(self, grip_offset: float = 0.06) -> None:
        self.grip_offset = grip_offset

    def skeleton_from_controller(self, hand: str, c: ControllerState, t: float) -> HandSkeleton:
        wrist_q = c.pose.q
        wrist_p = c.pose.p - q_rotate(wrist_q, v3(0, 0, self.grip_offset))
        g, tr = float(c.grip), float(c.trigger)
        curls = FingerCurls(thumb=max(g, tr * 0.8) * 0.85, index=max(tr, g * 0.9), middle=g, ring=g, little=g)
        return build_skeleton(hand, wrist_p, wrist_q, curls, t=t, confidence=1.0 if c.tracked else 0.0, source="controller")


class OpenXRAdapter:  # pragma: no cover - requires hardware
    name = "openxr"

    def __init__(self) -> None:
        try:
            import xr  # noqa: F401
        except Exception as exc:
            raise VRUnavailable(f"pyopenxr not installed: {exc}") from exc
        raise VRUnavailable("No OpenXR runtime/session available in this environment")

    @staticmethod
    def convert_joints(positions_xr: np.ndarray, orientations_xr: np.ndarray):
        """Reference conversion used when wiring `xrLocateHandJointsEXT` results into `HandSkeleton`."""
        from ..engine.mathx import openxr_to_world

        ps, qs = [], []
        for p, q in zip(positions_xr, orientations_xr, strict=True):
            pw, qw = openxr_to_world(p, q)
            ps.append(pw)
            qs.append(qw)
        return np.array(ps), np.array(qs)
