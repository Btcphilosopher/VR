"""Core VR data types. Everything here is in the engine world frame (x right, y up, z forward)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

import numpy as np

from ..engine.mathx import QIDENT, Vec, q_rotate, v3
from ..hands.skeleton import HandSkeleton


class SessionState(str, Enum):
    """Mirrors XrSessionState."""

    IDLE = "idle"
    READY = "ready"
    SYNCHRONIZED = "synchronized"
    VISIBLE = "visible"
    FOCUSED = "focused"
    STOPPING = "stopping"
    LOSS_PENDING = "loss_pending"
    EXITING = "exiting"


@dataclass(frozen=True)
class VRPose:
    p: Vec = field(default_factory=lambda: v3())
    q: Vec = field(default_factory=lambda: QIDENT.copy())
    valid: bool = True
    linear_velocity: Vec | None = None
    angular_velocity: Vec | None = None

    def forward(self) -> Vec:
        return q_rotate(self.q, v3(0, 0, 1))


@dataclass
class ControllerState:
    pose: VRPose = field(default_factory=VRPose)
    trigger: float = 0.0
    grip: float = 0.0
    stick: tuple[float, float] = (0.0, 0.0)
    a: bool = False
    b: bool = False
    menu: bool = False
    tracked: bool = True


@dataclass
class VRFrame:
    """One predicted-pose snapshot for a rendered frame."""

    frame_id: int
    t: float
    dt: float
    head: VRPose
    controllers: dict[str, ControllerState]
    hands: dict[str, HandSkeleton | None]
    state: SessionState = SessionState.FOCUSED
    hand_source: dict[str, str] = field(default_factory=dict)   # per hand: hand_tracking | controller | none
    capture_time: float = 0.0
    frame_time_ms: float = 0.0
    missed_frames: int = 0

    def hand(self, which: str) -> HandSkeleton | None:
        return self.hands.get(which)


QUANT = 5


def quantize_frame(f: VRFrame) -> VRFrame:
    """Round all tracking data to a fixed precision. Applied to every frame the session consumes (live *and* replayed), so a
    recording - which stores rounded values - reproduces the live run bit for bit."""
    r = lambda a: np.round(np.asarray(a, dtype=np.float64), QUANT)   # noqa: E731
    head = VRPose(r(f.head.p), r(f.head.q), f.head.valid)
    ctrls = {}
    for h, c in f.controllers.items():
        ctrls[h] = ControllerState(VRPose(r(c.pose.p), r(c.pose.q), c.pose.valid), round(c.trigger, 4), round(c.grip, 4),
                                   (round(c.stick[0], 4), round(c.stick[1], 4)), c.a, c.b, c.menu, c.tracked)
    hands = {}
    for h, sk in f.hands.items():
        hands[h] = None if sk is None else HandSkeleton(sk.hand, round(f.t, 5), r(sk.positions), r(sk.orientations), round(sk.confidence, 4), sk.source, sk.tracked)
    return VRFrame(f.frame_id, round(f.t, 5), round(f.dt, 6), head, ctrls, hands, f.state, dict(f.hand_source), round(f.capture_time, 5),
                   f.frame_time_ms, f.missed_frames)
