"""VR device abstraction. Hardware lives behind adapters that implement these interfaces; nothing else in the engine imports a
vendor SDK."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np

from ..engine.clock import Clock, SimClock
from ..engine.mathx import Transform, q_from_yaw, q_mul, q_norm, q_rotate, q_to_yaw
from ..hands.skeleton import HandSkeleton
from .types import ControllerState, SessionState, VRFrame, VRPose


class VRUnavailable(RuntimeError):
    pass


class VRDevice(ABC):
    name = "device"

    @abstractmethod
    def start(self) -> None: ...

    @abstractmethod
    def stop(self) -> None: ...

    @property
    def available(self) -> bool:
        return True


class VRHeadset(VRDevice):
    @abstractmethod
    def get_pose(self, t: float) -> VRPose: ...


class VRController(VRDevice):
    @abstractmethod
    def get_state(self, hand: str, t: float) -> ControllerState: ...


class VRHandTracker(VRDevice):
    """Skeletal hand tracking (26 joints per hand)."""

    @abstractmethod
    def get_hands(self, t: float) -> dict[str, HandSkeleton | None]: ...


def _qm(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return q_norm(q_mul(a, b))


@dataclass
class PlaySpace:
    """Maps tracking space to game world. `recenter` re-origins on the user's current head position / yaw."""

    transform: Transform = field(default_factory=Transform.identity)

    def recenter(self, head: VRPose, keep_height: bool = True) -> None:
        yaw = q_to_yaw(head.q)
        inv = q_from_yaw(-yaw)
        origin = head.p.copy()
        if keep_height:
            origin[1] = 0.0
        self.transform = Transform(-q_rotate(inv, origin), inv)

    def apply_pose(self, p: VRPose) -> VRPose:
        t = self.transform
        return VRPose(t.apply(p.p), _qm(t.q, p.q), p.valid, p.linear_velocity, p.angular_velocity)

    def apply_hand(self, h: HandSkeleton) -> HandSkeleton:
        t = self.transform
        out = h.copy()
        out.positions = t.apply(h.positions)
        out.orientations = np.array([_qm(t.q, q) for q in h.orientations])
        return out


class VRRuntime:
    """Composes headset + hand tracker + controllers into per-frame `VRFrame`s with timing and session state.

    Hand source selection: use skeletal tracking when it reports sufficient confidence, otherwise synthesise a hand from the
    controller (grip/trigger -> finger curls) so the game stays playable with plain controllers.
    """

    def __init__(self, headset: VRHeadset, tracker: VRHandTracker | None, controllers: VRController | None, clock: Clock | None = None,
                 min_confidence: float = 0.35, target_fps: float = 90.0, fallback: object | None = None) -> None:
        self.headset, self.tracker, self.controllers = headset, tracker, controllers
        self.clock = clock or SimClock()
        self.min_confidence = min_confidence
        self.target_dt = 1.0 / target_fps
        self.playspace = PlaySpace()
        self.state = SessionState.IDLE
        self.frame_id = 0
        self._last_t: float | None = None
        self.missed = 0
        self.fallback = fallback
        self.frame_times_ms: list[float] = []

    def start(self) -> None:
        for d in (self.headset, self.tracker, self.controllers):
            if d is not None:
                d.start()
        for st in (SessionState.READY, SessionState.SYNCHRONIZED, SessionState.VISIBLE, SessionState.FOCUSED):
            self.state = st

    def stop(self) -> None:
        self.state = SessionState.STOPPING
        for d in (self.headset, self.tracker, self.controllers):
            if d is not None:
                d.stop()
        self.state = SessionState.EXITING

    def recenter(self, t: float | None = None) -> None:
        self.playspace.recenter(self.headset.get_pose(self.clock.now() if t is None else t))

    def poll(self, t: float | None = None) -> VRFrame:
        t = self.clock.now() if t is None else t
        dt = self.target_dt if self._last_t is None else max(t - self._last_t, 1e-6)
        if self._last_t is not None and dt > 1.5 * self.target_dt:
            self.missed += int(round(dt / self.target_dt)) - 1
        self._last_t = t
        head = self.playspace.apply_pose(self.headset.get_pose(t))
        ctrls: dict[str, ControllerState] = {}
        if self.controllers is not None:
            for h in ("left", "right"):
                cs = self.controllers.get_state(h, t)
                cs.pose = self.playspace.apply_pose(cs.pose)
                ctrls[h] = cs
        raw = self.tracker.get_hands(t) if self.tracker is not None else {"left": None, "right": None}
        hands: dict[str, HandSkeleton | None] = {}
        src: dict[str, str] = {}
        for h in ("left", "right"):
            sk = raw.get(h)
            if sk is not None and sk.tracked and sk.confidence >= self.min_confidence:
                hands[h] = self.playspace.apply_hand(sk)
                src[h] = "hand_tracking"
            elif h in ctrls and ctrls[h].tracked and self.fallback is not None:
                hands[h] = self.fallback.skeleton_from_controller(h, ctrls[h], t)  # type: ignore[attr-defined]
                src[h] = "controller"
            else:
                hands[h] = None
                src[h] = "none"
        self.frame_id += 1
        self.frame_times_ms.append(dt * 1000.0)
        if len(self.frame_times_ms) > 240:
            self.frame_times_ms.pop(0)
        return VRFrame(self.frame_id, t, dt, head, ctrls, hands, self.state, src, capture_time=t, frame_time_ms=dt * 1000.0, missed_frames=self.missed)

    @property
    def mean_frame_ms(self) -> float:
        return float(np.mean(self.frame_times_ms)) if self.frame_times_ms else 0.0
