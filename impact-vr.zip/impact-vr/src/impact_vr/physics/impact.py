"""Physical impact model - deliberately separate from gameplay damage.

    energy  = 0.5 * m_eff * v_n^2          (v_n: closing speed along the contact normal, glancing-corrected)
    impulse = m_eff * v_n * (1 + e)        (e: material restitution)

`m_eff` is a configurable *lumped effective mass* per attack type (fist + forearm + body share) - a gameplay-physics abstraction,
NOT a biomechanical or injury model, and it is never used to claim real-world force values.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..engine.config import MaterialCfg, PhysicsCfg
from ..engine.mathx import Vec, clamp, norm, unit


@dataclass(frozen=True)
class PhysicalImpact:
    energy_j: float
    impulse: float
    closing_speed: float
    angle_factor: float
    effective_mass: float
    material: str
    restitution: float
    hardness: float
    contact_angle_deg: float


def effective_mass(attack: str, cfg: PhysicsCfg) -> float:
    return cfg.effective_mass_kg.get(attack, cfg.effective_mass_kg.get("touch", 0.8))


def compute_impact(attack: str, hand_velocity: Vec, target_velocity: Vec, normal: Vec, material: str, cfg: PhysicsCfg,
                   mass_scale: float = 1.0) -> PhysicalImpact:
    """normal points from the target surface towards the striker."""
    mat: MaterialCfg = cfg.materials.get(material, cfg.materials["flesh"])
    rel = hand_velocity - target_velocity
    n = unit(normal)
    v_n = max(0.0, float(-(rel @ n)))                   # speed *into* the surface
    speed = norm(rel)
    cos_a = clamp(v_n / speed, 0.0, 1.0) if speed > 1e-9 else 0.0
    angle_factor = cos_a ** cfg.glancing_exponent
    v_eff = v_n * (angle_factor if cos_a < 1.0 else 1.0) ** 0.5 if v_n > 0 else 0.0
    m = effective_mass(attack, cfg) * mass_scale
    energy = 0.5 * m * v_eff * v_eff
    impulse = m * v_eff * (1.0 + mat.restitution)
    return PhysicalImpact(energy, impulse, v_n, angle_factor, m, material, mat.restitution, mat.hardness,
                          math.degrees(math.acos(cos_a)) if speed > 1e-9 else 90.0)
