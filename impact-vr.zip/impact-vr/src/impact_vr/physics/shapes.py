"""Collision primitives and *swept* tests (fast punches tunnel through thin hitboxes in discrete tests)."""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..engine.mathx import EPS, Vec, norm, unit


@dataclass(frozen=True)
class Sphere:
    c: Vec
    r: float


@dataclass(frozen=True)
class Capsule:
    a: Vec
    b: Vec
    r: float


@dataclass(frozen=True)
class AABB:
    lo: Vec
    hi: Vec

    @property
    def center(self) -> Vec:
        return (self.lo + self.hi) * 0.5

    def contains(self, p: Vec) -> bool:
        return bool(np.all(p >= self.lo) and np.all(p <= self.hi))

    def expanded(self, r: float) -> AABB:
        return AABB(self.lo - r, self.hi + r)


@dataclass
class Contact:
    t: float            # 0..1 along the sweep
    point: Vec          # contact point on the target surface
    normal: Vec         # unit normal pointing from target towards the striker
    depth: float = 0.0


def closest_on_segment(p: Vec, a: Vec, b: Vec) -> Vec:
    ab = b - a
    t = float(np.dot(p - a, ab) / max(float(np.dot(ab, ab)), EPS))
    return a + ab * min(1.0, max(0.0, t))


def sphere_capsule(s: Sphere, cap: Capsule) -> Contact | None:
    q = closest_on_segment(s.c, cap.a, cap.b)
    d = s.c - q
    dist = norm(d)
    rr = s.r + cap.r
    if dist >= rr:
        return None
    n = d / dist if dist > EPS else unit(s.c - (cap.a + cap.b) * 0.5)
    if norm(n) < EPS:
        n = np.array([0.0, 1.0, 0.0])
    return Contact(0.0, q + n * cap.r, n, rr - dist)


def sphere_sphere(s: Sphere, o: Sphere) -> Contact | None:
    d = s.c - o.c
    dist = norm(d)
    rr = s.r + o.r
    if dist >= rr:
        return None
    n = d / dist if dist > EPS else np.array([0.0, 0.0, -1.0])
    return Contact(0.0, o.c + n * o.r, n, rr - dist)


def sphere_aabb(s: Sphere, box: AABB) -> Contact | None:
    q = np.minimum(np.maximum(s.c, box.lo), box.hi)
    d = s.c - q
    dist = norm(d)
    if dist >= s.r:
        return None
    if dist > EPS:
        n = d / dist
        depth = s.r - dist
    else:  # centre inside: push out through the nearest face
        to_lo, to_hi = s.c - box.lo, box.hi - s.c
        m = np.concatenate([to_lo, to_hi])
        i = int(np.argmin(m))
        n = np.zeros(3)
        n[i % 3] = -1.0 if i < 3 else 1.0
        depth = float(m[i]) + s.r
        q = s.c.copy()
        q[i % 3] = box.lo[i % 3] if i < 3 else box.hi[i % 3]
    return Contact(0.0, q, n, depth)


def sweep_sphere_capsule(p0: Vec, p1: Vec, r: float, cap: Capsule, max_substeps: int = 24) -> Contact | None:
    """Continuous test of a moving sphere against a capsule via adaptive sub-sampling along the sweep segment.

    Substep spacing <= target radius, so a fist cannot skip over a limb. Returns the *first* contact.
    """
    length = norm(p1 - p0)
    n = int(min(max_substeps, max(1, math.ceil(length / max(min(r, cap.r), 0.02)))))
    ts = np.linspace(0.0, 1.0, n + 1)
    pts = p0[None, :] + (p1 - p0)[None, :] * ts[:, None]
    ab = cap.b - cap.a
    denom = max(float(np.dot(ab, ab)), EPS)
    u = np.clip(((pts - cap.a) @ ab) / denom, 0.0, 1.0)
    closest = cap.a[None, :] + ab[None, :] * u[:, None]
    d = pts - closest
    dist = np.linalg.norm(d, axis=1)
    hit = np.nonzero(dist < r + cap.r)[0]
    if hit.size == 0:
        return None
    i = int(hit[0])
    nrm = d[i] / dist[i] if dist[i] > EPS else unit(p0 - p1)
    if norm(nrm) < EPS:
        nrm = np.array([0.0, 1.0, 0.0])
    return Contact(float(ts[i]), closest[i] + nrm * cap.r, nrm, float(r + cap.r - dist[i]))


def sweep_sphere_sphere(p0: Vec, p1: Vec, r: float, target: Sphere) -> Contact | None:
    return sweep_sphere_capsule(p0, p1, r, Capsule(target.c, target.c, target.r))


def sweep_sphere_aabb(p0: Vec, p1: Vec, r: float, box: AABB, max_substeps: int = 24) -> Contact | None:
    length = norm(p1 - p0)
    n = int(min(max_substeps, max(1, math.ceil(length / max(r, 0.02)))))
    for i in range(n + 1):
        t = i / n
        c = sphere_aabb(Sphere(p0 + (p1 - p0) * t, r), box)
        if c is not None:
            c.t = t
            return c
    return None


class SpatialHash:
    """Uniform grid broadphase over static AABBs (environment). Cell size ~ typical prop size."""

    def __init__(self, cell: float = 2.0) -> None:
        self.cell = cell
        self._cells: dict[tuple[int, int, int], list[int]] = {}
        self.items: list[tuple[AABB, object]] = []

    def _range(self, lo: Vec, hi: Vec):
        c = self.cell
        a = np.floor(lo / c).astype(int)
        b = np.floor(hi / c).astype(int)
        for x in range(a[0], b[0] + 1):
            for y in range(a[1], b[1] + 1):
                for z in range(a[2], b[2] + 1):
                    yield (x, y, z)

    def insert(self, box: AABB, payload: object) -> None:
        idx = len(self.items)
        self.items.append((box, payload))
        for k in self._range(box.lo, box.hi):
            self._cells.setdefault(k, []).append(idx)

    def query(self, lo: Vec, hi: Vec) -> list[tuple[AABB, object]]:
        seen: set[int] = set()
        out = []
        for k in self._range(lo, hi):
            for i in self._cells.get(k, ()):
                if i not in seen:
                    seen.add(i)
                    out.append(self.items[i])
        return out
