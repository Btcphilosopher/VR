"""Fixed-timestep rigid props (heavy bag, crates, bottles) and a world container with a spatial hash of statics."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from ..engine.config import PhysicsCfg
from ..engine.mathx import Vec, v3
from .shapes import AABB, Capsule, Contact, Sphere, SpatialHash, sphere_aabb, sweep_sphere_aabb, sweep_sphere_capsule


@dataclass
class StaticCollider:
    name: str
    box: AABB
    material: str
    kind: str = "ENVIRONMENT"


@dataclass
class PropBody:
    """A dynamic prop: simple point-mass with spring return (heavy bag) or free flight (crates)."""

    name: str
    p: Vec
    mass: float
    material: str
    radius: float
    home: Vec | None = None
    spring_k: float = 0.0
    damping: float = 1.2
    v: Vec = field(default_factory=lambda: v3())
    height: float = 1.0
    grabbable: bool = True
    held_by: str | None = None

    def apply_impulse(self, j: Vec) -> None:
        self.v = self.v + j / max(self.mass, 1e-3)

    def step(self, dt: float, gravity: float) -> None:
        if self.held_by is not None:
            return
        acc = v3()
        if self.home is not None and self.spring_k > 0:
            acc = acc - (self.p - self.home) * (self.spring_k / self.mass)
        elif self.p[1] > self.radius:
            acc = acc + v3(0, -gravity, 0)
        self.v = self.v + acc * dt
        airborne = self.home is None and self.p[1] > self.radius + 0.03
        self.v = self.v * float(np.exp(-(0.12 if airborne else self.damping) * dt))
        self.p = self.p + self.v * dt
        if self.home is None and self.p[1] < self.radius:
            self.p[1] = self.radius
            self.v[1] = max(0.0, self.v[1]) * -0.2
            self.v[[0, 2]] *= 0.6

    @property
    def sphere(self) -> Sphere:
        return Sphere(self.p, self.radius)


class PhysicsWorld:
    def __init__(self, cfg: PhysicsCfg) -> None:
        self.cfg = cfg
        self.statics = SpatialHash(2.0)
        self.props: list[PropBody] = []
        self.time = 0.0
        self.steps = 0

    def add_static(self, s: StaticCollider) -> None:
        self.statics.insert(s.box, s)

    def add_prop(self, p: PropBody) -> PropBody:
        self.props.append(p)
        return p

    def step(self, dt: float) -> None:
        for p in self.props:
            p.step(dt, self.cfg.gravity)
        self.time += dt
        self.steps += 1

    def sweep_statics(self, p0: Vec, p1: Vec, r: float) -> tuple[Contact, StaticCollider] | None:
        lo = np.minimum(p0, p1) - r
        hi = np.maximum(p0, p1) + r
        best: tuple[Contact, StaticCollider] | None = None
        for box, payload in self.statics.query(lo, hi):
            c = sweep_sphere_aabb(p0, p1, r, box, self.cfg.sweep_substeps_max)
            if c is not None and (best is None or c.t < best[0].t):
                best = (c, payload)  # type: ignore[assignment]
        return best

    def sweep_props(self, p0: Vec, p1: Vec, r: float) -> tuple[Contact, PropBody] | None:
        best: tuple[Contact, PropBody] | None = None
        for pr in self.props:
            if pr.held_by is not None:
                continue
            c = sweep_sphere_capsule(p0, p1, r, Capsule(pr.p - v3(0, pr.height / 2 - pr.radius, 0), pr.p + v3(0, pr.height / 2 - pr.radius, 0), pr.radius),
                                     self.cfg.sweep_substeps_max)
            if c is not None and (best is None or c.t < best[0].t):
                best = (c, pr)
        return best

    def blocked(self, p: Vec, r: float = 0.25) -> bool:
        lo, hi = p - r, p + r
        for box, _ in self.statics.query(lo, hi):
            if sphere_aabb(Sphere(p, r), box) is not None:
                return True
        return False
