# Aureom GlassOS — Rust / Kotlin Bridge Specification

## 1. Boundary Architecture

The bridge between the Kotlin host application and the Rust core runtime is designed around **UniFFI** and zero-copy pinned native buffers for deterministic performance and memory safety.

```
┌────────────────────────────────────────────────────────┐
│                      Kotlin / JVM                      │
│  - GlassOSViewModel & Jetpack Compose UI               │
│  - Android SensorManager callbacks                     │
│  - AudioRecord buffer collector                        │
└──────────────────────────┬─────────────────────────────┘
                           │ UniFFI / Direct JNI Call
┌──────────────────────────▼─────────────────────────────┐
│                 Rust JNI FFI Bridge                    │
│  - Pinned DirectByteBuffer for IMU & Audio batches     │
│  - Thread-safe Arc<CoreRuntime> handle                 │
│  - Panic unwind catch boundary (`catch_unwind`)        │
└──────────────────────────┬─────────────────────────────┘
                           │ Zero-copy internal dispatch
┌──────────────────────────▼─────────────────────────────┐
│                    Rust Core Engine                    │
│  - Typed Event Bus & Queue Supervisor                  │
│  - Madgwick 9-Axis AHRS & Timestamp Alignment          │
│  - Ring-buffered Telemetry (p50 / p95 / p99)           │
└────────────────────────────────────────────────────────┘
```

## 2. Memory Ownership Rules

1. **Host-Owned Lifetimes**: The Kotlin runtime instantiates a `NativeCoreBridge` which holds a 64-bit raw pointer (`jlong`) to the heap-allocated Rust `CoreRuntime`.
2. **Deterministic Destruction**: When the Android host terminates or unbinds, `destroyRuntime(handle)` is explicitly called, invoking `Box::from_raw` inside Rust to free all allocations.
3. **No Per-Sample Crossing**: High-rate sensors (100 Hz IMU) are buffered into direct byte buffers (arrays of `float[6]` with 64-bit nanosecond timestamps). The JNI call passes a batch pointer, avoiding JNI transition overhead (1.2 microseconds vs 20 nanoseconds per sample).
4. **Panic Isolation**: All Rust FFI entry points wrap their logic inside `std::panic::catch_unwind`. If an unexpected panic occurs in a sub-service, it returns an explicit `FfiResult::Error` instead of terminating the host Android process.

## 3. Fallback Native Simulator

For development environments where native shared libraries (`.so`) are compiling or running in mock mode, `NativeCoreBridge` includes a fully deterministic pure-Kotlin software emulation of the Rust state machine, ensuring identical state transitions and queue accounting.
