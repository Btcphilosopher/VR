# Aureom GlassOS — Build and Test Instructions

## Prerequisites
- Android Studio Ladybug+ or Gradle 8.10+
- JDK 17 or JDK 21
- Rust toolchain (`cargo`, `rustc` 1.78+) for native core compilation
- R 4.2+ (with `ggplot2`, `dplyr`, `tidyr`, `readr`) for analytics scripts

## 1. Android Application Build
```bash
# Clean and assemble debug APK
gradle :app:assembleDebug

# Run unit and Robolectric tests
gradle :app:testDebugUnitTest
```

## 2. Rust Core Build & Test
```bash
cd core-rust

# Verify formatting and clippy
cargo check
cargo test --verbose

# Build release shared library
cargo build --release
```

## 3. R Analytics Verification
```bash
cd analytics-r

# Run reproducible analysis and generate report
Rscript reproducible_report.R
```
