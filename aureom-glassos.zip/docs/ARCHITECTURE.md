# Aureom GlassOS — System Architecture

> *"Code at the speed of civilisation."*

Aureom GlassOS is an application-based operating environment designed specifically for optical smartglasses, engineered with OS-grade discipline. It runs as a host application atop Android, providing a hardened runtime, deterministic service orchestration, zero-trust privacy boundaries, and an optical heads-up display (HUD) presentation pipeline.

---

## 1. Architectural Overview & Boundaries

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           AUREOM GLASSOS RUNTIME                            │
├─────────────────────────────────────────────────────────────────────────────┤
│  HUD PRESENTATION (Compose / Optical Shader) │ COMPANION PHONE LINK (BLE/TCP)│
│  - Dark-field optics (true black = clear)    │ - Authenticated E2E Session  │
│  - Monocular (15° FOV) & Binocular (30° FOV) │ - Route & Notification Relay │
│  - Head-locked HUD & Safe-zone composition   │ - Telemetry & Data Export    │
├─────────────────────────────────────────────────────────────────────────────┤
│                           KOTLIN HOST APPLICATION                           │
│  - GlassOSViewModel (Single source of state) │ Android SensorManager        │
│  - Temple Touchpad & Rocker Input Adapter    │ AudioRecord & TTS Engine     │
│  - System Service Supervisor (Crash Guard)   │ Foreground Service & WakeLock│
├─────────────────────────────────────────────────────────────────────────────┤
│                     RUST CORE RUNTIME (uniffi / JNI)                        │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────┐  │
│  │   Typed Event Bus     │  │   Service Supervisor  │  │ Resource Policy │  │
│  │ (Bounded, Backpress.) │  │  (Restart & Backoff)  │  │(Eco, Normal, Th)│  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────┘  │
│  ┌───────────────────────┐  ┌───────────────────────┐  ┌─────────────────┐  │
│  │  Sensor Fusion Filter │  │  Notification Router  │  │ Telemetry Buffer│  │
│  │ (Madgwick 9-Axis AHRS)│  │ (Priority, Redaction) │  │(p50, p95, p99)  │  │
│  └───────────────────────┘  └───────────────────────┘  └─────────────────┘  │
├─────────────────────────────────────────────────────────────────────────────┤
│                          HOST PLATFORM (ANDROID OS)                         │
│  - Linux Kernel, Hardware Drivers, Sandboxed Application Process            │
│  - Android Runtime (ART), System Permissions, SurfaceFlinger                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Core Subsystems

### 2.1 Rust Core Runtime
- **Typed Event Bus**: Ring-buffered multi-producer, single-consumer (MPSC) channel with explicit overflow handling (`DropOldest`, `Reject`, `BackpressureWait`).
- **Service Supervisor**: Monitors sub-services (`NavigationService`, `VoiceService`, `SensorService`, `NotificationService`, `CompanionService`). Automatically restarts failed tasks with exponential backoff and degraded-mode fallback.
- **Resource Policy Engine**: Enforces three operating regimes:
  1. `NormalMode`: 60 FPS, full sensor rate (100 Hz), full brightness range.
  2. `LowPowerMode`: 30 FPS, decimated sensor rate (25 Hz), capped brightness (50%), disabled background sync.
  3. `ThermalDegraded`: 15 FPS, IMU throttled (10 Hz), voice continuous listener disabled, warning HUD overlay.
- **Sensor Timestamping & Fusion**: Aligns monotonic platform timestamps (`CLOCK_BOOTTIME`) with IMU frames; executes 9-axis Madgwick AHRS orientation filter.

### 2.2 Privacy & Security Broker
- **Explicit Sensor Ledger**: Every access to microphone, camera, or GNSS is logged with timestamp, caller service, and purpose.
- **Hardware Indicator Simulation**: Replicates hardware privacy LED for camera and microphone in the HUD status layer.
- **Sensitive Content Masking**: Notifications containing private data (e.g. 2FA codes, sensitive messages) are masked on the HUD until explicitly unlocked via touchpad tap.

### 2.3 Heads-Up Display (HUD) Presentation
- **Optical Combiner Profile**: Emulates optical see-through displays (MicroLED Waveguide, Birdbath optics, Prism combiner). Since smartglasses cannot display black pixels (black = transparent), all visuals use additive luminous rendering with high-contrast amber/cyan/emerald accents.
- **Safe Zones**: Renders within a 15°–30° field-of-view bounding box to prevent eye strain and chromatic aberration at optical boundaries.

### 2.4 Offline R Analytics Toolkit
- Telemetry streams are exported in structured CSV/Parquet format.
- Reproducible R scripts calculate empirical frame-time distributions, 9-axis gyro drift, battery discharge slopes, and voice command confusion matrices.
