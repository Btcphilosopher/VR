# Aureom GlassOS — Permission & Privacy Broker Model

Wearable devices are uniquely intimate: microphones and optical sensors rest directly on the user's face. Aureom GlassOS enforces strict OS-grade separation between the **Host OS Sandbox** and the **GlassOS Internal Service Broker**.

## 1. Distinction of Authority

- **Host OS Authority (Android)**: Owns the Linux kernel, physical hardware drivers, Android manifest permissions (`RECORD_AUDIO`, `CAMERA`, `ACCESS_FINE_LOCATION`), and hardware enforcement sandboxes.
- **GlassOS Authority**: Operates inside the application sandbox and mediates access among internal modules (`VoiceEngine`, `NavigationEngine`, `CaptureService`, `DiagnosticsEngine`).

## 2. Least-Privilege Policy

1. **Explicit Purpose Specification**: Every internal request for sensor data must declare:
   - Requesting Service Identifier (e.g. `com.aureom.service.voice`)
   - Sensor Type (`AudioStream`, `CameraFrame`, `GnssLocation`, `ImuStream`)
   - Duration & Sampling Rate (e.g. `Once`, `ActiveSession`, `Decimated10Hz`)
   - Rationale string visible in the Privacy Center audit log.
2. **HUD Privacy Indicators**:
   - Whenever the microphone is capturing audio, an optical green/amber microphone dot is permanently illuminated on the HUD status bar.
   - Whenever the camera is activated, a prominent HUD indicator flashes and an optical status icon is displayed.
3. **Emergency Sensor Kill Switch**: A single action in the Privacy Center or a long-press combination disables all active capture sessions immediately, dropping buffers without disk writes.
4. **Data Retention & Redaction**:
   - Audio buffers for voice commands are kept strictly in volatile RAM and zeroed immediately after command parsing.
   - Telemetry logs redact all user messages, notification bodies, and precise coordinate offsets before exporting to CSV/Parquet.
