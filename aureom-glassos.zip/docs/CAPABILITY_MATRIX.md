# Aureom GlassOS — Device Capability Matrix

This matrix documents the hardware requirements, operating assumptions, and fallback behavior for wearable glass devices versus the Android host application.

| Subsystem | Ideal Hardware Feature | Android Host Reality | GlassOS Adapter Strategy | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Optics** | Binocular MicroLED Waveguide (10,000 nits, 30° FOV) | Smartphone / Tablet OLED/LCD Screen | Dark-field combiner shader; selectable Monocular (Right 15°) or Binocular (30°) safe-box | **Implemented** |
| **Display Mode**| Transparent see-through optical combiner | Emissive panel | Black pixel transparency simulation `#000000` = clear world view; luminescent UI overlays | **Implemented** |
| **Input: Touch** | Capacitive Temple Touchpad (Tap, Swipe, Double Tap, Hold) | Touchscreen on phone / external trackpad | Dedicated on-screen Temple Touchpad interactive simulator & hardware volume key bindings | **Implemented** |
| **Input: Voice** | Multi-mic beamforming array with push-to-talk hardware button | Android AudioRecord API / microphone | Push-to-talk state machine with deterministic command grammar and audio level visualizer | **Implemented** |
| **Input: Keys** | Physical Temple Action Rocker | Physical Volume / Power Keys | Key-event interception (`KEYCODE_VOLUME_UP`, `KEYCODE_VOLUME_DOWN`, `KEYCODE_BACK`, `KEYCODE_ENTER`) | **Implemented** |
| **Tracking: 9-DOF**| Calibrated IMU (Accel + Gyro + Magnetometer) in frame | Android SensorManager (`TYPE_ROTATION_VECTOR`) | Monotonic timestamping, jitter filtering, drift simulation, Madgwick AHRS fusion | **Implemented** |
| **Tracking: Spatial**| 6-DoF SLAM with dual grayscale cameras + depth sensor | Not available on general Android phones without ARCore | Explicitly labelled "Simulated World-Anchor Mode" with drift alerts; does not fake full 6-DoF SLAM | **Documented** |
| **Eye Tracking** | Dual infrared glint cameras in frame rims | Not available on standard Android hardware | Capabilities flagged as `UNSUPPORTED`; fallback to fixed glance-safe placement | **Documented** |
| **Camera Capture**| Front-facing 12MP ultra-wide sensor | Android Camera2 API | Hardened permission broker; explicit HUD indicator whenever camera stream is open | **Implemented** |
| **Companion Link** | Authenticated Bluetooth Low Energy / Wi-Fi Aware | Android Bluetooth / TCP Loopback | Session handshake, shared AES-GCM session key simulation, bidirectional telemetry stream | **Implemented** |
| **Thermal / Power**| Micro-thermistor array on temple PCB | Android `BatteryManager` & `HardwarePropertiesManager` | 3-tier resource policy: Normal (60Hz), Eco (30Hz), Throttled (15Hz), plus simulated heating trigger | **Implemented** |
