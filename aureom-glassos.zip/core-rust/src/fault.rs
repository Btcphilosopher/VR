use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FaultReport {
    pub fault_id: u64,
    pub timestamp_ms: u64,
    pub subsystem: String,
    pub error_message: String,
    pub recovered: bool,
}

pub struct FaultManager {
    faults: Vec<FaultReport>,
}

impl FaultManager {
    pub fn new() -> Self {
        Self { faults: Vec::new() }
    }

    pub fn record_fault(&mut self, subsystem: &str, error: &str, recovered: bool, timestamp_ms: u64) {
        static FAULT_CTR: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        self.faults.push(FaultReport {
            fault_id: FAULT_CTR.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
            timestamp_ms,
            subsystem: subsystem.to_string(),
            error_message: error.to_string(),
            recovered,
        });
    }

    pub fn reports(&self) -> &[FaultReport] {
        &self.faults
    }
}
