use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PermissionScope {
    Microphone,
    Camera,
    FineLocation,
    ImuSensors,
    CompanionTransport,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PermissionAuditEntry {
    pub timestamp_ms: u64,
    pub service_id: String,
    pub scope: PermissionScope,
    pub granted: bool,
    pub rationale: String,
}

pub struct PermissionBroker {
    granted_scopes: Vec<PermissionScope>,
    audit_log: Vec<PermissionAuditEntry>,
}

impl PermissionBroker {
    pub fn new() -> Self {
        Self {
            granted_scopes: vec![
                PermissionScope::ImuSensors,
                PermissionScope::CompanionTransport,
            ],
            audit_log: Vec::new(),
        }
    }

    pub fn grant(&mut self, scope: PermissionScope) {
        if !self.granted_scopes.contains(&scope) {
            self.granted_scopes.push(scope);
        }
    }

    pub fn revoke(&mut self, scope: PermissionScope) {
        self.granted_scopes.retain(|s| *s != scope);
    }

    pub fn check(&mut self, service_id: &str, scope: PermissionScope, rationale: &str, timestamp_ms: u64) -> bool {
        let granted = self.granted_scopes.contains(&scope);
        self.audit_log.push(PermissionAuditEntry {
            timestamp_ms,
            service_id: service_id.to_string(),
            scope,
            granted,
            rationale: rationale.to_string(),
        });
        granted
    }

    pub fn audit_log(&self) -> &[PermissionAuditEntry] {
        &self.audit_log
    }
}
