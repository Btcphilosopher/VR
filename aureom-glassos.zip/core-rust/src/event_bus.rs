use serde::{Deserialize, Serialize};
use std::collections::VecDeque;

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum Priority {
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Topic {
    SystemPowerState,
    SystemThermalAlert,
    InputTempleGesture,
    InputPhysicalKey,
    InputVoiceCommand,
    SensorImuBatch,
    SensorGnssUpdate,
    NavigationInstruction,
    NotificationIncoming,
    NotificationDismissed,
    CompanionConnectionState,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlassEvent {
    pub id: u64,
    pub timestamp_ns: u64,
    pub priority: Priority,
    pub topic: Topic,
    pub payload: String,
}

impl GlassEvent {
    pub fn new(priority: Priority, topic: Topic, payload: impl Into<String>) -> Self {
        static COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
        Self {
            id: COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
            timestamp_ns: 0,
            priority,
            topic,
            payload: payload.into(),
        }
    }
}

pub struct EventBus {
    queue: VecDeque<GlassEvent>,
    capacity: usize,
    dropped_count: u64,
    total_published: u64,
}

impl EventBus {
    pub fn new(capacity: usize) -> Self {
        Self {
            queue: VecDeque::with_capacity(capacity),
            capacity,
            dropped_count: 0,
            total_published: 0,
        }
    }

    /// Publishes an event with backpressure drop policy.
    /// Critical events drop the oldest low-priority event rather than being dropped.
    pub fn publish(&mut self, event: GlassEvent) -> bool {
        self.total_published += 1;
        if self.queue.len() >= self.capacity {
            if event.priority == Priority::Critical {
                if let Some(idx) = self.queue.iter().position(|e| e.priority < Priority::High) {
                    self.queue.remove(idx);
                    self.dropped_count += 1;
                } else {
                    self.queue.pop_front();
                    self.dropped_count += 1;
                }
            } else {
                self.dropped_count += 1;
                return false;
            }
        }
        self.queue.push_back(event);
        true
    }

    pub fn poll(&mut self) -> Option<GlassEvent> {
        self.queue.pop_front()
    }

    pub fn queue_depth(&self) -> usize {
        self.queue.len()
    }

    pub fn dropped_count(&self) -> u64 {
        self.dropped_count
    }

    pub fn total_published(&self) -> u64 {
        self.total_published
    }
}
