use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
pub enum NotificationPriority {
    Low = 0,
    Standard = 1,
    Urgent = 2,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Notification {
    pub id: String,
    pub app_source: String,
    pub title: String,
    pub body_masked: String,
    pub body_raw: String,
    pub priority: NotificationPriority,
    pub is_sensitive: bool,
    pub timestamp_ms: u64,
    pub dismissed: bool,
}

pub struct NotificationRouter {
    notifications: Vec<Notification>,
    quiet_hours_enabled: bool,
}

impl NotificationRouter {
    pub fn new() -> Self {
        Self {
            notifications: Vec::new(),
            quiet_hours_enabled: false,
        }
    }

    pub fn post(&mut self, mut notif: Notification) -> bool {
        if self.quiet_hours_enabled && notif.priority < NotificationPriority::Urgent {
            return false;
        }
        if notif.is_sensitive {
            notif.body_masked = "●●● Preview Hidden for Privacy ●●●".to_string();
        }
        self.notifications.push(notif);
        true
    }

    pub fn dismiss(&mut self, id: &str) -> bool {
        if let Some(notif) = self.notifications.iter_mut().find(|n| n.id == id) {
            notif.dismissed = true;
            true
        } else {
            false
        }
    }

    pub fn active_notifications(&self) -> Vec<&Notification> {
        self.notifications.iter().filter(|n| !n.dismissed).collect()
    }

    pub fn set_quiet_hours(&mut self, enabled: bool) {
        self.quiet_hours_enabled = enabled;
    }
}
