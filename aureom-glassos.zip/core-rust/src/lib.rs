//! Aureom GlassOS Core Runtime
//! "Code at the speed of civilisation."
//!
//! Provides OS-grade service orchestration, bounded typed event bus,
//! Madgwick 9-axis AHRS sensor fusion, and resource budgeting for smartglasses.

pub mod bridge;
pub mod capabilities;
pub mod companion_transport;
pub mod config;
pub mod event_bus;
pub mod fault;
pub mod notifications;
pub mod permissions;
pub mod persistence;
pub mod resource_policy;
pub mod runtime;
pub mod scheduler;
pub mod sensors;
pub mod supervisor;
pub mod telemetry;

pub use capabilities::{CapabilitiesRegistry, DeviceCapability, DisplayProfile};
pub use event_bus::{EventBus, GlassEvent, Priority, Topic};
pub use notifications::{Notification, NotificationPriority, NotificationRouter};
pub use resource_policy::{PowerMode, ResourcePolicy};
pub use runtime::{GlassRuntime, RuntimeState};
pub use sensors::{AhrsFilter, ImuSample, Quaternion};
pub use supervisor::{ServiceHealth, ServiceId, ServiceSupervisor};
pub use telemetry::{FrameTimeSample, TelemetryBuffer, TelemetrySnapshot};
