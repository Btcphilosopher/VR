use crate::capabilities::CapabilitiesRegistry;
use crate::event_bus::{EventBus, GlassEvent, Priority, Topic};
use crate::notifications::NotificationRouter;
use crate::resource_policy::{PowerMode, ResourcePolicy};
use crate::sensors::AhrsFilter;
use crate::supervisor::ServiceSupervisor;
use crate::telemetry::TelemetryBuffer;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum RuntimeState {
    Booting,
    Active,
    LowPower,
    ThermalThrottled,
    Recovering,
    Suspended,
}

pub struct GlassRuntime {
    state: RuntimeState,
    event_bus: EventBus,
    supervisor: ServiceSupervisor,
    capabilities: CapabilitiesRegistry,
    notifications: NotificationRouter,
    resource_policy: ResourcePolicy,
    ahrs: AhrsFilter,
    telemetry: TelemetryBuffer,
}

impl GlassRuntime {
    pub fn new() -> Self {
        let mut runtime = Self {
            state: RuntimeState::Booting,
            event_bus: EventBus::new(256),
            supervisor: ServiceSupervisor::new(),
            capabilities: CapabilitiesRegistry::default_glasses_profile(),
            notifications: NotificationRouter::new(),
            resource_policy: ResourcePolicy::new(),
            ahrs: AhrsFilter::new(0.041),
            telemetry: TelemetryBuffer::new(1000),
        };
        runtime.initialize_services();
        runtime.state = RuntimeState::Active;
        runtime
    }

    fn initialize_services(&mut self) {
        use crate::supervisor::ServiceId;
        self.supervisor.register(ServiceId::Navigation, "Turn-by-turn guidance");
        self.supervisor.register(ServiceId::Voice, "Push-to-talk speech engine");
        self.supervisor.register(ServiceId::Sensors, "IMU 9-DoF & environmental telemetry");
        self.supervisor.register(ServiceId::Companion, "Encrypted BLE transport");
        self.supervisor.register(ServiceId::Notifications, "Priority notification broker");
    }

    pub fn state(&self) -> RuntimeState {
        self.state
    }

    pub fn transition_power_mode(&mut self, mode: PowerMode) {
        self.resource_policy.set_mode(mode);
        self.state = match mode {
            PowerMode::Normal => RuntimeState::Active,
            PowerMode::Eco => RuntimeState::LowPower,
            PowerMode::ThermalThrottled => RuntimeState::ThermalThrottled,
        };

        let event = GlassEvent::new(
            Priority::Critical,
            Topic::SystemPowerState,
            format!("Transitioned to {:?}", mode),
        );
        self.event_bus.publish(event);
    }

    pub fn event_bus(&mut self) -> &mut EventBus {
        &mut self.event_bus
    }

    pub fn supervisor(&mut self) -> &mut ServiceSupervisor {
        &mut self.supervisor
    }

    pub fn capabilities(&self) -> &CapabilitiesRegistry {
        &self.capabilities
    }

    pub fn notifications(&mut self) -> &mut NotificationRouter {
        &mut self.notifications
    }

    pub fn ahrs(&mut self) -> &mut AhrsFilter {
        &mut self.ahrs
    }

    pub fn telemetry(&mut self) -> &mut TelemetryBuffer {
        &mut self.telemetry
    }
}
