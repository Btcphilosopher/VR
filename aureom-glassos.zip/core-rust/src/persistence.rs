use crate::config::UserPreferences;
use std::collections::HashMap;

pub struct StatePersistence {
    store: HashMap<String, String>,
}

impl StatePersistence {
    pub fn new() -> Self {
        Self {
            store: HashMap::new(),
        }
    }

    pub fn save_prefs(&mut self, prefs: &UserPreferences) {
        if let Ok(json) = serde_json::to_string(prefs) {
            self.store.insert("prefs".to_string(), json);
        }
    }

    pub fn load_prefs(&self) -> UserPreferences {
        if let Some(json) = self.store.get("prefs") {
            serde_json::from_str(json).unwrap_or_default()
        } else {
            UserPreferences::default()
        }
    }
}
