use serde::{Deserialize, Serialize};
use std::collections::VecDeque;

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct FrameTimeSample {
    pub frame_time_ms: f32,
    pub input_to_display_ms: f32,
    pub timestamp_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetrySnapshot {
    pub p50_frame_time_ms: f32,
    pub p95_frame_time_ms: f32,
    pub p99_frame_time_ms: f32,
    pub sample_count: usize,
    pub current_queue_depth: usize,
}

pub struct TelemetryBuffer {
    samples: VecDeque<FrameTimeSample>,
    capacity: usize,
}

impl TelemetryBuffer {
    pub fn new(capacity: usize) -> Self {
        Self {
            samples: VecDeque::with_capacity(capacity),
            capacity,
        }
    }

    pub fn record(&mut self, sample: FrameTimeSample) {
        if self.samples.len() >= self.capacity {
            self.samples.pop_front();
        }
        self.samples.push_back(sample);
    }

    pub fn snapshot(&self, current_queue_depth: usize) -> TelemetrySnapshot {
        if self.samples.is_empty() {
            return TelemetrySnapshot {
                p50_frame_time_ms: 16.6,
                p95_frame_time_ms: 16.6,
                p99_frame_time_ms: 16.6,
                sample_count: 0,
                current_queue_depth,
            };
        }

        let mut sorted: Vec<f32> = self.samples.iter().map(|s| s.frame_time_ms).collect();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));

        let len = sorted.len();
        let p50 = sorted[(len as f32 * 0.50) as usize];
        let p95 = sorted[((len as f32 * 0.95) as usize).min(len - 1)];
        let p99 = sorted[((len as f32 * 0.99) as usize).min(len - 1)];

        TelemetrySnapshot {
            p50_frame_time_ms: p50,
            p95_frame_time_ms: p95,
            p99_frame_time_ms: p99,
            sample_count: len,
            current_queue_depth,
        }
    }
}
