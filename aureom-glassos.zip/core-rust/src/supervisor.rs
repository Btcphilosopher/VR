use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ServiceId {
    Navigation,
    Voice,
    Sensors,
    Companion,
    Notifications,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ServiceHealth {
    Healthy,
    Degraded,
    Restarting,
    Failed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceRecord {
    pub id: ServiceId,
    pub name: String,
    pub health: ServiceHealth,
    pub restarts: u32,
    pub max_restarts: u32,
    pub last_heartbeat_ms: u64,
}

pub struct ServiceSupervisor {
    services: HashMap<ServiceId, ServiceRecord>,
}

impl ServiceSupervisor {
    pub fn new() -> Self {
        Self {
            services: HashMap::new(),
        }
    }

    pub fn register(&mut self, id: ServiceId, name: impl Into<String>) {
        self.services.insert(
            id,
            ServiceRecord {
                id,
                name: name.into(),
                health: ServiceHealth::Healthy,
                restarts: 0,
                max_restarts: 5,
                last_heartbeat_ms: 0,
            },
        );
    }

    pub fn report_failure(&mut self, id: ServiceId, reason: &str) -> ServiceHealth {
        if let Some(record) = self.services.get_mut(&id) {
            record.restarts += 1;
            if record.restarts > record.max_restarts {
                record.health = ServiceHealth::Failed;
            } else {
                record.health = ServiceHealth::Degraded;
            }
            record.health
        } else {
            ServiceHealth::Failed
        }
    }

    pub fn heartbeat(&mut self, id: ServiceId, timestamp_ms: u64) {
        if let Some(record) = self.services.get_mut(&id) {
            record.last_heartbeat_ms = timestamp_ms;
            if record.health == ServiceHealth::Degraded {
                record.health = ServiceHealth::Healthy;
            }
        }
    }

    pub fn all_services(&self) -> Vec<&ServiceRecord> {
        self.services.values().collect()
    }
}
