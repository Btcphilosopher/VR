use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum PowerMode {
    Normal,
    Eco,
    ThermalThrottled,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourcePolicy {
    pub mode: PowerMode,
    pub target_fps: u32,
    pub sensor_rate_hz: u32,
    pub max_luminance_pct: f32,
    pub allow_background_sync: bool,
    pub continuous_mic_enabled: bool,
}

impl ResourcePolicy {
    pub fn new() -> Self {
        Self::for_mode(PowerMode::Normal)
    }

    pub fn for_mode(mode: PowerMode) -> Self {
        match mode {
            PowerMode::Normal => Self {
                mode,
                target_fps: 60,
                sensor_rate_hz: 100,
                max_luminance_pct: 1.0,
                allow_background_sync: true,
                continuous_mic_enabled: true,
            },
            PowerMode::Eco => Self {
                mode,
                target_fps: 30,
                sensor_rate_hz: 25,
                max_luminance_pct: 0.50,
                allow_background_sync: false,
                continuous_mic_enabled: false,
            },
            PowerMode::ThermalThrottled => Self {
                mode,
                target_fps: 15,
                sensor_rate_hz: 10,
                max_luminance_pct: 0.30,
                allow_background_sync: false,
                continuous_mic_enabled: false,
            },
        }
    }

    pub fn set_mode(&mut self, mode: PowerMode) {
        *self = Self::for_mode(mode);
    }
}
