use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DisplayType {
    MicroLedWaveguide,
    BirdbathOptical,
    PrismMonocular,
    OledCombiner,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DisplayProfile {
    pub display_type: DisplayType,
    pub fov_degrees: f32,
    pub is_binocular: bool,
    pub max_luminance_nits: u32,
    pub safe_zone_margin_pct: f32,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum DeviceCapability {
    Imu9Dof,
    CameraCapture,
    AmbientLightSensor,
    TempleTouchpad,
    PhysicalActionRocker,
    MicrophoneBeamforming,
    EyeTracking,
    SpatialDepthMapping,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CapabilitiesRegistry {
    pub display: DisplayProfile,
    pub supported_capabilities: Vec<DeviceCapability>,
    pub simulated_capabilities: Vec<DeviceCapability>,
}

impl CapabilitiesRegistry {
    pub fn default_glasses_profile() -> Self {
        Self {
            display: DisplayProfile {
                display_type: DisplayType::MicroLedWaveguide,
                fov_degrees: 28.0,
                is_binocular: false,
                max_luminance_nits: 8000,
                safe_zone_margin_pct: 0.15,
            },
            supported_capabilities: vec![
                DeviceCapability::Imu9Dof,
                DeviceCapability::TempleTouchpad,
                DeviceCapability::PhysicalActionRocker,
                DeviceCapability::MicrophoneBeamforming,
                DeviceCapability::CameraCapture,
            ],
            simulated_capabilities: vec![
                DeviceCapability::EyeTracking,
                DeviceCapability::SpatialDepthMapping,
            ],
        }
    }

    pub fn is_supported(&self, cap: DeviceCapability) -> bool {
        self.supported_capabilities.contains(&cap)
    }

    pub fn is_simulated(&self, cap: DeviceCapability) -> bool {
        self.simulated_capabilities.contains(&cap)
    }
}
