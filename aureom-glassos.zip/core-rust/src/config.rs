use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UserPreferences {
    pub display_profile_id: String,
    pub brightness_level: f32,
    pub quiet_hours: bool,
    pub reduced_motion: bool,
    pub voice_wake_word_enabled: bool,
}

impl Default for UserPreferences {
    fn default() -> Self {
        Self {
            display_profile_id: "micro_led_waveguide".to_string(),
            brightness_level: 0.85,
            quiet_hours: false,
            reduced_motion: false,
            voice_wake_word_enabled: false,
        }
    }
}
