use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

pub struct CancellationToken {
    cancelled: Arc<AtomicBool>,
}

impl CancellationToken {
    pub fn new() -> Self {
        Self {
            cancelled: Arc::new(AtomicBool::new(false)),
        }
    }

    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::Relaxed);
    }

    pub fn is_cancelled(&self) -> bool {
        self.cancelled.load(Ordering::Relaxed)
    }
}

pub struct TaskScheduler {
    active_tasks: usize,
}

impl TaskScheduler {
    pub fn new() -> Self {
        Self { active_tasks: 0 }
    }

    pub fn spawn_task(&mut self) -> CancellationToken {
        self.active_tasks += 1;
        CancellationToken::new()
    }

    pub fn complete_task(&mut self) {
        if self.active_tasks > 0 {
            self.active_tasks -= 1;
        }
    }
}
