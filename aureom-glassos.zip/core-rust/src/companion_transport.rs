use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CompanionLinkState {
    Disconnected,
    Advertising,
    Handshaking,
    Connected,
    Reconnecting,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompanionSession {
    pub state: CompanionLinkState,
    pub peer_device_name: String,
    pub session_token: u32,
    pub auth_pin: u32,
    pub last_ping_ms: u64,
}

pub struct CompanionTransport {
    session: CompanionSession,
}

impl CompanionTransport {
    pub fn new() -> Self {
        Self {
            session: CompanionSession {
                state: CompanionLinkState::Disconnected,
                peer_device_name: "Unpaired".to_string(),
                session_token: 0,
                auth_pin: 742918,
                last_ping_ms: 0,
            },
        }
    }

    pub fn initiate_pairing(&mut self, device_name: &str) -> u32 {
        self.session.state = CompanionLinkState::Handshaking;
        self.session.peer_device_name = device_name.to_string();
        self.session.auth_pin = 742918;
        self.session.auth_pin
    }

    pub fn confirm_pairing(&mut self, pin: u32) -> bool {
        if pin == self.session.auth_pin {
            self.session.state = CompanionLinkState::Connected;
            self.session.session_token = 0xA1B2C3D4;
            true
        } else {
            false
        }
    }

    pub fn disconnect(&mut self) {
        self.session.state = CompanionLinkState::Disconnected;
    }

    pub fn session(&self) -> &CompanionSession {
        &self.session
    }
}
