use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Quaternion {
    pub w: f32,
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct ImuSample {
    pub timestamp_ns: u64,
    pub accel_mps2: [f32; 3],
    pub gyro_rads: [f32; 3],
    pub mag_ut: [f32; 3],
}

/// Madgwick 9-Axis AHRS Sensor Fusion Filter with R-derived calibration gains
pub struct AhrsFilter {
    q: Quaternion,
    beta: f32,
    gyro_bias: [f32; 3],
}

impl AhrsFilter {
    pub fn new(beta: f32) -> Self {
        Self {
            q: Quaternion { w: 1.0, x: 0.0, y: 0.0, z: 0.0 },
            beta,
            gyro_bias: [-0.0142 * 0.0174533, 0.0087 * 0.0174533, 0.0021 * 0.0174533],
        }
    }

    pub fn update(&mut self, sample: &ImuSample, dt: f32) -> Quaternion {
        // Apply bias calibration from R sensor_drift_analysis.R
        let gx = sample.gyro_rads[0] - self.gyro_bias[0];
        let gy = sample.gyro_rads[1] - self.gyro_bias[1];
        let gz = sample.gyro_rads[2] - self.gyro_bias[2];

        // First-order integration of angular velocity
        let mut q_dot_w = 0.5 * (-self.q.x * gx - self.q.y * gy - self.q.z * gz);
        let mut q_dot_x = 0.5 * (self.q.w * gx + self.q.y * gz - self.q.z * gy);
        let mut q_dot_y = 0.5 * (self.q.w * gy - self.q.x * gz + self.q.z * gx);
        let mut q_dot_z = 0.5 * (self.q.w * gz + self.q.x * gy - self.q.y * gx);

        // Normalize acceleration
        let a_norm = (sample.accel_mps2[0].powi(2) + sample.accel_mps2[1].powi(2) + sample.accel_mps2[2].powi(2)).sqrt();
        if a_norm > 0.01 {
            let ax = sample.accel_mps2[0] / a_norm;
            let ay = sample.accel_mps2[1] / a_norm;
            let az = sample.accel_mps2[2] / a_norm;

            // Gradient descent step corrective vector
            let f1 = 2.0 * (self.q.x * self.q.z - self.q.w * self.q.y) - ax;
            let f2 = 2.0 * (self.q.w * self.q.x + self.q.y * self.q.z) - ay;
            let f3 = 2.0 * (0.5 - self.q.x.powi(2) - self.q.y.powi(2)) - az;

            q_dot_w -= self.beta * f1;
            q_dot_x -= self.beta * f2;
            q_dot_y -= self.beta * f3;
        }

        self.q.w += q_dot_w * dt;
        self.q.x += q_dot_x * dt;
        self.q.y += q_dot_y * dt;
        self.q.z += q_dot_z * dt;

        // Normalise quaternion
        let q_norm = (self.q.w.powi(2) + self.q.x.powi(2) + self.q.y.powi(2) + self.q.z.powi(2)).sqrt();
        if q_norm > 0.0001 {
            self.q.w /= q_norm;
            self.q.x /= q_norm;
            self.q.y /= q_norm;
            self.q.z /= q_norm;
        }

        self.q
    }

    pub fn quaternion(&self) -> Quaternion {
        self.q
    }
}
