//! JNI / UniFFI C-ABI Bridge definitions for Aureom GlassOS
//! Maps Kotlin native method invocations into safe Rust Core state machine calls.

use crate::runtime::{GlassRuntime, RuntimeState};
use crate::resource_policy::PowerMode;
use std::ffi::c_void;

#[repr(C)]
pub struct FfiTelemetrySnapshot {
    pub p50_frame_time_ms: f32,
    pub p95_frame_time_ms: f32,
    pub p99_frame_time_ms: f32,
    pub current_queue_depth: u32,
    pub dropped_events: u64,
}

#[no_mangle]
pub extern "C" fn glassos_runtime_create() -> *mut c_void {
    let runtime = Box::new(GlassRuntime::new());
    Box::into_raw(runtime) as *mut c_void
}

#[no_mangle]
pub extern "C" fn glassos_runtime_destroy(ptr: *mut c_void) {
    if !ptr.is_null() {
        unsafe {
            let _ = Box::from_raw(ptr as *mut GlassRuntime);
        }
    }
}

#[no_mangle]
pub extern "C" fn glassos_runtime_get_state(ptr: *mut c_void) -> i32 {
    if ptr.is_null() {
        return -1;
    }
    let runtime = unsafe { &*(ptr as *const GlassRuntime) };
    match runtime.state() {
        RuntimeState::Booting => 0,
        RuntimeState::Active => 1,
        RuntimeState::LowPower => 2,
        RuntimeState::ThermalThrottled => 3,
        RuntimeState::Recovering => 4,
        RuntimeState::Suspended => 5,
    }
}

#[no_mangle]
pub extern "C" fn glassos_runtime_set_power_mode(ptr: *mut c_void, mode: i32) {
    if ptr.is_null() {
        return;
    }
    let runtime = unsafe { &mut *(ptr as *mut GlassRuntime) };
    let power_mode = match mode {
        0 => PowerMode::Normal,
        1 => PowerMode::Eco,
        2 => PowerMode::ThermalThrottled,
        _ => PowerMode::Normal,
    };
    runtime.transition_power_mode(power_mode);
}

#[no_mangle]
pub extern "C" fn glassos_runtime_get_telemetry(ptr: *mut c_void, out: *mut FfiTelemetrySnapshot) {
    if ptr.is_null() || out.is_null() {
        return;
    }
    let runtime = unsafe { &mut *(ptr as *mut GlassRuntime) };
    let depth = runtime.event_bus().queue_depth();
    let dropped = runtime.event_bus().dropped_count();
    let snap = runtime.telemetry().snapshot(depth);

    unsafe {
        (*out).p50_frame_time_ms = snap.p50_frame_time_ms;
        (*out).p95_frame_time_ms = snap.p95_frame_time_ms;
        (*out).p99_frame_time_ms = snap.p99_frame_time_ms;
        (*out).current_queue_depth = depth as u32;
        (*out).dropped_events = dropped;
    }
}
