#[cfg(test)]
mod tests {
    use glassos_core::event_bus::{EventBus, GlassEvent, Priority, Topic};
    use glassos_core::notifications::{Notification, NotificationPriority, NotificationRouter};
    use glassos_core::resource_policy::PowerMode;
    use glassos_core::runtime::{GlassRuntime, RuntimeState};
    use glassos_core::sensors::{AhrsFilter, ImuSample};

    #[test]
    fn test_runtime_lifecycle_transitions() {
        let mut runtime = GlassRuntime::new();
        assert_eq!(runtime.state(), RuntimeState::Active);

        runtime.transition_power_mode(PowerMode::Eco);
        assert_eq!(runtime.state(), RuntimeState::LowPower);

        runtime.transition_power_mode(PowerMode::ThermalThrottled);
        assert_eq!(runtime.state(), RuntimeState::ThermalThrottled);

        runtime.transition_power_mode(PowerMode::Normal);
        assert_eq!(runtime.state(), RuntimeState::Active);
    }

    #[test]
    fn test_event_bus_backpressure_and_drop_policy() {
        let mut bus = EventBus::new(3);

        // Fill queue
        assert!(bus.publish(GlassEvent::new(Priority::Normal, Topic::InputTempleGesture, "tap_1")));
        assert!(bus.publish(GlassEvent::new(Priority::Normal, Topic::InputTempleGesture, "tap_2")));
        assert!(bus.publish(GlassEvent::new(Priority::Normal, Topic::InputTempleGesture, "tap_3")));
        assert_eq!(bus.queue_depth(), 3);

        // A low-priority event should be rejected when full
        assert!(!bus.publish(GlassEvent::new(Priority::Low, Topic::InputTempleGesture, "rejected")));

        // A critical event should evict the oldest low/normal event
        assert!(bus.publish(GlassEvent::new(Priority::Critical, Topic::SystemThermalAlert, "throttle")));
        assert_eq!(bus.queue_depth(), 3);
        assert_eq!(bus.dropped_count(), 2);
    }

    #[test]
    fn test_notification_privacy_masking() {
        let mut router = NotificationRouter::new();
        let notif = Notification {
            id: "notif_1".into(),
            app_source: "Messenger".into(),
            title: "Alice".into(),
            body_masked: "".into(),
            body_raw: "Secret 2FA Code is 83921".into(),
            priority: NotificationPriority::Standard,
            is_sensitive: true,
            timestamp_ms: 1000,
            dismissed: false,
        };

        router.post(notif);
        let active = router.active_notifications();
        assert_eq!(active.len(), 1);
        assert!(active[0].body_masked.contains("Hidden"));
    }

    #[test]
    fn test_ahrs_sensor_fusion_convergence() {
        let mut filter = AhrsFilter::new(0.041);
        let sample = ImuSample {
            timestamp_ns: 1000000,
            accel_mps2: [0.0, 0.0, 9.81],
            gyro_rads: [0.0, 0.0, 0.0],
            mag_ut: [0.0, 30.0, 0.0],
        };

        let q = filter.update(&sample, 0.01);
        assert!((q.w.powi(2) + q.x.powi(2) + q.y.powi(2) + q.z.powi(2) - 1.0).abs() < 0.01);
    }
}
