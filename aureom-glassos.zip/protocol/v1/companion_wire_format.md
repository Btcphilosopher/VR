# Aureom GlassOS — Companion Wire Format (v1)

## 1. Frame Structure

All frames over the BLE L2CAP or TCP companion transport follow a compact 16-byte fixed header followed by payload and SHA256 integrity tag:

```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|       Magic: 0x41 0x55 ("AU") |   Protocol: 0x01  | Flags     |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       Sequence Number (uint32)                |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|      Message Opcode (uint16)  |      Payload Length (uint16)  |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                      Session Token (uint32)                   |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                       Payload Data (N bytes)                  |
|                              ...                              |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                   HMAC-SHA256 Auth Tag (32 bytes)             |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

## 2. Opcodes

| Opcode | Name | Direction | Description |
| :--- | :--- | :--- | :--- |
| `0x0001` | `HELLO_PAIR_REQ` | Phone -> Glasses | Initiate pairing with ephemeral X25519 public key |
| `0x0002` | `HELLO_PAIR_RESP` | Glasses -> Phone | Confirm pairing with 6-digit visual auth code |
| `0x0010` | `ROUTE_DISPATCH` | Phone -> Glasses | Dispatch turn-by-turn route waypoints |
| `0x0011` | `ROUTE_PROGRESS` | Glasses -> Phone | Report current distance and step index |
| `0x0020` | `NOTIF_FORWARD` | Phone -> Glasses | Forward sanitized notification |
| `0x0021` | `NOTIF_ACTION` | Glasses -> Phone | Transmit user action (e.g. dismiss, accept) |
| `0x0030` | `TELEMETRY_SYNC` | Glasses -> Phone | Stream buffered p50/p95 frame and battery records |
| `0x00FE` | `HEARTBEAT_PING` | Bidirectional | Connection keepalive (sent every 3 seconds) |
