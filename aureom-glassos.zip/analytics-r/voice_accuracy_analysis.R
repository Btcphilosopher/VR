#!/usr/bin/env Rscript
# Aureom GlassOS — Voice Command Recognition Accuracy & Latency Analysis

suppressPackageStartupMessages({
  if (!require("readr", quietly = TRUE)) install.packages("readr", repos="https://cloud.r-project.org")
  if (!require("dplyr", quietly = TRUE)) install.packages("dplyr", repos="https://cloud.r-project.org")
  library(readr)
  library(dplyr)
})

csv_path <- "sample_telemetry.csv"
if (!file.exists(csv_path)) {
  csv_path <- file.path("analytics-r", "sample_telemetry.csv")
}

data <- read_csv(csv_path, show_col_types = FALSE)

cat("=== Aureom GlassOS: Voice Command Performance ===\n")

total_commands <- nrow(data)
successful_commands <- sum(data$voice_success)
accuracy_pct <- (successful_commands / total_commands) * 100

cat(sprintf("Total Evaluated Audio Windows: %d\n", total_commands))
cat(sprintf("Deterministic Command Accuracy: %.1f %%\n", accuracy_pct))

cat("\nSignal Quality vs Command Outcome (BLE RSSI Proxy):\n")
success_rssi <- mean(data$ble_rssi_dbm[data$voice_success == 1])
fail_rssi <- mean(data$ble_rssi_dbm[data$voice_success == 0])

cat(sprintf("Mean RSSI during successful execution: %.1f dBm\n", success_rssi))
cat(sprintf("Mean RSSI during failed/dropped attempts: %.1f dBm\n", fail_rssi))
