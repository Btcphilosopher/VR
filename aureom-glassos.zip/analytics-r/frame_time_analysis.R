#!/usr/bin/env Rscript
# Aureom GlassOS — Frame-Time & Latency Distribution Analysis
# Generates empirical percentiles (p50, p95, p99), jitter, and frame pacing diagnostics.

suppressPackageStartupMessages({
  if (!require("readr", quietly = TRUE)) install.packages("readr", repos="https://cloud.r-project.org")
  if (!require("dplyr", quietly = TRUE)) install.packages("dplyr", repos="https://cloud.r-project.org")
  library(readr)
  library(dplyr)
})

csv_path <- "sample_telemetry.csv"
if (!file.exists(csv_path)) {
  csv_path <- file.path("analytics-r", "sample_telemetry.csv")
}

cat("=== Aureom GlassOS: Frame-Time & Input Latency Analysis ===\n")
data <- read_csv(csv_path, show_col_types = FALSE)

# Compute metrics per operating mode
stats <- data %>%
  group_by(system_mode) %>%
  summarise(
    n = n(),
    mean_frame_ms = round(mean(frame_time_ms), 2),
    p50_frame_ms = round(median(frame_time_ms), 2),
    p95_frame_ms = round(quantile(frame_time_ms, 0.95), 2),
    p99_frame_ms = round(quantile(frame_time_ms, 0.99), 2),
    mean_input_latency_ms = round(mean(input_to_display_ms), 2),
    max_input_latency_ms = round(max(input_to_display_ms), 2),
    total_dropped = sum(dropped_events)
  )

print(as.data.frame(stats))

cat("\nJitter Analysis (Frame-to-Frame Variance):\n")
active_data <- filter(data, system_mode == "ACTIVE")
frame_diffs <- abs(diff(active_data$frame_time_ms))
cat(sprintf("Active 60Hz Mode - Mean Absolute Jitter: %.3f ms\n", mean(frame_diffs)))
cat(sprintf("Active 60Hz Mode - 95th Percentile Jitter: %.3f ms\n", quantile(frame_diffs, 0.95)))

cat("\nAnalysis complete. Results reproducible across test runs.\n")
