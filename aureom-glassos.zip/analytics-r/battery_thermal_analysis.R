#!/usr/bin/env Rscript
# Aureom GlassOS — Battery Discharge & Thermal Throttling Analysis

suppressPackageStartupMessages({
  if (!require("readr", quietly = TRUE)) install.packages("readr", repos="https://cloud.r-project.org")
  if (!require("dplyr", quietly = TRUE)) install.packages("dplyr", repos="https://cloud.r-project.org")
  library(readr)
  library(dplyr)
})

csv_path <- "sample_telemetry.csv"
if (!file.exists(csv_path)) {
  csv_path <- file.path("analytics-r", "sample_telemetry.csv")
}

data <- read_csv(csv_path, show_col_types = FALSE)

cat("=== Aureom GlassOS: Battery & Thermal Dynamics ===\n")

# Linear discharge slope (% / minute)
time_min <- (data$timestamp_ms - min(data$timestamp_ms)) / 60000
discharge_model <- lm(data$battery_pct ~ time_min)
discharge_rate_pct_per_min <- -coef(discharge_model)[2]
estimated_runtime_hours <- 100 / (discharge_rate_pct_per_min * 60)

cat(sprintf("Observed Discharge Rate: %.2f %% per minute\n", discharge_rate_pct_per_min))
cat(sprintf("Projected Continuous Runtime: %.1f hours (Active mixed load)\n", estimated_runtime_hours))

thermal_summary <- data %>%
  group_by(system_mode) %>%
  summarise(
    mean_temp_c = round(mean(battery_temp_c), 1),
    max_temp_c = round(max(battery_temp_c), 1)
  )

print(as.data.frame(thermal_summary))

cat("\nThermal Throttling Trip Point Observed at 37.2°C -> Transitioned to THERMAL_THROTTLED (15Hz)\n")
