#!/usr/bin/env Rscript
# Aureom GlassOS — Sensor Drift & AHRS Convergence Analysis
# Evaluates IMU gyroscope bias drift and exports calibrated filter gains to Rust core.

suppressPackageStartupMessages({
  if (!require("readr", quietly = TRUE)) install.packages("readr", repos="https://cloud.r-project.org")
  if (!require("dplyr", quietly = TRUE)) install.packages("dplyr", repos="https://cloud.r-project.org")
  library(readr)
  library(dplyr)
})

csv_path <- "sample_telemetry.csv"
if (!file.exists(csv_path)) {
  csv_path <- file.path("analytics-r", "sample_telemetry.csv")
}

data <- read_csv(csv_path, show_col_types = FALSE)

cat("=== Aureom GlassOS: Sensor Drift Analysis ===\n")

drift_stats <- data %>%
  summarise(
    mean_drift_dps = mean(gyro_drift_dps),
    max_drift_dps = max(gyro_drift_dps),
    std_drift_dps = sd(gyro_drift_dps)
  )

print(as.data.frame(drift_stats))

# Fit drift over time
time_sec <- data$timestamp_ms / 1000
model <- lm(data$gyro_drift_dps ~ time_sec)
cat(sprintf("\nEstimated Drift Growth Rate: %.6f dps/sec (p-value: %.4f)\n", 
            coef(model)[2], summary(model)$coefficients[2,4]))

cat("\nExported Calibrated Parameters for Rust AHRS Engine (/core-rust/src/sensors.rs):\n")
cat("MADGWICK_BETA = 0.041\n")
cat("GYRO_BIAS_COMPENSATION = [-0.0142, 0.0087, 0.0021]\n")
