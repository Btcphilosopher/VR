# Aureom GlassOS R Analytics Toolkit

This toolkit provides reproducible offline analysis scripts for smartglasses performance evaluation, sensor calibration, battery discharge modeling, and voice recognition quality.

## Dependencies

```r
# Required R packages
packages <- c("ggplot2", "dplyr", "tidyr", "readr", "knitr")
install.packages(packages, repos = "https://cloud.r-project.org")
```

## Running the Analyses

```bash
# Generate comprehensive summary report and calibration parameters
Rscript reproducible_report.R

# Individual modular analyses
Rscript frame_time_analysis.R
Rscript sensor_drift_analysis.R
Rscript battery_thermal_analysis.R
Rscript voice_accuracy_analysis.R
```

## Exported Calibration Parameters for Rust Core

Sensor drift calibration coefficients computed in `sensor_drift_analysis.R` are exported as:
- `gyro_bias_x`: -0.0142 deg/s
- `gyro_bias_y`: +0.0087 deg/s
- `gyro_bias_z`: +0.0021 deg/s
- `madgwick_beta`: 0.041

These parameters are consumed directly by the Rust AHRS filter in `/core-rust/src/sensors.rs`.
