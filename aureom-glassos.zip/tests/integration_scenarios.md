# Aureom GlassOS — Verification and Integration Test Scenarios

This document details the 10 critical user journeys verified in the Aureom GlassOS test harness:

1. **Simulator Startup & Display Profile Selection**: Verifies initial boot, MicroLED waveguide shader parameters, and status bar rendering.
2. **Capability Registry Discovery**: Inspects Android SensorManager, flags supported vs simulated sensors, and logs missing hardware gracefully.
3. **Temple Touchpad Input Flow**: Exercises swipe forward (next app/item), swipe back (prev), tap (select), double tap (back), and long press (voice trigger).
4. **Physical Key Rocker Navigation**: Intercepts volume keys and back key to mirror physical glasses frame buttons.
5. **Notification Ingestion & Privacy Masking**: Receives sensitive 2FA message, masks preview on HUD, unlocks on explicit tap, and dismisses via action.
6. **Turn-by-Turn Route Navigation**: Traverses sample route waypoints, monitors bearing angle, computes distance countdown, and displays tracking confidence.
7. **Deterministic Voice Command Recognition**: Activates Push-to-Talk, computes audio RMS waveform visualizer, executes supported grammars ("Go home", "Show notifications", "Start navigation", "Pause music", "What is my next appointment", "Cancel").
8. **Power Mode Degradation & Recovery**: Triggers Low Power (Eco 30Hz) and Thermal Throttling (15Hz), confirms sensor rate decimation, and tests recovery to Normal (60Hz).
9. **Companion Phone Link & Remote Control**: Switches to Companion Phone mode, tests pairing code confirmation, route destination dispatch, and live telemetry stream.
10. **Telemetry Export & R Reproducibility**: Generates p50/p95/p99 frame latencies, queue depth metrics, and exports CSV dataset for offline R analytics.
