package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.glassos.core.model.ActiveHudApp
import com.example.glassos.core.model.TempleGesture
import com.example.glassos.ui.companion.CompanionScreen
import com.example.glassos.ui.hud.HudViewport
import com.example.glassos.ui.viewmodel.GlassOSViewModel
import com.example.ui.theme.AureomGlassOSTheme
import com.example.ui.theme.OpticalBlack

class MainActivity : ComponentActivity() {

    private val viewModel: GlassOSViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AureomGlassOSTheme {
                val activeApp by viewModel.activeApp.collectAsStateWithLifecycle()
                val isPhoneMode by viewModel.isCompanionPhoneView.collectAsStateWithLifecycle()
                val displayProfile by viewModel.displayProfile.collectAsStateWithLifecycle()
                val powerMode by viewModel.powerMode.collectAsStateWithLifecycle()
                val batteryPct by viewModel.telemetry.batteryPct.collectAsStateWithLifecycle()
                val isMicActive by viewModel.permissions.isMicActive.collectAsStateWithLifecycle()
                val isCameraActive by viewModel.permissions.isCameraActive.collectAsStateWithLifecycle()
                val lastGesture by viewModel.lastGesture.collectAsStateWithLifecycle()
                val monocularEye by viewModel.monocularEye.collectAsStateWithLifecycle()
                val companionLinkStatus by viewModel.companion.linkStatus.collectAsStateWithLifecycle()
                val deviceName by viewModel.companion.deviceName.collectAsStateWithLifecycle()
                val authPin by viewModel.companion.authPin.collectAsStateWithLifecycle()
                val sessionToken by viewModel.companion.sessionToken.collectAsStateWithLifecycle()

                // Hardware Back button handling
                BackHandler(enabled = isPhoneMode || activeApp != ActiveHudApp.HOME) {
                    if (isPhoneMode) {
                        viewModel.toggleViewMode()
                    } else {
                        viewModel.handleTempleGesture(TempleGesture.DOUBLE_TAP)
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = OpticalBlack,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(OpticalBlack)
                    ) {
                        if (isPhoneMode) {
                            CompanionScreen(
                                linkStatus = companionLinkStatus,
                                deviceName = deviceName,
                                authPin = authPin,
                                sessionToken = sessionToken,
                                currentProfile = displayProfile,
                                onPair = { viewModel.companion.initiatePairing() },
                                onConfirmPin = { viewModel.companion.confirmPairing() },
                                onDisconnect = { viewModel.companion.disconnect() },
                                onDispatchRoute = { dest -> viewModel.setDestination(dest) },
                                onSendNotification = { title, body, sens ->
                                    viewModel.addNotification(title, body, sens)
                                },
                                onSelectProfile = { p -> viewModel.setDisplayProfile(p) },
                                onSwitchToGlassesView = { viewModel.toggleViewMode() }
                            )
                        } else {
                            HudViewport(
                                viewModel = viewModel,
                                activeApp = activeApp,
                                displayProfile = displayProfile,
                                powerMode = powerMode,
                                batteryPct = batteryPct,
                                isMicActive = isMicActive,
                                isCameraActive = isCameraActive,
                                lastGesture = lastGesture,
                                monocularEye = monocularEye
                            )
                        }
                    }
                }
            }
        }
    }

    // Intercept physical buttons (Volume rockers & D-pad) to act as glasses frame controls
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                viewModel.handlePhysicalRockerUp()
                true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                viewModel.handlePhysicalRockerDown()
                true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_DOWN -> {
                viewModel.handleTempleGesture(TempleGesture.SWIPE_FORWARD)
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_UP -> {
                viewModel.handleTempleGesture(TempleGesture.SWIPE_BACKWARD)
                true
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                viewModel.handleTempleGesture(TempleGesture.TAP)
                true
            }
            KeyEvent.KEYCODE_SPACE -> {
                viewModel.handleTempleGesture(TempleGesture.LONG_PRESS)
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }
}
