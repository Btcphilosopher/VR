package com.example.glassos.core.engine

import com.example.glassos.core.model.NavigationState
import com.example.glassos.core.model.NavigationStep
import com.example.glassos.core.model.TrackingConfidence
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Deterministic Navigation Guidance Engine.
 * Traverses sample routes with step progression, bearing angles,
 * distance decimation, and tracking confidence states.
 */
class NavigationEngine {
    private val sampleSteps = listOf(
        NavigationStep(
            instruction = "Head northeast on Avinguda Diagonal",
            streetName = "Av. Diagonal",
            distanceMeters = 350,
            turnIcon = "straight",
            bearingDegrees = 42f
        ),
        NavigationStep(
            instruction = "Turn right onto Passeig de Gràcia",
            streetName = "Pg. de Gràcia",
            distanceMeters = 600,
            turnIcon = "turn_right",
            bearingDegrees = 135f
        ),
        NavigationStep(
            instruction = "Keep left towards Plaça de Catalunya",
            streetName = "Rambla de Catalunya",
            distanceMeters = 400,
            turnIcon = "keep_left",
            bearingDegrees = 178f
        ),
        NavigationStep(
            instruction = "Arrived at Plaça de Catalunya",
            streetName = "Destination",
            distanceMeters = 100,
            turnIcon = "arrival",
            bearingDegrees = 180f
        )
    )

    private val _navState = MutableStateFlow(
        NavigationState(
            destination = "Plaça de Catalunya",
            currentStepIndex = 0,
            steps = sampleSteps,
            totalDistanceMeters = 1450,
            remainingDistanceMeters = 1450,
            etaMinutes = 18,
            currentBearing = 42f,
            targetBearing = 42f,
            confidence = TrackingConfidence.HIGH,
            isNavigating = true
        )
    )
    val navState: StateFlow<NavigationState> = _navState.asStateFlow()

    fun advanceStep() {
        val curr = _navState.value
        val nextIdx = (curr.currentStepIndex + 1) % sampleSteps.size
        val nextStep = sampleSteps[nextIdx]
        val remaining = (sampleSteps.size - nextIdx) * 350
        val eta = (remaining / 80).coerceAtLeast(1)

        _navState.value = curr.copy(
            currentStepIndex = nextIdx,
            remainingDistanceMeters = remaining,
            etaMinutes = eta,
            targetBearing = nextStep.bearingDegrees,
            currentBearing = nextStep.bearingDegrees
        )
    }

    fun stepBack() {
        val curr = _navState.value
        val prevIdx = if (curr.currentStepIndex > 0) curr.currentStepIndex - 1 else sampleSteps.size - 1
        val prevStep = sampleSteps[prevIdx]
        _navState.value = curr.copy(
            currentStepIndex = prevIdx,
            targetBearing = prevStep.bearingDegrees,
            currentBearing = prevStep.bearingDegrees
        )
    }

    fun toggleTrackingConfidence() {
        val curr = _navState.value.confidence
        val next = when (curr) {
            TrackingConfidence.HIGH -> TrackingConfidence.DEGRADED
            TrackingConfidence.DEGRADED -> TrackingConfidence.LOST
            TrackingConfidence.LOST -> TrackingConfidence.HIGH
        }
        _navState.value = _navState.value.copy(confidence = next)
    }

    fun setDestination(dest: String) {
        _navState.value = _navState.value.copy(
            destination = dest,
            currentStepIndex = 0,
            remainingDistanceMeters = 1450,
            etaMinutes = 18,
            isNavigating = true
        )
    }
}
