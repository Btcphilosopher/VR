package com.example.glassos.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.VoiceState
import com.example.glassos.core.model.VoiceStateMode
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Push-to-Talk Voice Command HUD Screen.
 * Minimalist waveform visualizer, explicit status indicators (Listening, Processing, Executed),
 * and deterministic command grammar quick-triggers.
 */
@Composable
fun VoiceScreen(
    voiceState: VoiceState,
    onStartListening: () -> Unit,
    onStopListening: (String?) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val waveScale1 by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(400, easing = LinearEasing), RepeatMode.Reverse),
        label = "w1"
    )
    val waveScale2 by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse),
        label = "w2"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_voice"),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = WaveguideEmerald,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "VOICE ENGINE • DETERMINISTIC GRAMMAR",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideEmerald
                )
            }
            TextButton(onClick = onBack, modifier = Modifier.testTag("btn_voice_close")) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        // Central Audio Waveform & Status Box
        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = if (voiceState.mode == VoiceStateMode.LISTENING) WaveguideEmerald else WaveguideCyan,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Waveform indicator bars
                Row(
                    modifier = Modifier.height(48.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val isListening = voiceState.mode == VoiceStateMode.LISTENING
                    val bars = listOf(0.4f, 0.7f, 1.0f, 0.85f, 0.5f, 0.9f, 0.3f)
                    bars.forEachIndexed { i, baseHeight ->
                        val h = if (isListening) {
                            val dyn = if (i % 2 == 0) waveScale1 else waveScale2
                            (baseHeight * dyn * 40).dp.coerceAtLeast(6.dp)
                        } else {
                            8.dp
                        }
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .height(h)
                                .clip(CircleShape)
                                .background(if (isListening) WaveguideEmerald else WaveguideCyan.copy(alpha = 0.4f))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = when (voiceState.mode) {
                        VoiceStateMode.LISTENING -> "● LISTENING..."
                        VoiceStateMode.PROCESSING -> "◷ PROCESSING AUDIO..."
                        VoiceStateMode.EXECUTED -> "✓ COMMAND EXECUTED"
                        VoiceStateMode.FAILED -> "✗ COMMAND NOT RECOGNIZED"
                        VoiceStateMode.IDLE -> "PUSH-TO-TALK READY"
                    },
                    style = MaterialTheme.typography.titleLarge,
                    color = when (voiceState.mode) {
                        VoiceStateMode.LISTENING -> WaveguideEmerald
                        VoiceStateMode.PROCESSING -> WaveguideAmber
                        VoiceStateMode.FAILED -> WarningRed
                        else -> HudTextPrimary
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = voiceState.feedbackMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = HudTextSecondary
                )
            }
        }

        // Deterministic command suggestions chips
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "SUPPORTED VOICE GRAMMARS (TAP TO DISPATCH):",
                style = MaterialTheme.typography.labelSmall,
                color = HudTextMuted
            )

            val commands = listOf(
                "Go home",
                "Show notifications",
                "Start navigation",
                "Pause music",
                "What is my next appointment?",
                "Low power"
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                commands.take(3).forEach { cmd ->
                    FilledTonalButton(
                        onClick = { onStopListening(cmd) },
                        modifier = Modifier.weight(1f).testTag("btn_voice_cmd_${cmd.take(5).lowercase()}"),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceDark)
                    ) {
                        Text(cmd, style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                commands.drop(3).forEach { cmd ->
                    FilledTonalButton(
                        onClick = { onStopListening(cmd) },
                        modifier = Modifier.weight(1f).testTag("btn_voice_cmd_${cmd.take(5).lowercase()}"),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceDark)
                    ) {
                        Text(cmd, style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                    }
                }
            }
        }

        // PTT Toggle Button
        Button(
            onClick = {
                if (voiceState.mode == VoiceStateMode.LISTENING) {
                    onStopListening(null)
                } else {
                    onStartListening()
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_voice_ptt_toggle"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (voiceState.mode == VoiceStateMode.LISTENING) WarningRed else WaveguideEmerald
            ),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = if (voiceState.mode == VoiceStateMode.LISTENING) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = null,
                tint = OpticalBlack
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (voiceState.mode == VoiceStateMode.LISTENING) "Release to Process Voice" else "Hold / Push to Speak",
                color = OpticalBlack,
                style = MaterialTheme.typography.labelLarge
            )
        }
    }
}
