package com.example.glassos.core.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.WaveguideAmber
import com.example.ui.theme.WaveguideCyan
import com.example.ui.theme.WaveguideEmerald

enum class SystemState {
    BOOTING,
    ACTIVE,
    LOW_POWER,
    THERMAL_THROTTLED,
    RECOVERY
}

enum class PowerMode(val label: String, val targetFps: Int, val sensorRateHz: Int, val maxBrightnessPct: Float) {
    NORMAL("Normal 60Hz", 60, 100, 1.0f),
    ECO("Eco 30Hz", 30, 25, 0.5f),
    THERMAL_THROTTLED("Thermal Throttled 15Hz", 15, 10, 0.3f)
}

data class DisplayProfile(
    val id: String,
    val name: String,
    val vendor: String,
    val fovHorizontalDeg: Float,
    val fovVerticalDeg: Float,
    val isBinocular: Boolean,
    val primaryColor: Color,
    val opticalCombiner: String,
    val peakLuminanceNits: Int,
    val darkFieldTransparent: Boolean = true
) {
    companion object {
        val MicroLedWaveguide = DisplayProfile(
            id = "micro_led_waveguide",
            name = "MicroLED Waveguide",
            vendor = "Aureom Optical Labs",
            fovHorizontalDeg = 28f,
            fovVerticalDeg = 16f,
            isBinocular = false,
            primaryColor = WaveguideCyan,
            opticalCombiner = "Diffractive Waveguide",
            peakLuminanceNits = 8000
        )
        val BirdbathFullColor = DisplayProfile(
            id = "birdbath_full_color",
            name = "Birdbath Polarized",
            vendor = "Reference AR Core",
            fovHorizontalDeg = 45f,
            fovVerticalDeg = 25f,
            isBinocular = true,
            primaryColor = WaveguideEmerald,
            opticalCombiner = "Polarized Beamsplitter",
            peakLuminanceNits = 1800
        )
        val PrismMonocular = DisplayProfile(
            id = "prism_monocular",
            name = "Monocular Prism",
            vendor = "Enterprise Glance",
            fovHorizontalDeg = 15f,
            fovVerticalDeg = 12f,
            isBinocular = false,
            primaryColor = WaveguideAmber,
            opticalCombiner = "Right-Eye Glass Prism",
            peakLuminanceNits = 3500
        )
    }
}

enum class EventPriority {
    LOW,
    NORMAL,
    HIGH,
    CRITICAL
}

enum class EventTopic {
    SYSTEM_POWER_STATE,
    SYSTEM_THERMAL_ALERT,
    INPUT_TEMPLE_GESTURE,
    INPUT_PHYSICAL_KEY,
    INPUT_VOICE_COMMAND,
    SENSOR_IMU_BATCH,
    SENSOR_GNSS_UPDATE,
    NAVIGATION_INSTRUCTION,
    NOTIFICATION_INCOMING,
    NOTIFICATION_DISMISSED,
    COMPANION_CONNECTION_STATE
}

data class GlassEvent(
    val id: Long,
    val timestampNs: Long = System.nanoTime(),
    val priority: EventPriority,
    val topic: EventTopic,
    val payload: String
)

enum class NotificationPriority {
    LOW,
    STANDARD,
    URGENT
}

data class GlassNotification(
    val id: String,
    val sourceApp: String,
    val title: String,
    val bodyRaw: String,
    val bodyMasked: String = "●●● Preview Hidden for Privacy ●●●",
    val isSensitive: Boolean = false,
    val isRevealed: Boolean = false,
    val priority: NotificationPriority = NotificationPriority.STANDARD,
    val timestampMs: Long = System.currentTimeMillis(),
    val actionLabel: String? = null,
    val isDismissed: Boolean = false
)

enum class TrackingConfidence {
    HIGH,
    DEGRADED,
    LOST
}

data class NavigationStep(
    val instruction: String,
    val streetName: String,
    val distanceMeters: Int,
    val turnIcon: String,
    val bearingDegrees: Float
)

data class NavigationState(
    val destination: String = "Plaça de Catalunya",
    val currentStepIndex: Int = 0,
    val steps: List<NavigationStep> = emptyList(),
    val totalDistanceMeters: Int = 1450,
    val remainingDistanceMeters: Int = 1450,
    val etaMinutes: Int = 18,
    val currentBearing: Float = 42f,
    val targetBearing: Float = 45f,
    val confidence: TrackingConfidence = TrackingConfidence.HIGH,
    val isNavigating: Boolean = false
)

enum class VoiceStateMode {
    IDLE,
    LISTENING,
    PROCESSING,
    EXECUTED,
    FAILED
}

data class VoiceState(
    val mode: VoiceStateMode = VoiceStateMode.IDLE,
    val rmsLevel: Float = 0.0f,
    val transcribedText: String = "",
    val feedbackMessage: String = "Push to Talk or long-press temple",
    val lastRecognizedCommand: String = ""
)

data class MediaState(
    val trackTitle: String = "Solaris Resonance",
    val artist: String = "Aureom Synthetics",
    val isPlaying: Boolean = true,
    val positionSeconds: Int = 74,
    val durationSeconds: Int = 236
)

data class ServiceStatus(
    val id: String,
    val name: String,
    val isHealthy: Boolean = true,
    val restartCount: Int = 0,
    val lastHeartbeatMs: Long = System.currentTimeMillis()
)

data class PermissionAuditLog(
    val id: Long,
    val timestampMs: Long = System.currentTimeMillis(),
    val serviceName: String,
    val sensorType: String,
    val granted: Boolean,
    val rationale: String
)

data class TelemetryPoint(
    val timestampMs: Long,
    val systemMode: String,
    val frameTimeMs: Float,
    val inputToDisplayMs: Float,
    val gyroDriftDps: Float,
    val batteryPct: Float,
    val batteryTempC: Float,
    val queueDepth: Int,
    val droppedEvents: Int,
    val voiceSuccess: Int,
    val bleRssiDbm: Int
)

enum class ActiveHudApp(val title: String, val iconName: String) {
    HOME("Glance", "home"),
    LAUNCHER("Apps", "apps"),
    NAVIGATION("Wayfinder", "navigation"),
    NOTIFICATIONS("Alerts", "notifications"),
    VOICE("Voice", "mic"),
    MEDIA("Media", "music"),
    SETTINGS("Display", "settings"),
    PRIVACY("Privacy", "shield"),
    DIAGNOSTICS("Telemetry", "analytics")
}

enum class TempleGesture {
    TAP,
    DOUBLE_TAP,
    SWIPE_FORWARD,
    SWIPE_BACKWARD,
    LONG_PRESS
}

enum class CompanionLinkStatus {
    DISCONNECTED,
    PAIRING,
    CONNECTED
}
