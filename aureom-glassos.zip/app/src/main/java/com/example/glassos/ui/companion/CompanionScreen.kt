package com.example.glassos.ui.companion

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.CompanionLinkStatus
import com.example.glassos.core.model.DisplayProfile
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Companion Smartphone Application Interface.
 * Acts as the companion phone app for Aureom GlassOS:
 * - Device Pairing with visual authentication PIN confirmation
 * - Route Dispatcher: injects destinations directly to the glasses HUD
 * - Notification Dispatcher: forwards test alerts and 2FA codes
 * - Display profile selector
 * - Mode toggle back to the Smartglasses HUD simulator.
 */
@Composable
fun CompanionScreen(
    linkStatus: CompanionLinkStatus,
    deviceName: String,
    authPin: String,
    sessionToken: String,
    currentProfile: DisplayProfile,
    onPair: () -> Unit,
    onConfirmPin: () -> Unit,
    onDisconnect: () -> Unit,
    onDispatchRoute: (String) -> Unit,
    onSendNotification: (String, String, Boolean) -> Unit,
    onSelectProfile: (DisplayProfile) -> Unit,
    onSwitchToGlassesView: () -> Unit,
    modifier: Modifier = Modifier
) {
    var customDestination by remember { mutableStateOf("Sagrada Família") }
    var customNotifTitle by remember { mutableStateOf("Flight Boarding") }
    var customNotifBody by remember { mutableStateOf("Gate B22 closing in 15 minutes") }
    var isSensitiveNotif by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CompanionBackground)
            .padding(16.dp)
            .testTag("screen_companion_phone"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Phone Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = WaveguideCyanBright)
                Text(
                    text = "AUREOM COMPANION",
                    style = MaterialTheme.typography.titleLarge,
                    color = HudTextPrimary
                )
            }

            Button(
                onClick = onSwitchToGlassesView,
                colors = ButtonDefaults.buttonColors(containerColor = WaveguideCyan),
                modifier = Modifier.testTag("btn_switch_to_hud")
            ) {
                Icon(Icons.Default.Visibility, contentDescription = null, tint = OpticalBlack, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("HUD Mode", color = OpticalBlack, style = MaterialTheme.typography.labelSmall)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // BLE Pairing & Authenticated Session Card
            item {
                WearableCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (linkStatus == CompanionLinkStatus.CONNECTED) WaveguideEmerald else WaveguideAmber
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AUTHENTICATED WEARABLE LINK", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                            Text(
                                text = linkStatus.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (linkStatus == CompanionLinkStatus.CONNECTED) WaveguideEmerald else WaveguideAmber
                            )
                        }

                        Text("Device: $deviceName", style = MaterialTheme.typography.bodyLarge, color = HudTextPrimary)
                        Text("Session Token: $sessionToken", style = MaterialTheme.typography.bodyMedium, color = HudTextSecondary)

                        if (linkStatus == CompanionLinkStatus.PAIRING) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Confirm PIN on Glasses: $authPin", style = MaterialTheme.typography.headlineMedium, color = WaveguideAmber)
                                Button(onClick = onConfirmPin, colors = ButtonDefaults.buttonColors(containerColor = WaveguideEmerald)) {
                                    Text("Confirm", color = OpticalBlack)
                                }
                            }
                        } else if (linkStatus == CompanionLinkStatus.CONNECTED) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton(onClick = onDisconnect) {
                                    Text("Disconnect Link", style = MaterialTheme.typography.labelSmall)
                                }
                                FilledTonalButton(onClick = onPair) {
                                    Text("Re-Pair with PIN", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        } else {
                            Button(onClick = onPair, colors = ButtonDefaults.buttonColors(containerColor = WaveguideCyan)) {
                                Text("Initiate Secure Pairing", color = OpticalBlack)
                            }
                        }
                    }
                }
            }

            // Route Dispatcher to Glasses HUD
            item {
                WearableCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("DISPATCH NAVIGATION TO GLASSES", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)

                        OutlinedTextField(
                            value = customDestination,
                            onValueChange = { customDestination = it },
                            label = { Text("Destination Address / Landmark") },
                            modifier = Modifier.fillMaxWidth().testTag("input_nav_dest"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = HudTextPrimary,
                                unfocusedTextColor = HudTextPrimary,
                                focusedBorderColor = WaveguideCyan,
                                unfocusedBorderColor = GlassSurfaceBorder
                            )
                        )

                        Button(
                            onClick = {
                                onDispatchRoute(customDestination)
                                onSwitchToGlassesView()
                            },
                            modifier = Modifier.fillMaxWidth().testTag("btn_dispatch_route"),
                            colors = ButtonDefaults.buttonColors(containerColor = WaveguideCyan)
                        ) {
                            Icon(Icons.Default.Navigation, contentDescription = null, tint = OpticalBlack)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Send Route to Glasses HUD", color = OpticalBlack)
                        }
                    }
                }
            }

            // Notification Forwarder to Glasses HUD
            item {
                WearableCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("FORWARD TEST NOTIFICATION TO GLASSES", style = MaterialTheme.typography.labelSmall, color = WaveguideAmber)

                        OutlinedTextField(
                            value = customNotifTitle,
                            onValueChange = { customNotifTitle = it },
                            label = { Text("Notification Title") },
                            modifier = Modifier.fillMaxWidth().testTag("input_notif_title"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = HudTextPrimary,
                                unfocusedTextColor = HudTextPrimary,
                                focusedBorderColor = WaveguideAmber,
                                unfocusedBorderColor = GlassSurfaceBorder
                            )
                        )

                        OutlinedTextField(
                            value = customNotifBody,
                            onValueChange = { customNotifBody = it },
                            label = { Text("Notification Message") },
                            modifier = Modifier.fillMaxWidth().testTag("input_notif_body"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = HudTextPrimary,
                                unfocusedTextColor = HudTextPrimary,
                                focusedBorderColor = WaveguideAmber,
                                unfocusedBorderColor = GlassSurfaceBorder
                            )
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isSensitiveNotif,
                                onCheckedChange = { isSensitiveNotif = it },
                                colors = CheckboxDefaults.colors(checkedColor = WaveguideAmber)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Mark as Sensitive (Mask preview on HUD)", style = MaterialTheme.typography.bodyMedium, color = HudTextPrimary)
                        }

                        Button(
                            onClick = {
                                onSendNotification(customNotifTitle, customNotifBody, isSensitiveNotif)
                                onSwitchToGlassesView()
                            },
                            modifier = Modifier.fillMaxWidth().testTag("btn_dispatch_notif"),
                            colors = ButtonDefaults.buttonColors(containerColor = WaveguideAmber)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = OpticalBlack)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Forward Notification to Glasses", color = OpticalBlack)
                        }
                    }
                }
            }
        }
    }
}
