package com.example.glassos.core.telemetry

import com.example.glassos.core.model.TelemetryPoint
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.LinkedList

/**
 * OS-Grade Telemetry Engine.
 * Collects runtime samples, computes p50/p95/p99 frame latencies,
 * and serializes datasets into CSV conforming to /analytics-r/sample_telemetry.csv.
 */
class TelemetryEngine(val maxSamples: Int = 120) {
    private val buffer = LinkedList<TelemetryPoint>()

    private val _p50FrameMs = MutableStateFlow(16.3f)
    val p50FrameMs: StateFlow<Float> = _p50FrameMs.asStateFlow()

    private val _p95FrameMs = MutableStateFlow(18.5f)
    val p95FrameMs: StateFlow<Float> = _p95FrameMs.asStateFlow()

    private val _p99FrameMs = MutableStateFlow(22.1f)
    val p99FrameMs: StateFlow<Float> = _p99FrameMs.asStateFlow()

    private val _batteryPct = MutableStateFlow(94.2f)
    val batteryPct: StateFlow<Float> = _batteryPct.asStateFlow()

    private val _batteryTempC = MutableStateFlow(31.4f)
    val batteryTempC: StateFlow<Float> = _batteryTempC.asStateFlow()

    private val _points = MutableStateFlow<List<TelemetryPoint>>(emptyList())
    val points: StateFlow<List<TelemetryPoint>> = _points.asStateFlow()

    init {
        // Seed initial telemetry ring buffer with baseline samples
        val baseTime = System.currentTimeMillis() - 30000
        for (i in 0 until 30) {
            val point = TelemetryPoint(
                timestampMs = baseTime + (i * 1000),
                systemMode = if (i > 25) "LOW_POWER" else "ACTIVE",
                frameTimeMs = 16.2f + (i % 3) * 0.3f,
                inputToDisplayMs = 28.0f + (i % 4) * 0.5f,
                gyroDriftDps = 0.013f + (i * 0.0001f),
                batteryPct = 96f - (i * 0.05f),
                batteryTempC = 29.5f + (i * 0.1f),
                queueDepth = 1 + (i % 3),
                droppedEvents = 0,
                voiceSuccess = 1,
                bleRssiDbm = -54 + (i % 5)
            )
            buffer.add(point)
        }
        _points.value = buffer.toList()
        recomputePercentiles()
    }

    fun recordSample(
        mode: String,
        frameTimeMs: Float,
        inputToDisplayMs: Float,
        queueDepth: Int,
        droppedEvents: Int
    ) {
        val last = buffer.lastOrNull()
        val nextBattery = ((last?.batteryPct ?: 95f) - 0.02f).coerceAtLeast(1f)
        val nextTemp = ((last?.batteryTempC ?: 30f) + 0.01f).coerceIn(25f, 45f)

        _batteryPct.value = nextBattery
        _batteryTempC.value = nextTemp

        val point = TelemetryPoint(
            timestampMs = System.currentTimeMillis(),
            systemMode = mode,
            frameTimeMs = frameTimeMs,
            inputToDisplayMs = inputToDisplayMs,
            gyroDriftDps = 0.014f,
            batteryPct = nextBattery,
            batteryTempC = nextTemp,
            queueDepth = queueDepth,
            droppedEvents = droppedEvents,
            voiceSuccess = 1,
            bleRssiDbm = -52
        )

        synchronized(buffer) {
            if (buffer.size >= maxSamples) {
                buffer.pollFirst()
            }
            buffer.addLast(point)
            _points.value = buffer.toList()
        }
        recomputePercentiles()
    }

    private fun recomputePercentiles() {
        val sortedFrames = buffer.map { it.frameTimeMs }.sorted()
        if (sortedFrames.isNotEmpty()) {
            val n = sortedFrames.size
            _p50FrameMs.value = sortedFrames[(n * 0.50f).toInt().coerceIn(0, n - 1)]
            _p95FrameMs.value = sortedFrames[(n * 0.95f).toInt().coerceIn(0, n - 1)]
            _p99FrameMs.value = sortedFrames[(n * 0.99f).toInt().coerceIn(0, n - 1)]
        }
    }

    fun exportCsv(): String {
        val sb = StringBuilder()
        sb.append("timestamp_ms,system_mode,frame_time_ms,input_to_display_ms,gyro_drift_dps,battery_pct,battery_temp_c,event_queue_depth,dropped_events,voice_success,ble_rssi_dbm\n")
        buffer.forEach { p ->
            sb.append("${p.timestampMs},${p.systemMode},${p.frameTimeMs},${p.inputToDisplayMs},${p.gyroDriftDps},${p.batteryPct},${p.batteryTempC},${p.queueDepth},${p.droppedEvents},${p.voiceSuccess},${p.bleRssiDbm}\n")
        }
        return sb.toString()
    }
}
