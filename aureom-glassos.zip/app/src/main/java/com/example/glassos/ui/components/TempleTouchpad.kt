package com.example.glassos.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.TempleGesture
import com.example.ui.theme.*

/**
 * Interactive Temple Touchpad Simulator.
 * Represents the capacitive touch surface along the right arm/temple of the glasses.
 * Supports direct gesture detection (drag forward/backward, tap, double-tap, long-press)
 * as well as explicit tactile buttons for simulator usability.
 */
@Composable
fun TempleTouchpad(
    lastGesture: TempleGesture?,
    onGesture: (TempleGesture) -> Unit,
    modifier: Modifier = Modifier
) {
    var touchStatus by remember { mutableStateOf("Touchpad Ready") }

    val padBorderColor by animateColorAsState(
        targetValue = if (lastGesture != null) WaveguideCyan else GlassSurfaceBorder,
        animationSpec = tween(durationMillis = 200),
        label = "padBorder"
    )

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(GlassSurfaceDark.copy(alpha = 0.95f))
            .border(BorderStroke(1.dp, padBorderColor), RoundedCornerShape(14.dp))
            .padding(12.dp)
            .testTag("temple_touchpad_container")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "TEMPLE TOUCHPAD",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
            Text(
                text = lastGesture?.name ?: touchStatus,
                style = MaterialTheme.typography.labelSmall,
                color = if (lastGesture != null) WaveguideEmerald else HudTextMuted
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Capacitive trackpad surface with pointerInput gesture detector
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(OpticalBlack)
                .border(BorderStroke(1.dp, WaveguideCyan.copy(alpha = 0.25f)), RoundedCornerShape(8.dp))
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            touchStatus = "Tap Registered"
                            onGesture(TempleGesture.TAP)
                        },
                        onDoubleTap = {
                            touchStatus = "Double Tap Registered"
                            onGesture(TempleGesture.DOUBLE_TAP)
                        },
                        onLongPress = {
                            touchStatus = "Long Press (Voice)"
                            onGesture(TempleGesture.LONG_PRESS)
                        }
                    )
                }
                .pointerInput(Unit) {
                    var totalDragX = 0f
                    detectDragGestures(
                        onDragStart = { totalDragX = 0f },
                        onDragEnd = {
                            if (totalDragX > 50f) {
                                touchStatus = "Swipe Forward"
                                onGesture(TempleGesture.SWIPE_FORWARD)
                            } else if (totalDragX < -50f) {
                                touchStatus = "Swipe Backward"
                                onGesture(TempleGesture.SWIPE_BACKWARD)
                            }
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                        }
                    )
                }
                .testTag("touchpad_swipe_surface"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "◄  Swipe / Tap / Long-press on Temple Surface  ►",
                style = MaterialTheme.typography.labelSmall,
                color = HudTextSecondary
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Direct Wearable Button Triggers for rapid testing
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilledTonalButton(
                onClick = { onGesture(TempleGesture.SWIPE_BACKWARD) },
                modifier = Modifier.weight(1f).testTag("btn_swipe_back"),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceElevated)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Prev", modifier = Modifier.size(14.dp), tint = HudTextPrimary)
                Spacer(modifier = Modifier.width(3.dp))
                Text("Prev", style = MaterialTheme.typography.labelSmall, color = HudTextPrimary)
            }

            FilledTonalButton(
                onClick = { onGesture(TempleGesture.TAP) },
                modifier = Modifier.weight(1f).testTag("btn_tap_select"),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = WaveguideCyan.copy(alpha = 0.2f))
            ) {
                Icon(Icons.Default.Check, contentDescription = "Select", modifier = Modifier.size(14.dp), tint = WaveguideCyan)
                Spacer(modifier = Modifier.width(3.dp))
                Text("Tap", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
            }

            FilledTonalButton(
                onClick = { onGesture(TempleGesture.SWIPE_FORWARD) },
                modifier = Modifier.weight(1f).testTag("btn_swipe_forward"),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceElevated)
            ) {
                Text("Next", style = MaterialTheme.typography.labelSmall, color = HudTextPrimary)
                Spacer(modifier = Modifier.width(3.dp))
                Icon(Icons.Default.ArrowForward, contentDescription = "Next", modifier = Modifier.size(14.dp), tint = HudTextPrimary)
            }

            FilledTonalButton(
                onClick = { onGesture(TempleGesture.DOUBLE_TAP) },
                modifier = Modifier.weight(1f).testTag("btn_double_tap_back"),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceElevated)
            ) {
                Icon(Icons.Default.Undo, contentDescription = "Back", modifier = Modifier.size(14.dp), tint = WaveguideAmber)
                Spacer(modifier = Modifier.width(3.dp))
                Text("Back", style = MaterialTheme.typography.labelSmall, color = WaveguideAmber)
            }

            FilledTonalButton(
                onClick = { onGesture(TempleGesture.LONG_PRESS) },
                modifier = Modifier.weight(1f).testTag("btn_long_press_voice"),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = WaveguideEmerald.copy(alpha = 0.2f))
            ) {
                Icon(Icons.Default.Mic, contentDescription = "PTT Voice", modifier = Modifier.size(14.dp), tint = WaveguideEmerald)
                Spacer(modifier = Modifier.width(3.dp))
                Text("PTT", style = MaterialTheme.typography.labelSmall, color = WaveguideEmerald)
            }
        }
    }
}
