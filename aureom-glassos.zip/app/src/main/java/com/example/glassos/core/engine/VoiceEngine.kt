package com.example.glassos.core.engine

import com.example.glassos.core.model.VoiceState
import com.example.glassos.core.model.VoiceStateMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Deterministic Push-to-Talk Voice Command Engine.
 * Supports explicit wearable command grammar with RMS audio feedback.
 */
class VoiceEngine {
    private val _voiceState = MutableStateFlow(VoiceState())
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    fun startListening() {
        _voiceState.value = _voiceState.value.copy(
            mode = VoiceStateMode.LISTENING,
            rmsLevel = 0.65f,
            feedbackMessage = "Listening... Speak command",
            transcribedText = ""
        )
    }

    fun stopListeningAndProcess(command: String? = null) {
        val input = command ?: "What is my next appointment?"
        _voiceState.value = _voiceState.value.copy(
            mode = VoiceStateMode.PROCESSING,
            rmsLevel = 0.15f,
            transcribedText = input,
            feedbackMessage = "Processing \"$input\"..."
        )
    }

    fun executeCommand(commandText: String): Pair<String, String> {
        val normalized = commandText.trim().lowercase()
        val (targetApp, feedback) = when {
            normalized.contains("home") -> "HOME" to "Navigating to Glance Home"
            normalized.contains("notification") || normalized.contains("alert") -> "NOTIFICATIONS" to "Opening Notifications"
            normalized.contains("navigation") || normalized.contains("navigate") || normalized.contains("route") -> "NAVIGATION" to "Opening Wayfinder Navigation"
            normalized.contains("pause music") || normalized.contains("play music") || normalized.contains("music") -> "MEDIA" to "Toggling media playback"
            normalized.contains("appointment") || normalized.contains("schedule") || normalized.contains("calendar") -> "HOME" to "Next: Technical Review at 11:30 AM"
            normalized.contains("low power") || normalized.contains("eco") -> "SETTINGS" to "Activating Eco 30Hz mode"
            normalized.contains("cancel") -> "CANCEL" to "Action cancelled"
            else -> "UNKNOWN" to "Command not recognized: \"$commandText\""
        }

        _voiceState.value = _voiceState.value.copy(
            mode = if (targetApp != "UNKNOWN") VoiceStateMode.EXECUTED else VoiceStateMode.FAILED,
            rmsLevel = 0f,
            transcribedText = commandText,
            feedbackMessage = feedback,
            lastRecognizedCommand = commandText
        )
        return targetApp to feedback
    }

    fun reset() {
        _voiceState.value = VoiceState(
            mode = VoiceStateMode.IDLE,
            rmsLevel = 0f,
            feedbackMessage = "Push to Talk or long-press temple"
        )
    }

    fun updateRms(level: Float) {
        if (_voiceState.value.mode == VoiceStateMode.LISTENING) {
            _voiceState.value = _voiceState.value.copy(rmsLevel = level.coerceIn(0f, 1f))
        }
    }
}
