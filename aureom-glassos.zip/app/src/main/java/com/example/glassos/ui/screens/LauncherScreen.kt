package com.example.glassos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.ActiveHudApp
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Wearable App Launcher / Carousel.
 * Shows horizontal card carousel with active focus ring,
 * swipe forward/back navigation, and clear sub-labels.
 */
@Composable
fun LauncherScreen(
    selectedIndex: Int,
    onSelectIndex: (Int) -> Unit,
    onLaunchApp: (ActiveHudApp) -> Unit,
    modifier: Modifier = Modifier
) {
    val apps = ActiveHudApp.entries.filter { it != ActiveHudApp.LAUNCHER }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_launcher"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "APPLICATIONS",
                style = MaterialTheme.typography.labelSmall,
                color = WaveguideCyan
            )
            Text(
                text = "${selectedIndex + 1} of ${apps.size}  (Swipe ◄ ► to navigate)",
                style = MaterialTheme.typography.labelSmall,
                color = HudTextMuted
            )
        }

        // Active App Hero Focus Card
        val currentApp = apps.getOrElse(selectedIndex.coerceIn(0, apps.size - 1)) { ActiveHudApp.HOME }
        WearableCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onLaunchApp(currentApp) }
                .testTag("launcher_active_card"),
            borderColor = WaveguideCyan,
            cornerRadius = 16.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WaveguideCyan.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = getIconForApp(currentApp),
                        contentDescription = currentApp.title,
                        tint = WaveguideCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentApp.title,
                        style = MaterialTheme.typography.displayMedium,
                        color = HudTextPrimary
                    )
                    Text(
                        text = getAppDescription(currentApp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = HudTextSecondary
                    )
                }

                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Open",
                    tint = WaveguideCyan,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Quick Selector Strip
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(apps) { index, app ->
                val isSelected = index == selectedIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) WaveguideCyan.copy(alpha = 0.25f) else GlassSurfaceDark)
                        .clickable {
                            onSelectIndex(index)
                            onLaunchApp(app)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("app_chip_${app.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(
                            imageVector = getIconForApp(app),
                            contentDescription = app.title,
                            tint = if (isSelected) WaveguideCyan else HudTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = app.title,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) HudTextPrimary else HudTextSecondary
                        )
                    }
                }
            }
        }
    }
}

fun getIconForApp(app: ActiveHudApp): ImageVector = when (app) {
    ActiveHudApp.HOME -> Icons.Default.Home
    ActiveHudApp.LAUNCHER -> Icons.Default.Apps
    ActiveHudApp.NAVIGATION -> Icons.Default.Navigation
    ActiveHudApp.NOTIFICATIONS -> Icons.Default.Notifications
    ActiveHudApp.VOICE -> Icons.Default.Mic
    ActiveHudApp.MEDIA -> Icons.Default.MusicNote
    ActiveHudApp.SETTINGS -> Icons.Default.Settings
    ActiveHudApp.PRIVACY -> Icons.Default.Security
    ActiveHudApp.DIAGNOSTICS -> Icons.Default.QueryStats
}

fun getAppDescription(app: ActiveHudApp): String = when (app) {
    ActiveHudApp.HOME -> "Glanceable time, weather, and schedule status"
    ActiveHudApp.LAUNCHER -> "Application drawer and system launcher"
    ActiveHudApp.NAVIGATION -> "Turn-by-turn wayfinding with bearing & lane guidance"
    ActiveHudApp.NOTIFICATIONS -> "Wearable notification center with privacy masking"
    ActiveHudApp.VOICE -> "Push-to-talk speech assistant and deterministic commands"
    ActiveHudApp.MEDIA -> "Now playing music and wearable haptic transport"
    ActiveHudApp.SETTINGS -> "Optical display profiles, brightness, and power modes"
    ActiveHudApp.PRIVACY -> "Hardware indicators, sensor broker, and emergency kill switch"
    ActiveHudApp.DIAGNOSTICS -> "Live frame pacing, queue depth, and CSV export for R"
}
