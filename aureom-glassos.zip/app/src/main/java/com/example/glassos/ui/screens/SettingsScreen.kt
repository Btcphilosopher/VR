package com.example.glassos.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.DisplayProfile
import com.example.glassos.core.model.PowerMode
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Optical Settings Screen.
 * Provides controls for optical profiles (MicroLED Waveguide, Birdbath, Monocular Prism),
 * brightness adjustments, monocular eye position, and OS power regimes.
 */
@Composable
fun SettingsScreen(
    currentProfile: DisplayProfile,
    brightness: Float,
    powerMode: PowerMode,
    monocularEye: String,
    onSelectProfile: (DisplayProfile) -> Unit,
    onSetPowerMode: (PowerMode) -> Unit,
    onToggleEye: () -> Unit,
    onSimulateThermal: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_settings"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.DisplaySettings,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "OPTICAL & POWER SETTINGS",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
            TextButton(onClick = onBack, modifier = Modifier.testTag("btn_settings_close")) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Optical Display Profile Card
            item {
                WearableCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "OPTICAL COMBINER PROFILE",
                            style = MaterialTheme.typography.labelSmall,
                            color = WaveguideCyan
                        )

                        val profiles = listOf(
                            DisplayProfile.MicroLedWaveguide,
                            DisplayProfile.BirdbathFullColor,
                            DisplayProfile.PrismMonocular
                        )

                        profiles.forEach { p ->
                            val isSelected = p.id == currentProfile.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectProfile(p) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = p.name,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = if (isSelected) p.primaryColor else HudTextSecondary
                                    )
                                    Text(
                                        text = "${p.opticalCombiner} • FOV: ${p.fovHorizontalDeg.toInt()}°",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = HudTextMuted
                                    )
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSelectProfile(p) },
                                    colors = RadioButtonDefaults.colors(selectedColor = p.primaryColor)
                                )
                            }
                        }
                    }
                }
            }

            // Power Mode Policy Card
            item {
                WearableCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "POWER & REFRESH REGIME",
                            style = MaterialTheme.typography.labelSmall,
                            color = WaveguideAmber
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PowerMode.entries.forEach { mode ->
                                val isSelected = mode == powerMode
                                FilledTonalButton(
                                    onClick = { onSetPowerMode(mode) },
                                    modifier = Modifier.weight(1f).testTag("btn_power_${mode.name.lowercase()}"),
                                    contentPadding = PaddingValues(4.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = if (isSelected) WaveguideCyan.copy(alpha = 0.3f) else GlassSurfaceElevated
                                    )
                                ) {
                                    Text(
                                        text = mode.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) WaveguideCyan else HudTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Eye Alignment & Thermal Fault Trigger
            item {
                WearableCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Visibility, contentDescription = null, tint = WaveguideEmerald, modifier = Modifier.size(16.dp))
                                Text("Eye Pod Alignment: $monocularEye", style = MaterialTheme.typography.bodyMedium, color = HudTextPrimary)
                            }
                            FilledTonalButton(onClick = onToggleEye, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)) {
                                Text("Toggle Eye", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningRed, modifier = Modifier.size(16.dp))
                                Text("Simulate Thermal Throttle", style = MaterialTheme.typography.bodyMedium, color = WarningRed)
                            }
                            Button(
                                onClick = onSimulateThermal,
                                colors = ButtonDefaults.buttonColors(containerColor = WarningRed.copy(alpha = 0.25f)),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("Inject Heat", style = MaterialTheme.typography.labelSmall, color = WarningRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
