package com.example.glassos.core.broker

import com.example.glassos.core.model.PermissionAuditLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

/**
 * Hardened Permission & Privacy Broker.
 * Mediates sensor usage, drives optical privacy indicators on the HUD,
 * and maintains an append-only audit log.
 */
class PermissionBroker {
    private val idCounter = AtomicLong(1L)

    private val _isMicActive = MutableStateFlow(false)
    val isMicActive: StateFlow<Boolean> = _isMicActive.asStateFlow()

    private val _isCameraActive = MutableStateFlow(false)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _isLocationActive = MutableStateFlow(true)
    val isLocationActive: StateFlow<Boolean> = _isLocationActive.asStateFlow()

    private val _isKillSwitchEngaged = MutableStateFlow(false)
    val isKillSwitchEngaged: StateFlow<Boolean> = _isKillSwitchEngaged.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<PermissionAuditLog>>(
        listOf(
            PermissionAuditLog(1, System.currentTimeMillis() - 24000, "SensorsEngine", "IMU 9-DoF", true, "Head orientation tracking"),
            PermissionAuditLog(2, System.currentTimeMillis() - 18000, "NavEngine", "GNSS Coarse", true, "Wayfinding guidance"),
            PermissionAuditLog(3, System.currentTimeMillis() - 10000, "CompanionLink", "BLE Radio", true, "Device telemetry sync")
        )
    )
    val auditLogs: StateFlow<List<PermissionAuditLog>> = _auditLogs.asStateFlow()

    fun requestAccess(serviceName: String, sensorType: String, rationale: String): Boolean {
        if (_isKillSwitchEngaged.value) {
            logAccess(serviceName, sensorType, false, "Denied: Emergency Kill Switch is engaged")
            return false
        }

        val granted = when (sensorType) {
            "Microphone" -> {
                _isMicActive.value = true
                true
            }
            "Camera" -> {
                _isCameraActive.value = true
                true
            }
            "Location" -> {
                _isLocationActive.value = true
                true
            }
            else -> true
        }

        logAccess(serviceName, sensorType, granted, rationale)
        return granted
    }

    fun releaseAccess(sensorType: String) {
        when (sensorType) {
            "Microphone" -> _isMicActive.value = false
            "Camera" -> _isCameraActive.value = false
            "Location" -> _isLocationActive.value = false
        }
    }

    fun toggleEmergencyKillSwitch() {
        val newState = !_isKillSwitchEngaged.value
        _isKillSwitchEngaged.value = newState
        if (newState) {
            _isMicActive.value = false
            _isCameraActive.value = false
            _isLocationActive.value = false
            logAccess("System", "ALL SENSORS", false, "Emergency kill switch activated")
        } else {
            logAccess("System", "ALL SENSORS", true, "Emergency kill switch disengaged")
        }
    }

    private fun logAccess(serviceName: String, sensorType: String, granted: Boolean, rationale: String) {
        val entry = PermissionAuditLog(
            id = idCounter.getAndIncrement(),
            serviceName = serviceName,
            sensorType = sensorType,
            granted = granted,
            rationale = rationale
        )
        _auditLogs.value = (listOf(entry) + _auditLogs.value).take(50)
    }
}
