package com.example.glassos.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.glassos.core.broker.PermissionBroker
import com.example.glassos.core.bus.EventBus
import com.example.glassos.core.companion.CompanionBridge
import com.example.glassos.core.engine.NavigationEngine
import com.example.glassos.core.engine.VoiceEngine
import com.example.glassos.core.model.*
import com.example.glassos.core.supervisor.ServiceSupervisor
import com.example.glassos.core.telemetry.TelemetryEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GlassOSViewModel(application: Application) : AndroidViewModel(application) {

    // Subsystem engines
    val eventBus = EventBus(128)
    val supervisor = ServiceSupervisor()
    val permissions = PermissionBroker()
    val navigation = NavigationEngine()
    val voice = VoiceEngine()
    val telemetry = TelemetryEngine()
    val companion = CompanionBridge()

    // System state
    private val _systemState = MutableStateFlow(SystemState.ACTIVE)
    val systemState: StateFlow<SystemState> = _systemState.asStateFlow()

    private val _powerMode = MutableStateFlow(PowerMode.NORMAL)
    val powerMode: StateFlow<PowerMode> = _powerMode.asStateFlow()

    private val _activeApp = MutableStateFlow(ActiveHudApp.HOME)
    val activeApp: StateFlow<ActiveHudApp> = _activeApp.asStateFlow()

    private val _launcherIndex = MutableStateFlow(0)
    val launcherIndex: StateFlow<Int> = _launcherIndex.asStateFlow()

    // Display & Optics
    private val _displayProfile = MutableStateFlow(DisplayProfile.MicroLedWaveguide)
    val displayProfile: StateFlow<DisplayProfile> = _displayProfile.asStateFlow()

    private val _brightness = MutableStateFlow(0.85f)
    val brightness: StateFlow<Float> = _brightness.asStateFlow()

    private val _isCompanionPhoneView = MutableStateFlow(false)
    val isCompanionPhoneView: StateFlow<Boolean> = _isCompanionPhoneView.asStateFlow()

    private val _monocularEye = MutableStateFlow("RIGHT") // RIGHT, LEFT, BINOCULAR
    val monocularEye: StateFlow<String> = _monocularEye.asStateFlow()

    // Media
    private val _mediaState = MutableStateFlow(MediaState())
    val mediaState: StateFlow<MediaState> = _mediaState.asStateFlow()

    // Notifications
    private val _notifications = MutableStateFlow(
        listOf(
            GlassNotification(
                id = "n_1",
                sourceApp = "Calendar",
                title = "Design Sync in 10m",
                bodyRaw = "Meeting with Hardware Optics Engineering",
                priority = NotificationPriority.URGENT,
                timestampMs = System.currentTimeMillis() - 120000,
                actionLabel = "Acknowledge"
            ),
            GlassNotification(
                id = "n_2",
                sourceApp = "Authenticator",
                title = "GitHub 2FA Verification",
                bodyRaw = "Your single-use login code is 849 203",
                isSensitive = true,
                priority = NotificationPriority.STANDARD,
                timestampMs = System.currentTimeMillis() - 360000,
                actionLabel = "Reveal Code"
            ),
            GlassNotification(
                id = "n_3",
                sourceApp = "Slack",
                title = "Elena Vance",
                bodyRaw = "Waveguide transmittance test results have been uploaded.",
                priority = NotificationPriority.LOW,
                timestampMs = System.currentTimeMillis() - 900000,
                actionLabel = "Reply"
            )
        )
    )
    val notifications: StateFlow<List<GlassNotification>> = _notifications.asStateFlow()

    // Active gesture feedback
    private val _lastGesture = MutableStateFlow<TempleGesture?>(null)
    val lastGesture: StateFlow<TempleGesture?> = _lastGesture.asStateFlow()

    // Export banner / status message
    private val _systemStatusMessage = MutableStateFlow("Aureom GlassOS • v1.0.4 RT")
    val systemStatusMessage: StateFlow<String> = _systemStatusMessage.asStateFlow()

    init {
        // Publish system boot event
        eventBus.publish(EventPriority.CRITICAL, EventTopic.SYSTEM_POWER_STATE, "GlassOS Kernel Booted")

        // Continuous simulated runtime loop (heartbeats & telemetry sampling)
        viewModelScope.launch {
            var counter = 0
            while (true) {
                val delayMs = when (_powerMode.value) {
                    PowerMode.NORMAL -> 1000L
                    PowerMode.ECO -> 2000L
                    PowerMode.THERMAL_THROTTLED -> 3000L
                }
                delay(delayMs)
                counter++

                // Heartbeat to supervisor
                supervisor.reportHeartbeat("hud")
                supervisor.reportHeartbeat("telemetry")
                if (counter % 3 == 0) supervisor.reportHeartbeat("nav")

                // Telemetry recording
                val frameTime = when (_powerMode.value) {
                    PowerMode.NORMAL -> 16.2f + (counter % 5) * 0.3f
                    PowerMode.ECO -> 32.8f + (counter % 3) * 0.4f
                    PowerMode.THERMAL_THROTTLED -> 65.5f + (counter % 4) * 0.8f
                }
                val inputLatency = frameTime * 1.7f
                telemetry.recordSample(
                    mode = _powerMode.value.name,
                    frameTimeMs = frameTime,
                    inputToDisplayMs = inputLatency,
                    queueDepth = eventBus.currentQueueDepth,
                    droppedEvents = eventBus.droppedEventsCount.value.toInt()
                )
            }
        }
    }

    // Input Handling: Temple Touchpad & Physical Buttons
    fun handleTempleGesture(gesture: TempleGesture) {
        _lastGesture.value = gesture
        eventBus.publish(EventPriority.HIGH, EventTopic.INPUT_TEMPLE_GESTURE, gesture.name)

        viewModelScope.launch {
            delay(400)
            if (_lastGesture.value == gesture) {
                _lastGesture.value = null
            }
        }

        when (gesture) {
            TempleGesture.TAP -> {
                when (_activeApp.value) {
                    ActiveHudApp.LAUNCHER -> {
                        val selected = ActiveHudApp.entries[_launcherIndex.value]
                        _activeApp.value = selected
                    }
                    ActiveHudApp.NOTIFICATIONS -> {
                        revealFirstSensitiveNotification()
                    }
                    ActiveHudApp.VOICE -> {
                        if (voice.voiceState.value.mode == VoiceStateMode.LISTENING) {
                            processVoiceInput()
                        } else {
                            startVoiceListening()
                        }
                    }
                    ActiveHudApp.MEDIA -> {
                        toggleMediaPlayback()
                    }
                    ActiveHudApp.NAVIGATION -> {
                        navigation.advanceStep()
                    }
                    else -> {
                        // Open launcher from home
                        if (_activeApp.value == ActiveHudApp.HOME) {
                            _activeApp.value = ActiveHudApp.LAUNCHER
                        }
                    }
                }
            }
            TempleGesture.DOUBLE_TAP -> {
                // Reliable Back action across all screens
                if (_activeApp.value != ActiveHudApp.HOME) {
                    _activeApp.value = ActiveHudApp.HOME
                    voice.reset()
                } else {
                    _activeApp.value = ActiveHudApp.LAUNCHER
                }
            }
            TempleGesture.SWIPE_FORWARD -> {
                if (_activeApp.value == ActiveHudApp.LAUNCHER) {
                    val count = ActiveHudApp.entries.size
                    _launcherIndex.value = (_launcherIndex.value + 1) % count
                } else if (_activeApp.value == ActiveHudApp.NAVIGATION) {
                    navigation.advanceStep()
                } else if (_activeApp.value == ActiveHudApp.MEDIA) {
                    nextMediaTrack()
                } else {
                    _activeApp.value = ActiveHudApp.LAUNCHER
                    _launcherIndex.value = 0
                }
            }
            TempleGesture.SWIPE_BACKWARD -> {
                if (_activeApp.value == ActiveHudApp.LAUNCHER) {
                    val count = ActiveHudApp.entries.size
                    _launcherIndex.value = if (_launcherIndex.value > 0) _launcherIndex.value - 1 else count - 1
                } else if (_activeApp.value == ActiveHudApp.NAVIGATION) {
                    navigation.stepBack()
                } else if (_activeApp.value == ActiveHudApp.MEDIA) {
                    prevMediaTrack()
                } else {
                    _activeApp.value = ActiveHudApp.HOME
                }
            }
            TempleGesture.LONG_PRESS -> {
                // Direct Push-to-Talk activation
                _activeApp.value = ActiveHudApp.VOICE
                startVoiceListening()
            }
        }
    }

    fun handlePhysicalRockerUp() {
        eventBus.publish(EventPriority.NORMAL, EventTopic.INPUT_PHYSICAL_KEY, "ROCKER_UP")
        _brightness.value = (_brightness.value + 0.1f).coerceAtMost(1.0f)
    }

    fun handlePhysicalRockerDown() {
        eventBus.publish(EventPriority.NORMAL, EventTopic.INPUT_PHYSICAL_KEY, "ROCKER_DOWN")
        _brightness.value = (_brightness.value - 0.1f).coerceAtLeast(0.2f)
    }

    fun handlePhysicalActionKey() {
        eventBus.publish(EventPriority.HIGH, EventTopic.INPUT_PHYSICAL_KEY, "ACTION_BUTTON")
        handleTempleGesture(TempleGesture.TAP)
    }

    // Voice Engine Actions
    fun startVoiceListening() {
        permissions.requestAccess("VoiceEngine", "Microphone", "Voice command push-to-talk")
        voice.startListening()
    }

    fun processVoiceInput(query: String? = null) {
        permissions.releaseAccess("Microphone")
        voice.stopListeningAndProcess(query)

        viewModelScope.launch {
            delay(600)
            val q = query ?: voice.voiceState.value.transcribedText
            val (target, feedback) = voice.executeCommand(q)
            _systemStatusMessage.value = feedback

            when (target) {
                "HOME" -> _activeApp.value = ActiveHudApp.HOME
                "NOTIFICATIONS" -> _activeApp.value = ActiveHudApp.NOTIFICATIONS
                "NAVIGATION" -> _activeApp.value = ActiveHudApp.NAVIGATION
                "MEDIA" -> {
                    _activeApp.value = ActiveHudApp.MEDIA
                    toggleMediaPlayback()
                }
                "SETTINGS" -> {
                    _activeApp.value = ActiveHudApp.SETTINGS
                    setPowerMode(PowerMode.ECO)
                }
            }
        }
    }

    // Navigation Actions
    fun setDestination(dest: String) {
        navigation.setDestination(dest)
        eventBus.publish(EventPriority.HIGH, EventTopic.NAVIGATION_INSTRUCTION, "Route: $dest")
        _activeApp.value = ActiveHudApp.NAVIGATION
    }

    // Media Actions
    fun toggleMediaPlayback() {
        _mediaState.value = _mediaState.value.copy(isPlaying = !_mediaState.value.isPlaying)
    }

    fun nextMediaTrack() {
        _mediaState.value = _mediaState.value.copy(
            trackTitle = "Chrono Drift (Remix)",
            artist = "Aureom Synthetics",
            positionSeconds = 0,
            durationSeconds = 195
        )
    }

    fun prevMediaTrack() {
        _mediaState.value = _mediaState.value.copy(
            trackTitle = "Solaris Resonance",
            artist = "Aureom Synthetics",
            positionSeconds = 0,
            durationSeconds = 236
        )
    }

    // Notification Actions
    fun dismissNotification(id: String) {
        _notifications.value = _notifications.value.filter { it.id != id }
        eventBus.publish(EventPriority.NORMAL, EventTopic.NOTIFICATION_DISMISSED, "ID: $id")
    }

    fun revealFirstSensitiveNotification() {
        _notifications.value = _notifications.value.map {
            if (it.isSensitive && !it.isRevealed) it.copy(isRevealed = true) else it
        }
    }

    fun addNotification(title: String, body: String, isSensitive: Boolean = false) {
        val newNotif = GlassNotification(
            id = "n_" + System.currentTimeMillis(),
            sourceApp = "Companion",
            title = title,
            bodyRaw = body,
            isSensitive = isSensitive,
            priority = NotificationPriority.STANDARD,
            actionLabel = "Open"
        )
        _notifications.value = listOf(newNotif) + _notifications.value
        eventBus.publish(EventPriority.HIGH, EventTopic.NOTIFICATION_INCOMING, title)
    }

    // Power & Resource Policy
    fun setPowerMode(mode: PowerMode) {
        _powerMode.value = mode
        _systemState.value = when (mode) {
            PowerMode.NORMAL -> SystemState.ACTIVE
            PowerMode.ECO -> SystemState.LOW_POWER
            PowerMode.THERMAL_THROTTLED -> SystemState.THERMAL_THROTTLED
        }
        eventBus.publish(EventPriority.CRITICAL, EventTopic.SYSTEM_POWER_STATE, mode.name)
    }

    fun simulateThermalEvent() {
        setPowerMode(PowerMode.THERMAL_THROTTLED)
        eventBus.publish(EventPriority.CRITICAL, EventTopic.SYSTEM_THERMAL_ALERT, "Core Temp 41.8°C -> Throttled")
        _systemStatusMessage.value = "⚠️ Thermal Limit: Throttled to 15Hz"
    }

    // Display & Profile
    fun setDisplayProfile(profile: DisplayProfile) {
        _displayProfile.value = profile
    }

    fun toggleMonocularEye() {
        _monocularEye.value = when (_monocularEye.value) {
            "RIGHT" -> "LEFT"
            "LEFT" -> "BINOCULAR"
            else -> "RIGHT"
        }
    }

    fun toggleViewMode() {
        _isCompanionPhoneView.value = !_isCompanionPhoneView.value
    }

    fun navigateTo(app: ActiveHudApp) {
        _activeApp.value = app
    }
}
