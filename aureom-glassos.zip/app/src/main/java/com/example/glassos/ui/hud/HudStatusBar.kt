package com.example.glassos.ui.hud

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.PowerMode
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Optical HUD Status Bar.
 * Unobtrusive, high-contrast, peripheral status elements.
 * Always renders battery, time, Bluetooth, and real-time privacy indicators.
 */
@Composable
fun HudStatusBar(
    batteryPct: Float,
    powerMode: PowerMode,
    isMicActive: Boolean,
    isCameraActive: Boolean,
    modifier: Modifier = Modifier
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    var currentTime by remember { mutableStateOf(timeFormat.format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(10000)
            currentTime = timeFormat.format(Date())
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("hud_status_bar"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: Time & Power Mode badge
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = currentTime,
                style = MaterialTheme.typography.labelLarge,
                color = HudTextPrimary
            )
            if (powerMode != PowerMode.NORMAL) {
                Text(
                    text = if (powerMode == PowerMode.ECO) "ECO 30Hz" else "THROTTLED",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (powerMode == PowerMode.ECO) WaveguideAmber else WarningRed
                )
            }
        }

        // Center: Privacy Indicators (Simulated Hardware LED)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isMicActive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.testTag("status_mic_active")
                ) {
                    Box(modifier = Modifier.size(7.dp).background(WaveguideEmerald, CircleShape))
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Microphone active",
                        tint = WaveguideEmerald,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            if (isCameraActive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.testTag("status_camera_active")
                ) {
                    Box(modifier = Modifier.size(7.dp).background(WaveguideAmber, CircleShape))
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Camera active",
                        tint = WaveguideAmber,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        // Right: Telemetry Badges (BLE, GPS, Battery)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Bluetooth,
                contentDescription = "Bluetooth Connected",
                tint = WaveguideCyanBright,
                modifier = Modifier.size(14.dp)
            )
            Icon(
                imageVector = Icons.Default.LocationOn,
                contentDescription = "GNSS Fix Active",
                tint = WaveguideEmerald,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = "${batteryPct.toInt()}%",
                style = MaterialTheme.typography.labelSmall,
                color = if (batteryPct > 20f) HudTextPrimary else WarningRed
            )
        }
    }
}
