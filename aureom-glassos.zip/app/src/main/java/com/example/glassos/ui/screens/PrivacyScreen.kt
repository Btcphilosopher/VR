package com.example.glassos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.PermissionAuditLog
import com.example.glassos.ui.components.WaveguideTag
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

/**
 * Optical Privacy & Security Center.
 * Enforces zero-trust sensor access, real-time microphone/camera ledgers,
 * audit log history, and emergency sensor kill switch.
 */
@Composable
fun PrivacyScreen(
    isMicActive: Boolean,
    isCameraActive: Boolean,
    isKillSwitchEngaged: Boolean,
    auditLogs: List<PermissionAuditLog>,
    onToggleKillSwitch: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_privacy"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = WaveguideEmerald,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "PRIVACY BROKER & SENSOR LEDGER",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideEmerald
                )
            }
            TextButton(onClick = onBack, modifier = Modifier.testTag("btn_privacy_close")) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        // Live Sensor State & Kill Switch
        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = if (isKillSwitchEngaged) WarningRed else WaveguideEmerald
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HARDWARE SENSOR INDICATORS",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextSecondary
                    )
                    WaveguideTag(
                        text = if (isKillSwitchEngaged) "KILL SWITCH ENGAGED" else "HARDWARE NOMINAL",
                        color = if (isKillSwitchEngaged) WarningRed else WaveguideEmerald
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Mic, contentDescription = null, tint = if (isMicActive) WaveguideEmerald else HudTextMuted, modifier = Modifier.size(16.dp))
                        Text(if (isMicActive) "Mic Active" else "Mic Idle", style = MaterialTheme.typography.labelSmall, color = if (isMicActive) WaveguideEmerald else HudTextMuted)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = if (isCameraActive) WaveguideAmber else HudTextMuted, modifier = Modifier.size(16.dp))
                        Text(if (isCameraActive) "Cam Active" else "Cam Idle", style = MaterialTheme.typography.labelSmall, color = if (isCameraActive) WaveguideAmber else HudTextMuted)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.LocationOn, contentDescription = null, tint = WaveguideCyan, modifier = Modifier.size(16.dp))
                        Text("GNSS Coarse", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                    }
                }

                Button(
                    onClick = onToggleKillSwitch,
                    modifier = Modifier.fillMaxWidth().testTag("btn_emergency_kill_switch"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isKillSwitchEngaged) WaveguideEmerald else WarningRed
                    )
                ) {
                    Icon(
                        imageVector = if (isKillSwitchEngaged) Icons.Default.Check else Icons.Default.Block,
                        contentDescription = null,
                        tint = OpticalBlack
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isKillSwitchEngaged) "Restore Sensor Access" else "Emergency Sensor Kill Switch (Cut All Mics/Cams)",
                        color = OpticalBlack,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Append-only Permission Audit Ledger
        Text(
            text = "APPEND-ONLY SENSOR ACCESS AUDIT LOG:",
            style = MaterialTheme.typography.labelSmall,
            color = HudTextMuted
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(auditLogs, key = { it.id }) { log ->
                WearableCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (log.granted) GlassSurfaceBorder else WarningRed.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = log.serviceName,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = HudTextPrimary
                                )
                                WaveguideTag(
                                    text = log.sensorType,
                                    color = if (log.granted) WaveguideCyan else WarningRed
                                )
                            }
                            Text(
                                text = "${log.rationale} • ${timeFormat.format(Date(log.timestampMs))}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = HudTextSecondary
                            )
                        }
                        Text(
                            text = if (log.granted) "ALLOWED" else "BLOCKED",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (log.granted) WaveguideEmerald else WarningRed
                        )
                    }
                }
            }
        }
    }
}
