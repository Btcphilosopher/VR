package com.example.glassos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.glassos.core.model.ActiveHudApp
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Optical Glance Home Screen.
 * Highly restrained, calm, minimal information density.
 * Shows time, primary situational context (upcoming meeting / ETA),
 * and quick glance cues without occluding the user's field of view.
 */
@Composable
fun HomeScreen(
    onOpenLauncher: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_home"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Glance Widget
        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = WaveguideCyan.copy(alpha = 0.4f)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "AUREOM GLANCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = WaveguideCyan
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = "Clear",
                            tint = WaveguideAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "21°C • Barcelona",
                            style = MaterialTheme.typography.labelSmall,
                            color = HudTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "10:42",
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = HudTextPrimary
                )
                Text(
                    text = "Friday, 7 November • All Systems Nominal",
                    style = MaterialTheme.typography.bodyMedium,
                    color = HudTextSecondary
                )
            }
        }

        // Contextual Smart Agenda Card
        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = GlassSurfaceBorder
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        tint = WaveguideEmerald,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "NEXT EVENT IN 18 MIN",
                        style = MaterialTheme.typography.labelSmall,
                        color = WaveguideEmerald
                    )
                    Text(
                        text = "Optics & AHRS System Verification",
                        style = MaterialTheme.typography.titleLarge,
                        color = HudTextPrimary
                    )
                    Text(
                        text = "Conf Room 4B • With Tom & Engineering Team",
                        style = MaterialTheme.typography.bodyMedium,
                        color = HudTextSecondary
                    )
                }
            }
        }

        // Bottom Tap Hint
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = onOpenLauncher,
                modifier = Modifier.testTag("btn_home_open_launcher")
            ) {
                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Tap Temple or Click Here for App Launcher",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
        }
    }
}
