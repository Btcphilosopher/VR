package com.example.glassos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.glassos.core.model.NavigationState
import com.example.glassos.core.model.TrackingConfidence
import com.example.glassos.ui.components.WaveguideTag
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Optical Navigation Guidance HUD.
 * Minimalist, high-contrast wayfinding display.
 * Displays step instruction, distance countdown, bearing compass, and tracking confidence.
 */
@Composable
fun NavigationScreen(
    navState: NavigationState,
    onAdvanceStep: () -> Unit,
    onStepBack: () -> Unit,
    onToggleConfidence: () -> Unit,
    onExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentStep = navState.steps.getOrNull(navState.currentStepIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_navigation"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Navigation Header & Confidence Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.Navigation,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "WAYFINDER • ${navState.destination.uppercase()}",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }

            // Tracking Confidence Pill
            val (confColor, confText) = when (navState.confidence) {
                TrackingConfidence.HIGH -> WaveguideEmerald to "GNSS LOCK"
                TrackingConfidence.DEGRADED -> WaveguideAmber to "DEGRADED"
                TrackingConfidence.LOST -> WarningRed to "TRACKING LOST"
            }
            WaveguideTag(text = confText, color = confColor, modifier = Modifier.testTag("nav_confidence_badge"))
        }

        // Main Turn Card
        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = WaveguideCyan,
            cornerRadius = 16.dp
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .background(WaveguideCyan.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        val turnIcon = when (currentStep?.turnIcon) {
                            "turn_right" -> Icons.Default.TurnRight
                            "keep_left" -> Icons.Default.TurnLeft
                            "arrival" -> Icons.Default.Place
                            else -> Icons.Default.ArrowUpward
                        }
                        Icon(
                            imageVector = turnIcon,
                            contentDescription = currentStep?.instruction ?: "Direction",
                            tint = WaveguideCyan,
                            modifier = Modifier.size(34.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "IN ${currentStep?.distanceMeters ?: 300} METERS",
                            style = MaterialTheme.typography.labelSmall,
                            color = WaveguideAmber
                        )
                        Text(
                            text = currentStep?.instruction ?: "Proceed along route",
                            style = MaterialTheme.typography.headlineMedium.copy(fontSize = 19.sp, fontWeight = FontWeight.Bold),
                            color = HudTextPrimary
                        )
                        Text(
                            text = currentStep?.streetName ?: "Wayfinding active",
                            style = MaterialTheme.typography.bodyMedium,
                            color = HudTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = {
                        val total = navState.totalDistanceMeters.toFloat()
                        val remaining = navState.remainingDistanceMeters.toFloat()
                        (1f - (remaining / total)).coerceIn(0f, 1f)
                    },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = WaveguideCyan,
                    trackColor = GlassSurfaceBorder
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Remaining: ${navState.remainingDistanceMeters}m",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextSecondary
                    )
                    Text(
                        text = "ETA: ${navState.etaMinutes} min",
                        style = MaterialTheme.typography.labelSmall,
                        color = WaveguideEmerald
                    )
                    Text(
                        text = "Bearing: ${navState.currentBearing.toInt()}°",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextPrimary
                    )
                }
            }
        }

        // Navigation Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(
                onClick = onStepBack,
                modifier = Modifier.weight(1f).testTag("btn_nav_prev"),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceDark)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Prev Step", modifier = Modifier.size(14.dp), tint = HudTextPrimary)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Prev", style = MaterialTheme.typography.labelSmall, color = HudTextPrimary)
            }
            FilledTonalButton(
                onClick = onAdvanceStep,
                modifier = Modifier.weight(1f).testTag("btn_nav_next"),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = WaveguideCyan.copy(alpha = 0.25f))
            ) {
                Text("Next Step", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Next Step", modifier = Modifier.size(14.dp), tint = WaveguideCyan)
            }
            FilledTonalButton(
                onClick = onToggleConfidence,
                modifier = Modifier.weight(1f).testTag("btn_nav_toggle_conf"),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceDark)
            ) {
                Text("GPS Sim", style = MaterialTheme.typography.labelSmall, color = WaveguideAmber)
            }
            FilledTonalButton(
                onClick = onExit,
                modifier = Modifier.testTag("btn_nav_exit"),
                colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceDark)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Exit Navigation", modifier = Modifier.size(14.dp), tint = WarningRed)
            }
        }
    }
}
