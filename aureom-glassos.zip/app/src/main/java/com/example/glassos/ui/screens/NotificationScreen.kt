package com.example.glassos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.GlassNotification
import com.example.glassos.core.model.NotificationPriority
import com.example.glassos.ui.components.WaveguideTag
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Optical Notification Center.
 * Implements OS-grade notification routing, priority tags,
 * sensitive content masking (e.g. 2FA codes), and quick actions.
 */
@Composable
fun NotificationScreen(
    notifications: List<GlassNotification>,
    onDismiss: (String) -> Unit,
    onRevealSensitive: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_notifications"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "NOTIFICATIONS (${notifications.size})",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
            TextButton(
                onClick = onBack,
                modifier = Modifier.testTag("btn_notif_back")
            ) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        if (notifications.isEmpty()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text(
                    text = "No pending notifications.\nAll clear.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = HudTextSecondary
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(notifications, key = { it.id }) { notif ->
                    val borderColor = when (notif.priority) {
                        NotificationPriority.URGENT -> WaveguideAmber
                        NotificationPriority.STANDARD -> WaveguideCyan.copy(alpha = 0.5f)
                        NotificationPriority.LOW -> GlassSurfaceBorder
                    }

                    WearableCard(
                        modifier = Modifier.fillMaxWidth().testTag("notif_card_${notif.id}"),
                        borderColor = borderColor
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = notif.sourceApp.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (notif.priority == NotificationPriority.URGENT) WaveguideAmber else WaveguideCyan
                                    )
                                    if (notif.isSensitive) {
                                        WaveguideTag(text = "SENSITIVE", color = WaveguideAmber)
                                    }
                                }

                                IconButton(
                                    onClick = { onDismiss(notif.id) },
                                    modifier = Modifier.size(24.dp).testTag("btn_dismiss_${notif.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Dismiss",
                                        tint = HudTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = notif.title,
                                style = MaterialTheme.typography.titleLarge,
                                color = HudTextPrimary
                            )

                            Spacer(modifier = Modifier.height(2.dp))

                            val displayText = if (notif.isSensitive && !notif.isRevealed) {
                                notif.bodyMasked
                            } else {
                                notif.bodyRaw
                            }

                            Text(
                                text = displayText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (notif.isSensitive && !notif.isRevealed) WaveguideAmber else HudTextSecondary
                            )

                            if (notif.isSensitive && !notif.isRevealed) {
                                Spacer(modifier = Modifier.height(8.dp))
                                TextButton(
                                    onClick = onRevealSensitive,
                                    modifier = Modifier.testTag("btn_reveal_${notif.id}")
                                ) {
                                    Icon(Icons.Default.Visibility, contentDescription = null, tint = WaveguideCyan, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Tap Temple to Reveal Sensitive Content", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Tap hint
        Text(
            text = "Tap = Reveal / Select • Double-Tap = Home",
            style = MaterialTheme.typography.labelSmall,
            color = HudTextMuted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}
