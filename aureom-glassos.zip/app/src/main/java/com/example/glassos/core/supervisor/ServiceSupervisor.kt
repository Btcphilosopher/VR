package com.example.glassos.core.supervisor

import com.example.glassos.core.model.ServiceStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Service Supervisor providing OS-grade monitoring, health checks,
 * restart throttling, and crash containment for GlassOS sub-services.
 */
class ServiceSupervisor {
    private val _services = MutableStateFlow<List<ServiceStatus>>(
        listOf(
            ServiceStatus("nav", "Navigation Engine", isHealthy = true),
            ServiceStatus("voice", "Voice Command Engine", isHealthy = true),
            ServiceStatus("sensors", "9-DoF Sensor AHRS", isHealthy = true),
            ServiceStatus("companion", "Companion BLE Link", isHealthy = true),
            ServiceStatus("hud", "HUD Optical Compositor", isHealthy = true),
            ServiceStatus("telemetry", "Telemetry & Diagnostics", isHealthy = true)
        )
    )
    val services: StateFlow<List<ServiceStatus>> = _services.asStateFlow()

    fun reportHeartbeat(serviceId: String) {
        _services.value = _services.value.map { service ->
            if (service.id == serviceId) {
                service.copy(
                    isHealthy = true,
                    lastHeartbeatMs = System.currentTimeMillis()
                )
            } else service
        }
    }

    fun reportFailure(serviceId: String): Boolean {
        var canRecover = true
        _services.value = _services.value.map { service ->
            if (service.id == serviceId) {
                val newRestarts = service.restartCount + 1
                if (newRestarts > 4) {
                    canRecover = false
                    service.copy(isHealthy = false, restartCount = newRestarts)
                } else {
                    service.copy(isHealthy = true, restartCount = newRestarts)
                }
            } else service
        }
        return canRecover
    }

    fun simulateInjectFailure(serviceId: String) {
        reportFailure(serviceId)
    }

    fun resetService(serviceId: String) {
        _services.value = _services.value.map { service ->
            if (service.id == serviceId) {
                service.copy(isHealthy = true, restartCount = 0, lastHeartbeatMs = System.currentTimeMillis())
            } else service
        }
    }
}
