package com.example.glassos.core.companion

import com.example.glassos.core.model.CompanionLinkStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Companion Link Bridge.
 * Emulates authenticated BLE L2CAP / TCP transport between smartglasses
 * and the companion smartphone application.
 */
class CompanionBridge {
    private val _linkStatus = MutableStateFlow(CompanionLinkStatus.CONNECTED)
    val linkStatus: StateFlow<CompanionLinkStatus> = _linkStatus.asStateFlow()

    private val _deviceName = MutableStateFlow("Pixel 9 Pro — Aureom Companion")
    val deviceName: StateFlow<String> = _deviceName.asStateFlow()

    private val _authPin = MutableStateFlow("742 918")
    val authPin: StateFlow<String> = _authPin.asStateFlow()

    private val _sessionToken = MutableStateFlow("0xA1B2C3D4")
    val sessionToken: StateFlow<String> = _sessionToken.asStateFlow()

    private val _bleRssi = MutableStateFlow(-54)
    val bleRssi: StateFlow<Int> = _bleRssi.asStateFlow()

    fun initiatePairing() {
        _linkStatus.value = CompanionLinkStatus.PAIRING
        val pin1 = (100..999).random()
        val pin2 = (100..999).random()
        _authPin.value = "$pin1 $pin2"
    }

    fun confirmPairing() {
        _linkStatus.value = CompanionLinkStatus.CONNECTED
        _sessionToken.value = "0x" + LongArray(1) { (System.currentTimeMillis() and 0xFFFFFFFF) }[0].toString(16).uppercase()
    }

    fun disconnect() {
        _linkStatus.value = CompanionLinkStatus.DISCONNECTED
    }

    fun reconnect() {
        _linkStatus.value = CompanionLinkStatus.CONNECTED
    }
}
