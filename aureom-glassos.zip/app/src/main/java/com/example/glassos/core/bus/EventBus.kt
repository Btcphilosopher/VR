package com.example.glassos.core.bus

import com.example.glassos.core.model.EventPriority
import com.example.glassos.core.model.GlassEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicLong

/**
 * OS-Grade Bounded Typed Event Bus with Priority Drop Policies and Backpressure metrics.
 */
class EventBus(val capacity: Int = 128) {
    private val queue = ConcurrentLinkedDeque<GlassEvent>()
    private val idCounter = AtomicLong(1L)

    private val _depthFlow = MutableStateFlow(0)
    val depthFlow: StateFlow<Int> = _depthFlow.asStateFlow()

    private val _droppedEventsCount = MutableStateFlow(0L)
    val droppedEventsCount: StateFlow<Long> = _droppedEventsCount.asStateFlow()

    private val _totalPublished = MutableStateFlow(0L)
    val totalPublished: StateFlow<Long> = _totalPublished.asStateFlow()

    fun publish(priority: EventPriority, topic: com.example.glassos.core.model.EventTopic, payload: String): Boolean {
        _totalPublished.value += 1
        val event = GlassEvent(
            id = idCounter.getAndIncrement(),
            priority = priority,
            topic = topic,
            payload = payload
        )

        synchronized(queue) {
            if (queue.size >= capacity) {
                if (priority == EventPriority.CRITICAL || priority == EventPriority.HIGH) {
                    // Evict oldest LOW or NORMAL priority event
                    val evicted = queue.firstOrNull { it.priority <= EventPriority.NORMAL }
                    if (evicted != null) {
                        queue.remove(evicted)
                        _droppedEventsCount.value += 1
                    } else {
                        queue.pollFirst()
                        _droppedEventsCount.value += 1
                    }
                } else {
                    // Reject lower priority event
                    _droppedEventsCount.value += 1
                    return false
                }
            }
            queue.addLast(event)
            _depthFlow.value = queue.size
        }
        return true
    }

    fun poll(): GlassEvent? {
        synchronized(queue) {
            val event = queue.pollFirst()
            _depthFlow.value = queue.size
            return event
        }
    }

    val currentQueueDepth: Int
        get() = queue.size
}
