package com.example.glassos.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.ServiceStatus
import com.example.glassos.ui.components.WaveguideTag
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Diagnostics & OS Telemetry Screen.
 * Displays empirical frame latency percentiles (p50, p95, p99),
 * queue depth, dropped event counters, service health status,
 * and a one-click CSV export engine for offline R analytics.
 */
@Composable
fun DiagnosticsScreen(
    p50Ms: Float,
    p95Ms: Float,
    p99Ms: Float,
    queueDepth: Int,
    droppedCount: Long,
    batteryTempC: Float,
    services: List<ServiceStatus>,
    onExportCsv: () -> String,
    onInjectCrash: (String) -> Unit,
    onResetService: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedCsvContent by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_diagnostics"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.QueryStats,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "OS DIAGNOSTICS & TELEMETRY",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
            TextButton(onClick = onBack, modifier = Modifier.testTag("btn_diag_close")) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Latency Percentiles Card
            item {
                WearableCard(modifier = Modifier.fillMaxWidth(), borderColor = WaveguideCyan) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("FRAME-TIME PERCENTILES", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                            Text("Queue Depth: $queueDepth / 128", style = MaterialTheme.typography.labelSmall, color = if (queueDepth > 10) WaveguideAmber else WaveguideEmerald)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("p50 (Median)", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
                                Text("${String.format("%.1f", p50Ms)} ms", style = MaterialTheme.typography.titleLarge, color = WaveguideEmerald)
                            }
                            Column {
                                Text("p95 Percentile", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
                                Text("${String.format("%.1f", p95Ms)} ms", style = MaterialTheme.typography.titleLarge, color = WaveguideCyan)
                            }
                            Column {
                                Text("p99 Tail Latency", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
                                Text("${String.format("%.1f", p99Ms)} ms", style = MaterialTheme.typography.titleLarge, color = if (p99Ms > 30f) WaveguideAmber else WaveguideCyan)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Dropped Events: $droppedCount", style = MaterialTheme.typography.labelSmall, color = if (droppedCount > 0) WarningRed else WaveguideEmerald)
                            Text("Thermal Core: ${String.format("%.1f", batteryTempC)}°C", style = MaterialTheme.typography.labelSmall, color = if (batteryTempC > 36f) WarningRed else HudTextPrimary)
                        }
                    }
                }
            }

            // Export to R Analytics Button
            item {
                Button(
                    onClick = {
                        val csv = onExportCsv()
                        exportedCsvContent = csv
                        showExportDialog = true
                    },
                    modifier = Modifier.fillMaxWidth().testTag("btn_export_telemetry_csv"),
                    colors = ButtonDefaults.buttonColors(containerColor = WaveguideCyan),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = OpticalBlack)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Export Telemetry Dataset for R Analytics (CSV)",
                        color = OpticalBlack,
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }

            // Subsystem Supervisor Health
            item {
                Text(
                    text = "SERVICE SUPERVISOR DAEMONS & CRASH ISOLATION:",
                    style = MaterialTheme.typography.labelSmall,
                    color = HudTextMuted
                )
            }

            items(services) { service ->
                WearableCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (service.isHealthy) GlassSurfaceBorder else WarningRed
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(service.name, style = MaterialTheme.typography.titleLarge, color = HudTextPrimary)
                                WaveguideTag(
                                    text = if (service.isHealthy) "HEALTHY" else "FAULTED",
                                    color = if (service.isHealthy) WaveguideEmerald else WarningRed
                                )
                            }
                            Text(
                                text = "Restarts: ${service.restartCount}/4 • Heartbeat: OK",
                                style = MaterialTheme.typography.bodyMedium,
                                color = HudTextSecondary
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (service.isHealthy) {
                                FilledTonalButton(
                                    onClick = { onInjectCrash(service.id) },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = WarningRed.copy(alpha = 0.2f)),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Crash Test", style = MaterialTheme.typography.labelSmall, color = WarningRed)
                                }
                            } else {
                                FilledTonalButton(
                                    onClick = { onResetService(service.id) },
                                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = WaveguideEmerald.copy(alpha = 0.2f)),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("Recover", style = MaterialTheme.typography.labelSmall, color = WaveguideEmerald)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("Aureom Telemetry CSV Export", color = WaveguideCyan) },
            text = {
                Column {
                    Text(
                        text = "Conforms to schema in /analytics-r/sample_telemetry.csv. Ready for R analysis scripts.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = HudTextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = exportedCsvContent.lines().take(6).joinToString("\n") + "\n...",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("GlassOS Telemetry", exportedCsvContent))
                        Toast.makeText(context, "Telemetry CSV copied to clipboard!", Toast.LENGTH_SHORT).show()
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WaveguideCyan)
                ) {
                    Text("Copy CSV", color = OpticalBlack)
                }
            },
            dismissButton = {
                TextButton(onClick = { showExportDialog = false }) {
                    Text("Close", color = HudTextSecondary)
                }
            },
            containerColor = GlassSurfaceDark
        )
    }
}
