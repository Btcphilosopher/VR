package com.example.glassos.ui.hud

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.*
import com.example.glassos.ui.components.TempleTouchpad
import com.example.glassos.ui.screens.*
import com.example.glassos.ui.viewmodel.GlassOSViewModel
import com.example.ui.theme.*

/**
 * Optical Heads-Up Display (HUD) Viewport Simulator.
 * Simulates real-world see-through optical combiner optics:
 * - Dark-field black transparency (0,0,0 = transparent see-through world)
 * - Safe field-of-view bounding box with optical reticle corners
 * - Top hardware status bar (battery, privacy LEDs, clock)
 * - Active screen content
 * - Interactive Temple Touchpad dock.
 */
@Composable
fun HudViewport(
    viewModel: GlassOSViewModel,
    activeApp: ActiveHudApp,
    displayProfile: DisplayProfile,
    powerMode: PowerMode,
    batteryPct: Float,
    isMicActive: Boolean,
    isCameraActive: Boolean,
    lastGesture: TempleGesture?,
    monocularEye: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OpticalBlack)
            .padding(8.dp)
            .testTag("hud_viewport_root")
    ) {
        // Quick Simulator Toolbar (Phone Mode toggle, Display Profile, Eye Alignment)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(displayProfile.primaryColor, androidx.compose.foundation.shape.CircleShape)
                )
                Text(
                    text = "${displayProfile.name} • ${displayProfile.fovHorizontalDeg.toInt()}° FOV ($monocularEye)",
                    style = MaterialTheme.typography.labelSmall,
                    color = displayProfile.primaryColor
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // Rocker Volume / Brightness buttons simulation
                IconButton(
                    onClick = { viewModel.handlePhysicalRockerUp() },
                    modifier = Modifier.size(32.dp).testTag("btn_rocker_up")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Brightness Up", tint = HudTextSecondary, modifier = Modifier.size(16.dp))
                }
                IconButton(
                    onClick = { viewModel.handlePhysicalRockerDown() },
                    modifier = Modifier.size(32.dp).testTag("btn_rocker_down")
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Brightness Down", tint = HudTextSecondary, modifier = Modifier.size(16.dp))
                }

                // Switch to Companion Phone Mode
                FilledTonalButton(
                    onClick = { viewModel.toggleViewMode() },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = GlassSurfaceElevated),
                    modifier = Modifier.testTag("btn_switch_to_companion")
                ) {
                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = WaveguideCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Companion", style = MaterialTheme.typography.labelSmall, color = WaveguideCyan)
                }
            }
        }

        // Optical Combiner Frame with Safe Region Bounds
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF040810))
                .border(BorderStroke(1.dp, displayProfile.primaryColor.copy(alpha = 0.35f)), RoundedCornerShape(16.dp))
                .padding(4.dp)
                .testTag("optical_safe_box")
        ) {
            // Optical Reticle Corner Markers (simulating waveguide glass)
            Box(modifier = Modifier.align(Alignment.TopStart).padding(6.dp)) {
                Text("⌜", color = displayProfile.primaryColor.copy(alpha = 0.4f), style = MaterialTheme.typography.titleLarge)
            }
            Box(modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                Text("⌝", color = displayProfile.primaryColor.copy(alpha = 0.4f), style = MaterialTheme.typography.titleLarge)
            }
            Box(modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)) {
                Text("⌞", color = displayProfile.primaryColor.copy(alpha = 0.4f), style = MaterialTheme.typography.titleLarge)
            }
            Box(modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp)) {
                Text("⌟", color = displayProfile.primaryColor.copy(alpha = 0.4f), style = MaterialTheme.typography.titleLarge)
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // Top Wearable Status Bar
                HudStatusBar(
                    batteryPct = batteryPct,
                    powerMode = powerMode,
                    isMicActive = isMicActive,
                    isCameraActive = isCameraActive
                )

                // Active App Screen Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    AnimatedContent(
                        targetState = activeApp,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "hud_app_transition"
                    ) { app ->
                        when (app) {
                            ActiveHudApp.HOME -> HomeScreen(
                                onOpenLauncher = { viewModel.navigateTo(ActiveHudApp.LAUNCHER) }
                            )
                            ActiveHudApp.LAUNCHER -> LauncherScreen(
                                selectedIndex = viewModel.launcherIndex.value,
                                onSelectIndex = { /* managed */ },
                                onLaunchApp = { target -> viewModel.navigateTo(target) }
                            )
                            ActiveHudApp.NAVIGATION -> NavigationScreen(
                                navState = viewModel.navigation.navState.value,
                                onAdvanceStep = { viewModel.navigation.advanceStep() },
                                onStepBack = { viewModel.navigation.stepBack() },
                                onToggleConfidence = { viewModel.navigation.toggleTrackingConfidence() },
                                onExit = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.NOTIFICATIONS -> NotificationScreen(
                                notifications = viewModel.notifications.value,
                                onDismiss = { id -> viewModel.dismissNotification(id) },
                                onRevealSensitive = { viewModel.revealFirstSensitiveNotification() },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.VOICE -> VoiceScreen(
                                voiceState = viewModel.voice.voiceState.value,
                                onStartListening = { viewModel.startVoiceListening() },
                                onStopListening = { query -> viewModel.processVoiceInput(query) },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.MEDIA -> MediaScreen(
                                mediaState = viewModel.mediaState.value,
                                onTogglePlay = { viewModel.toggleMediaPlayback() },
                                onNext = { viewModel.nextMediaTrack() },
                                onPrev = { viewModel.prevMediaTrack() },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.SETTINGS -> SettingsScreen(
                                currentProfile = displayProfile,
                                brightness = viewModel.brightness.value,
                                powerMode = powerMode,
                                monocularEye = monocularEye,
                                onSelectProfile = { p -> viewModel.setDisplayProfile(p) },
                                onSetPowerMode = { m -> viewModel.setPowerMode(m) },
                                onToggleEye = { viewModel.toggleMonocularEye() },
                                onSimulateThermal = { viewModel.simulateThermalEvent() },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.PRIVACY -> PrivacyScreen(
                                isMicActive = isMicActive,
                                isCameraActive = isCameraActive,
                                isKillSwitchEngaged = viewModel.permissions.isKillSwitchEngaged.value,
                                auditLogs = viewModel.permissions.auditLogs.value,
                                onToggleKillSwitch = { viewModel.permissions.toggleEmergencyKillSwitch() },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                            ActiveHudApp.DIAGNOSTICS -> DiagnosticsScreen(
                                p50Ms = viewModel.telemetry.p50FrameMs.value,
                                p95Ms = viewModel.telemetry.p95FrameMs.value,
                                p99Ms = viewModel.telemetry.p99FrameMs.value,
                                queueDepth = viewModel.eventBus.currentQueueDepth,
                                droppedCount = viewModel.eventBus.droppedEventsCount.value,
                                batteryTempC = viewModel.telemetry.batteryTempC.value,
                                services = viewModel.supervisor.services.value,
                                onExportCsv = { viewModel.telemetry.exportCsv() },
                                onInjectCrash = { id -> viewModel.supervisor.simulateInjectFailure(id) },
                                onResetService = { id -> viewModel.supervisor.resetService(id) },
                                onBack = { viewModel.navigateTo(ActiveHudApp.HOME) }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Interactive Temple Touchpad & Rocker Dock
        TempleTouchpad(
            lastGesture = lastGesture,
            onGesture = { gesture -> viewModel.handleTempleGesture(gesture) }
        )
    }
}
