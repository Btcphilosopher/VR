package com.example.glassos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.glassos.core.model.MediaState
import com.example.glassos.ui.components.WearableCard
import com.example.ui.theme.*

/**
 * Wearable Media HUD Screen.
 * Calm playback controller with scrub bar, now-playing card,
 * and temple-friendly transport buttons.
 */
@Composable
fun MediaScreen(
    mediaState: MediaState,
    onTogglePlay: () -> Unit,
    onNext: () -> Unit,
    onPrev: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("screen_media"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "NOW PLAYING • WEARABLE AUDIO",
                    style = MaterialTheme.typography.labelSmall,
                    color = WaveguideCyan
                )
            }
            TextButton(onClick = onBack, modifier = Modifier.testTag("btn_media_close")) {
                Text("Close", style = MaterialTheme.typography.labelSmall, color = HudTextSecondary)
            }
        }

        WearableCard(
            modifier = Modifier.fillMaxWidth(),
            borderColor = WaveguideCyan,
            cornerRadius = 16.dp
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Album,
                    contentDescription = null,
                    tint = WaveguideCyan,
                    modifier = Modifier.size(54.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = mediaState.trackTitle,
                    style = MaterialTheme.typography.displayMedium,
                    color = HudTextPrimary
                )
                Text(
                    text = mediaState.artist,
                    style = MaterialTheme.typography.bodyLarge,
                    color = HudTextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                LinearProgressIndicator(
                    progress = { (mediaState.positionSeconds.toFloat() / mediaState.durationSeconds).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = WaveguideCyan,
                    trackColor = GlassSurfaceBorder
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val posMin = mediaState.positionSeconds / 60
                    val posSec = mediaState.positionSeconds % 60
                    val durMin = mediaState.durationSeconds / 60
                    val durSec = mediaState.durationSeconds % 60
                    Text(
                        text = String.format("%d:%02d", posMin, posSec),
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextSecondary
                    )
                    Text(
                        text = String.format("%d:%02d", durMin, durSec),
                        style = MaterialTheme.typography.labelSmall,
                        color = HudTextSecondary
                    )
                }
            }
        }

        // Playback Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPrev,
                modifier = Modifier.size(48.dp).testTag("btn_media_prev")
            ) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Prev", tint = HudTextPrimary, modifier = Modifier.size(32.dp))
            }

            Spacer(modifier = Modifier.width(16.dp))

            FilledIconButton(
                onClick = onTogglePlay,
                modifier = Modifier.size(56.dp).testTag("btn_media_play_pause"),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = WaveguideCyan)
            ) {
                Icon(
                    imageVector = if (mediaState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (mediaState.isPlaying) "Pause" else "Play",
                    tint = OpticalBlack,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            IconButton(
                onClick = onNext,
                modifier = Modifier.size(48.dp).testTag("btn_media_next")
            ) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = HudTextPrimary, modifier = Modifier.size(32.dp))
            }
        }
    }
}
