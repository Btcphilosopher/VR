package com.example.glassos.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.GlassSurfaceBorder
import com.example.ui.theme.GlassSurfaceDark
import com.example.ui.theme.WaveguideCyan

/**
 * Optical Waveguide Card component.
 * Features dark-field transparent background with crisp, luminous border
 * suited for optical see-through displays without glare or wash-out.
 */
@Composable
fun WearableCard(
    modifier: Modifier = Modifier,
    borderColor: Color = GlassSurfaceBorder,
    glowColor: Color? = null,
    cornerRadius: Dp = 12.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    val effectiveBorder = glowColor ?: borderColor

    Box(
        modifier = modifier
            .clip(shape)
            .background(GlassSurfaceDark.copy(alpha = 0.82f))
            .border(BorderStroke(1.dp, effectiveBorder), shape)
            .padding(12.dp),
        content = content
    )
}

@Composable
fun WaveguideTag(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = WaveguideCyan
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(BorderStroke(1.dp, color.copy(alpha = 0.4f)), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall
        )
    }
}
