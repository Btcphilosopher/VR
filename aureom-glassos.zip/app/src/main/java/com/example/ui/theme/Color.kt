package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom GlassOS — Optical Waveguide Color Palette
// Optical principles: True black (#000000) corresponds to 100% real-world transparency
// Luminous high-contrast emissions for daylight and indoor visibility

val VoidBlack = Color(0xFF030712)
val OpticalBlack = Color(0xFF000000)
val GlassSurfaceDark = Color(0xFF0B1220)
val GlassSurfaceBorder = Color(0xFF1E293B)
val GlassSurfaceElevated = Color(0xFF131D31)

// Waveguide Luminous Primaries
val WaveguideCyan = Color(0xFF00F2FE)
val WaveguideCyanBright = Color(0xFF38BDF8)
val WaveguideEmerald = Color(0xFF10B981)
val WaveguideAmber = Color(0xFFFBBF24)
val WarningRed = Color(0xFFEF4444)

// HUD Status & Optics
val HudStatusOnline = Color(0xFF22C55E)
val HudStatusDegraded = Color(0xFFF59E0B)
val HudStatusAlert = Color(0xFFEF4444)
val HudTextPrimary = Color(0xFFFFFFFF)
val HudTextSecondary = Color(0xFF94A3B8)
val HudTextMuted = Color(0xFF64748B)

// Companion Phone Mode Theme
val CompanionBackground = Color(0xFF080D1A)
val CompanionSurface = Color(0xFF0F172A)
val CompanionCard = Color(0xFF1E293B)
val CompanionAccent = Color(0xFF0284C7)
