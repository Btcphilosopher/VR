package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GlassOSColorScheme = darkColorScheme(
    primary = WaveguideCyan,
    onPrimary = OpticalBlack,
    primaryContainer = GlassSurfaceElevated,
    onPrimaryContainer = WaveguideCyanBright,
    secondary = WaveguideEmerald,
    onSecondary = OpticalBlack,
    secondaryContainer = GlassSurfaceDark,
    onSecondaryContainer = WaveguideEmerald,
    tertiary = WaveguideAmber,
    onTertiary = OpticalBlack,
    background = OpticalBlack,
    onBackground = HudTextPrimary,
    surface = GlassSurfaceDark,
    onSurface = HudTextPrimary,
    surfaceVariant = GlassSurfaceElevated,
    onSurfaceVariant = HudTextSecondary,
    outline = GlassSurfaceBorder,
    error = WarningRed,
    onError = Color.White
)

@Composable
fun AureomGlassOSTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GlassOSColorScheme,
        typography = Typography,
        content = content
    )
}
