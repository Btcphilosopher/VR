package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.glassos.core.broker.PermissionBroker
import com.example.glassos.core.bus.EventBus
import com.example.glassos.core.engine.NavigationEngine
import com.example.glassos.core.engine.VoiceEngine
import com.example.glassos.core.model.EventPriority
import com.example.glassos.core.model.EventTopic
import com.example.glassos.core.supervisor.ServiceSupervisor
import com.example.glassos.core.telemetry.TelemetryEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context matches Aureom GlassOS`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureom GlassOS", appName)
    }

    @Test
    fun `event bus enforces queue capacity and priority eviction`() {
        val bus = EventBus(capacity = 3)
        assertTrue(bus.publish(EventPriority.NORMAL, EventTopic.INPUT_TEMPLE_GESTURE, "tap1"))
        assertTrue(bus.publish(EventPriority.NORMAL, EventTopic.INPUT_TEMPLE_GESTURE, "tap2"))
        assertTrue(bus.publish(EventPriority.NORMAL, EventTopic.INPUT_TEMPLE_GESTURE, "tap3"))
        assertEquals(3, bus.currentQueueDepth)

        // Low priority rejected when full
        assertFalse(bus.publish(EventPriority.LOW, EventTopic.INPUT_TEMPLE_GESTURE, "reject"))

        // Critical priority evicts oldest normal event
        assertTrue(bus.publish(EventPriority.CRITICAL, EventTopic.SYSTEM_POWER_STATE, "critical"))
        assertEquals(3, bus.currentQueueDepth)
        assertTrue(bus.droppedEventsCount.value >= 2)
    }

    @Test
    fun `service supervisor tracks restarts and containment`() {
        val supervisor = ServiceSupervisor()
        val initialHealth = supervisor.services.value.first { it.id == "nav" }.isHealthy
        assertTrue(initialHealth)

        // Simulate failures
        repeat(3) { supervisor.simulateInjectFailure("nav") }
        val recovering = supervisor.services.value.first { it.id == "nav" }.isHealthy
        assertTrue(recovering) // Under max restarts, it recovers

        repeat(3) { supervisor.simulateInjectFailure("nav") }
        val failed = supervisor.services.value.first { it.id == "nav" }.isHealthy
        assertFalse(failed) // Exceeded max restarts -> quarantined/faulted
    }

    @Test
    fun `permission broker enforces emergency kill switch`() {
        val broker = PermissionBroker()
        assertTrue(broker.requestAccess("TestService", "Microphone", "Voice test"))
        assertTrue(broker.isMicActive.value)

        broker.toggleEmergencyKillSwitch()
        assertTrue(broker.isKillSwitchEngaged.value)
        assertFalse(broker.isMicActive.value)

        // Access denied while kill switch engaged
        assertFalse(broker.requestAccess("TestService", "Microphone", "Another test"))
    }

    @Test
    fun `navigation engine advances step and counts distance`() {
        val nav = NavigationEngine()
        val initialIdx = nav.navState.value.currentStepIndex
        assertEquals(0, initialIdx)

        nav.advanceStep()
        assertEquals(1, nav.navState.value.currentStepIndex)
        assertTrue(nav.navState.value.remainingDistanceMeters < nav.navState.value.totalDistanceMeters)
    }

    @Test
    fun `voice engine recognizes deterministic wearable grammar`() {
        val voice = VoiceEngine()
        val (target1, _) = voice.executeCommand("Show notifications")
        assertEquals("NOTIFICATIONS", target1)

        val (target2, _) = voice.executeCommand("What is my next appointment?")
        assertEquals("HOME", target2)

        val (target3, _) = voice.executeCommand("Start navigation")
        assertEquals("NAVIGATION", target3)
    }

    @Test
    fun `telemetry engine calculates valid percentiles and exports csv`() {
        val telem = TelemetryEngine()
        assertTrue(telem.p50FrameMs.value > 0f)
        assertTrue(telem.p95FrameMs.value >= telem.p50FrameMs.value)
        assertTrue(telem.p99FrameMs.value >= telem.p95FrameMs.value)

        val csv = telem.exportCsv()
        assertTrue(csv.startsWith("timestamp_ms,system_mode"))
        assertTrue(csv.contains("ACTIVE") || csv.contains("LOW_POWER"))
    }
}
